# Cryo-Obsidian Sanctuary

A 3,000-ant, five-pheromone colony sandbox whose trained ants all share **one** evolved recurrent brain, with a
headless proof-of-learning suite that runs both from the CLI and inside the app.

Next.js App Router, strict TypeScript (no `any`), Tailwind CSS, Canvas 2D. No emoji anywhere: every icon, chart
and diagram is bespoke SVG or Canvas.

## Run it

```bash
npm run dev                       # the sandbox
npx vitest run                    # 42 tests: grid physics, mixer, brain, engine, presets, benchmark, health
npx tsx scripts/train.ts --help   # see the header of scripts/train.ts for every flag
```

Training and benchmarking:

```bash
npx tsx scripts/train.ts --gens 60 --pop 24 --seed 1          # evolve from random weights, benchmark, bake
npx tsx scripts/train.ts --warm --gens 30 --seed 11           # refine the baked champion
npx tsx scripts/train.ts --out a.json --no-bake --budget 500  # checkpoint only, stop after 500 s
npx tsx scripts/train.ts --from a.json,b.json                 # pick the best island on 12 validation seeds, bake
npx tsx scripts/train.ts --bench-only                         # re-run the held-out benchmark on what is baked
```

`--bake` rewrites the `BAKED_CHAMPION` block in `lib/neat.ts` (weights, learning curve and benchmark), so the app
boots with the trained brain and its evidence.

## What was measured

Everything below is reproduced by `npx tsx scripts/train.ts --bench-only` and asserted in `tests/simulation.test.ts`.

**Setup.** 72 ants, 1,200 ticks (20 simulated seconds), 480 x 480 world. Seeds pick the scenario: two thirds are
Open Sanctuary layouts with random caches and rocks, one third are Double Bridge layouts. Benchmark seeds
`9001..9005` were never used for fitness, curve scoring or island selection.

| Condition (5 held-out seeds) | Food delivered, mean | std | Per seed |
| --- | ---: | ---: | --- |
| Full Trained Brain | **159.6** | 144.4 | 4, 277, 245, 0, 272 |
| Hand-Crafted ACO | 115.2 | 86.8 | 23, 146, 197, 22, 188 |
| Random Brain | 7.2 | 16.1 | 0, 0, 0, 0, 36 |
| -foodTrail | 136.0 | 127.3 | delta -23.6 |
| -homeGuide | 90.8 | 67.4 | delta -68.8 |
| -alarm | 126.0 | 110.2 | delta -33.6 |
| -scoutPulse | 42.2 | 38.7 | delta -117.4 |
| -noEntry | 147.6 | 121.1 | delta -12.0 |
| -PathIntegration | 24.0 | 29.1 | delta -135.6 |

`Trained > ACO > Random` holds on the held-out mean, and every single-input ablation lowers food.

**Read this before quoting the table.**

- The trained brain wins on the three open seeds and **loses on both Double Bridge seeds** (4 and 0 food against
  ACO's 23 and 22). It has not learned to route around the barrier inside a 20 second episode.
- Five seeds with a standard deviation as large as the mean is a small sample. The ordering is real on these
  seeds; it is not a significance claim. The small ablation deltas (-noEntry, -foodTrail, -alarm) are within
  seed-to-seed noise; -PathIntegration, -scoutPulse and -homeGuide are large.
- The brain leans on scoutPulse far more than I expected. It uses that channel as its own signal; I did not
  design that in, and I have not analysed why.
- Episodes are chaotic: rounding the weights to 4 decimals moved one checkpoint's 3-seed curve score from 131 to
  167. That is why the curve has a step at generation 67, and why island selection uses 12 validation seeds.
- ACO has no path integration by design (it is pure stigmergy), so the comparison is "evolved brain with a home
  vector" against "classic two-pheromone trail following", not equal-information policies.

**Learning curve** (best genome per generation, mean food over fixed seeds 101, 202, 303; ACO 93.0, Random 0.0):

| Generation | 0 | 10 | 20 | 45 | 66 | 80 | 94 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Champion food | 6.7 | 27.3 | 89.0 | 88.3 | 131.0 | 167.3 | 209.7 |

**How the shipped champion was produced.** Stage 1: four islands from random weights (67 generations for the
selected one). Their champions did not beat ACO on held-out seeds (83.4 vs 115.2) because mutation strength was
pinned at its ceiling. Stage 2: after fixing the schedule (log-uniform per-child strength, lower ceiling, small
steps on warm starts), four islands refined the best stage-1 checkpoint for 28 more generations. Three of the
four beat ACO on the held-out seeds (155.0, 157.0, 159.6); the one with the best 12-seed validation score was
baked. No hand-set weights were used at any point.

## Engine

- `lib/ant-soa-engine.ts`: `MAX_ANTS = 3000` preallocated typed arrays, free-list slot reuse, `Int32Array`
  spatial hash (`cellSize = 24`), fixed `dt = 1/60`. The step loop allocates nothing.
- Three policies behind one action interface: `TRAINED_MLP`, `HANDCRAFTED_ACO`, `RANDOM_MLP`.
- Shared innate reflexes for every policy: turn 180 degrees on pickup and on delivery, alarm flight, warden
  defence, trail damping, tandem following, corpse hauling. Steering, speed and the five glands during
  FORAGING and RETURNING belong to the policy.
- Mortality: ATP burn by speed, load and combat; death by starvation or age; corpses leak weak alarm; Wardens
  haul them to a graveyard placed away from food. The nest refills energy. Three delivered food hatch one ant,
  25 births advance the colony generation, fewer than 35 survivors triggers a founder brood wave and arms a
  2.5x mutation boost for the next in-app training run.
- Predators (0 to 6 Abyssal Stalkers): ants within 75 px emit a +80 alarm burst; foragers flee, Wardens climb
  the gradient and wear the predator down.

### Brain (`lib/neat.ts`)

Fixed topology `19 -> 16 (tanh) -> 9`, 473 weights, Jordan recurrence (two outputs feed back as inputs).

- Inputs: bilateral gradient `S_right - S_left` and centre `S_center` for each of the five channels with
  `S = log(1 + C)`; three wall rays; egocentric home vector (forward, lateral); carrying; energy; memA; memB.
- Outputs: steer torque, speed, five gland outputs, next memA, next memB.
- Evolution: elitism, tournament selection, neuron-wise crossover, adaptive Gaussian mutation, optional
  NEAT-style speciation (`--speciate`). Topology never grows.
- Glands: foodTrail can only be secreted while carrying and fades with time since pickup; homeGuide fades with
  time since the last nest visit. That gives both fields a usable gradient for every policy.
- Fitness: `10 * food + 4 * sum(StraightDist / ActualDist) + 2 * pickups + homing progress + trophallaxis and
  defence bonuses - wall scraping - looping stagnation - starvation`.

### Pheromones (`lib/pheromone-grid.ts`)

Five ping-pong `Float32Array` channels, `cellSize = 6`, values in `[0, 100]`. Explicit 3x3 diffusion with a CFL
clamp, zero-flux walls, alarm decaying 3.2x faster, foodTrail + homeGuide polymer decaying 35% slower, noEntry
dissolving foodTrail at `0.45 * C * dt`. The mixer computes `1 - exp(-gamma * sum(w * C * RGB))` and then
pairwise interference: pearl cores with turquoise edges, rose-gold, magenta, sulfur-gold.

### Renderer (`lib/renderer.ts`)

Ten layers, no `ctx.filter` and no `shadowBlur`: terrain cache with dirty-rect repaint, pheromone ImageData
(`screen`), quarter-res bloom (`lighter`, every 2nd frame), husks and crystals, nest mandala, ants and
predators, arcs, spore motes, brush ribbon, vignette and grain. Below 50 FPS the scaler halves the diffusion
rate and drops bloom; ants and physics stay at 100%.

## App

- Top HUD: FPS dot, alive (deaths), food, `GEN n`, live A/B score, speed chip, 48 px play/pause; two squircles.
- Bottom cockpit: peek card with quick pills (Train +5 Gen, A/B vs Random, Predator Threat, Clear trails,
  two-tap Reset) that expands to a three-snap sheet (390 px side panel on desktop) with five tabs; contextual
  pills for the five channels plus Spawn Predator; six-tool dock.
- Proof of Learning tab: SVG learning curve, in-app chunked trainer (one headless episode per slice), headless
  benchmark and ablation chart (N = 3 seeds), live channel mutes, arena policy switcher, weight heatmap, brain
  JSON import and export.
- 50/50 arenas split the world into two sealed halves with identical layouts, one colony each, so cohorts never
  share pheromones.
- Shortcuts: `1`-`6` tools, `Space` pause, `[` `]` brush size, `Esc` close.
- Settings and any locally trained brain persist in `localStorage` (guarded; the app works without it).

## Known limits

- The trained brain is weak on Double Bridge and untested on Subterranean Labyrinth, which is not part of the
  headless scenario set. Expect the hand-crafted ACO arena to look better on those two presets.
- In-app training blocks the main thread for roughly a third of a second per episode, so the live view drops
  to a few frames per second while it runs. "+5 Gen" takes on the order of half a minute.
- In-app training keeps a candidate only if it beats the champion on the three curve seeds, so it can report
  "no improvement".
- The canvas UI was type-checked and built but not exercised in a real browser in this environment.

## Deviations from the brief

- The sandbox had no `todo` tool; phases were tracked in the working log instead.
- `package.json` could not be edited by hand in this environment, so the template's database packages
  (`drizzle-orm`, `pg`, `dotenv`) and `src/db/` are still present but unused. `vitest` and `tsx` were added.
- Sprite sheets: one 4-row caste sheet (Scout, Hauler, Warden, Drone palette) and one 2-row cohort sheet
  (Trained, Rival), each 8 frames, unladen and laden.
