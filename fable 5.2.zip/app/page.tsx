'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import FieldGuideModal from '../components/FieldGuideModal';
import FloatingToolDock, { TOOLS } from '../components/FloatingToolDock';
import ParameterSheet from '../components/ParameterSheet';
import type { Settings, SheetSnap, SheetTab } from '../components/ParameterSheet';
import ProofOfLearningLab from '../components/ProofOfLearningLab';
import type { TrainingState } from '../components/ProofOfLearningLab';
import SanctuaryCanvas from '../components/SanctuaryCanvas';
import type { SanctuaryHandle } from '../components/SanctuaryCanvas';
import TelemetryPill from '../components/TelemetryPill';
import ToastOverlay from '../components/ToastOverlay';
import type { ColonySim } from '../lib/ant-soa-engine';
import { BENCH_SEEDS, DEFAULT_SHAPE, HeadlessTrainer, benchmarkSteps } from '../lib/headless-sim';
import { BAKED_CHAMPION, exportBrainJSON, getChampionWeights, importBrainJSON } from '../lib/neat';
import { PRESETS } from '../lib/presets';
import { CHANNEL_KEYS } from '../lib/types';
import type {
  AblationId, ArenaMode, BenchmarkProgress, BenchmarkResult, GenerationRecord, PresetId, SubMode, Telemetry,
  ToastMessage, ToolId,
} from '../lib/types';

const STORE_KEY = 'cryo-sanctuary:settings:v1';
const BRAIN_KEY = 'cryo-sanctuary:brain:v1';

const DEFAULT_SETTINGS: Settings = {
  maxPop: 1600, atpBurn: 1, lifespan: 200, predators: 0, evaporation: 1, diffusion: 2, crossReaction: 1, radius: 24, strength: 1,
};

const NO_MUTES: Record<AblationId, boolean> = {
  foodTrail: false, homeGuide: false, alarm: false, scoutPulse: false, noEntry: false, pathIntegration: false,
};

const INITIAL_TELEMETRY: Telemetry = {
  fps: 60, alive: 0, deaths: 0, food: 0, generation: 1, births: 0, predators: 0, scoreA: 0, scoreB: 0, arena: 'trained', adaptive: false,
};

const IDLE_TRAINING: TrainingState = { running: false, done: 0, target: 0, progress: 0 };

/* ----------------------------- safe localStorage ----------------------------- */

function safeGet(key: string): string | null {
  try {
    return window.localStorage.getItem(key);
  } catch {
    return null;
  }
}

function safeSet(key: string, value: string): void {
  try {
    window.localStorage.setItem(key, value);
  } catch {
    /* storage may be full or blocked: persistence is optional */
  }
}

function isRecord(v: unknown): v is Record<string, unknown> {
  return typeof v === 'object' && v !== null;
}

function num(v: unknown, fallback: number, min: number, max: number): number {
  return typeof v === 'number' && Number.isFinite(v) ? Math.min(max, Math.max(min, v)) : fallback;
}

function parseHistory(v: unknown): GenerationRecord[] {
  if (!Array.isArray(v)) return [];
  const out: GenerationRecord[] = [];
  for (const item of v as unknown[]) {
    if (!isRecord(item)) continue;
    out.push({
      generation: num(item.generation, 0, 0, 1e6),
      bestFood: num(item.bestFood, 0, 0, 1e6),
      championFood: num(item.championFood, 0, 0, 1e6),
      bestFitness: num(item.bestFitness, 0, -1e9, 1e9),
      meanFitness: num(item.meanFitness, 0, -1e9, 1e9),
      acoFood: num(item.acoFood, 0, 0, 1e6),
      randomFood: num(item.randomFood, 0, 0, 1e6),
      sigma: num(item.sigma, 0, 0, 10),
      species: num(item.species, 1, 0, 1e4),
    });
  }
  return out;
}

export default function Page() {
  const canvasRef = useRef<SanctuaryHandle | null>(null);
  const brainRef = useRef<Float32Array>(getChampionWeights());
  const brainGenRef = useRef<number>(BAKED_CHAMPION.generations);
  const liveHistoryRef = useRef<GenerationRecord[]>([]);
  const settingsRef = useRef<Settings>(DEFAULT_SETTINGS);
  const mutedRef = useRef<Record<AblationId, boolean>>(NO_MUTES);
  const workTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const dimTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const toastId = useRef(0);
  const loaded = useRef(false);

  const [tool, setTool] = useState<ToolId>('food-trail');
  const [subMode, setSubMode] = useState<SubMode>(0);
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const [paused, setPaused] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [preset, setPreset] = useState<PresetId>('open');
  const [arena, setArena] = useState<ArenaMode>('trained');
  const [muted, setMuted] = useState<Record<AblationId, boolean>>(NO_MUTES);
  const [telemetry, setTelemetry] = useState<Telemetry>(INITIAL_TELEMETRY);
  const [snap, setSnap] = useState<SheetSnap>('peek');
  const [tab, setTab] = useState<SheetTab>('proof');
  const [guideOpen, setGuideOpen] = useState(false);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [splashHidden, setSplashHidden] = useState(false);
  const [ghost, setGhost] = useState(true);
  const [dim, setDim] = useState(false);
  const [history, setHistory] = useState<GenerationRecord[]>(BAKED_CHAMPION.history);
  const [benchmark, setBenchmark] = useState<BenchmarkResult | null>(BAKED_CHAMPION.benchmark);
  const [benchProgress, setBenchProgress] = useState<BenchmarkProgress | null>(null);
  const [training, setTraining] = useState<TrainingState>(IDLE_TRAINING);
  const [weightsVersion, setWeightsVersion] = useState(0);

  const busy = training.running || benchProgress !== null;

  const pushToast = useCallback((text: string, tone: ToastMessage['tone']) => {
    const id = ++toastId.current;
    setToasts((t) => [...t.slice(-2), { id, text, tone }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3200);
  }, []);

  /* ----------------------------- sim synchronisation ----------------------------- */

  const applySettings = useCallback((sim: ColonySim, s: Settings) => {
    sim.params.maxPop = s.maxPop;
    sim.params.atpBurn = s.atpBurn;
    sim.params.lifespan = s.lifespan;
    sim.grid.evaporation = s.evaporation;
    sim.grid.diffusion = s.diffusion;
    sim.grid.crossReaction = s.crossReaction;
  }, []);

  const applyMutes = useCallback((sim: ColonySim, m: Record<AblationId, boolean>) => {
    for (let c = 0; c < CHANNEL_KEYS.length; c++) sim.grid.mask[c] = m[CHANNEL_KEYS[c]] ? 0 : 1;
    sim.pathIntegration = !m.pathIntegration;
  }, []);

  const handleReady = useCallback(
    (sim: ColonySim) => {
      sim.setBrain(brainRef.current);
      applySettings(sim, settingsRef.current);
      applyMutes(sim, mutedRef.current);
    },
    [applySettings, applyMutes],
  );

  useEffect(() => {
    settingsRef.current = settings;
    const sim = canvasRef.current?.getSim();
    if (sim) applySettings(sim, settings);
  }, [settings, applySettings]);

  useEffect(() => {
    mutedRef.current = muted;
    const sim = canvasRef.current?.getSim();
    if (sim) applyMutes(sim, muted);
  }, [muted, applyMutes]);

  /* ----------------------------- persistence ----------------------------- */

  useEffect(() => {
    const raw = safeGet(STORE_KEY);
    if (raw) {
      try {
        const data: unknown = JSON.parse(raw);
        if (isRecord(data)) {
          const s = isRecord(data.settings) ? data.settings : {};
          const restored: Settings = {
            maxPop: num(s.maxPop, DEFAULT_SETTINGS.maxPop, 100, 3000),
            atpBurn: num(s.atpBurn, DEFAULT_SETTINGS.atpBurn, 0.25, 3),
            lifespan: num(s.lifespan, DEFAULT_SETTINGS.lifespan, 60, 600),
            predators: 0,
            evaporation: num(s.evaporation, DEFAULT_SETTINGS.evaporation, 0.25, 3),
            diffusion: num(s.diffusion, DEFAULT_SETTINGS.diffusion, 0, 8),
            crossReaction: num(s.crossReaction, DEFAULT_SETTINGS.crossReaction, 0, 2),
            radius: num(s.radius, DEFAULT_SETTINGS.radius, 8, 64),
            strength: num(s.strength, DEFAULT_SETTINGS.strength, 0.3, 2),
          };
          setSettings(restored);
          const sp = num(data.speed, 1, 1, 4);
          setSpeed(sp === 2 || sp === 4 ? sp : 1);
          const toolDef = TOOLS.find((t) => t.id === data.tool);
          if (toolDef) {
            setTool(toolDef.id);
            setSubMode(toolDef.id === 'home-trail' ? 1 : toolDef.id === 'alarm' ? 2 : 0);
          }
          if (data.seenGuide === true) setGhost(false);
        }
      } catch {
        /* corrupted settings are ignored */
      }
    }
    const brainRaw = safeGet(BRAIN_KEY);
    if (brainRaw) {
      try {
        const data: unknown = JSON.parse(brainRaw);
        // only resume a locally trained brain if it continues the currently shipped champion
        if (isRecord(data) && data.bakedAt === BAKED_CHAMPION.trainedAt) {
          const brain = importBrainJSON(data.brain);
          if (brain) {
            brainRef.current = brain.weights;
            brainGenRef.current = brain.generation;
            liveHistoryRef.current = parseHistory(data.history);
            setHistory([...BAKED_CHAMPION.history, ...liveHistoryRef.current]);
            canvasRef.current?.setBrain(brain.weights);
            setWeightsVersion((v) => v + 1);
          }
        }
      } catch {
        /* corrupted brain is ignored */
      }
    }
    loaded.current = true;
    const splash = setTimeout(() => setSplashHidden(true), 300);
    const hint = setTimeout(() => pushToast('Drag on the soil to paint pheromone. Keys 1 to 6 switch tools.', 'info'), 900);
    const ghostOff = setTimeout(() => setGhost(false), 12000);
    return () => {
      clearTimeout(splash);
      clearTimeout(hint);
      clearTimeout(ghostOff);
      if (workTimer.current) clearTimeout(workTimer.current);
      if (dimTimer.current) clearTimeout(dimTimer.current);
    };
  }, [pushToast]);

  useEffect(() => {
    if (!loaded.current) return;
    safeSet(STORE_KEY, JSON.stringify({ settings, speed, tool, seenGuide: !ghost }));
  }, [settings, speed, tool, ghost]);

  const persistBrain = useCallback(() => {
    safeSet(
      BRAIN_KEY,
      JSON.stringify({
        bakedAt: BAKED_CHAMPION.trainedAt,
        brain: exportBrainJSON(brainRef.current, brainGenRef.current),
        history: liveHistoryRef.current,
      }),
    );
  }, []);

  /* ----------------------------- actions ----------------------------- */

  const selectTool = useCallback((t: ToolId) => {
    setTool(t);
    if (t === 'food-trail') setSubMode(0);
    else if (t === 'home-trail') setSubMode(1);
    else if (t === 'alarm') setSubMode(2);
  }, []);

  const rebuildWorld = useCallback((p: PresetId, a: ArenaMode) => {
    const h = canvasRef.current;
    if (!h) return;
    h.resetWorld(p, a);
    h.setPredators(settingsRef.current.predators);
  }, []);

  const changeArena = useCallback(
    (a: ArenaMode) => {
      setArena(a);
      rebuildWorld(preset, a);
      pushToast(
        a === 'trained' ? 'Arena: 100% trained brain'
          : a === 'aco' ? 'Arena: 100% hand-crafted ACO'
            : a === 'ab-aco' ? 'Arena split: trained brain vs hand-crafted ACO'
              : 'Arena split: trained brain vs random network',
        'info',
      );
    },
    [preset, rebuildWorld, pushToast],
  );

  const changePreset = useCallback(
    (p: PresetId) => {
      setPreset(p);
      rebuildWorld(p, arena);
      pushToast(`World: ${PRESETS.find((x) => x.id === p)?.title ?? p}`, 'info');
    },
    [arena, rebuildWorld, pushToast],
  );

  const changeSetting = useCallback((key: keyof Settings, value: number) => {
    setSettings((s) => ({ ...s, [key]: value }));
    if (key === 'predators') canvasRef.current?.setPredators(value);
  }, []);

  const predatorThreat = useCallback(() => {
    const h = canvasRef.current;
    if (!h) return;
    if (h.spawnPredator()) {
      const n = h.getSim()?.predatorCount ?? 0;
      setSettings((s) => ({ ...s, predators: n }));
      pushToast('An Abyssal Stalker has entered the sanctuary', 'warn');
    } else {
      pushToast('Predator cap reached (6)', 'warn');
    }
  }, [pushToast]);

  const startTraining = useCallback(
    (generations: number) => {
      if (workTimer.current || busy) return;
      const lastRec = history.length > 0 ? history[history.length - 1] : null;
      const trainer = new HeadlessTrainer({
        populationSize: 6,
        seedsPerEval: 2,
        seed: 1 + (Date.now() % 9973),
        shape: DEFAULT_SHAPE,
        warmStart: brainRef.current,
        startGeneration: lastRec ? lastRec.generation + 1 : 0,
        knownBaselines: lastRec ? { aco: lastRec.acoFood, random: lastRec.randomFood } : null,
      });
      const sim = canvasRef.current?.getSim();
      if (sim && sim.founderBoost > 1) {
        // Founder Bottleneck: the next brood of candidate brains mutates 2.5x harder
        trainer.evo.mutationBoost = sim.founderBoost;
        sim.founderBoost = 1;
      }
      const startFood = { value: -1 };
      let done = 0;
      setTraining({ running: true, done: 0, target: generations, progress: 0 });
      const tick = (): void => {
        const rec = trainer.advance(); // exactly one headless episode per slice
        if (startFood.value < 0) startFood.value = trainer.championFood;
        if (rec) {
          done++;
          liveHistoryRef.current = [...liveHistoryRef.current, rec];
          setHistory((h) => [...h, rec]);
        }
        if (done >= generations) {
          workTimer.current = null;
          brainRef.current = Float32Array.from(trainer.champion);
          brainGenRef.current = trainer.generation;
          canvasRef.current?.setBrain(brainRef.current);
          setWeightsVersion((v) => v + 1);
          persistBrain();
          setTraining(IDLE_TRAINING);
          const gain = trainer.championFood - startFood.value;
          pushToast(
            gain > 0.05
              ? `+${generations} generations: champion food ${startFood.value.toFixed(1)} to ${trainer.championFood.toFixed(1)}`
              : `+${generations} generations: no candidate beat the current champion (${trainer.championFood.toFixed(1)} food)`,
            gain > 0.05 ? 'good' : 'info',
          );
          return;
        }
        setTraining({ running: true, done, target: generations, progress: trainer.progress });
        workTimer.current = setTimeout(tick, 0);
      };
      workTimer.current = setTimeout(tick, 60);
    },
    [busy, history, persistBrain, pushToast],
  );

  const runBenchmark = useCallback(() => {
    if (workTimer.current || busy) return;
    const it = benchmarkSteps(brainRef.current, { seeds: BENCH_SEEDS.slice(0, 3), shape: DEFAULT_SHAPE });
    setBenchProgress({ done: 0, total: 27, label: 'Preparing' });
    const tick = (): void => {
      const step = it.next();
      if (step.done) {
        workTimer.current = null;
        setBenchmark(step.value);
        setBenchProgress(null);
        pushToast('Benchmark complete', 'good');
        return;
      }
      setBenchProgress(step.value);
      workTimer.current = setTimeout(tick, 0);
    };
    workTimer.current = setTimeout(tick, 60);
  }, [busy, pushToast]);

  const exportBrain = useCallback(() => {
    const json = JSON.stringify(exportBrainJSON(brainRef.current, brainGenRef.current));
    const url = URL.createObjectURL(new Blob([json], { type: 'application/json' }));
    const a = document.createElement('a');
    a.href = url;
    a.download = `colony-brain-gen${brainGenRef.current}.json`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    pushToast('Brain weights exported', 'good');
  }, [pushToast]);

  const importBrain = useCallback(
    (file: File) => {
      file.text().then(
        (text) => {
          const brain = importBrainJSON(text);
          if (!brain) {
            pushToast('That file is not a valid 19-16-9 colony brain', 'warn');
            return;
          }
          brainRef.current = brain.weights;
          brainGenRef.current = brain.generation;
          canvasRef.current?.setBrain(brain.weights);
          setWeightsVersion((v) => v + 1);
          persistBrain();
          pushToast(`Imported brain (generation ${brain.generation})`, 'good');
        },
        () => pushToast('Could not read that file', 'warn'),
      );
    },
    [persistBrain, pushToast],
  );

  const handlePointerActive = useCallback((active: boolean) => {
    if (dimTimer.current) clearTimeout(dimTimer.current);
    if (active) {
      setDim(true);
      setGhost(false);
    } else {
      dimTimer.current = setTimeout(() => setDim(false), 200);
    }
  }, []);

  /* ----------------------------- keyboard ----------------------------- */

  useEffect(() => {
    const onKey = (e: KeyboardEvent): void => {
      const target = e.target as HTMLElement | null;
      if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA')) return;
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      if (e.key >= '1' && e.key <= '6') {
        selectTool(TOOLS[Number(e.key) - 1].id);
      } else if (e.key === ' ') {
        if (target && target.tagName === 'BUTTON') return;
        e.preventDefault();
        setPaused((p) => !p);
      } else if (e.key === '[') {
        setSettings((s) => ({ ...s, radius: Math.max(8, s.radius - 4) }));
      } else if (e.key === ']') {
        setSettings((s) => ({ ...s, radius: Math.min(64, s.radius + 4) }));
      } else if (e.key === 'Escape') {
        if (guideOpen) setGuideOpen(false);
        else setSnap('peek');
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [guideOpen, selectTool]);

  return (
    <main className="sanctuary-root">
      <SanctuaryCanvas
        ref={canvasRef}
        tool={tool}
        subMode={subMode}
        radius={settings.radius}
        strength={settings.strength}
        paused={paused}
        speed={speed}
        busy={busy}
        initialPreset="open"
        initialArena="trained"
        onReady={handleReady}
        onTelemetry={setTelemetry}
        onPointerActive={handlePointerActive}
        onEvent={pushToast}
      />

      <div className={dim ? 'ui-layer dim' : 'ui-layer'}>
        <TelemetryPill
          telemetry={telemetry}
          paused={paused}
          speed={speed}
          onTogglePause={() => setPaused((p) => !p)}
          onCycleSpeed={() => setSpeed((s) => (s === 1 ? 2 : s === 2 ? 4 : 1))}
          onGuide={() => setGuideOpen(true)}
          onParams={() => {
            setSnap((s) => (s === 'peek' ? 'half' : 'peek'));
          }}
        />
        <ToastOverlay toasts={toasts} />
        {ghost && !splashHidden ? null : ghost && (
          <div className="ghost-guide" aria-hidden="true">
            <svg viewBox="0 0 320 120" width="100%" fill="none">
              <path d="M24 92C70 30 120 110 166 62s84-40 130-14" stroke="#ffa800" strokeWidth="3" strokeLinecap="round" />
              <circle cx="24" cy="92" r="7" fill="#ffa800" />
            </svg>
            <div>Drag to paint a food trail</div>
          </div>
        )}
        <div className="cockpit" data-snap={snap}>
          <ParameterSheet
            snap={snap}
            onSnap={setSnap}
            tab={tab}
            onTab={setTab}
            presetId={preset}
            onPreset={changePreset}
            settings={settings}
            onSetting={changeSetting}
            livePredators={telemetry.predators}
            abRandomActive={arena === 'ab-random'}
            busy={busy}
            onTrain5={() => {
              setTab('proof');
              setSnap((s) => (s === 'peek' ? 'half' : s));
              startTraining(5);
            }}
            onAbRandom={() => changeArena(arena === 'ab-random' ? 'trained' : 'ab-random')}
            onPredatorThreat={predatorThreat}
            onClearTrails={() => {
              canvasRef.current?.clearTrails();
              pushToast('All five pheromone channels cleared', 'info');
            }}
            onReset={() => {
              rebuildWorld(preset, arena);
              pushToast('World reset', 'info');
            }}
          >
            <ProofOfLearningLab
              history={history}
              bakedGenerations={BAKED_CHAMPION.generations}
              trainedAt={BAKED_CHAMPION.trainedAt}
              training={training}
              onTrain={startTraining}
              benchmark={benchmark}
              benchProgress={benchProgress}
              onRunBenchmark={runBenchmark}
              arena={arena}
              onArena={changeArena}
              muted={muted}
              onToggleMute={(id) => setMuted((m) => ({ ...m, [id]: !m[id] }))}
              weights={brainRef.current}
              weightsVersion={weightsVersion}
              onExport={exportBrain}
              onImport={importBrain}
            />
          </ParameterSheet>
          <FloatingToolDock
            tool={tool}
            subMode={subMode}
            radius={settings.radius}
            onTool={selectTool}
            onSubMode={setSubMode}
            onRadius={(r) => changeSetting('radius', r)}
          />
        </div>
      </div>

      <FieldGuideModal open={guideOpen} onClose={() => setGuideOpen(false)} />

      <div className="splash" data-hide={splashHidden} aria-hidden={splashHidden}>
        <div className="flex flex-col items-center gap-3">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/logo.svg" alt="" width={72} height={72} />
          <span className="font-display text-[22px] font-semibold">Cryo-Obsidian Sanctuary</span>
        </div>
      </div>
    </main>
  );
}
