export type PheromoneChannel = "foodTrail" | "homeGuide" | "alarm";

export interface DirtyRect {
  minGx: number;
  minGy: number;
  maxGx: number;
  maxGy: number;
}

export interface PheromoneLUTs {
  food: Uint8Array; // 256 * 4 RGBA
  home: Uint8Array; // 256 * 4 RGBA
  alarm: Uint8Array; // 256 * 4 RGBA
}

function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

function buildChannelLut(
  stops: Array<{ t: number; r: number; g: number; b: number; a: number }>
): Uint8Array {
  const lut = new Uint8Array(256 * 4);
  for (let i = 0; i < 256; i++) {
    const raw = i / 255;
    // Non-linear perceptual gamma curve: dark transparent tail -> saturated body -> incandescent core
    const u = Math.pow(raw, 0.72);
    let s0 = stops[0];
    let s1 = stops[stops.length - 1];
    for (let k = 0; k < stops.length - 1; k++) {
      if (u >= stops[k].t && u <= stops[k + 1].t) {
        s0 = stops[k];
        s1 = stops[k + 1];
        break;
      }
    }
    const span = Math.max(1e-5, s1.t - s0.t);
    const f = Math.min(1, Math.max(0, (u - s0.t) / span));
    const idx = i * 4;
    lut[idx] = Math.round(lerp(s0.r, s1.r, f));
    lut[idx + 1] = Math.round(lerp(s0.g, s1.g, f));
    lut[idx + 2] = Math.round(lerp(s0.b, s1.b, f));
    lut[idx + 3] = Math.round(lerp(s0.a, s1.a, f));
  }
  return lut;
}

export function createPheromoneLUTs(): PheromoneLUTs {
  const food = buildChannelLut([
    { t: 0.0, r: 0, g: 0, b: 0, a: 0 },
    { t: 0.08, r: 77, g: 31, b: 0, a: 28 },     // #4d1f00 warm rust tail
    { t: 0.45, r: 215, g: 110, b: 0, a: 145 },
    { t: 0.78, r: 255, g: 174, b: 0, a: 220 },  // #ffae00 incandescent amber
    { t: 1.0, r: 255, g: 243, b: 176, a: 255 }, // #fff3b0 white-hot core
  ]);

  const home = buildChannelLut([
    { t: 0.0, r: 0, g: 0, b: 0, a: 0 },
    { t: 0.08, r: 0, g: 51, b: 102, a: 26 },   // #003366 deep cobalt tail
    { t: 0.48, r: 0, g: 148, b: 214, a: 132 },
    { t: 0.80, r: 0, g: 240, b: 255, a: 215 },  // #00f0ff electric cyan
    { t: 1.0, r: 224, g: 255, b: 255, a: 250 }, // #e0ffff core
  ]);

  const alarm = buildChannelLut([
    { t: 0.0, r: 0, g: 0, b: 0, a: 0 },
    { t: 0.1, r: 95, g: 4, b: 26, a: 34 },
    { t: 0.55, r: 255, g: 10, b: 67, a: 195 },  // #ff0a43 crimson pulse
    { t: 1.0, r: 255, g: 209, b: 220, a: 250 }, // #ffd1dc hot core
  ]);

  return { food, home, alarm };
}

export class PheromoneGrid {
  public readonly worldWidth: number;
  public readonly worldHeight: number;
  public readonly cellSize: number;
  public readonly cols: number;
  public readonly rows: number;
  public readonly totalCells: number;

  public foodTrailA: Float32Array;
  public foodTrailB: Float32Array;
  public homeGuideA: Float32Array;
  public homeGuideB: Float32Array;
  public alarmA: Float32Array;
  public alarmB: Float32Array;

  public wallMask: Uint8Array;
  public smoothedWallField: Float32Array;
  public luts: PheromoneLUTs;

  public suppressedCount = 0;

  constructor(worldWidth: number, worldHeight: number, cellSize = 6) {
    this.worldWidth = worldWidth;
    this.worldHeight = worldHeight;
    this.cellSize = cellSize;
    this.cols = Math.ceil(worldWidth / cellSize);
    this.rows = Math.ceil(worldHeight / cellSize);
    this.totalCells = this.cols * this.rows;

    this.foodTrailA = new Float32Array(this.totalCells);
    this.foodTrailB = new Float32Array(this.totalCells);
    this.homeGuideA = new Float32Array(this.totalCells);
    this.homeGuideB = new Float32Array(this.totalCells);
    this.alarmA = new Float32Array(this.totalCells);
    this.alarmB = new Float32Array(this.totalCells);

    this.wallMask = new Uint8Array(this.totalCells);
    this.smoothedWallField = new Float32Array(this.totalCells);
    this.luts = createPheromoneLUTs();
  }

  public clearPheromones(): void {
    this.foodTrailA.fill(0);
    this.foodTrailB.fill(0);
    this.homeGuideA.fill(0);
    this.homeGuideB.fill(0);
    this.alarmA.fill(0);
    this.alarmB.fill(0);
    this.suppressedCount = 0;
  }

  public clearAll(): void {
    this.clearPheromones();
    this.wallMask.fill(0);
    this.smoothedWallField.fill(0);
  }

  public worldToCellX(x: number): number {
    const gx = (x / this.cellSize) | 0;
    return gx < 0 ? 0 : gx >= this.cols ? this.cols - 1 : gx;
  }

  public worldToCellY(y: number): number {
    const gy = (y / this.cellSize) | 0;
    return gy < 0 ? 0 : gy >= this.rows ? this.rows - 1 : gy;
  }

  public isWallAtWorld(x: number, y: number): boolean {
    if (x < 0 || y < 0 || x >= this.worldWidth || y >= this.worldHeight) return true;
    const gx = (x / this.cellSize) | 0;
    const gy = (y / this.cellSize) | 0;
    if (gx < 0 || gx >= this.cols || gy < 0 || gy >= this.rows) return true;
    return this.wallMask[gy * this.cols + gx] === 1;
  }

  /**
   * Line-of-sight check between two world points preventing ants from sensing
   * pheromones across solid walls.
   */
  public hasLineOfSight(x0: number, y0: number, x1: number, y1: number): boolean {
    const dx = x1 - x0;
    const dy = y1 - y0;
    const dist = Math.hypot(dx, dy);
    const steps = Math.max(1, Math.ceil(dist / (this.cellSize * 0.75)));
    const inv = 1 / steps;
    for (let i = 1; i <= steps; i++) {
      const t = i * inv;
      const sx = x0 + dx * t;
      const sy = y0 + dy * t;
      if (this.isWallAtWorld(sx, sy)) return false;
    }
    return true;
  }

  public sampleChannel(channel: PheromoneChannel, x: number, y: number): number {
    if (x < 0 || y < 0 || x >= this.worldWidth || y >= this.worldHeight) return 0;
    const gx = (x / this.cellSize) | 0;
    const gy = (y / this.cellSize) | 0;
    if (gx < 0 || gx >= this.cols || gy < 0 || gy >= this.rows) return 0;
    const idx = gy * this.cols + gx;
    if (this.wallMask[idx] === 1) return 0;
    if (channel === "foodTrail") return this.foodTrailA[idx];
    if (channel === "homeGuide") return this.homeGuideA[idx];
    return this.alarmA[idx];
  }

  public depositAtWorld(
    channel: PheromoneChannel,
    x: number,
    y: number,
    baseStrength: number,
    decayAgeFactor = 1.0
  ): void {
    if (x < 0 || y < 0 || x >= this.worldWidth || y >= this.worldHeight) return;
    const gx = (x / this.cellSize) | 0;
    const gy = (y / this.cellSize) | 0;
    if (gx < 0 || gx >= this.cols || gy < 0 || gy >= this.rows) return;
    const idx = gy * this.cols + gx;
    if (this.wallMask[idx] === 1) return;

    const arr =
      channel === "foodTrail"
        ? this.foodTrailA
        : channel === "homeGuide"
          ? this.homeGuideA
          : this.alarmA;

    const current = arr[idx];
    // Saturating age-attenuated deposition formula preventing dead-trail locking
    const delta = (baseStrength * decayAgeFactor) / (1.0 + 0.08 * current);
    const next = current + delta;
    arr[idx] = next > 100.0 ? 100.0 : next;
  }

  /**
   * RL False-Trail Extinction: returning ants that discovered depleted food emit
   * a suppressive cancellation signal that rapidly erases obsolete food trails.
   */
  public dampFoodTrailAtWorld(x: number, y: number, radiusWorld: number, factor: number): void {
    const rCells = Math.max(1, Math.ceil(radiusWorld / this.cellSize));
    const cx = this.worldToCellX(x);
    const cy = this.worldToCellY(y);
    const minX = Math.max(0, cx - rCells);
    const maxX = Math.min(this.cols - 1, cx + rCells);
    const minY = Math.max(0, cy - rCells);
    const maxY = Math.min(this.rows - 1, cy + rCells);
    const r2 = radiusWorld * radiusWorld;

    let damped = false;
    for (let gy = minY; gy <= maxY; gy++) {
      const wy = (gy + 0.5) * this.cellSize;
      const dy = wy - y;
      for (let gx = minX; gx <= maxX; gx++) {
        const wx = (gx + 0.5) * this.cellSize;
        const dx = wx - x;
        const d2 = dx * dx + dy * dy;
        if (d2 <= r2) {
          const idx = gy * this.cols + gx;
          if (this.foodTrailA[idx] > 0.25) {
            const falloff = 1.0 - Math.sqrt(d2) / radiusWorld;
            this.foodTrailA[idx] *= Math.max(0.05, 1.0 - factor * falloff);
            damped = true;
          }
        }
      }
    }
    if (damped) {
      this.suppressedCount++;
    }
  }

  public paintPheromoneBrush(
    channel: PheromoneChannel,
    x: number,
    y: number,
    radiusWorld: number,
    strength: number
  ): void {
    const rCells = Math.max(1, Math.ceil(radiusWorld / this.cellSize));
    const cx = this.worldToCellX(x);
    const cy = this.worldToCellY(y);
    const minX = Math.max(0, cx - rCells);
    const maxX = Math.min(this.cols - 1, cx + rCells);
    const minY = Math.max(0, cy - rCells);
    const maxY = Math.min(this.rows - 1, cy + rCells);
    const r2 = radiusWorld * radiusWorld;

    const arr =
      channel === "foodTrail"
        ? this.foodTrailA
        : channel === "homeGuide"
          ? this.homeGuideA
          : this.alarmA;

    for (let gy = minY; gy <= maxY; gy++) {
      const wy = (gy + 0.5) * this.cellSize;
      const dy = wy - y;
      for (let gx = minX; gx <= maxX; gx++) {
        const wx = (gx + 0.5) * this.cellSize;
        const dx = wx - x;
        const d2 = dx * dx + dy * dy;
        if (d2 <= r2) {
          const idx = gy * this.cols + gx;
          if (this.wallMask[idx] === 1) continue;
          const dist = Math.sqrt(d2);
          const falloff = Math.pow(1.0 - dist / radiusWorld, 1.45);
          const next = arr[idx] + strength * falloff;
          arr[idx] = next > 100.0 ? 100.0 : next;
        }
      }
    }
  }

  public erasePheromonesInCircle(x: number, y: number, radiusWorld: number): void {
    const rCells = Math.max(1, Math.ceil(radiusWorld / this.cellSize));
    const cx = this.worldToCellX(x);
    const cy = this.worldToCellY(y);
    const minX = Math.max(0, cx - rCells);
    const maxX = Math.min(this.cols - 1, cx + rCells);
    const minY = Math.max(0, cy - rCells);
    const maxY = Math.min(this.rows - 1, cy + rCells);
    const r2 = radiusWorld * radiusWorld;

    for (let gy = minY; gy <= maxY; gy++) {
      const wy = (gy + 0.5) * this.cellSize;
      const dy = wy - y;
      for (let gx = minX; gx <= maxX; gx++) {
        const wx = (gx + 0.5) * this.cellSize;
        const dx = wx - x;
        const d2 = dx * dx + dy * dy;
        if (d2 <= r2) {
          const idx = gy * this.cols + gx;
          const fade = Math.sqrt(d2) / radiusWorld;
          const keep = Math.max(0, fade * 0.25);
          this.foodTrailA[idx] *= keep;
          this.homeGuideA[idx] *= keep;
          this.alarmA[idx] *= keep;
        }
      }
    }
  }

  public paintWallCircle(
    x: number,
    y: number,
    radiusWorld: number,
    isWall: boolean
  ): DirtyRect {
    const rCells = Math.max(1, Math.ceil(radiusWorld / this.cellSize));
    const cx = this.worldToCellX(x);
    const cy = this.worldToCellY(y);
    const minX = Math.max(0, cx - rCells);
    const maxX = Math.min(this.cols - 1, cx + rCells);
    const minY = Math.max(0, cy - rCells);
    const maxY = Math.min(this.rows - 1, cy + rCells);
    const r2 = radiusWorld * radiusWorld;

    for (let gy = minY; gy <= maxY; gy++) {
      const wy = (gy + 0.5) * this.cellSize;
      const dy = wy - y;
      for (let gx = minX; gx <= maxX; gx++) {
        const wx = (gx + 0.5) * this.cellSize;
        const dx = wx - x;
        if (dx * dx + dy * dy <= r2) {
          const idx = gy * this.cols + gx;
          this.wallMask[idx] = isWall ? 1 : 0;
          if (isWall) {
            this.foodTrailA[idx] = 0;
            this.homeGuideA[idx] = 0;
            this.alarmA[idx] = 0;
          }
        }
      }
    }

    const margin = 3;
    const sMinX = Math.max(0, minX - margin);
    const sMaxX = Math.min(this.cols - 1, maxX + margin);
    const sMinY = Math.max(0, minY - margin);
    const sMaxY = Math.min(this.rows - 1, maxY + margin);
    this.recomputeSmoothedWalls(sMinX, sMinY, sMaxX, sMaxY);

    return {
      minGx: sMinX,
      minGy: sMinY,
      maxGx: sMaxX,
      maxGy: sMaxY,
    };
  }

  public recomputeSmoothedWalls(
    minGx = 0,
    minGy = 0,
    maxGx = this.cols - 1,
    maxGy = this.rows - 1
  ): void {
    const cols = this.cols;
    const rows = this.rows;
    const mask = this.wallMask;
    const out = this.smoothedWallField;

    for (let gy = minGy; gy <= maxGy; gy++) {
      for (let gx = minGx; gx <= maxGx; gx++) {
        let sum = 0;
        let wSum = 0;
        for (let oy = -2; oy <= 2; oy++) {
          const ny = gy + oy;
          if (ny < 0 || ny >= rows) continue;
          for (let ox = -2; ox <= 2; ox++) {
            const nx = gx + ox;
            if (nx < 0 || nx >= cols) continue;
            const d2 = ox * ox + oy * oy;
            const w = d2 === 0 ? 4 : d2 <= 2 ? 2 : 1;
            sum += mask[ny * cols + nx] * w;
            wSum += w;
          }
        }
        out[gy * cols + gx] = wSum > 0 ? sum / wSum : 0;
      }
    }
  }

  /**
   * Step exact exponential evaporation and CFL-stable 3x3 Laplacian diffusion
   * enforcing strict zero-flux Neumann boundary conditions at walls & borders.
   */
  public step(dt: number, evaporationRate: number, diffusionRate: number, doDiffusion = true): void {
    const decayTrail = Math.exp(-dt * evaporationRate);
    const decayAlarm = Math.exp(-dt * evaporationRate * 3.5);

    // Clamp diffusion coefficient for strict CFL stability on 3x3 stencil
    const alpha = doDiffusion ? Math.min(0.45, Math.max(0.0, diffusionRate * dt * 4.5)) : 0;

    if (alpha <= 0.0001) {
      // Evaporation-only fast pass
      const n = this.totalCells;
      const fA = this.foodTrailA;
      const hA = this.homeGuideA;
      const aA = this.alarmA;
      const walls = this.wallMask;
      for (let i = 0; i < n; i++) {
        if (walls[i] === 1) {
          fA[i] = 0;
          hA[i] = 0;
          aA[i] = 0;
        } else {
          const nf = fA[i] * decayTrail;
          const nh = hA[i] * decayTrail;
          const na = aA[i] * decayAlarm;
          fA[i] = nf < 0.008 ? 0 : nf;
          hA[i] = nh < 0.008 ? 0 : nh;
          aA[i] = na < 0.008 ? 0 : na;
        }
      }
      return;
    }

    this.stepFieldNeumann(this.foodTrailA, this.foodTrailB, decayTrail, alpha);
    this.stepFieldNeumann(this.homeGuideA, this.homeGuideB, decayTrail, alpha * 0.92);
    this.stepFieldNeumann(this.alarmA, this.alarmB, decayAlarm, Math.min(0.48, alpha * 1.45));

    // Swap ping-pong buffers
    let tmp = this.foodTrailA;
    this.foodTrailA = this.foodTrailB;
    this.foodTrailB = tmp;

    tmp = this.homeGuideA;
    this.homeGuideA = this.homeGuideB;
    this.homeGuideB = tmp;

    tmp = this.alarmA;
    this.alarmA = this.alarmB;
    this.alarmB = tmp;
  }

  private stepFieldNeumann(
    src: Float32Array,
    dst: Float32Array,
    decay: number,
    alpha: number
  ): void {
    const cols = this.cols;
    const rows = this.rows;
    const walls = this.wallMask;

    // 3x3 isotropic weights: orthogonal = 0.2, diagonal = 0.05 (sum = 1.0)
    for (let y = 0; y < rows; y++) {
      const rowOff = y * cols;
      const hasUp = y > 0;
      const hasDn = y < rows - 1;
      for (let x = 0; x < cols; x++) {
        const idx = rowOff + x;
        if (walls[idx] === 1) {
          dst[idx] = 0;
          continue;
        }

        const c = src[idx];
        const hasL = x > 0;
        const hasR = x < cols - 1;

        // Zero-flux Neumann boundary: neighbor wall or out-of-bounds reflects c back
        let diffusedSum = 0;

        // Up
        if (hasUp) {
          const u = idx - cols;
          diffusedSum += (walls[u] === 1 ? c : src[u]) * 0.2;
          if (hasL) {
            const ul = u - 1;
            diffusedSum += (walls[ul] === 1 ? c : src[ul]) * 0.05;
          } else {
            diffusedSum += c * 0.05;
          }
          if (hasR) {
            const ur = u + 1;
            diffusedSum += (walls[ur] === 1 ? c : src[ur]) * 0.05;
          } else {
            diffusedSum += c * 0.05;
          }
        } else {
          diffusedSum += c * 0.3;
        }

        // Left / Right
        if (hasL) {
          const l = idx - 1;
          diffusedSum += (walls[l] === 1 ? c : src[l]) * 0.2;
        } else {
          diffusedSum += c * 0.2;
        }
        if (hasR) {
          const r = idx + 1;
          diffusedSum += (walls[r] === 1 ? c : src[r]) * 0.2;
        } else {
          diffusedSum += c * 0.2;
        }

        // Down
        if (hasDn) {
          const d = idx + cols;
          diffusedSum += (walls[d] === 1 ? c : src[d]) * 0.2;
          if (hasL) {
            const dl = d - 1;
            diffusedSum += (walls[dl] === 1 ? c : src[dl]) * 0.05;
          } else {
            diffusedSum += c * 0.05;
          }
          if (hasR) {
            const dr = d + 1;
            diffusedSum += (walls[dr] === 1 ? c : src[dr]) * 0.05;
          } else {
            diffusedSum += c * 0.05;
          }
        } else {
          diffusedSum += c * 0.3;
        }

        const blended = c + alpha * (diffusedSum - c);
        const decayed = blended * decay;
        dst[idx] = decayed < 0.008 ? 0 : decayed > 100.0 ? 100.0 : decayed;
      }
    }
  }

  /**
   * Renders all 3 pheromone fields into a preallocated cols x rows ImageData
   * using the 256-entry RGB Color Look-Up Tables with zero allocations.
   */
  public renderToImageData(imageData: ImageData): void {
    const data = imageData.data;
    const fA = this.foodTrailA;
    const hA = this.homeGuideA;
    const aA = this.alarmA;
    const walls = this.wallMask;
    const fLut = this.luts.food;
    const hLut = this.luts.home;
    const aLut = this.luts.alarm;
    const n = this.totalCells;

    for (let i = 0; i < n; i++) {
      const px = i << 2;
      if (walls[i] === 1) {
        data[px] = 0;
        data[px + 1] = 0;
        data[px + 2] = 0;
        data[px + 3] = 0;
        continue;
      }

      const fv = fA[i];
      const hv = hA[i];
      const av = aA[i];

      if (fv < 0.08 && hv < 0.08 && av < 0.08) {
        data[px] = 0;
        data[px + 1] = 0;
        data[px + 2] = 0;
        data[px + 3] = 0;
        continue;
      }

      // Map [0..100] -> [0..255] with perceptual compression so active trails shine clearly
      const fi = fv > 0.08 ? Math.min(255, ((Math.log1p(fv) * 55.2) | 0)) : 0;
      const hi = hv > 0.08 ? Math.min(255, ((Math.log1p(hv) * 55.2) | 0)) : 0;
      const ai = av > 0.08 ? Math.min(255, ((Math.log1p(av) * 62.0) | 0)) : 0;

      const fIdx = fi << 2;
      const hIdx = hi << 2;
      const aIdx = ai << 2;

      const r = fLut[fIdx] + hLut[hIdx] + aLut[aIdx];
      const g = fLut[fIdx + 1] + hLut[hIdx + 1] + aLut[aIdx + 1];
      const b = fLut[fIdx + 2] + hLut[hIdx + 2] + aLut[aIdx + 2];
      const a = Math.max(fLut[fIdx + 3], hLut[hIdx + 3], aLut[aIdx + 3]);

      data[px] = r > 255 ? 255 : r;
      data[px + 1] = g > 255 ? 255 : g;
      data[px + 2] = b > 255 ? 255 : b;
      data[px + 3] = a;
    }
  }
}
