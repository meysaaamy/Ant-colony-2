import {
  AntColonySoA,
  STATE_ALARMED,
  STATE_RETURNING,
} from "./ant-soa-engine";
import { DirtyRect, PheromoneGrid } from "./pheromone-grid";
import { Mulberry32 } from "./prng-noise";
import {
  bakeVignetteGrainOverlay,
  getProceduralAssets,
  ProceduralAssets,
} from "./procedural-assets";
import {
  ActiveStroke,
  FoodCluster,
  NestState,
  SparkParticle,
  SporeMote,
  TOOL_MAP,
} from "./types";

export class SanctuaryRenderer {
  public readonly worldWidth: number;
  public readonly worldHeight: number;
  private readonly assets: ProceduralAssets;

  // Offscreen cached layers
  private terrainCanvas: HTMLCanvasElement;
  private terrainCtx: CanvasRenderingContext2D;
  private soilPattern: CanvasPattern | null = null;
  private basaltPattern: CanvasPattern | null = null;

  private pheromoneCanvas: HTMLCanvasElement;
  private pheromoneCtx: CanvasRenderingContext2D;
  private pheromoneImg: ImageData;

  private bloomCanvas: HTMLCanvasElement;
  private bloomCtx: CanvasRenderingContext2D;

  private vignetteCanvas: HTMLCanvasElement;

  // Ambient spore motes & harvest sparks
  private sporeMotes: SporeMote[] = [];
  private sparks: SparkParticle[] = [];

  // Adaptive Quality Scaler (60-frame rolling window)
  private frameTimes = new Float32Array(60);
  private frameCursor = 0;
  private frameSamples = 0;
  public qualityTier: "high" | "balanced" = "high";
  public currentFps = 60;
  private frameCounter = 0;
  private elapsedTime = 0;

  // Optional 200ms preset crossfade snapshot
  private crossfadeSnapshot: HTMLCanvasElement | null = null;
  private crossfadeTimer = 0;

  constructor(worldWidth: number, worldHeight: number, grid: PheromoneGrid) {
    this.worldWidth = worldWidth;
    this.worldHeight = worldHeight;
    this.assets = getProceduralAssets();

    this.terrainCanvas = document.createElement("canvas");
    this.terrainCanvas.width = worldWidth;
    this.terrainCanvas.height = worldHeight;
    const tCtx = this.terrainCanvas.getContext("2d");
    if (!tCtx) throw new Error("Failed to acquire terrain 2D context");
    this.terrainCtx = tCtx;

    this.soilPattern = this.terrainCtx.createPattern(this.assets.soilTile, "repeat");
    this.basaltPattern = this.terrainCtx.createPattern(this.assets.basaltTile, "repeat");

    this.pheromoneCanvas = document.createElement("canvas");
    this.pheromoneCanvas.width = grid.cols;
    this.pheromoneCanvas.height = grid.rows;
    const pCtx = this.pheromoneCanvas.getContext("2d");
    if (!pCtx) throw new Error("Failed to acquire pheromone 2D context");
    this.pheromoneCtx = pCtx;
    this.pheromoneImg = this.pheromoneCtx.createImageData(grid.cols, grid.rows);

    this.bloomCanvas = document.createElement("canvas");
    this.bloomCanvas.width = Math.max(64, Math.ceil(worldWidth * 0.25));
    this.bloomCanvas.height = Math.max(64, Math.ceil(worldHeight * 0.25));
    const bCtx = this.bloomCanvas.getContext("2d");
    if (!bCtx) throw new Error("Failed to acquire bloom 2D context");
    this.bloomCtx = bCtx;

    this.vignetteCanvas = bakeVignetteGrainOverlay(worldWidth, worldHeight);

    this.initSporeMotes();
    this.rebuildTerrainFull(grid);
  }

  private initSporeMotes(): void {
    const rng = new Mulberry32(8181);
    const tints: Array<"cyan" | "amber" | "emerald"> = ["cyan", "amber", "emerald"];
    this.sporeMotes = [];
    for (let i = 0; i < 40; i++) {
      this.sporeMotes.push({
        x: rng.range(0, this.worldWidth),
        y: rng.range(0, this.worldHeight),
        vx: rng.range(-5, 5),
        vy: rng.range(-7, -1.5),
        radius: rng.range(0.9, 2.2),
        alpha: rng.range(0.16, 0.46),
        phase: rng.range(0, Math.PI * 2),
        tint: tints[i % 3],
      });
    }
  }

  public triggerCrossfade(sourceCanvas: HTMLCanvasElement): void {
    if (!this.crossfadeSnapshot) {
      this.crossfadeSnapshot = document.createElement("canvas");
    }
    this.crossfadeSnapshot.width = sourceCanvas.width;
    this.crossfadeSnapshot.height = sourceCanvas.height;
    const cctx = this.crossfadeSnapshot.getContext("2d");
    if (cctx) {
      cctx.clearRect(0, 0, sourceCanvas.width, sourceCanvas.height);
      cctx.drawImage(sourceCanvas, 0, 0);
      this.crossfadeTimer = 0.2; // 200ms crossfade
    }
  }

  public addSparks(x: number, y: number, color: string, count = 5): void {
    if (this.sparks.length > 140) return;
    for (let i = 0; i < count; i++) {
      const ang = Math.random() * Math.PI * 2;
      const spd = 22 + Math.random() * 58;
      this.sparks.push({
        x,
        y,
        vx: Math.cos(ang) * spd,
        vy: Math.sin(ang) * spd,
        life: 0,
        maxLife: 0.26 + Math.random() * 0.24,
        color,
        size: 1.4 + Math.random() * 1.8,
      });
    }
  }

  public recordFrameDelta(ms: number): void {
    this.frameTimes[this.frameCursor] = ms;
    this.frameCursor = (this.frameCursor + 1) % 60;
    if (this.frameSamples < 60) this.frameSamples++;

    let sum = 0;
    for (let i = 0; i < this.frameSamples; i++) {
      sum += this.frameTimes[i];
    }
    const avgMs = sum / Math.max(1, this.frameSamples);
    this.currentFps = Math.min(120, Math.round(1000 / Math.max(1, avgMs)));

    if (this.frameSamples >= 30) {
      if (avgMs > 20.5) {
        this.qualityTier = "balanced";
      } else if (avgMs < 16.2) {
        this.qualityTier = "high";
      }
    }
  }

  public rebuildTerrainFull(grid: PheromoneGrid): void {
    this.rebuildTerrainDirty(grid, {
      minGx: 0,
      minGy: 0,
      maxGx: grid.cols - 1,
      maxGy: grid.rows - 1,
    });
  }

  public rebuildTerrainDirty(grid: PheromoneGrid, dirty: DirtyRect): void {
    const ctx = this.terrainCtx;
    const cell = grid.cellSize;
    const rx = Math.max(0, (dirty.minGx - 2) * cell);
    const ry = Math.max(0, (dirty.minGy - 2) * cell);
    const rw = Math.min(this.worldWidth - rx, (dirty.maxGx - dirty.minGx + 5) * cell);
    const rh = Math.min(this.worldHeight - ry, (dirty.maxGy - dirty.minGy + 5) * cell);

    if (rw <= 0 || rh <= 0) return;

    ctx.save();
    ctx.beginPath();
    ctx.rect(rx, ry, rw, rh);
    ctx.clip();

    // 1. Dark abyssal soil substrate (#03050a)
    if (this.soilPattern) {
      ctx.fillStyle = this.soilPattern;
    } else {
      ctx.fillStyle = "#03050a";
    }
    ctx.fillRect(rx, ry, rw, rh);

    // 2. Delicate macro mineral / root veins
    ctx.strokeStyle = "rgba(18, 29, 46, 0.24)";
    ctx.lineWidth = 1.2;
    const veinSpacing = 180;
    const startVein = Math.floor(rx / veinSpacing) * veinSpacing;
    for (let vx = startVein; vx < rx + rw + veinSpacing; vx += veinSpacing) {
      ctx.beginPath();
      ctx.moveTo(vx, 0);
      ctx.bezierCurveTo(
        vx + 38,
        this.worldHeight * 0.32,
        vx - 44,
        this.worldHeight * 0.68,
        vx + 16,
        this.worldHeight
      );
      ctx.stroke();
    }

    // 3. Faint scientific coordinate reticles & edge tick marks
    ctx.strokeStyle = "rgba(148, 163, 184, 0.045)";
    ctx.lineWidth = 1;
    const gridStep = 120;
    const gxStart = Math.floor(rx / gridStep) * gridStep;
    const gyStart = Math.floor(ry / gridStep) * gridStep;
    for (let x = gxStart; x <= rx + rw; x += gridStep) {
      ctx.beginPath();
      ctx.moveTo(x, ry);
      ctx.lineTo(x, ry + rh);
      ctx.stroke();
    }
    for (let y = gyStart; y <= ry + rh; y += gridStep) {
      ctx.beginPath();
      ctx.moveTo(rx, y);
      ctx.lineTo(rx + rw, y);
      ctx.stroke();
    }

    // Reticle crosshairs at intersections
    ctx.strokeStyle = "rgba(0, 240, 255, 0.08)";
    for (let x = gxStart; x <= rx + rw; x += gridStep) {
      for (let y = gyStart; y <= ry + rh; y += gridStep) {
        if (x <= 0 || y <= 0) continue;
        ctx.beginPath();
        ctx.moveTo(x - 4, y);
        ctx.lineTo(x + 4, y);
        ctx.moveTo(x, y - 4);
        ctx.lineTo(x, y + 4);
        ctx.stroke();
      }
    }

    // 4. Baked Ambient-Occlusion Halo & Smoothed Organic Basalt Walls
    const sMinX = Math.max(0, dirty.minGx - 2);
    const sMaxX = Math.min(grid.cols - 1, dirty.maxGx + 2);
    const sMinY = Math.max(0, dirty.minGy - 2);
    const sMaxY = Math.min(grid.rows - 1, dirty.maxGy + 2);
    const field = grid.smoothedWallField;
    const cols = grid.cols;

    // AO Halo around walls
    ctx.fillStyle = "rgba(1, 2, 5, 0.52)";
    for (let gy = sMinY; gy <= sMaxY; gy++) {
      for (let gx = sMinX; gx <= sMaxX; gx++) {
        const v = field[gy * cols + gx];
        if (v > 0.14 && v < 0.44) {
          ctx.beginPath();
          ctx.arc((gx + 0.5) * cell, (gy + 0.5) * cell, cell * 0.95, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    }

    // Crisp rim-light bevel (#26354d) on outer contour
    ctx.fillStyle = "#26354d";
    for (let gy = sMinY; gy <= sMaxY; gy++) {
      for (let gx = sMinX; gx <= sMaxX; gx++) {
        const v = field[gy * cols + gx];
        if (v >= 0.42 && v < 0.62) {
          ctx.beginPath();
          ctx.arc((gx + 0.5) * cell, (gy + 0.5) * cell, cell * 0.88, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    }

    // Inner organic basalt/obsidian rock texture (#101622)
    if (this.basaltPattern) {
      ctx.fillStyle = this.basaltPattern;
    } else {
      ctx.fillStyle = "#101622";
    }
    for (let gy = sMinY; gy <= sMaxY; gy++) {
      for (let gx = sMinX; gx <= sMaxX; gx++) {
        const v = field[gy * cols + gx];
        if (v >= 0.52) {
          ctx.beginPath();
          ctx.arc((gx + 0.5) * cell, (gy + 0.5) * cell, cell * 0.82, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    }

    ctx.restore();
  }

  public render(
    mainCtx: CanvasRenderingContext2D,
    canvasWidthPx: number,
    canvasHeightPx: number,
    dt: number,
    grid: PheromoneGrid,
    colony: AntColonySoA,
    nest: NestState,
    clusters: FoodCluster[],
    stroke: ActiveStroke,
    ghostPoint: { x: number; y: number; active: boolean } | null
  ): void {
    this.elapsedTime += dt;
    this.frameCounter++;

    // Update timers
    if (nest.deliveryPulse > 0) nest.deliveryPulse = Math.max(0, nest.deliveryPulse - dt * 2.4);
    if (nest.protectionPulse > 0) nest.protectionPulse = Math.max(0, nest.protectionPulse - dt * 2.2);
    if (stroke.rippleAge > 0) {
      stroke.rippleAge = stroke.rippleAge < 0.45 ? stroke.rippleAge + dt : 0;
    }

    // Update sparks
    for (let i = this.sparks.length - 1; i >= 0; i--) {
      const sp = this.sparks[i];
      sp.life += dt;
      if (sp.life >= sp.maxLife) {
        this.sparks.splice(i, 1);
      } else {
        sp.x += sp.vx * dt;
        sp.y += sp.vy * dt;
        sp.vx *= 0.94;
        sp.vy *= 0.94;
      }
    }

    // Update drifting spore motes
    const activeMotes = this.qualityTier === "high" ? this.sporeMotes.length : 14;
    for (let i = 0; i < activeMotes; i++) {
      const m = this.sporeMotes[i];
      m.x += (m.vx + Math.sin(this.elapsedTime * 0.7 + m.phase) * 2.5) * dt;
      m.y += m.vy * dt;
      if (m.y < -4) m.y = this.worldHeight + 4;
      if (m.x < -4) m.x = this.worldWidth + 4;
      if (m.x > this.worldWidth + 4) m.x = -4;
    }

    // Compute world-to-screen transform (cover / fit seamlessly)
    const scaleX = canvasWidthPx / this.worldWidth;
    const scaleY = canvasHeightPx / this.worldHeight;

    mainCtx.save();
    mainCtx.setTransform(scaleX, 0, 0, scaleY, 0, 0);

    // 1. Static Terrain Cache Canvas
    mainCtx.drawImage(this.terrainCanvas, 0, 0);

    // 2. Pheromone LUT Offscreen Canvas -> 'screen' composite
    grid.renderToImageData(this.pheromoneImg);
    this.pheromoneCtx.putImageData(this.pheromoneImg, 0, 0);

    mainCtx.save();
    mainCtx.globalCompositeOperation = "screen";
    mainCtx.imageSmoothingEnabled = true;
    mainCtx.imageSmoothingQuality = "high";
    mainCtx.drawImage(this.pheromoneCanvas, 0, 0, this.worldWidth, this.worldHeight);
    mainCtx.restore();

    // 3. 1/4-Res Bloom Layer (refreshed every other frame in high quality)
    if (this.qualityTier === "high") {
      if ((this.frameCounter & 1) === 0) {
        this.bloomCtx.clearRect(0, 0, this.bloomCanvas.width, this.bloomCanvas.height);
        this.bloomCtx.drawImage(
          this.pheromoneCanvas,
          0,
          0,
          this.bloomCanvas.width,
          this.bloomCanvas.height
        );
      }
      mainCtx.save();
      mainCtx.globalCompositeOperation = "lighter";
      mainCtx.globalAlpha = 0.42;
      mainCtx.imageSmoothingEnabled = true;
      mainCtx.drawImage(this.bloomCanvas, 0, 0, this.worldWidth, this.worldHeight);
      mainCtx.restore();
    }

    // 4. Faceted Emerald Nutrient Crystals
    this.renderFoodClusters(mainCtx, clusters, dt);

    // 5. Living Nest Crater
    this.renderNest(mainCtx, nest);

    // 6. 3,000 Rotated Ant Sprites
    this.renderAnts(mainCtx, colony);

    // 7. Drifting Spore Motes
    this.renderSporeMotes(mainCtx, activeMotes);

    // 8. Active Stroke Light Ribbon, Ghost Stroke & Sparks
    this.renderSparks(mainCtx);
    this.renderActiveStroke(mainCtx, stroke);
    if (ghostPoint && ghostPoint.active) {
      this.renderGhostPointer(mainCtx, ghostPoint.x, ghostPoint.y);
    }

    // 9. Cached Vignette & Film Grain Overlay
    mainCtx.drawImage(this.vignetteCanvas, 0, 0);

    mainCtx.restore();

    // Optional 200ms Preset Crossfade
    if (this.crossfadeTimer > 0 && this.crossfadeSnapshot) {
      this.crossfadeTimer = Math.max(0, this.crossfadeTimer - dt);
      const alpha = this.crossfadeTimer / 0.2;
      mainCtx.save();
      mainCtx.setTransform(1, 0, 0, 1, 0, 0);
      mainCtx.globalAlpha = alpha;
      mainCtx.drawImage(this.crossfadeSnapshot, 0, 0, canvasWidthPx, canvasHeightPx);
      mainCtx.restore();
    }
  }

  private renderFoodClusters(
    ctx: CanvasRenderingContext2D,
    clusters: FoodCluster[],
    dt: number
  ): void {
    const spriteSize = this.assets.crystalSize;
    for (let i = 0; i < clusters.length; i++) {
      const cl = clusters[i];
      if (cl.glintTimer > 0) cl.glintTimer = Math.max(0, cl.glintTimer - dt);
      if (cl.amount <= 0) {
        // Depleted crystal socket faint outline
        ctx.save();
        ctx.strokeStyle = "rgba(0, 230, 118, 0.14)";
        ctx.lineWidth = 1;
        ctx.setLineDash([3, 4]);
        ctx.beginPath();
        ctx.arc(cl.x, cl.y, cl.radius * 0.55, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
        continue;
      }

      const ratio = Math.max(0.26, Math.sqrt(cl.amount / Math.max(1, cl.maxAmount)));
      const breathe = 1 + Math.sin(this.elapsedTime * 2.1 + cl.phase) * 0.05;
      const drawR = spriteSize * 0.65 * ratio * breathe;

      // Multi-stop radial halo with 'screen' compositing
      ctx.save();
      ctx.globalCompositeOperation = "screen";
      const glowR = drawR * 2.2;
      ctx.globalAlpha = 0.55 + cl.glintTimer * 1.4;
      ctx.drawImage(
        this.assets.glowEmerald,
        cl.x - glowR * 0.5,
        cl.y - glowR * 0.5,
        glowR,
        glowR
      );
      ctx.restore();

      // Faceted crystal cluster sprite
      const sprite = this.assets.crystalVariants[cl.variant % this.assets.crystalVariants.length];
      ctx.drawImage(sprite, cl.x - drawR * 0.5, cl.y - drawR * 0.5, drawR, drawR);

      // Occasional specular glint
      const periodicGlint = Math.sin(this.elapsedTime * 1.6 + cl.phase * 3) > 0.96;
      if (cl.glintTimer > 0 || periodicGlint) {
        ctx.save();
        ctx.globalCompositeOperation = "lighter";
        ctx.strokeStyle = "rgba(225, 255, 236, 0.85)";
        ctx.lineWidth = 1.4;
        const gSize = 5 * ratio;
        ctx.beginPath();
        ctx.moveTo(cl.x - gSize, cl.y);
        ctx.lineTo(cl.x + gSize, cl.y);
        ctx.moveTo(cl.x, cl.y - gSize);
        ctx.lineTo(cl.x, cl.y + gSize);
        ctx.stroke();
        ctx.restore();
      }
    }
  }

  private renderNest(ctx: CanvasRenderingContext2D, nest: NestState): void {
    const heartbeat = 1 + Math.sin(this.elapsedTime * 2.3) * 0.05;
    const pulseBoost = nest.deliveryPulse * 0.35;
    const r = nest.radius * (heartbeat + pulseBoost * 0.25);

    ctx.save();
    ctx.globalCompositeOperation = "screen";
    const cyanSize = r * 4.4;
    ctx.globalAlpha = 0.48 + pulseBoost;
    ctx.drawImage(
      this.assets.glowCyan,
      nest.x - cyanSize * 0.5,
      nest.y - cyanSize * 0.5,
      cyanSize,
      cyanSize
    );
    const amberSize = r * 2.7;
    ctx.globalAlpha = 0.55 + pulseBoost;
    ctx.drawImage(
      this.assets.glowAmber,
      nest.x - amberSize * 0.5,
      nest.y - amberSize * 0.5,
      amberSize,
      amberSize
    );
    ctx.restore();

    // Dark central crater
    const crater = ctx.createRadialGradient(nest.x, nest.y, 2, nest.x, nest.y, r);
    crater.addColorStop(0, "#010205");
    crater.addColorStop(0.6, "#060b14");
    crater.addColorStop(1, "rgba(0, 240, 255, 0.16)");
    ctx.fillStyle = crater;
    ctx.beginPath();
    ctx.arc(nest.x, nest.y, r, 0, Math.PI * 2);
    ctx.fill();

    // Concentric cyan & amber rings
    ctx.strokeStyle = `rgba(0, 240, 255, ${0.52 + pulseBoost})`;
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.arc(nest.x, nest.y, r * 0.96, 0, Math.PI * 2);
    ctx.stroke();

    ctx.strokeStyle = `rgba(255, 174, 0, ${0.65 + pulseBoost})`;
    ctx.lineWidth = 1.3;
    ctx.beginPath();
    ctx.arc(nest.x, nest.y, r * 0.64, 0, Math.PI * 2);
    ctx.stroke();

    // Thin progress arc toward next ant spawn (every 3 stored food)
    const prog = Math.max(0.02, nest.spawnProgress);
    ctx.strokeStyle = "#fff3b0";
    ctx.lineWidth = 2.2;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.arc(
      nest.x,
      nest.y,
      r * 1.18,
      -Math.PI * 0.5,
      -Math.PI * 0.5 + prog * Math.PI * 2
    );
    ctx.stroke();

    // Protective ring shimmer if touched by Eraser
    if (nest.protectionPulse > 0) {
      ctx.save();
      ctx.globalCompositeOperation = "lighter";
      ctx.strokeStyle = `rgba(224, 255, 255, ${nest.protectionPulse * 0.9})`;
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(nest.x, nest.y, r * (1.28 + (1 - nest.protectionPulse) * 0.35), 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }
  }

  private renderAnts(ctx: CanvasRenderingContext2D, colony: AntColonySoA): void {
    const n = colony.activeCount;
    const sheet = this.assets.antSheet;
    const cell = this.assets.antFrameSize;
    const drawSize = 20; // crisp logical world size downscaled from 56px 2x sheet
    const halfDraw = drawSize * 0.5;

    const ax = colony.x;
    const ay = colony.y;
    const aAng = colony.angle;
    const aPhase = colony.legPhase;
    const aState = colony.state;
    const aFood = colony.hasFood;
    const aActive = colony.active;

    for (let i = 0; i < n; i++) {
      if (aActive[i] === 0) continue;
      const frame = (aPhase[i] | 0) & 7;
      const st = aState[i];
      const row = st === STATE_ALARMED ? 2 : aFood[i] === 1 || st === STATE_RETURNING ? 1 : 0;

      ctx.save();
      ctx.translate(ax[i], ay[i]);
      ctx.rotate(aAng[i]);
      ctx.drawImage(
        sheet,
        frame * cell,
        row * cell,
        cell,
        cell,
        -halfDraw,
        -halfDraw,
        drawSize,
        drawSize
      );
      ctx.restore();
    }
  }

  private renderSporeMotes(ctx: CanvasRenderingContext2D, count: number): void {
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    for (let i = 0; i < count; i++) {
      const m = this.sporeMotes[i];
      const pulse = 0.65 + 0.35 * Math.sin(this.elapsedTime * 1.4 + m.phase);
      ctx.globalAlpha = m.alpha * pulse;
      ctx.fillStyle =
        m.tint === "cyan" ? "#00f0ff" : m.tint === "amber" ? "#ffae00" : "#00e676";
      ctx.beginPath();
      ctx.arc(m.x, m.y, m.radius, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }

  private renderSparks(ctx: CanvasRenderingContext2D): void {
    if (this.sparks.length === 0) return;
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    for (let i = 0; i < this.sparks.length; i++) {
      const sp = this.sparks[i];
      const alpha = 1 - sp.life / sp.maxLife;
      ctx.globalAlpha = alpha;
      ctx.fillStyle = sp.color;
      ctx.beginPath();
      ctx.arc(sp.x, sp.y, sp.size * alpha, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }

  private renderActiveStroke(ctx: CanvasRenderingContext2D, stroke: ActiveStroke): void {
    const meta = TOOL_MAP[stroke.tool];

    // Expanding contact ripple at stroke start
    if (stroke.rippleAge > 0) {
      const t = stroke.rippleAge / 0.45;
      ctx.save();
      ctx.globalCompositeOperation = "screen";
      ctx.strokeStyle = meta.accentColor;
      ctx.globalAlpha = (1 - t) * 0.72;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(stroke.rippleX, stroke.rippleY, 10 + t * 44, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }

    if (!stroke.active) return;

    // Dual-core tapered glowing light ribbon along pointer path
    const pts = stroke.points;
    if (pts.length >= 2) {
      ctx.save();
      ctx.globalCompositeOperation = "screen";
      ctx.lineCap = "round";
      ctx.lineJoin = "round";

      const segCount = pts.length - 1;
      for (let i = 0; i < segCount; i++) {
        const p0 = pts[i];
        const p1 = pts[i + 1];
        const progress = (i + 1) / segCount; // tapers at tail, brightest under finger

        // Outer halo
        ctx.strokeStyle = meta.accentColor;
        ctx.globalAlpha = 0.22 * progress;
        ctx.lineWidth = 14 * progress + 3;
        ctx.beginPath();
        ctx.moveTo(p0.x, p0.y);
        ctx.lineTo(p1.x, p1.y);
        ctx.stroke();

        // Incandescent core filament
        ctx.strokeStyle = meta.coreColor;
        ctx.globalAlpha = 0.78 * progress;
        ctx.lineWidth = 3.2 * progress + 1;
        ctx.beginPath();
        ctx.moveTo(p0.x, p0.y);
        ctx.lineTo(p1.x, p1.y);
        ctx.stroke();
      }
      ctx.restore();
    }

    // Dynamic Brush Ring under finger
    ctx.save();
    ctx.globalCompositeOperation = "screen";
    const ringRadius = Math.max(12, 22);
    if (stroke.tool === "eraser") {
      ctx.translate(stroke.lastX, stroke.lastY);
      ctx.rotate(this.elapsedTime * 1.8);
      ctx.strokeStyle = "#e2e8f0";
      ctx.lineWidth = 1.6;
      ctx.setLineDash([5, 5]);
      ctx.beginPath();
      ctx.arc(0, 0, ringRadius, 0, Math.PI * 2);
      ctx.stroke();
    } else {
      ctx.strokeStyle = meta.accentColor;
      ctx.lineWidth = 1.8;
      ctx.beginPath();
      ctx.arc(stroke.lastX, stroke.lastY, ringRadius, 0, Math.PI * 2);
      ctx.stroke();

      ctx.fillStyle = meta.coreColor;
      ctx.globalAlpha = 0.28;
      ctx.beginPath();
      ctx.arc(stroke.lastX, stroke.lastY, 4.5, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }

  private renderGhostPointer(ctx: CanvasRenderingContext2D, x: number, y: number): void {
    ctx.save();
    ctx.globalCompositeOperation = "screen";
    const pulse = 0.7 + 0.3 * Math.sin(this.elapsedTime * 5);
    ctx.globalAlpha = 0.85 * pulse;
    ctx.drawImage(this.assets.glowAmber, x - 26, y - 26, 52, 52);
    ctx.strokeStyle = "#fff3b0";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(x, y, 12, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }
}
