import { PheromoneGrid } from "./pheromone-grid";
import { Mulberry32 } from "./prng-noise";
import { FoodCluster, NestState, SimulationConfig } from "./types";

export const MAX_ANTS = 3000;
export const STATE_FORAGING = 0;
export const STATE_RETURNING = 1;
export const STATE_ALARMED = 2;

const BASE_SPEED = 74; // logical units / sec
const SPATIAL_CELL = 24;
const HOF_CAPACITY = 64;

function clamp(v: number, min: number, max: number): number {
  return v < min ? min : v > max ? max : v;
}

export interface HarvestSparkEvent {
  x: number;
  y: number;
}

export class AntColonySoA {
  public readonly worldWidth: number;
  public readonly worldHeight: number;
  public activeCount = 0;

  // Core kinematics & physiology SoA
  public readonly x = new Float32Array(MAX_ANTS);
  public readonly y = new Float32Array(MAX_ANTS);
  public readonly vx = new Float32Array(MAX_ANTS);
  public readonly vy = new Float32Array(MAX_ANTS);
  public readonly angle = new Float32Array(MAX_ANTS);
  public readonly homeDx = new Float32Array(MAX_ANTS);
  public readonly homeDy = new Float32Array(MAX_ANTS);
  public readonly legPhase = new Float32Array(MAX_ANTS);
  public readonly pheromoneTimer = new Float32Array(MAX_ANTS);
  public readonly timeSinceLastVisit = new Float32Array(MAX_ANTS);
  public readonly wanderAngle = new Float32Array(MAX_ANTS);
  public readonly state = new Uint8Array(MAX_ANTS);
  public readonly hasFood = new Uint8Array(MAX_ANTS);
  public readonly active = new Uint8Array(MAX_ANTS);

  // RL Adaptive Agent Brain (Learnable Policy Weights)
  public readonly wTrailCommit = new Float32Array(MAX_ANTS);
  public readonly wCuriosity = new Float32Array(MAX_ANTS);
  public readonly wForesight = new Float32Array(MAX_ANTS);
  public readonly wMemoryTrust = new Float32Array(MAX_ANTS);
  public readonly wNegFeedback = new Float32Array(MAX_ANTS);

  // RL Fitness, Traces, Stagnation & Trail-Damping
  public readonly fitness = new Float32Array(MAX_ANTS);
  public readonly tripTime = new Float32Array(MAX_ANTS);
  public readonly tripDistance = new Float32Array(MAX_ANTS);
  public readonly straightLineRef = new Float32Array(MAX_ANTS);
  public readonly lastProgressX = new Float32Array(MAX_ANTS);
  public readonly lastProgressY = new Float32Array(MAX_ANTS);
  public readonly stagnationTimer = new Float32Array(MAX_ANTS);
  public readonly wallContourDir = new Int8Array(MAX_ANTS);
  public readonly eligibilityTurn = new Float32Array(MAX_ANTS);
  public readonly dampingMode = new Uint8Array(MAX_ANTS);
  public readonly generation = new Uint16Array(MAX_ANTS);
  public readonly exciteTimer = new Float32Array(MAX_ANTS);

  // O(1) Spatial Hash Grid
  private readonly hashCols: number;
  private readonly hashRows: number;
  private readonly head: Int32Array;
  private readonly next = new Int32Array(MAX_ANTS);

  // Hall of Fame (Top Elites Pool)
  private readonly hofFitness = new Float32Array(HOF_CAPACITY);
  private readonly hofTrailCommit = new Float32Array(HOF_CAPACITY);
  private readonly hofCuriosity = new Float32Array(HOF_CAPACITY);
  private readonly hofForesight = new Float32Array(HOF_CAPACITY);
  private readonly hofMemoryTrust = new Float32Array(HOF_CAPACITY);
  private readonly hofNegFeedback = new Float32Array(HOF_CAPACITY);
  public hofCount = 0;
  public maxGeneration = 1;
  public eliteScore = 0;
  public avgFitness = 0;
  public avgTrailCommit = 1.0;
  public avgCuriosity = 0.7;
  public avgForesight = 1.0;

  // Colony signals for UI
  public foodDeliveredJustHappened = false;
  public capacityReachedEvent = false;
  private capacityNotified = false;

  private rng = new Mulberry32(42077);

  constructor(worldWidth: number, worldHeight: number) {
    this.worldWidth = worldWidth;
    this.worldHeight = worldHeight;
    this.hashCols = Math.ceil(worldWidth / SPATIAL_CELL);
    this.hashRows = Math.ceil(worldHeight / SPATIAL_CELL);
    this.head = new Int32Array(this.hashCols * this.hashRows);
  }

  public reset(initialCount: number, nest: NestState): void {
    this.active.fill(0);
    this.hofCount = 0;
    this.hofFitness.fill(0);
    this.maxGeneration = 1;
    this.eliteScore = 0;
    this.avgFitness = 0;
    this.capacityNotified = false;
    this.foodDeliveredJustHappened = false;
    this.capacityReachedEvent = false;

    const count = Math.min(MAX_ANTS, initialCount);
    this.activeCount = count;
    this.rng = new Mulberry32(42077);

    for (let i = 0; i < count; i++) {
      this.spawnAntAtNest(i, nest, 1);
    }
  }

  private spawnAntAtNest(i: number, nest: NestState, gen: number): void {
    const a = this.rng.range(0, Math.PI * 2);
    const r = this.rng.range(2, Math.max(6, nest.radius * 0.65));
    const px = clamp(nest.x + Math.cos(a) * r, 8, this.worldWidth - 8);
    const py = clamp(nest.y + Math.sin(a) * r, 8, this.worldHeight - 8);

    this.x[i] = px;
    this.y[i] = py;
    this.angle[i] = a;
    this.vx[i] = Math.cos(a) * BASE_SPEED;
    this.vy[i] = Math.sin(a) * BASE_SPEED;
    this.homeDx[i] = px - nest.x;
    this.homeDy[i] = py - nest.y;
    this.legPhase[i] = this.rng.range(0, 8);
    this.pheromoneTimer[i] = this.rng.range(0, 0.08);
    this.timeSinceLastVisit[i] = 0;
    this.wanderAngle[i] = 0;
    this.state[i] = STATE_FORAGING;
    this.hasFood[i] = 0;
    this.active[i] = 1;

    this.tripTime[i] = 0;
    this.tripDistance[i] = 0;
    this.straightLineRef[i] = 0;
    this.lastProgressX[i] = px;
    this.lastProgressY[i] = py;
    this.stagnationTimer[i] = 0;
    this.wallContourDir[i] = this.rng.next() > 0.5 ? 1 : -1;
    this.eligibilityTurn[i] = 0;
    this.dampingMode[i] = 0;
    this.exciteTimer[i] = 0;
    this.fitness[i] = 0;

    if (this.hofCount >= 2) {
      // Cross-breed & mutate two Hall-of-Fame elites
      const p1 = (this.rng.next() * this.hofCount) | 0;
      const p2 = (this.rng.next() * this.hofCount) | 0;
      const mix = this.rng.next();
      this.wTrailCommit[i] = clamp(
        this.hofTrailCommit[p1] * mix + this.hofTrailCommit[p2] * (1 - mix) + this.rng.range(-0.08, 0.08),
        0.35,
        2.25
      );
      this.wCuriosity[i] = clamp(
        this.hofCuriosity[p1] * mix + this.hofCuriosity[p2] * (1 - mix) + this.rng.range(-0.06, 0.06),
        0.15,
        1.6
      );
      this.wForesight[i] = clamp(
        this.hofForesight[p1] * mix + this.hofForesight[p2] * (1 - mix) + this.rng.range(-0.08, 0.08),
        0.4,
        2.2
      );
      this.wMemoryTrust[i] = clamp(
        this.hofMemoryTrust[p1] * mix + this.hofMemoryTrust[p2] * (1 - mix) + this.rng.range(-0.07, 0.07),
        0.2,
        1.8
      );
      this.wNegFeedback[i] = clamp(
        this.hofNegFeedback[p1] * mix + this.hofNegFeedback[p2] * (1 - mix) + this.rng.range(-0.07, 0.07),
        0.3,
        2.0
      );
      this.generation[i] = Math.max(gen, this.maxGeneration);
    } else {
      this.wTrailCommit[i] = clamp(1.0 + this.rng.range(-0.22, 0.22), 0.35, 2.25);
      this.wCuriosity[i] = clamp(0.7 + this.rng.range(-0.2, 0.2), 0.15, 1.6);
      this.wForesight[i] = clamp(1.0 + this.rng.range(-0.2, 0.2), 0.4, 2.2);
      this.wMemoryTrust[i] = clamp(1.0 + this.rng.range(-0.2, 0.2), 0.2, 1.8);
      this.wNegFeedback[i] = clamp(1.0 + this.rng.range(-0.2, 0.2), 0.3, 2.0);
      this.generation[i] = gen;
    }
  }

  private recordElite(i: number, score: number): void {
    if (score <= 0) return;
    if (score > this.eliteScore) this.eliteScore = score;

    if (this.hofCount < HOF_CAPACITY) {
      const idx = this.hofCount++;
      this.hofFitness[idx] = score;
      this.hofTrailCommit[idx] = this.wTrailCommit[i];
      this.hofCuriosity[idx] = this.wCuriosity[i];
      this.hofForesight[idx] = this.wForesight[i];
      this.hofMemoryTrust[idx] = this.wMemoryTrust[i];
      this.hofNegFeedback[idx] = this.wNegFeedback[i];
      return;
    }

    // Replace lowest-scoring slot if beaten
    let minIdx = 0;
    let minVal = this.hofFitness[0];
    for (let k = 1; k < HOF_CAPACITY; k++) {
      if (this.hofFitness[k] < minVal) {
        minVal = this.hofFitness[k];
        minIdx = k;
      }
    }
    if (score > minVal) {
      this.hofFitness[minIdx] = score;
      this.hofTrailCommit[minIdx] = this.wTrailCommit[i];
      this.hofCuriosity[minIdx] = this.wCuriosity[i];
      this.hofForesight[minIdx] = this.wForesight[i];
      this.hofMemoryTrust[minIdx] = this.wMemoryTrust[i];
      this.hofNegFeedback[minIdx] = this.wNegFeedback[i];
    }
  }

  public trySpawnFromStoredFood(nest: NestState, maxCap: number): boolean {
    if (this.activeCount >= Math.min(MAX_ANTS, maxCap)) {
      if (!this.capacityNotified) {
        this.capacityNotified = true;
        this.capacityReachedEvent = true;
      }
      return false;
    }
    this.capacityNotified = false;
    const idx = this.activeCount++;
    const nextGen = this.hofCount >= 2 ? this.maxGeneration + 1 : this.maxGeneration;
    if (nextGen > this.maxGeneration && idx % 10 === 0) {
      this.maxGeneration = nextGen;
    }
    this.spawnAntAtNest(idx, nest, this.maxGeneration);
    return true;
  }

  /**
   * Safely ejects any ants trapped inside newly painted basalt walls
   * to the nearest open cell using an expanding spiral search.
   */
  public ejectAntsFromWalls(grid: PheromoneGrid): void {
    const n = this.activeCount;
    const cell = grid.cellSize;
    for (let i = 0; i < n; i++) {
      if (this.active[i] === 0) continue;
      const ax = this.x[i];
      const ay = this.y[i];
      if (!grid.isWallAtWorld(ax, ay)) continue;

      let found = false;
      for (let r = 1; r <= 18 && !found; r++) {
        const radius = r * cell;
        const samples = 8 + r * 4;
        for (let s = 0; s < samples; s++) {
          const ang = (s / samples) * Math.PI * 2;
          const cx = ax + Math.cos(ang) * radius;
          const cy = ay + Math.sin(ang) * radius;
          if (
            cx >= 8 &&
            cy >= 8 &&
            cx <= this.worldWidth - 8 &&
            cy <= this.worldHeight - 8 &&
            !grid.isWallAtWorld(cx, cy)
          ) {
            this.x[i] = cx;
            this.y[i] = cy;
            this.angle[i] = ang;
            found = true;
            break;
          }
        }
      }
    }
  }

  public step(
    dt: number,
    config: SimulationConfig,
    grid: PheromoneGrid,
    nest: NestState,
    clusters: FoodCluster[],
    onHarvestSpark?: (x: number, y: number) => void
  ): void {
    const cap = Math.min(MAX_ANTS, config.maxAnts);
    if (this.activeCount > cap) {
      this.activeCount = cap;
    }
    const n = this.activeCount;
    if (n === 0) return;

    // 1. Rebuild O(1) Spatial Hash Grid
    this.head.fill(-1);
    const hCols = this.hashCols;
    const hRows = this.hashRows;
    for (let i = 0; i < n; i++) {
      if (this.active[i] === 0) continue;
      let gx = (this.x[i] / SPATIAL_CELL) | 0;
      let gy = (this.y[i] / SPATIAL_CELL) | 0;
      if (gx < 0) gx = 0;
      else if (gx >= hCols) gx = hCols - 1;
      if (gy < 0) gy = 0;
      else if (gy >= hRows) gy = hRows - 1;
      const cellIdx = gy * hCols + gx;
      this.next[i] = this.head[cellIdx];
      this.head[cellIdx] = i;
    }

    const sensorAngleRad = (config.antennaAngleDeg * Math.PI) / 180;
    const sensorDist = 17.5;
    const sensitivity = config.trailSensitivity;
    const maxTurnRate = 6.2; // rad/sec
    const halfW = this.worldWidth - 6;
    const halfH = this.worldHeight - 6;

    let sumFitness = 0;
    let sumTrailCommit = 0;
    let sumCuriosity = 0;
    let sumForesight = 0;

    for (let i = 0; i < n; i++) {
      if (this.active[i] === 0) continue;

      let px = this.x[i];
      let py = this.y[i];
      let ang = this.angle[i];
      let st = this.state[i];

      this.timeSinceLastVisit[i] += dt;
      this.tripTime[i] += dt;
      if (this.exciteTimer[i] > 0) {
        this.exciteTimer[i] = Math.max(0, this.exciteTimer[i] - dt);
      }

      // Sample alarm directly under & ahead of ant
      const localAlarm = grid.sampleChannel("alarm", px, py);
      if (localAlarm > 2.2) {
        st = STATE_ALARMED;
        this.state[i] = STATE_ALARMED;
      } else if (st === STATE_ALARMED && localAlarm < 0.7) {
        st = this.hasFood[i] === 1 ? STATE_RETURNING : STATE_FORAGING;
        this.state[i] = st;
      }

      // Bilateral Tropotaxis Antenna Sensing (Left, Center, Right) with Wall Line-of-Sight
      const foresightDist = sensorDist * (0.85 + 0.35 * this.wForesight[i]);
      const angL = ang - sensorAngleRad;
      const angR = ang + sensorAngleRad;

      const lx = px + Math.cos(angL) * sensorDist;
      const ly = py + Math.sin(angL) * sensorDist;
      const cx = px + Math.cos(ang) * foresightDist;
      const cy = py + Math.sin(ang) * foresightDist;
      const rx = px + Math.cos(angR) * sensorDist;
      const ry = py + Math.sin(angR) * sensorDist;

      const losL = grid.hasLineOfSight(px, py, lx, ly);
      const losC = grid.hasLineOfSight(px, py, cx, cy);
      const losR = grid.hasLineOfSight(px, py, rx, ry);

      // Select chemical target based on behavioral state
      const targetChannel =
        st === STATE_RETURNING ? "homeGuide" : st === STATE_ALARMED ? "alarm" : "foodTrail";

      const rawL = losL ? grid.sampleChannel(targetChannel, lx, ly) : 0;
      const rawC = losC ? grid.sampleChannel(targetChannel, cx, cy) : 0;
      const rawR = losR ? grid.sampleChannel(targetChannel, rx, ry) : 0;

      // Weber-Fechner Law: perceived neural stimulus S = ln(1 + C)
      const sL = Math.log(1.0 + rawL);
      const sC = Math.log(1.0 + rawC);
      const sR = Math.log(1.0 + rawR);

      // Also sense alarm ahead to steer evasively
      const alarmL = losL ? Math.log(1.0 + grid.sampleChannel("alarm", lx, ly)) : 0;
      const alarmR = losR ? Math.log(1.0 + grid.sampleChannel("alarm", rx, ry)) : 0;

      let steerTorque = 0;

      if (st === STATE_ALARMED) {
        // Klinokinesis + repulsive steering away from alarm gradient
        steerTorque += (alarmL - alarmR) * 2.8;
      } else if (st === STATE_FORAGING) {
        const diff = sR - sL;
        const commit = sensitivity * this.wTrailCommit[i];
        steerTorque += diff * commit * (1.0 + 0.35 * sC);

        // Highway bonus: staying inside validated trail core
        if (sC > 1.2 && losC) {
          this.fitness[i] += 0.35 * dt;
        }

        // Repulsive alarm avoidance
        if (alarmL + alarmR > 0.4) {
          steerTorque += (alarmL - alarmR) * 2.2 * this.wNegFeedback[i];
        }
      } else if (st === STATE_RETURNING) {
        // Blend path integration vector with homeGuide pheromone gradient
        const toHomeX = -this.homeDx[i];
        const toHomeY = -this.homeDy[i];
        const homeDist = Math.hypot(toHomeX, toHomeY);
        const homeBearing = homeDist > 1e-3 ? Math.atan2(toHomeY, toHomeX) : ang;
        let angleErr = homeBearing - ang;
        while (angleErr > Math.PI) angleErr -= Math.PI * 2;
        while (angleErr < -Math.PI) angleErr += Math.PI * 2;

        // If near nest, lock directly onto nest beacon
        const distToNest = Math.hypot(nest.x - px, nest.y - py);
        if (distToNest < nest.radius * 4.2) {
          const directAng = Math.atan2(nest.y - py, nest.x - px);
          let dErr = directAng - ang;
          while (dErr > Math.PI) dErr -= Math.PI * 2;
          while (dErr < -Math.PI) dErr += Math.PI * 2;
          steerTorque += dErr * 3.8;
        } else {
          // Shift blend weight toward homeGuide when chemical signal is strong
          const chemStrength = Math.min(1, (sL + sC + sR) * 0.22);
          const piWeight = this.wMemoryTrust[i] * (1.0 - 0.55 * chemStrength);
          const chemWeight = sensitivity * (0.55 + 0.75 * chemStrength);
          steerTorque += angleErr * piWeight * 1.45;
          steerTorque += (sR - sL) * chemWeight * (1.0 + 0.25 * sC);
        }

        if (alarmL + alarmR > 0.4) {
          steerTorque += (alarmL - alarmR) * 2.0 * this.wNegFeedback[i];
        }
      }

      // Obstacle Foresight: initiate smooth tangent turns BEFORE hitting walls
      if (!losC) {
        const clearPush = (losR ? 1 : 0) - (losL ? 1 : 0);
        if (clearPush !== 0) {
          steerTorque += clearPush * 2.6 * this.wForesight[i];
        } else {
          steerTorque += this.wallContourDir[i] * 2.4 * this.wForesight[i];
        }
      } else if (!losL && losR) {
        steerTorque += 1.3 * this.wForesight[i];
      } else if (!losR && losL) {
        steerTorque -= 1.3 * this.wForesight[i];
      }

      // Persistent Ornstein-Uhlenbeck wander noise (scaled by Curiosity & inverse trail confidence)
      const ouTheta = 3.2;
      const trailConfidence = Math.min(1, sC * 0.35);
      const curiosityBoost = st === STATE_FORAGING ? this.wCuriosity[i] * (1.0 - 0.68 * trailConfidence) : 0.22;
      const ouSigma = 2.8 * (0.4 + curiosityBoost);
      const rnd = (this.rng.next() - 0.5) * 2.0;
      this.wanderAngle[i] += -ouTheta * this.wanderAngle[i] * dt + ouSigma * Math.sqrt(dt) * rnd;
      steerTorque += this.wanderAngle[i];

      // Spatial Hash neighbor separation + Antennation & Elite Social Learning
      const hgx = clamp((px / SPATIAL_CELL) | 0, 0, hCols - 1);
      const hgy = clamp((py / SPATIAL_CELL) | 0, 0, hRows - 1);
      let sepX = 0;
      let sepY = 0;

      for (let oy = -1; oy <= 1; oy++) {
        const ny = hgy + oy;
        if (ny < 0 || ny >= hRows) continue;
        for (let ox = -1; ox <= 1; ox++) {
          const nx = hgx + ox;
          if (nx < 0 || nx >= hCols) continue;
          let other = this.head[ny * hCols + nx];
          let checks = 0;
          while (other !== -1 && checks < 8) {
            if (other !== i) {
              const dx = px - this.x[other];
              const dy = py - this.y[other];
              const d2 = dx * dx + dy * dy;
              if (d2 > 0.01 && d2 < 64) {
                const d = Math.sqrt(d2);
                const push = (8 - d) / 8;
                sepX += (dx / d) * push;
                sepY += (dy / d) * push;
              }
              // Antennation & Social Information Transfer
              if (d2 < 144) {
                if (st === STATE_FORAGING && this.state[other] === STATE_RETURNING && this.hasFood[other] === 1) {
                  // Excitement boost & alignment nudge toward returning ant's origin
                  this.exciteTimer[i] = 0.75;
                  const targetAng = this.angle[other] + Math.PI;
                  let aDiff = targetAng - ang;
                  while (aDiff > Math.PI) aDiff -= Math.PI * 2;
                  while (aDiff < -Math.PI) aDiff += Math.PI * 2;
                  steerTorque += aDiff * 0.45;
                  // Returning ant gets Social Antennation Reward
                  this.fitness[other] += 0.25;
                }
                // Elite Social Learning: weaker ant blends toward higher-scoring neighbor
                if (this.fitness[other] > this.fitness[i] + 3.0) {
                  const blend = 0.025;
                  this.wTrailCommit[i] += (this.wTrailCommit[other] - this.wTrailCommit[i]) * blend;
                  this.wForesight[i] += (this.wForesight[other] - this.wForesight[i]) * blend;
                  this.wMemoryTrust[i] += (this.wMemoryTrust[other] - this.wMemoryTrust[i]) * blend;
                }
              }
            }
            other = this.next[other];
            checks++;
          }
        }
      }

      if (sepX !== 0 || sepY !== 0) {
        const sepAng = Math.atan2(sepY, sepX);
        let sErr = sepAng - ang;
        while (sErr > Math.PI) sErr -= Math.PI * 2;
        while (sErr < -Math.PI) sErr += Math.PI * 2;
        steerTorque += sErr * 0.6;
      }

      // Clamp steering & record eligibility trace
      steerTorque = clamp(steerTorque, -maxTurnRate, maxTurnRate);
      this.eligibilityTurn[i] = this.eligibilityTurn[i] * 0.86 + steerTorque * 0.14;
      ang += steerTorque * dt;

      // Orthokinesis speed modulation
      let speed = BASE_SPEED;
      if (st === STATE_ALARMED) {
        speed *= 1.55; // evasive orthokinesis burst
      } else if (this.exciteTimer[i] > 0) {
        speed *= 1.24; // antennation excitement boost
      } else if (sC > 0.8) {
        speed *= 1.12; // confident highway stride
      }

      const stepDist = speed * dt;
      const moveX = Math.cos(ang) * stepDist;
      const moveY = Math.sin(ang) * stepDist;
      let nextX = px + moveX;
      let nextY = py + moveY;

      // Smooth tangent wall collision + sub-stepped raycast + RL Wall-Scraping Penalty
      let collided = false;
      const midX = px + moveX * 0.5;
      const midY = py + moveY * 0.5;

      if (
        nextX < 6 ||
        nextX > halfW ||
        nextY < 6 ||
        nextY > halfH ||
        grid.isWallAtWorld(midX, midY) ||
        grid.isWallAtWorld(nextX, nextY)
      ) {
        collided = true;
        // Try smooth tangent slide along X or Y independently
        const canX = nextX >= 6 && nextX <= halfW && !grid.isWallAtWorld(nextX, py);
        const canY = nextY >= 6 && nextY <= halfH && !grid.isWallAtWorld(px, nextY);

        if (canX && !canY) {
          nextY = py;
          ang = Math.atan2(0, moveX);
        } else if (canY && !canX) {
          nextX = px;
          ang = Math.atan2(moveY, 0);
        } else {
          // Bounce + flip contour direction
          nextX = px;
          nextY = py;
          ang += this.wallContourDir[i] * 1.45 + this.rng.range(-0.35, 0.35);
          this.wallContourDir[i] = (this.wallContourDir[i] * -1) as 1 | -1;
        }

        // RL Wall-Scraping & Corner-Trap Penalty: increase Obstacle Foresight
        this.fitness[i] -= 0.45 * this.wNegFeedback[i];
        this.wForesight[i] = clamp(this.wForesight[i] + 0.045 * this.wNegFeedback[i], 0.4, 2.2);
      }

      // Keep angle normalized [-PI, PI]
      if (ang > Math.PI) ang -= Math.PI * 2;
      else if (ang < -Math.PI) ang += Math.PI * 2;

      const actualDx = nextX - px;
      const actualDy = nextY - py;
      const actualMove = Math.hypot(actualDx, actualDy);

      px = nextX;
      py = nextY;
      this.x[i] = px;
      this.y[i] = py;
      this.vx[i] = actualDx / dt;
      this.vy[i] = actualDy / dt;
      this.angle[i] = ang;
      this.legPhase[i] = (this.legPhase[i] + actualMove * 0.24) % 8;
      this.tripDistance[i] += actualMove;

      // Update noisy path-integration dead reckoning vector
      const piNoise = 1.0 + this.rng.range(-0.015, 0.015);
      this.homeDx[i] += actualDx * piNoise;
      this.homeDy[i] += actualDy * piNoise;

      // Looping & Stagnation Penalty (check every 1.2s of trip)
      this.stagnationTimer[i] += dt;
      if (this.stagnationTimer[i] >= 1.2) {
        const progress = Math.hypot(px - this.lastProgressX[i], py - this.lastProgressY[i]);
        if (progress < 18 && !collided) {
          // Ant is looping or stuck: apply penalty + breakout turn
          this.fitness[i] -= 1.2 * this.wNegFeedback[i];
          ang += this.wallContourDir[i] * 2.1;
          this.angle[i] = ang;
          this.wCuriosity[i] = clamp(this.wCuriosity[i] + 0.04, 0.15, 1.6);
        }
        this.lastProgressX[i] = px;
        this.lastProgressY[i] = py;
        this.stagnationTimer[i] = 0;
      }

      // Metabolic Timeout Penalty
      if (this.tripTime[i] > 26 && st === STATE_FORAGING) {
        this.fitness[i] -= 0.15 * dt;
      }

      // Pheromone Deposition & Trail-Damping Mode
      this.pheromoneTimer[i] += dt;
      if (this.pheromoneTimer[i] >= 0.065) {
        this.pheromoneTimer[i] = 0;
        const ageFactor = Math.exp(-0.032 * this.timeSinceLastVisit[i]);
        if (st === STATE_RETURNING) {
          if (this.dampingMode[i] === 1) {
            // Depleted-Food False-Trail Extinction: cancel obsolete food trail!
            grid.dampFoodTrailAtWorld(px, py, 16, 0.55);
          } else if (this.hasFood[i] === 1) {
            grid.depositAtWorld("foodTrail", px, py, 12.5, ageFactor);
          }
        } else if (st === STATE_FORAGING) {
          grid.depositAtWorld("homeGuide", px, py, 5.2, ageFactor);
        }
      }

      // Check interactions with Emerald Food Clusters
      if (st === STATE_FORAGING && this.hasFood[i] === 0) {
        for (let c = 0; c < clusters.length; c++) {
          const cl = clusters[c];
          const dx = px - cl.x;
          const dy = py - cl.y;
          const hitR = cl.radius + 7;
          if (dx * dx + dy * dy <= hitR * hitR) {
            if (cl.amount > 0) {
              // Harvest 1 nutrient crystal unit
              cl.amount -= 1;
              cl.glintTimer = 0.25;
              this.hasFood[i] = 1;
              this.state[i] = STATE_RETURNING;
              this.dampingMode[i] = 0;
              this.timeSinceLastVisit[i] = 0;
              this.straightLineRef[i] = Math.hypot(px - nest.x, py - nest.y);
              this.tripDistance[i] = 0;
              this.tripTime[i] = 0;
              this.angle[i] = ang + Math.PI; // Reverse smoothly toward home

              // First-Discovery Pioneer Bonus if weak trail around crystal
              const existingFoodTrail = grid.sampleChannel("foodTrail", px, py);
              if (existingFoodTrail < 1.2) {
                this.fitness[i] += 8.5;
                this.wCuriosity[i] = clamp(this.wCuriosity[i] + 0.05, 0.15, 1.6);
              }
              if (onHarvestSpark) {
                onHarvestSpark(px, py);
              }
              break;
            } else {
              // Depleted-Food / False-Trail Penalty & Trail-Damping Mode!
              const localTrail = grid.sampleChannel("foodTrail", px, py);
              if (localTrail > 1.0) {
                this.fitness[i] -= 3.5 * this.wNegFeedback[i];
                this.dampingMode[i] = 1;
                this.state[i] = STATE_RETURNING;
                this.hasFood[i] = 0;
                this.timeSinceLastVisit[i] = 0;
                this.angle[i] = ang + Math.PI;
                break;
              }
            }
          }
        }
      }

      // Check delivery / reset at the Nest
      if (st === STATE_RETURNING || this.dampingMode[i] === 1) {
        const ndx = px - nest.x;
        const ndy = py - nest.y;
        const nestHit = nest.radius + 5;
        if (ndx * ndx + ndy * ndy <= nestHit * nestHit) {
          if (this.hasFood[i] === 1) {
            // Deliver food to Nest!
            nest.storedFood += 1;
            nest.spawnProgress = (nest.storedFood % 3) / 3;
            nest.deliveryPulse = 1.0;
            this.foodDeliveredJustHappened = true;

            // Shortest-Path Efficiency Jackpot Reward
            const straight = Math.max(20, this.straightLineRef[i]);
            const actual = Math.max(straight, this.tripDistance[i]);
            const efficiency = clamp(straight / actual, 0.1, 1.0);
            const jackpot = 18.0 * efficiency + Math.max(0, 10.0 - this.tripTime[i] * 0.35);
            this.fitness[i] += jackpot;

            // Eligibility trace reinforcement
            if (efficiency > 0.68) {
              this.wTrailCommit[i] = clamp(this.wTrailCommit[i] + 0.06, 0.35, 2.25);
              this.wMemoryTrust[i] = clamp(this.wMemoryTrust[i] + 0.04, 0.2, 1.8);
            }

            this.recordElite(i, this.fitness[i]);

            // Spawn 1 new ant every 3 stored food units
            if (nest.storedFood % 3 === 0) {
              this.trySpawnFromStoredFood(nest, cap);
            }
          }

          // Reset path integration, stamina, and resume foraging
          this.hasFood[i] = 0;
          this.dampingMode[i] = 0;
          this.state[i] = STATE_FORAGING;
          this.homeDx[i] = px - nest.x;
          this.homeDy[i] = py - nest.y;
          this.timeSinceLastVisit[i] = 0;
          this.tripTime[i] = 0;
          this.tripDistance[i] = 0;
          this.angle[i] = ang + Math.PI;
        }
      }

      sumFitness += this.fitness[i];
      sumTrailCommit += this.wTrailCommit[i];
      sumCuriosity += this.wCuriosity[i];
      sumForesight += this.wForesight[i];
    }

    if (n > 0) {
      this.avgFitness = sumFitness / n;
      this.avgTrailCommit = sumTrailCommit / n;
      this.avgCuriosity = sumCuriosity / n;
      this.avgForesight = sumForesight / n;
    }
  }
}
