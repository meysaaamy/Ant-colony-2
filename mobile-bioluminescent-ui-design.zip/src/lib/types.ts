export type ToolId =
  | "food-trail"
  | "home-trail"
  | "alarm"
  | "food-cluster"
  | "wall"
  | "eraser";

export type PresetId =
  | "open-sanctuary"
  | "double-bridge"
  | "subterranean-labyrinth";

export type SimSpeed = 1 | 2 | 4;

export type SheetSnap = "peek" | "half" | "full";

export type ParameterTab = "colony" | "pheromones" | "brush" | "world";

export interface ToolMetadata {
  id: ToolId;
  index: number;
  label: string;
  coreColor: string;
  accentColor: string;
  ambientColor: string;
  firstUseCaption: string;
}

export const TOOL_LIST: ToolMetadata[] = [
  {
    id: "food-trail",
    index: 1,
    label: "Food trail",
    coreColor: "#fff3b0",
    accentColor: "#ffae00",
    ambientColor: "rgba(255, 174, 0, 0.18)",
    firstUseCaption: "Amber food scent recruits foragers outward along your stroke.",
  },
  {
    id: "home-trail",
    index: 2,
    label: "Home trail",
    coreColor: "#e0ffff",
    accentColor: "#00f0ff",
    ambientColor: "rgba(0, 240, 255, 0.18)",
    firstUseCaption: "Cyan orientation scent guides returning carriers homeward.",
  },
  {
    id: "alarm",
    index: 3,
    label: "Alarm",
    coreColor: "#ffd1dc",
    accentColor: "#ff0a43",
    ambientColor: "rgba(255, 10, 67, 0.18)",
    firstUseCaption: "Alarm scares ants away from this spot and disperses trails.",
  },
  {
    id: "food-cluster",
    index: 4,
    label: "Food cluster",
    coreColor: "#b9f6ca",
    accentColor: "#00e676",
    ambientColor: "rgba(0, 230, 118, 0.18)",
    firstUseCaption: "Emerald crystal cluster planted for colony harvesting.",
  },
  {
    id: "wall",
    index: 5,
    label: "Wall",
    coreColor: "#cbd5e1",
    accentColor: "#64748b",
    ambientColor: "rgba(100, 116, 139, 0.18)",
    firstUseCaption: "Basalt barrier sculpted; overlapping ants are safely ejected.",
  },
  {
    id: "eraser",
    index: 6,
    label: "Eraser",
    coreColor: "#ffffff",
    accentColor: "#94a3b8",
    ambientColor: "rgba(148, 163, 184, 0.16)",
    firstUseCaption: "Dissolves scents, crystals, and basalt while protecting the nest.",
  },
];

export const TOOL_MAP: Record<ToolId, ToolMetadata> = TOOL_LIST.reduce(
  (acc, item) => {
    acc[item.id] = item;
    return acc;
  },
  {} as Record<ToolId, ToolMetadata>
);

export interface SimulationConfig {
  maxAnts: number;
  evaporationRate: number;
  diffusionRate: number;
  trailSensitivity: number;
  antennaAngleDeg: number;
  brushRadius: number;
  depositionIntensity: number;
  timeScale: SimSpeed;
}

export const DEFAULT_SIM_CONFIG: SimulationConfig = {
  maxAnts: 900,
  evaporationRate: 0.14,
  diffusionRate: 0.18,
  trailSensitivity: 1.45,
  antennaAngleDeg: 38,
  brushRadius: 24,
  depositionIntensity: 0.78,
  timeScale: 1,
};

export interface FoodCluster {
  id: number;
  x: number;
  y: number;
  radius: number;
  amount: number;
  maxAmount: number;
  variant: number;
  phase: number;
  glintTimer: number;
}

export interface NestState {
  x: number;
  y: number;
  radius: number;
  storedFood: number;
  spawnProgress: number;
  deliveryPulse: number;
  protectionPulse: number;
}

export interface SparkParticle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  color: string;
  size: number;
}

export interface SporeMote {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  alpha: number;
  phase: number;
  tint: "cyan" | "amber" | "emerald";
}

export interface ActiveStroke {
  active: boolean;
  pointerId: number | null;
  tool: ToolId;
  points: Array<{ x: number; y: number }>;
  lastX: number;
  lastY: number;
  rippleX: number;
  rippleY: number;
  rippleAge: number;
}

export interface TelemetrySnapshot {
  fps: number;
  activeAnts: number;
  storedFood: number;
  totalFoodRemaining: number;
  generation: number;
  avgFitness: number;
  eliteScore: number;
  hallOfFameCount: number;
  suppressedTrails: number;
  avgTrailCommit: number;
  avgCuriosity: number;
  avgForesight: number;
  qualityTier: "high" | "balanced";
}

export interface PresetDefinition {
  id: PresetId;
  title: string;
  subtitle: string;
  description: string;
  initialAnts: number;
}

export const PRESET_DEFINITIONS: PresetDefinition[] = [
  {
    id: "open-sanctuary",
    title: "Open Sanctuary",
    subtitle: "Free-foraging baseline",
    description: "Central-left nest surrounded by three emerald groves at progressive distances.",
    initialAnts: 260,
  },
  {
    id: "double-bridge",
    title: "Double Bridge",
    subtitle: "Deneubourg 1990 assay",
    description: "Asymmetric 1x vs 2x diamond bridges demonstrating autocatalytic shortest-path convergence.",
    initialAnts: 340,
  },
  {
    id: "subterranean-labyrinth",
    title: "Subterranean Labyrinth",
    subtitle: "Multi-chambered cavern",
    description: "Basalt chambers, dead-ends, and narrow choke points leading to deep nutrient vaults.",
    initialAnts: 360,
  },
];
