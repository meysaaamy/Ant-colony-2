import { PheromoneGrid } from "./pheromone-grid";
import { fbm2D } from "./prng-noise";
import { FoodCluster, NestState, PresetId } from "./types";

export interface GeneratedWorld {
  nest: NestState;
  clusters: FoodCluster[];
  initialAnts: number;
}

function paintLineWall(
  grid: PheromoneGrid,
  x0: number,
  y0: number,
  x1: number,
  y1: number,
  radius: number,
  isWall = true
): void {
  const dist = Math.hypot(x1 - x0, y1 - y0);
  const step = Math.max(2, radius * 0.35);
  const steps = Math.max(1, Math.ceil(dist / step));
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    grid.paintWallCircle(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t, radius, isWall);
  }
}

export function generatePresetWorld(
  preset: PresetId,
  grid: PheromoneGrid
): GeneratedWorld {
  grid.clearAll();
  const w = grid.worldWidth;
  const h = grid.worldHeight;
  const isPortrait = h >= w;

  // Keep important features comfortably inside safe visible play zone (away from top HUD & bottom dock)
  const topMargin = isPortrait ? h * 0.14 : h * 0.16;
  const botMargin = isPortrait ? h * 0.24 : h * 0.24;
  const playH = h - topMargin - botMargin;
  const cy = topMargin + playH * 0.5;

  const clusters: FoodCluster[] = [];
  let nextId = 1;

  if (preset === "open-sanctuary") {
    const nestX = isPortrait ? w * 0.28 : w * 0.24;
    const nestY = isPortrait ? topMargin + playH * 0.56 : cy;
    const nest: NestState = {
      x: nestX,
      y: nestY,
      radius: 28,
      storedFood: 0,
      spawnProgress: 0,
      deliveryPulse: 0,
      protectionPulse: 0,
    };

    // Three rich emerald nutrient groves at progressive distances
    const groveCoords = isPortrait
      ? [
          { x: w * 0.68, y: topMargin + playH * 0.28, amount: 220, r: 28 },
          { x: w * 0.74, y: topMargin + playH * 0.62, amount: 260, r: 30 },
          { x: w * 0.36, y: topMargin + playH * 0.18, amount: 190, r: 26 },
        ]
      : [
          { x: w * 0.58, y: topMargin + playH * 0.25, amount: 220, r: 28 },
          { x: w * 0.78, y: topMargin + playH * 0.54, amount: 280, r: 31 },
          { x: w * 0.52, y: topMargin + playH * 0.78, amount: 210, r: 26 },
        ];

    for (let i = 0; i < groveCoords.length; i++) {
      const g = groveCoords[i];
      clusters.push({
        id: nextId++,
        x: g.x,
        y: g.y,
        radius: g.r,
        amount: g.amount,
        maxAmount: g.amount,
        variant: i % 8,
        phase: i * 1.4,
        glintTimer: 0,
      });
    }

    grid.recomputeSmoothedWalls();
    return { nest, clusters, initialAnts: 260 };
  }

  if (preset === "double-bridge") {
    // Deneubourg 1990 Asymmetric Diamond Bridge
    // Orientation: vertical in portrait, horizontal in landscape
    if (isPortrait) {
      const nestX = w * 0.5;
      const nestY = topMargin + playH * 0.84;
      const foodX = w * 0.5;
      const foodY = topMargin + playH * 0.16;

      // Central diamond island separating short (left) vs long (right) paths
      const midY = (nestY + foodY) * 0.5;
      const spanY = Math.abs(nestY - foodY);
      const wallThick = 20;

      // Outer bounding basalt canyon walls forcing ants onto the 2 diamond branches
      paintLineWall(grid, w * 0.04, topMargin + playH * 0.5, w * 0.22, topMargin + playH * 0.5, 42);
      paintLineWall(grid, w * 0.96, topMargin + playH * 0.5, w * 0.86, topMargin + playH * 0.5, 34);

      // Asymmetric central diamond divider: shorter curve on left, wide detour on right
      paintLineWall(grid, w * 0.44, midY - spanY * 0.22, w * 0.44, midY + spanY * 0.22, wallThick);
      paintLineWall(grid, w * 0.44, midY - spanY * 0.22, w * 0.64, midY, wallThick);
      paintLineWall(grid, w * 0.44, midY + spanY * 0.22, w * 0.64, midY, wallThick);
      paintLineWall(grid, w * 0.5, midY - spanY * 0.12, w * 0.5, midY + spanY * 0.12, 26);

      // Carve clean 1x short corridor (left) and 2x long corridor (right)
      paintLineWall(grid, nestX, nestY, w * 0.30, midY, 26, false);
      paintLineWall(grid, w * 0.30, midY, foodX, foodY, 26, false);

      paintLineWall(grid, nestX, nestY, w * 0.78, midY + spanY * 0.18, 26, false);
      paintLineWall(grid, w * 0.78, midY + spanY * 0.18, w * 0.80, midY - spanY * 0.18, 26, false);
      paintLineWall(grid, w * 0.80, midY - spanY * 0.18, foodX, foodY, 26, false);

      grid.recomputeSmoothedWalls();
      const nest: NestState = {
        x: nestX,
        y: nestY,
        radius: 28,
        storedFood: 0,
        spawnProgress: 0,
        deliveryPulse: 0,
        protectionPulse: 0,
      };
      clusters.push({
        id: nextId++,
        x: foodX,
        y: foodY,
        radius: 32,
        amount: 340,
        maxAmount: 340,
        variant: 2,
        phase: 0.4,
        glintTimer: 0,
      });
      return { nest, clusters, initialAnts: 340 };
    } else {
      const nestX = w * 0.18;
      const nestY = cy;
      const foodX = w * 0.82;
      const foodY = cy;
      const midX = w * 0.5;

      // Central diamond obstacle shifted upward so upper branch is 2x longer than lower branch
      paintLineWall(grid, midX - w * 0.14, cy, midX, cy - playH * 0.16, 22);
      paintLineWall(grid, midX, cy - playH * 0.16, midX + w * 0.14, cy, 22);
      paintLineWall(grid, midX - w * 0.14, cy, midX, cy + playH * 0.08, 22);
      paintLineWall(grid, midX, cy + playH * 0.08, midX + w * 0.14, cy, 22);
      paintLineWall(grid, midX - w * 0.08, cy - playH * 0.04, midX + w * 0.08, cy - playH * 0.04, 24);

      // Outer funnel walls
      paintLineWall(grid, midX - w * 0.18, topMargin, midX + w * 0.18, topMargin, 28);
      paintLineWall(grid, midX - w * 0.18, topMargin + playH, midX + w * 0.18, topMargin + playH, 28);

      // Carve short lower bridge (1x) and long upper bridge (2x)
      paintLineWall(grid, nestX, nestY, midX, cy + playH * 0.25, 28, false);
      paintLineWall(grid, midX, cy + playH * 0.25, foodX, foodY, 28, false);
      paintLineWall(grid, nestX, nestY, midX - w * 0.12, cy - playH * 0.34, 28, false);
      paintLineWall(grid, midX - w * 0.12, cy - playH * 0.34, midX + w * 0.12, cy - playH * 0.34, 28, false);
      paintLineWall(grid, midX + w * 0.12, cy - playH * 0.34, foodX, foodY, 28, false);

      grid.recomputeSmoothedWalls();
      const nest: NestState = {
        x: nestX,
        y: nestY,
        radius: 28,
        storedFood: 0,
        spawnProgress: 0,
        deliveryPulse: 0,
        protectionPulse: 0,
      };
      clusters.push({
        id: nextId++,
        x: foodX,
        y: foodY,
        radius: 32,
        amount: 340,
        maxAmount: 340,
        variant: 4,
        phase: 0.9,
        glintTimer: 0,
      });
      return { nest, clusters, initialAnts: 340 };
    }
  }

  // Subterranean Labyrinth: Organic procedural cave network with chambers, choke points & 2 deep vaults
  const cols = grid.cols;
  const rows = grid.rows;
  for (let gy = 0; gy < rows; gy++) {
    for (let gx = 0; gx < cols; gx++) {
      const wx = (gx + 0.5) * grid.cellSize;
      const wy = (gy + 0.5) * grid.cellSize;
      const n = fbm2D(wx * 0.0068, wy * 0.0068, 3, 7421);
      if (n > 0.53) {
        grid.wallMask[gy * cols + gx] = 1;
      }
    }
  }

  const nestX = isPortrait ? w * 0.26 : w * 0.2;
  const nestY = isPortrait ? topMargin + playH * 0.8 : cy;
  const v1x = isPortrait ? w * 0.74 : w * 0.76;
  const v1y = isPortrait ? topMargin + playH * 0.22 : topMargin + playH * 0.26;
  const v2x = isPortrait ? w * 0.72 : w * 0.78;
  const v2y = isPortrait ? topMargin + playH * 0.52 : topMargin + playH * 0.76;

  // Carve nest chamber + 2 deep nutrient vaults + winding organic choke passages
  grid.paintWallCircle(nestX, nestY, 64, false);
  grid.paintWallCircle(v1x, v1y, 58, false);
  grid.paintWallCircle(v2x, v2y, 58, false);

  // Winding corridors + intentional dead-ends
  const wp1x = w * 0.48;
  const wp1y = topMargin + playH * 0.64;
  const wp2x = w * 0.36;
  const wp2y = topMargin + playH * 0.38;
  const wp3x = w * 0.56;
  const wp3y = topMargin + playH * 0.28;

  paintLineWall(grid, nestX, nestY, wp1x, wp1y, 24, false);
  paintLineWall(grid, wp1x, wp1y, v2x, v2y, 22, false);
  paintLineWall(grid, wp1x, wp1y, wp2x, wp2y, 20, false);
  paintLineWall(grid, wp2x, wp2y, wp3x, wp3y, 20, false);
  paintLineWall(grid, wp3x, wp3y, v1x, v1y, 22, false);
  // Secondary bypass choke point
  paintLineWall(grid, v2x, v2y, v1x, v1y, 19, false);

  grid.recomputeSmoothedWalls();

  const nest: NestState = {
    x: nestX,
    y: nestY,
    radius: 28,
    storedFood: 0,
    spawnProgress: 0,
    deliveryPulse: 0,
    protectionPulse: 0,
  };

  clusters.push(
    {
      id: nextId++,
      x: v1x,
      y: v1y,
      radius: 30,
      amount: 260,
      maxAmount: 260,
      variant: 1,
      phase: 0.3,
      glintTimer: 0,
    },
    {
      id: nextId++,
      x: v2x,
      y: v2y,
      radius: 28,
      amount: 240,
      maxAmount: 240,
      variant: 5,
      phase: 1.7,
      glintTimer: 0,
    }
  );

  return { nest, clusters, initialAnts: 360 };
}

export function renderPresetPreviewCanvas(
  canvas: HTMLCanvasElement,
  preset: PresetId
): void {
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  const w = canvas.width;
  const h = canvas.height;

  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = "#04070e";
  ctx.fillRect(0, 0, w, h);

  // Subtle substrate grid
  ctx.strokeStyle = "rgba(148, 163, 184, 0.08)";
  ctx.lineWidth = 1;
  for (let x = 20; x < w; x += 24) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, h);
    ctx.stroke();
  }
  for (let y = 16; y < h; y += 24) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(w, y);
    ctx.stroke();
  }

  if (preset === "open-sanctuary") {
    drawPreviewNest(ctx, w * 0.24, h * 0.56);
    drawPreviewCrystal(ctx, w * 0.62, h * 0.28);
    drawPreviewCrystal(ctx, w * 0.78, h * 0.56);
    drawPreviewCrystal(ctx, w * 0.48, h * 0.78);
    drawPreviewTrail(ctx, w * 0.24, h * 0.56, w * 0.62, h * 0.28);
    return;
  }

  if (preset === "double-bridge") {
    ctx.fillStyle = "#101622";
    ctx.strokeStyle = "#26354d";
    ctx.lineWidth = 1.5;
    // Diamond island
    ctx.beginPath();
    ctx.moveTo(w * 0.36, h * 0.52);
    ctx.lineTo(w * 0.5, h * 0.32);
    ctx.lineTo(w * 0.64, h * 0.52);
    ctx.lineTo(w * 0.5, h * 0.62);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    drawPreviewTrail(ctx, w * 0.2, h * 0.52, w * 0.8, h * 0.52, true);
    drawPreviewNest(ctx, w * 0.2, h * 0.52);
    drawPreviewCrystal(ctx, w * 0.8, h * 0.52);
    return;
  }

  // Subterranean labyrinth
  ctx.fillStyle = "#101622";
  ctx.strokeStyle = "#26354d";
  ctx.lineWidth = 1.2;
  const blobs = [
    { x: w * 0.36, y: h * 0.24, rx: 24, ry: 15 },
    { x: w * 0.56, y: h * 0.52, rx: 26, ry: 18 },
    { x: w * 0.28, y: h * 0.76, rx: 20, ry: 14 },
    { x: w * 0.74, y: h * 0.28, rx: 16, ry: 14 },
  ];
  for (const b of blobs) {
    ctx.beginPath();
    ctx.ellipse(b.x, b.y, b.rx, b.ry, 0.3, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
  }
  drawPreviewNest(ctx, w * 0.18, h * 0.66);
  drawPreviewCrystal(ctx, w * 0.8, h * 0.26);
  drawPreviewCrystal(ctx, w * 0.78, h * 0.74);
}

function drawPreviewNest(ctx: CanvasRenderingContext2D, x: number, y: number): void {
  const g = ctx.createRadialGradient(x, y, 2, x, y, 16);
  g.addColorStop(0, "rgba(255, 243, 176, 0.85)");
  g.addColorStop(0.5, "rgba(0, 240, 255, 0.35)");
  g.addColorStop(1, "rgba(0, 0, 0, 0)");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(x, y, 16, 0, Math.PI * 2);
  ctx.fill();

  ctx.strokeStyle = "#00f0ff";
  ctx.lineWidth = 1.25;
  ctx.beginPath();
  ctx.arc(x, y, 7, 0, Math.PI * 2);
  ctx.stroke();
}

function drawPreviewCrystal(ctx: CanvasRenderingContext2D, x: number, y: number): void {
  const g = ctx.createRadialGradient(x, y, 1, x, y, 14);
  g.addColorStop(0, "rgba(185, 246, 202, 0.9)");
  g.addColorStop(0.5, "rgba(0, 230, 118, 0.35)");
  g.addColorStop(1, "rgba(0, 0, 0, 0)");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(x, y, 14, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "#00e676";
  ctx.beginPath();
  ctx.moveTo(x, y - 6);
  ctx.lineTo(x + 5, y);
  ctx.lineTo(x, y + 6);
  ctx.lineTo(x - 5, y);
  ctx.closePath();
  ctx.fill();
}

function drawPreviewTrail(
  ctx: CanvasRenderingContext2D,
  x0: number,
  y0: number,
  x1: number,
  y1: number,
  curved = false
): void {
  ctx.strokeStyle = "rgba(255, 174, 0, 0.45)";
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  ctx.moveTo(x0, y0);
  if (curved) {
    ctx.quadraticCurveTo((x0 + x1) * 0.5, y0 + 26, x1, y1);
  } else {
    ctx.lineTo(x1, y1);
  }
  ctx.stroke();
}
