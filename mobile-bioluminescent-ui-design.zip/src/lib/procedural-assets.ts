import { Mulberry32, periodicNoise2D } from "./prng-noise";

export interface ProceduralAssets {
  soilTile: HTMLCanvasElement;
  basaltTile: HTMLCanvasElement;
  antSheet: HTMLCanvasElement;
  antFrameSize: number;
  crystalVariants: HTMLCanvasElement[];
  crystalSize: number;
  glowEmerald: HTMLCanvasElement;
  glowAmber: HTMLCanvasElement;
  glowCyan: HTMLCanvasElement;
  glowCrimson: HTMLCanvasElement;
}

function makeCanvas(w: number, h: number): HTMLCanvasElement {
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  return canvas;
}

function createRadialGlowSprite(
  size: number,
  coreColor: string,
  midColor: string,
  outerColor: string
): HTMLCanvasElement {
  const c = makeCanvas(size, size);
  const ctx = c.getContext("2d");
  if (!ctx) return c;
  const r = size * 0.5;
  const grad = ctx.createRadialGradient(r, r, 0, r, r, r);
  grad.addColorStop(0, coreColor);
  grad.addColorStop(0.28, midColor);
  grad.addColorStop(0.65, outerColor);
  grad.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, size, size);
  return c;
}

function bakeSeamlessSoilTile(): HTMLCanvasElement {
  const size = 256;
  const c = makeCanvas(size, size);
  const ctx = c.getContext("2d");
  if (!ctx) return c;

  const img = ctx.createImageData(size, size);
  const data = img.data;
  const rng = new Mulberry32(90421);

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const n1 = periodicNoise2D((x / size) * 8, (y / size) * 8, 8, 8, 101);
      const n2 = periodicNoise2D((x / size) * 24, (y / size) * 24, 24, 24, 202);
      const grain = rng.next() * 0.15;
      const v = n1 * 0.55 + n2 * 0.3 + grain;

      // Strict grading: base #03050a, max never exceeds #0a0f18 (10, 15, 24)
      const r = Math.min(10, Math.max(2, Math.round(2 + v * 7.5)));
      const g = Math.min(15, Math.max(4, Math.round(4 + v * 10.5)));
      const b = Math.min(24, Math.max(8, Math.round(8 + v * 15)));

      const idx = (y * size + x) * 4;
      data[idx] = r;
      data[idx + 1] = g;
      data[idx + 2] = b;
      data[idx + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);

  // Subtle mineral flecks capped below #0a0f18
  for (let i = 0; i < 65; i++) {
    const fx = rng.range(0, size);
    const fy = rng.range(0, size);
    const fr = rng.range(0.6, 1.8);
    ctx.fillStyle = "rgba(10, 15, 24, 0.45)";
    ctx.beginPath();
    ctx.arc(fx, fy, fr, 0, Math.PI * 2);
    ctx.fill();
  }

  return c;
}

function bakeSeamlessBasaltTile(): HTMLCanvasElement {
  const size = 256;
  const c = makeCanvas(size, size);
  const ctx = c.getContext("2d");
  if (!ctx) return c;

  const img = ctx.createImageData(size, size);
  const data = img.data;

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const n1 = periodicNoise2D((x / size) * 6, (y / size) * 6, 6, 6, 411);
      const n2 = periodicNoise2D((x / size) * 18, (y / size) * 18, 18, 18, 512);
      const ridge = 1 - Math.abs(n1 * 2 - 1);
      const v = ridge * 0.6 + n2 * 0.4;

      // Mean #101622 (16, 22, 34), highlights capped strictly below #26354d (38, 53, 77)
      const r = Math.min(36, Math.max(10, Math.round(11 + v * 22)));
      const g = Math.min(50, Math.max(15, Math.round(16 + v * 30)));
      const b = Math.min(74, Math.max(24, Math.round(25 + v * 44)));

      const idx = (y * size + x) * 4;
      data[idx] = r;
      data[idx + 1] = g;
      data[idx + 2] = b;
      data[idx + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);

  // Subtle crystalline fracture lines
  const rng = new Mulberry32(7731);
  ctx.strokeStyle = "rgba(38, 53, 77, 0.35)";
  ctx.lineWidth = 1;
  for (let i = 0; i < 18; i++) {
    const sx = rng.range(0, size);
    const sy = rng.range(0, size);
    const len = rng.range(12, 36);
    const ang = rng.range(0, Math.PI * 2);
    ctx.beginPath();
    ctx.moveTo(sx, sy);
    ctx.lineTo(sx + Math.cos(ang) * len, sy + Math.sin(ang) * len);
    ctx.stroke();
  }

  return c;
}

function drawAntFrame(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  phaseIdx: number,
  stateRow: number,
  scale: number
) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(scale, scale);

  // Ant faces +X (right) in local space
  const t = (phaseIdx / 8) * Math.PI * 2;
  const tripodA = Math.sin(t);
  const tripodB = Math.sin(t + Math.PI);

  const isCarrying = stateRow === 1;
  const isAlarmed = stateRow === 2;

  const legStroke = isAlarmed
    ? "rgba(255, 92, 128, 0.9)"
    : isCarrying
      ? "rgba(185, 246, 202, 0.85)"
      : "rgba(155, 198, 232, 0.85)";
  const rimStroke = isAlarmed
    ? "#ff0a43"
    : isCarrying
      ? "#00e676"
      : "#48b5d6";
  const cuticleFill = isAlarmed
    ? "#2c0914"
    : isCarrying
      ? "#0d221c"
      : "#111a28";

  // 2-segment jointed legs (tripod gait)
  const legPairs = [
    { bx: 2.2, by: 2.0, fx: 5.5, fy: 6.4, swing: tripodA },
    { bx: 0.0, by: 2.2, fx: -0.4, fy: 7.4, swing: tripodB },
    { bx: -2.4, by: 1.9, fx: -6.4, fy: 6.4, swing: tripodA },
  ];

  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  ctx.strokeStyle = legStroke;
  ctx.lineWidth = 1.15;

  for (let i = 0; i < legPairs.length; i++) {
    const leg = legPairs[i];
    for (const side of [-1, 1]) {
      const s = side === 1 ? leg.swing : -leg.swing;
      const kneeX = (leg.bx + leg.fx) * 0.5 + s * 1.1;
      const kneeY = side * (leg.by + (leg.fy - leg.by) * 0.52);
      const footX = leg.fx + s * 2.1;
      const footY = side * leg.fy;

      ctx.beginPath();
      ctx.moveTo(leg.bx, side * leg.by);
      ctx.lineTo(kneeX, kneeY);
      ctx.lineTo(footX, footY);
      ctx.stroke();
    }
  }

  // Elbowed antennae
  const antWiggle = Math.sin(t * 2) * 0.55;
  ctx.strokeStyle = isAlarmed ? "#ffd1dc" : "#9ceeff";
  ctx.lineWidth = 1.05;
  for (const side of [-1, 1]) {
    ctx.beginPath();
    ctx.moveTo(7.4, side * 1.4);
    ctx.lineTo(9.8, side * (3.1 + antWiggle * 0.4));
    ctx.lineTo(12.2, side * (4.1 - antWiggle * 0.5));
    ctx.stroke();
  }

  // Gaster (abdomen) with subtle bioluminescent band
  ctx.fillStyle = cuticleFill;
  ctx.strokeStyle = rimStroke;
  ctx.lineWidth = 1.1;
  ctx.beginPath();
  ctx.ellipse(-5.6, 0, 4.4, 3.1, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  // Gaster banding & specular sheen
  ctx.strokeStyle = isAlarmed
    ? "rgba(255, 10, 67, 0.55)"
    : isCarrying
      ? "rgba(255, 174, 0, 0.55)"
      : "rgba(0, 240, 255, 0.35)";
  ctx.lineWidth = 0.9;
  ctx.beginPath();
  ctx.arc(-5.6, 0, 2.5, -0.8, 0.8);
  ctx.stroke();

  // Petiole + Thorax
  ctx.fillStyle = cuticleFill;
  ctx.strokeStyle = rimStroke;
  ctx.lineWidth = 1.05;
  ctx.beginPath();
  ctx.ellipse(0.4, 0, 2.7, 1.75, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  // Head
  ctx.beginPath();
  ctx.ellipse(5.3, 0, 2.5, 2.15, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  // Specular cuticle highlight
  ctx.fillStyle = "rgba(255, 255, 255, 0.34)";
  ctx.beginPath();
  ctx.ellipse(-5.2, -1.0, 1.6, 0.65, -0.2, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(5.5, -0.7, 0.9, 0.45, 0, 0, Math.PI * 2);
  ctx.fill();

  // Food crystal held in mandibles when returning
  if (isCarrying) {
    ctx.fillStyle = "#b9f6ca";
    ctx.strokeStyle = "#00e676";
    ctx.lineWidth = 0.9;
    ctx.beginPath();
    ctx.moveTo(8.1, 0);
    ctx.lineTo(10.0, -2.1);
    ctx.lineTo(12.2, 0);
    ctx.lineTo(10.0, 2.1);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }

  ctx.restore();
}

function bakeAntSpriteSheet(): { canvas: HTMLCanvasElement; frameSize: number } {
  const frameSize = 56; // 2x resolution sprite cell
  const cols = 8;
  const rows = 3;
  const c = makeCanvas(frameSize * cols, frameSize * rows);
  const ctx = c.getContext("2d");
  if (!ctx) return { canvas: c, frameSize };

  for (let row = 0; row < rows; row++) {
    for (let col = 0; col < cols; col++) {
      const cx = col * frameSize + frameSize * 0.5;
      const cy = row * frameSize + frameSize * 0.5;
      drawAntFrame(ctx, cx, cy, col, row, 1.75);
    }
  }

  return { canvas: c, frameSize };
}

function bakeCrystalVariant(variant: number, size: number): HTMLCanvasElement {
  const c = makeCanvas(size, size);
  const ctx = c.getContext("2d");
  if (!ctx) return c;

  const rng = new Mulberry32(3100 + variant * 197);
  const cx = size * 0.5;
  const cy = size * 0.5;
  const spireCount = 5 + (variant % 3);

  // Soft emerald aura at center
  const aura = ctx.createRadialGradient(cx, cy, 2, cx, cy, size * 0.46);
  aura.addColorStop(0, "rgba(185, 246, 202, 0.48)");
  aura.addColorStop(0.45, "rgba(0, 230, 118, 0.2)");
  aura.addColorStop(1, "rgba(0, 230, 118, 0)");
  ctx.fillStyle = aura;
  ctx.fillRect(0, 0, size, size);

  for (let i = 0; i < spireCount; i++) {
    const angle = (i / spireCount) * Math.PI * 2 + rng.range(-0.22, 0.22);
    const len = size * rng.range(0.24, 0.4);
    const halfW = size * rng.range(0.08, 0.13);

    const tipX = cx + Math.cos(angle) * len;
    const tipY = cy + Math.sin(angle) * len;
    const perpX = -Math.sin(angle);
    const perpY = Math.cos(angle);

    const baseL_X = cx + perpX * halfW;
    const baseL_Y = cy + perpY * halfW;
    const baseR_X = cx - perpX * halfW;
    const baseR_Y = cy - perpY * halfW;

    const grad = ctx.createLinearGradient(cx, cy, tipX, tipY);
    grad.addColorStop(0, "rgba(0, 168, 84, 0.88)");
    grad.addColorStop(0.65, "rgba(0, 230, 118, 0.94)");
    grad.addColorStop(1, "#e2ffec");

    ctx.fillStyle = grad;
    ctx.strokeStyle = "rgba(185, 246, 202, 0.85)";
    ctx.lineWidth = 1.25;

    ctx.beginPath();
    ctx.moveTo(baseL_X, baseL_Y);
    ctx.lineTo(tipX, tipY);
    ctx.lineTo(baseR_X, baseR_Y);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    // Inner facet refraction streak
    ctx.strokeStyle = "rgba(255, 255, 255, 0.45)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(cx + Math.cos(angle) * (len * 0.2), cy + Math.sin(angle) * (len * 0.2));
    ctx.lineTo(tipX, tipY);
    ctx.stroke();
  }

  // Incandescent center crystal core
  ctx.fillStyle = "#d9ffe7";
  ctx.beginPath();
  ctx.arc(cx, cy, size * 0.09, 0, Math.PI * 2);
  ctx.fill();

  return c;
}

export function bakeVignetteGrainOverlay(width: number, height: number): HTMLCanvasElement {
  const c = makeCanvas(width, height);
  const ctx = c.getContext("2d");
  if (!ctx) return c;

  // Radial vignette
  const cx = width * 0.5;
  const cy = height * 0.5;
  const outerR = Math.hypot(cx, cy);
  const vig = ctx.createRadialGradient(cx, cy, outerR * 0.48, cx, cy, outerR);
  vig.addColorStop(0, "rgba(3, 5, 10, 0)");
  vig.addColorStop(0.75, "rgba(3, 5, 10, 0.22)");
  vig.addColorStop(1, "rgba(2, 3, 7, 0.62)");
  ctx.fillStyle = vig;
  ctx.fillRect(0, 0, width, height);

  // Subtle deterministic film grain pattern
  const tileSize = 128;
  const grainTile = makeCanvas(tileSize, tileSize);
  const gctx = grainTile.getContext("2d");
  if (gctx) {
    const img = gctx.createImageData(tileSize, tileSize);
    const rng = new Mulberry32(55123);
    for (let i = 0; i < img.data.length; i += 4) {
      const v = rng.next() > 0.5 ? 225 : 15;
      img.data[i] = v;
      img.data[i + 1] = v;
      img.data[i + 2] = v;
      img.data[i + 3] = Math.round(rng.next() * 7);
    }
    gctx.putImageData(img, 0, 0);
    const pattern = ctx.createPattern(grainTile, "repeat");
    if (pattern) {
      ctx.fillStyle = pattern;
      ctx.fillRect(0, 0, width, height);
    }
  }

  return c;
}

let cachedAssets: ProceduralAssets | null = null;

export function getProceduralAssets(): ProceduralAssets {
  if (cachedAssets) return cachedAssets;

  const soilTile = bakeSeamlessSoilTile();
  const basaltTile = bakeSeamlessBasaltTile();
  const antSheetResult = bakeAntSpriteSheet();
  const crystalSize = 96;
  const crystalVariants: HTMLCanvasElement[] = [];
  for (let i = 0; i < 8; i++) {
    crystalVariants.push(bakeCrystalVariant(i, crystalSize));
  }

  cachedAssets = {
    soilTile,
    basaltTile,
    antSheet: antSheetResult.canvas,
    antFrameSize: antSheetResult.frameSize,
    crystalVariants,
    crystalSize,
    glowEmerald: createRadialGlowSprite(
      128,
      "rgba(185, 246, 202, 0.65)",
      "rgba(0, 230, 118, 0.24)",
      "rgba(0, 230, 118, 0.05)"
    ),
    glowAmber: createRadialGlowSprite(
      128,
      "rgba(255, 243, 176, 0.72)",
      "rgba(255, 174, 0, 0.28)",
      "rgba(255, 174, 0, 0.06)"
    ),
    glowCyan: createRadialGlowSprite(
      128,
      "rgba(224, 255, 255, 0.68)",
      "rgba(0, 240, 255, 0.26)",
      "rgba(0, 240, 255, 0.06)"
    ),
    glowCrimson: createRadialGlowSprite(
      128,
      "rgba(255, 209, 220, 0.65)",
      "rgba(255, 10, 67, 0.28)",
      "rgba(255, 10, 67, 0.06)"
    ),
  };

  return cachedAssets;
}
