"use client";

import React from "react";

export interface ToastOverlayProps {
  toastMessage: string | null;
  captionMessage: string | null;
  isPainting: boolean;
}

export function ToastOverlay({
  toastMessage,
  captionMessage,
  isPainting,
}: ToastOverlayProps) {
  const activeText = toastMessage || captionMessage;

  return (
    <div
      aria-live="polite"
      aria-atomic="true"
      className="pointer-events-none fixed inset-x-0 top-[68px] z-20 flex justify-center px-4"
    >
      {activeText && (
        <div
          className={`obsidian-glass-subtle rounded-full px-4 py-1.5 text-center text-[12px] font-medium text-slate-100 transition-all duration-200 ${
            isPainting ? "opacity-45" : "opacity-100"
          }`}
          style={{
            boxShadow: toastMessage
              ? "inset 0 1px 0 rgba(255,255,255,0.16), 0 0 0 1px rgba(0,240,255,0.35), 0 8px 24px rgba(0,0,0,0.65)"
              : "inset 0 1px 0 rgba(255,255,255,0.14), 0 0 0 1px rgba(255,174,0,0.32), 0 8px 24px rgba(0,0,0,0.65)",
          }}
        >
          {activeText}
        </div>
      )}
    </div>
  );
}
