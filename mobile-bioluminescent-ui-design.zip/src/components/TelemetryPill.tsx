"use client";

import React from "react";
import { SimSpeed, TelemetrySnapshot } from "@/lib/types";
import {
  ArticulatedAntIcon,
  FacetedCrystalIcon,
  InfoEmblemIcon,
  PauseIcon,
  PlayIcon,
  SlidersIcon,
} from "./ui/icons";

export interface TelemetryPillProps {
  telemetry: TelemetrySnapshot;
  isPlaying: boolean;
  timeScale: SimSpeed;
  isPainting: boolean;
  isFieldGuideOpen: boolean;
  isSettingsOpen: boolean;
  onTogglePlay: () => void;
  onCycleSpeed: () => void;
  onOpenFieldGuide: () => void;
  onToggleSettings: () => void;
}

export function TelemetryPill({
  telemetry,
  isPlaying,
  timeScale,
  isPainting,
  isFieldGuideOpen,
  isSettingsOpen,
  onTogglePlay,
  onCycleSpeed,
  onOpenFieldGuide,
  onToggleSettings,
}: TelemetryPillProps) {
  const fpsColor =
    telemetry.fps >= 55
      ? "#00e676"
      : telemetry.fps >= 40
        ? "#ffae00"
        : "#ff0a43";

  return (
    <header
      data-painting={isPainting ? "true" : "false"}
      className="ui-chrome-layer pointer-events-none fixed inset-x-0 top-0 z-30 flex items-center justify-between gap-2 px-3 pt-[max(10px,env(safe-area-inset-top))] sm:px-5"
    >
      {/* Left Telemetry Capsule (Unified Glass Pill) */}
      <div className="obsidian-glass pointer-events-auto flex items-center rounded-full pl-3 pr-1.5 py-1 min-h-[48px] max-w-[calc(100vw-116px)]">
        {/* Live FPS Status Dot */}
        <span
          className="mr-2 inline-block h-2 w-2 shrink-0 rounded-full"
          style={{
            backgroundColor: fpsColor,
            boxShadow: `0 0 8px ${fpsColor}`,
          }}
          title={`${telemetry.fps} FPS (${telemetry.qualityTier})`}
          aria-label={`Simulation frame rate ${telemetry.fps} frames per second`}
        />

        {/* Ants Counter */}
        <div className="flex items-center gap-1.5 pr-2.5">
          <ArticulatedAntIcon size={17} className="shrink-0" />
          <span className="tabular-nums text-[12.5px] font-semibold tracking-tight text-slate-100 whitespace-nowrap">
            {telemetry.activeAnts}
            <span className="ml-1 hidden xs:inline text-[11px] font-normal text-slate-400">
              ants
            </span>
          </span>
        </div>

        {/* Vertical Hairline Divider */}
        <div className="h-5 w-px bg-white/12 shrink-0" aria-hidden="true" />

        {/* Food Counter */}
        <div className="flex items-center gap-1.5 pl-2.5 pr-2">
          <FacetedCrystalIcon size={16} className="shrink-0" />
          <span className="tabular-nums text-[12.5px] font-semibold tracking-tight text-emerald-100 whitespace-nowrap">
            {telemetry.storedFood}
            <span className="ml-1 hidden xs:inline text-[11px] font-normal text-slate-400">
              food
            </span>
          </span>
        </div>

        {/* Embedded Speed Chip (1x / 2x / 4x) */}
        <button
          type="button"
          onClick={onCycleSpeed}
          aria-label={`Simulation speed ${timeScale}x. Tap to cycle.`}
          title="Cycle simulation speed (1x / 2x / 4x)"
          className="ml-0.5 flex h-[34px] min-w-[36px] items-center justify-center rounded-full bg-slate-950/75 px-2 text-[11.5px] font-semibold tabular-nums text-cyan-200 shadow-[inset_0_1px_0_rgba(255,255,255,0.08),0_0_0_1px_rgba(255,255,255,0.08)] transition hover:bg-slate-900 active:scale-95"
        >
          {timeScale}x
        </button>

        {/* Warm Amber-Tinted Play / Pause Button (38x38 inner pill inside 48x48 touch zone) */}
        <button
          type="button"
          onClick={onTogglePlay}
          aria-label={isPlaying ? "Pause simulation (Space)" : "Resume simulation (Space)"}
          title={isPlaying ? "Pause (Space)" : "Play (Space)"}
          className="ml-0.5 flex h-[44px] w-[42px] items-center justify-center rounded-full"
        >
          <span
            className="flex h-[38px] w-[38px] items-center justify-center rounded-full transition-all active:scale-95"
            style={{
              background: isPlaying
                ? "radial-gradient(circle at 50% 30%, rgba(255, 243, 176, 0.22), rgba(255, 174, 0, 0.14))"
                : "radial-gradient(circle at 50% 30%, rgba(0, 230, 118, 0.24), rgba(0, 230, 118, 0.12))",
              boxShadow: isPlaying
                ? "inset 0 1px 0 rgba(255,255,255,0.18), 0 0 0 1px rgba(255, 174, 0, 0.42), 0 0 14px rgba(255, 174, 0, 0.2)"
                : "inset 0 1px 0 rgba(255,255,255,0.18), 0 0 0 1px rgba(0, 230, 118, 0.45), 0 0 14px rgba(0, 230, 118, 0.22)",
              color: isPlaying ? "#fff3b0" : "#b9f6ca",
            }}
          >
            {isPlaying ? <PauseIcon size={17} /> : <PlayIcon size={17} />}
          </span>
        </button>
      </div>

      {/* Right Standalone Squircle Utility Buttons (46x46px, 14px radius) */}
      <div className="pointer-events-auto flex items-center gap-2 shrink-0">
        <button
          type="button"
          onClick={onOpenFieldGuide}
          aria-label="Open scientific field guide"
          aria-expanded={isFieldGuideOpen}
          title="Field guide & science"
          className="obsidian-glass flex h-[46px] w-[46px] items-center justify-center rounded-[14px] transition-all active:scale-95"
          style={
            isFieldGuideOpen
              ? {
                  boxShadow:
                    "inset 0 1px 0 rgba(255,255,255,0.2), 0 0 0 1px rgba(0,240,255,0.48), 0 0 18px rgba(0,240,255,0.24)",
                  color: "#e0ffff",
                }
              : { color: "#cbd5e1" }
          }
        >
          <InfoEmblemIcon size={20} />
        </button>

        <button
          type="button"
          onClick={onToggleSettings}
          aria-label="Toggle parameter controls"
          aria-expanded={isSettingsOpen}
          title="Parameters & world settings"
          className="obsidian-glass flex h-[46px] w-[46px] items-center justify-center rounded-[14px] transition-all active:scale-95"
          style={
            isSettingsOpen
              ? {
                  boxShadow:
                    "inset 0 1px 0 rgba(255,255,255,0.2), 0 0 0 1px rgba(255,174,0,0.48), 0 0 18px rgba(255,174,0,0.22)",
                  color: "#fff3b0",
                }
              : { color: "#cbd5e1" }
          }
        >
          <SlidersIcon size={20} />
        </button>
      </div>
    </header>
  );
}
