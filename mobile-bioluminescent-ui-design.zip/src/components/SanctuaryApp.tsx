"use client";

import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  DEFAULT_SIM_CONFIG,
  PRESET_DEFINITIONS,
  ParameterTab,
  PresetId,
  SheetSnap,
  SimSpeed,
  SimulationConfig,
  TOOL_LIST,
  TOOL_MAP,
  TelemetrySnapshot,
  ToolId,
} from "@/lib/types";
import { FieldGuideModal } from "./FieldGuideModal";
import { FloatingToolDock } from "./FloatingToolDock";
import { ParameterSheet } from "./ParameterSheet";
import { SanctuaryCanvas, SanctuaryCanvasHandle } from "./SanctuaryCanvas";
import { TelemetryPill } from "./TelemetryPill";
import { ToastOverlay } from "./ToastOverlay";

export function SanctuaryApp() {
  const simCanvasRef = useRef<SanctuaryCanvasHandle | null>(null);

  const [activeTool, setActiveTool] = useState<ToolId>("food-trail");
  const [activePreset, setActivePreset] = useState<PresetId>("open-sanctuary");
  const [config, setConfig] = useState<SimulationConfig>(DEFAULT_SIM_CONFIG);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [wasPausedByTab, setWasPausedByTab] = useState<boolean>(false);

  const [sheetSnap, setSheetSnap] = useState<SheetSnap>("peek");
  const [activeTab, setActiveTab] = useState<ParameterTab>("colony");
  const [isBrushPopoverOpen, setIsBrushPopoverOpen] = useState<boolean>(false);
  const [isFieldGuideOpen, setIsFieldGuideOpen] = useState<boolean>(false);
  const [isPainting, setIsPainting] = useState<boolean>(false);

  const [telemetry, setTelemetry] = useState<TelemetrySnapshot>({
    fps: 60,
    activeAnts: 260,
    storedFood: 0,
    totalFoodRemaining: 670,
    generation: 1,
    avgFitness: 0,
    eliteScore: 0,
    hallOfFameCount: 0,
    suppressedTrails: 0,
    avgTrailCommit: 1.0,
    avgCuriosity: 0.7,
    avgForesight: 1.0,
    qualityTier: "high",
  });

  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [captionMessage, setCaptionMessage] = useState<string | null>(null);
  const toastTimerRef = useRef<number | null>(null);
  const captionTimerRef = useRef<number | null>(null);
  const usedToolsRef = useRef<Set<ToolId>>(new Set(["food-trail"]));

  const showToast = useCallback((msg: string, durationMs = 2000) => {
    if (toastTimerRef.current !== null) window.clearTimeout(toastTimerRef.current);
    setToastMessage(msg);
    toastTimerRef.current = window.setTimeout(() => {
      setToastMessage(null);
    }, durationMs);
  }, []);

  const showCaption = useCallback((msg: string, durationMs = 3000) => {
    if (captionTimerRef.current !== null) window.clearTimeout(captionTimerRef.current);
    setCaptionMessage(msg);
    captionTimerRef.current = window.setTimeout(() => {
      setCaptionMessage(null);
    }, durationMs);
  }, []);

  useEffect(() => {
    return () => {
      if (toastTimerRef.current !== null) window.clearTimeout(toastTimerRef.current);
      if (captionTimerRef.current !== null) window.clearTimeout(captionTimerRef.current);
    };
  }, []);

  const handleSelectTool = useCallback(
    (tool: ToolId) => {
      setActiveTool(tool);
      if (!usedToolsRef.current.has(tool)) {
        usedToolsRef.current.add(tool);
        showCaption(TOOL_MAP[tool].firstUseCaption, 3000);
      }
    },
    [showCaption]
  );

  const handleUpdateConfig = useCallback((partial: Partial<SimulationConfig>) => {
    setConfig((prev) => ({ ...prev, ...partial }));
  }, []);

  const handleCycleSpeed = useCallback(() => {
    setConfig((prev) => {
      const next: SimSpeed = prev.timeScale === 1 ? 2 : prev.timeScale === 2 ? 4 : 1;
      return { ...prev, timeScale: next };
    });
  }, []);

  const handleClearPheromones = useCallback(() => {
    simCanvasRef.current?.clearPheromones();
    showToast("Pheromones cleared");
  }, [showToast]);

  const handleResetWorld = useCallback(() => {
    simCanvasRef.current?.resetWorld();
    showToast("World reset");
  }, [showToast]);

  const handleSelectPreset = useCallback(
    (preset: PresetId) => {
      setActivePreset(preset);
      simCanvasRef.current?.loadPreset(preset);
      const title =
        PRESET_DEFINITIONS.find((p) => p.id === preset)?.title ?? "Preset";
      showToast(`${title} loaded`);
    },
    [showToast]
  );

  const handleStrokeStarted = useCallback(() => {
    setIsBrushPopoverOpen(false);
    setSheetSnap((prev) => (prev !== "peek" ? "peek" : prev));
  }, []);

  const handleVisibilityAutoPause = useCallback(
    (hidden: boolean) => {
      if (hidden) {
        setIsPlaying((curr) => {
          if (curr) {
            setWasPausedByTab(true);
            return false;
          }
          return curr;
        });
      } else if (wasPausedByTab) {
        setWasPausedByTab(false);
        setIsPlaying(true);
      }
    },
    [wasPausedByTab]
  );

  // Desktop keyboard shortcuts: 1-6 tools, Space play/pause, [ / ] brush size, Esc close
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (
        e.target instanceof HTMLInputElement ||
        e.target instanceof HTMLTextAreaElement
      ) {
        return;
      }

      if (e.key === "Escape") {
        setIsFieldGuideOpen(false);
        setIsBrushPopoverOpen(false);
        setSheetSnap("peek");
        return;
      }

      if (isFieldGuideOpen) return;

      if (e.key >= "1" && e.key <= "6") {
        const idx = parseInt(e.key, 10) - 1;
        const tool = TOOL_LIST[idx];
        if (tool) {
          handleSelectTool(tool.id);
        }
        return;
      }

      if (e.code === "Space") {
        e.preventDefault();
        setIsPlaying((p) => !p);
        return;
      }

      if (e.key === "[") {
        setConfig((prev) => ({
          ...prev,
          brushRadius: Math.max(8, prev.brushRadius - 4),
        }));
        return;
      }

      if (e.key === "]") {
        setConfig((prev) => ({
          ...prev,
          brushRadius: Math.min(64, prev.brushRadius + 4),
        }));
      }
    };

    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [handleSelectTool, isFieldGuideOpen]);

  return (
    <main className="relative h-[100dvh] w-full overflow-hidden bg-[#03050a]">
      {/* Full-bleed Interactive Simulation Canvas */}
      <SanctuaryCanvas
        ref={simCanvasRef}
        activeTool={activeTool}
        activePreset={activePreset}
        isPlaying={isPlaying}
        config={config}
        onTelemetry={setTelemetry}
        onPaintingChange={setIsPainting}
        onStrokeStarted={handleStrokeStarted}
        onFirstFoodDelivered={() =>
          showCaption("Food delivered. Every 3 units adds an ant.", 3200)
        }
        onCapacityReached={() =>
          showToast("Colony at capacity. Raise the cap in Colony settings.", 2500)
        }
        onShowCaption={showCaption}
        onVisibilityAutoPause={handleVisibilityAutoPause}
      />

      {/* Zone 1: Top Split HUD Bar */}
      <TelemetryPill
        telemetry={telemetry}
        isPlaying={isPlaying}
        timeScale={config.timeScale}
        isPainting={isPainting}
        isFieldGuideOpen={isFieldGuideOpen}
        isSettingsOpen={sheetSnap !== "peek"}
        onTogglePlay={() => setIsPlaying((p) => !p)}
        onCycleSpeed={handleCycleSpeed}
        onOpenFieldGuide={() => {
          setIsBrushPopoverOpen(false);
          setIsFieldGuideOpen(true);
        }}
        onToggleSettings={() => {
          setIsBrushPopoverOpen(false);
          setSheetSnap((prev) => (prev === "peek" ? "half" : "peek"));
        }}
      />

      {/* Contextual Captions & Non-Stacking Toast */}
      <ToastOverlay
        toastMessage={toastMessage}
        captionMessage={captionMessage}
        isPainting={isPainting}
      />

      {/* Zone 2: Bottom 3-Tier Floating Control Cockpit */}
      <div
        data-painting={isPainting ? "true" : "false"}
        className="ui-chrome-layer pointer-events-none fixed inset-x-0 bottom-0 z-30 flex justify-center px-3 pb-[max(10px,env(safe-area-inset-bottom))] sm:px-5"
      >
        <div className="pointer-events-auto flex w-full max-w-[460px] flex-col gap-2">
          {/* Tier 1 — Interactive World Controls & Preset Peek Card */}
          <ParameterSheet
            snap={sheetSnap}
            activeTab={activeTab}
            activePreset={activePreset}
            config={config}
            telemetry={telemetry}
            onChangeSnap={(s) => {
              setIsBrushPopoverOpen(false);
              setSheetSnap(s);
            }}
            onChangeTab={setActiveTab}
            onUpdateConfig={handleUpdateConfig}
            onClearPheromones={handleClearPheromones}
            onResetWorld={handleResetWorld}
            onSelectPreset={handleSelectPreset}
          />

          {/* Tiers 2 & 3 — Active Tool Pill + Brush Popover + Primary 6-Tool Thumb Dock */}
          <FloatingToolDock
            activeTool={activeTool}
            brushRadius={config.brushRadius}
            depositionIntensity={config.depositionIntensity}
            isBrushPopoverOpen={isBrushPopoverOpen}
            onSelectTool={handleSelectTool}
            onToggleBrushPopover={() => setIsBrushPopoverOpen((o) => !o)}
            onChangeBrushRadius={(val) =>
              handleUpdateConfig({ brushRadius: val })
            }
            onChangeDepositionIntensity={(val) =>
              handleUpdateConfig({ depositionIntensity: val })
            }
          />
        </div>
      </div>

      {/* Scientific Field Guide & Ethology Modal */}
      <FieldGuideModal
        isOpen={isFieldGuideOpen}
        onClose={() => setIsFieldGuideOpen(false)}
      />
    </main>
  );
}
