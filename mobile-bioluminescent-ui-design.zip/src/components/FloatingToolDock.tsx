"use client";

import React from "react";
import { TOOL_LIST, TOOL_MAP, ToolId } from "@/lib/types";
import { BioSlider } from "./ui/BioSlider";
import {
  AlarmIcon,
  ChevronDownIcon,
  DottedBrushRingIcon,
  EraserIcon,
  FoodClusterIcon,
  FoodTrailIcon,
  HomeTrailIcon,
  WallIcon,
} from "./ui/icons";

export interface FloatingToolDockProps {
  activeTool: ToolId;
  brushRadius: number;
  depositionIntensity: number;
  isBrushPopoverOpen: boolean;
  onSelectTool: (tool: ToolId) => void;
  onToggleBrushPopover: () => void;
  onChangeBrushRadius: (val: number) => void;
  onChangeDepositionIntensity: (val: number) => void;
}

function renderToolGlyph(id: ToolId, isActive: boolean) {
  const cls = `transition-transform duration-150 ${isActive ? "-translate-y-[1px]" : ""}`;
  switch (id) {
    case "food-trail":
      return <FoodTrailIcon size={23} className={cls} />;
    case "home-trail":
      return <HomeTrailIcon size={23} className={cls} />;
    case "alarm":
      return <AlarmIcon size={23} className={cls} />;
    case "food-cluster":
      return <FoodClusterIcon size={23} className={cls} />;
    case "wall":
      return <WallIcon size={23} className={cls} />;
    case "eraser":
      return <EraserIcon size={23} className={cls} />;
  }
}

export function FloatingToolDock({
  activeTool,
  brushRadius,
  depositionIntensity,
  isBrushPopoverOpen,
  onSelectTool,
  onToggleBrushPopover,
  onChangeBrushRadius,
  onChangeDepositionIntensity,
}: FloatingToolDockProps) {
  const activeMeta = TOOL_MAP[activeTool];

  const handleSelect = (tool: ToolId) => {
    if (typeof navigator !== "undefined" && typeof navigator.vibrate === "function") {
      try {
        navigator.vibrate(8);
      } catch {
        // ignore vibration unsupported
      }
    }
    onSelectTool(tool);
  };

  return (
    <div data-tool={activeTool} className="relative w-full space-y-2">
      {/* Floating Brush Popover directly above Brush Trigger */}
      {isBrushPopoverOpen && (
        <div
          role="dialog"
          aria-label="Brush controls"
          className="obsidian-glass absolute right-0 bottom-[112px] z-40 w-[268px] rounded-[20px] p-3.5 shadow-2xl"
        >
          <div className="mb-2 flex items-center justify-between">
            <span className="text-[11px] font-semibold uppercase tracking-[0.08em] text-slate-400">
              Brush tuning
            </span>
            <span
              className="text-[11px] font-medium"
              style={{ color: activeMeta.coreColor }}
            >
              {activeMeta.label}
            </span>
          </div>

          <div className="space-y-3">
            <BioSlider
              id="popover-brush-radius"
              label="Brush radius"
              value={brushRadius}
              defaultValue={24}
              min={8}
              max={64}
              step={2}
              unit="px"
              accentColor={activeMeta.accentColor}
              coreColor={activeMeta.coreColor}
              ambientColor={activeMeta.ambientColor}
              onChange={onChangeBrushRadius}
              compact
            />
            <BioSlider
              id="popover-deposition"
              label="Deposition intensity"
              value={depositionIntensity}
              defaultValue={0.78}
              min={0.2}
              max={1.5}
              step={0.04}
              formatValue={(v) => `${Math.round(v * 100)}%`}
              accentColor={activeMeta.accentColor}
              coreColor={activeMeta.coreColor}
              ambientColor={activeMeta.ambientColor}
              onChange={onChangeDepositionIntensity}
              compact
            />
          </div>
        </div>
      )}

      {/* Tier 2 — Contextual Active Tool Pill & Live Brush Popover Trigger */}
      <div className="flex items-center justify-between gap-2">
        {/* Left Floating Badge */}
        <div className="tool-status-glow inline-flex items-center gap-2 rounded-full px-3.5 py-1.5 min-h-[36px]">
          <span
            className="bio-dot-breathe inline-block h-2.5 w-2.5 rounded-full"
            style={{
              backgroundColor: "var(--tool-core)",
              boxShadow: "0 0 10px var(--tool-accent)",
            }}
            aria-hidden="true"
          />
          <span className="text-[13px] font-semibold tracking-tight text-slate-100">
            {activeMeta.label}
          </span>
          <span className="tabular-nums text-[12px] font-medium text-slate-400">
            · {activeMeta.index}
          </span>
        </div>

        {/* Right Floating Brush Trigger */}
        <button
          type="button"
          onClick={onToggleBrushPopover}
          aria-expanded={isBrushPopoverOpen}
          aria-label={`Brush radius ${Math.round(brushRadius)}. Tap to adjust brush radius and intensity.`}
          title="Brush radius & intensity ([ / ])"
          className="obsidian-glass inline-flex min-h-[38px] items-center gap-1.5 rounded-full px-3 py-1.5 text-[12.5px] font-semibold tabular-nums text-slate-100 transition active:scale-95"
          style={
            isBrushPopoverOpen
              ? {
                  boxShadow:
                    "inset 0 1px 0 rgba(255,255,255,0.18), 0 0 0 1px color-mix(in srgb, var(--tool-accent) 48%, transparent), 0 0 16px var(--tool-ambient)",
                }
              : undefined
          }
        >
          <DottedBrushRingIcon size={16} className="text-[var(--tool-core)]" />
          <span>{Math.round(brushRadius)}</span>
          <ChevronDownIcon
            size={13}
            className={`text-slate-400 transition-transform duration-150 ${
              isBrushPopoverOpen ? "rotate-180" : ""
            }`}
          />
        </button>
      </div>

      {/* Tier 3 — Primary 6-Tool Thumb Dock */}
      <nav
        aria-label="Scent and terrain tools"
        className="obsidian-glass grid grid-cols-6 gap-1 rounded-[24px] p-[6px]"
      >
        {TOOL_LIST.map((tool) => {
          const isActive = tool.id === activeTool;
          return (
            <button
              key={tool.id}
              type="button"
              data-tool={tool.id}
              onClick={() => handleSelect(tool.id)}
              aria-pressed={isActive}
              aria-label={`${tool.label} (Shortcut ${tool.index})`}
              title={`${tool.label} (${tool.index})`}
              className={`relative flex h-[52px] items-center justify-center rounded-[16px] transition-all duration-150 active:scale-95 ${
                isActive
                  ? "tool-active-jewel"
                  : "hover:bg-white/[0.04]"
              }`}
              style={{
                color: isActive ? tool.coreColor : "#94a3b8",
              }}
            >
              {renderToolGlyph(tool.id, isActive)}
              <span
                aria-hidden="true"
                className={`tabular-nums absolute right-1.5 bottom-1 text-[9.5px] font-semibold leading-none ${
                  isActive ? "text-slate-200/85" : "text-slate-500/75"
                }`}
              >
                {tool.index}
              </span>
            </button>
          );
        })}
      </nav>
    </div>
  );
}
