"use client";

import React, { useId } from "react";

export interface IconProps {
  className?: string;
  size?: number;
  active?: boolean;
}

export function FoodTrailIcon({ className = "", size = 24 }: IconProps) {
  const uid = useId();
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      className={className}
      aria-hidden="true"
    >
      <defs>
        <linearGradient id={`${uid}-grad`} x1="3" y1="18" x2="21" y2="6" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#ffae00" stopOpacity="0.5" />
          <stop offset="55%" stopColor="#ffae00" />
          <stop offset="100%" stopColor="#fff3b0" />
        </linearGradient>
        <radialGradient id={`${uid}-halo`} cx="19" cy="6.5" r="5" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#fff3b0" stopOpacity="0.45" />
          <stop offset="100%" stopColor="#ffae00" stopOpacity="0" />
        </radialGradient>
      </defs>
      <circle cx="19" cy="6.5" r="4.5" fill={`url(#${uid}-halo)`} />
      <path
        d="M3.5 16.5C6.8 18 9.2 14.5 12 12C14.8 9.5 16.8 7 19.5 6.5"
        stroke={`url(#${uid}-grad)`}
        strokeWidth="1.75"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M5.5 19.5C8.5 19.2 10.7 16.8 13.4 14.5C15.4 12.8 17.5 11.4 19.2 11.2"
        stroke="currentColor"
        strokeOpacity="0.32"
        strokeWidth="1.35"
        strokeLinecap="round"
      />
      <path
        d="M16.2 5.4L20.3 6.2L18.9 10.1"
        stroke="#fff3b0"
        strokeWidth="1.75"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle cx="5" cy="14" r="1.2" fill="currentColor" fillOpacity="0.32" />
    </svg>
  );
}

export function HomeTrailIcon({ className = "", size = 24 }: IconProps) {
  const uid = useId();
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      className={className}
      aria-hidden="true"
    >
      <defs>
        <linearGradient id={`${uid}-grad`} x1="20" y1="18" x2="5" y2="6" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#00f0ff" stopOpacity="0.45" />
          <stop offset="55%" stopColor="#00f0ff" />
          <stop offset="100%" stopColor="#e0ffff" />
        </linearGradient>
        <radialGradient id={`${uid}-beacon`} cx="6.5" cy="7" r="4.5" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#e0ffff" stopOpacity="0.45" />
          <stop offset="100%" stopColor="#00f0ff" stopOpacity="0" />
        </radialGradient>
      </defs>
      <circle cx="6.5" cy="7" r="4.5" fill={`url(#${uid}-beacon)`} />
      <circle
        cx="6.5"
        cy="7"
        r="3"
        fill="currentColor"
        fillOpacity="0.22"
        stroke="#e0ffff"
        strokeWidth="1.75"
      />
      <circle cx="6.5" cy="7" r="1" fill="#e0ffff" />
      <path
        d="M20 17C16.5 18.2 13.8 16.5 12.3 13.8C10.9 11.3 10.2 9.2 8.8 8.2"
        stroke={`url(#${uid}-grad)`}
        strokeWidth="1.75"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M17.5 19.5C14.7 19.6 12.5 18.3 10.8 16"
        stroke="currentColor"
        strokeOpacity="0.3"
        strokeWidth="1.35"
        strokeLinecap="round"
      />
    </svg>
  );
}

export function AlarmIcon({ className = "", size = 24 }: IconProps) {
  const uid = useId();
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      className={className}
      aria-hidden="true"
    >
      <defs>
        <radialGradient id={`${uid}-glow`} cx="12" cy="14" r="7" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#ffd1dc" stopOpacity="0.32" />
          <stop offset="65%" stopColor="#ff0a43" stopOpacity="0.16" />
          <stop offset="100%" stopColor="#ff0a43" stopOpacity="0" />
        </radialGradient>
        <linearGradient id={`${uid}-grad`} x1="12" y1="4" x2="12" y2="20" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#ffd1dc" />
          <stop offset="100%" stopColor="#ff0a43" />
        </linearGradient>
      </defs>
      <circle cx="12" cy="14" r="7" fill={`url(#${uid}-glow)`} />
      <path
        d="M5.2 11.4C6.6 7.9 9.1 6.2 12 6.2C14.9 6.2 17.4 7.9 18.8 11.4"
        stroke="currentColor"
        strokeOpacity="0.52"
        strokeWidth="1.65"
        strokeLinecap="round"
      />
      <path
        d="M7.9 13.6C8.8 11.4 10.3 10.2 12 10.2C13.7 10.2 15.2 11.4 16.1 13.6"
        stroke={`url(#${uid}-grad)`}
        strokeWidth="1.75"
        strokeLinecap="round"
      />
      <path d="M12 4.5V14.2" stroke="#ffd1dc" strokeWidth="1.8" strokeLinecap="round" />
      <circle cx="12" cy="18.2" r="1.4" fill="#ffd1dc" stroke="#ff0a43" strokeWidth="1" />
    </svg>
  );
}

export function FoodClusterIcon({ className = "", size = 24 }: IconProps) {
  const uid = useId();
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      className={className}
      aria-hidden="true"
    >
      <defs>
        <radialGradient id={`${uid}-base`} cx="12" cy="17" r="7.5" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#b9f6ca" stopOpacity="0.38" />
          <stop offset="100%" stopColor="#00e676" stopOpacity="0" />
        </radialGradient>
        <linearGradient id={`${uid}-main`} x1="12" y1="3.5" x2="12" y2="19.5" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#b9f6ca" />
          <stop offset="100%" stopColor="#00e676" />
        </linearGradient>
      </defs>
      <ellipse cx="12" cy="17.5" rx="7.5" ry="3.2" fill={`url(#${uid}-base)`} />
      <path
        d="M12 3.8L15.4 8.5L14.2 18.8H9.8L8.6 8.5L12 3.8Z"
        fill="currentColor"
        fillOpacity="0.25"
        stroke={`url(#${uid}-main)`}
        strokeWidth="1.75"
        strokeLinejoin="round"
      />
      <path
        d="M8.6 10.4L5.6 9.1L4.6 14.5L7.6 18.8H9.8"
        fill="currentColor"
        fillOpacity="0.18"
        stroke="currentColor"
        strokeWidth="1.65"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M15.4 10.4L18.4 9.1L19.4 14.5L16.4 18.8H14.2"
        fill="currentColor"
        fillOpacity="0.18"
        stroke="currentColor"
        strokeWidth="1.65"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path d="M12 4.2V18.5" stroke="#b9f6ca" strokeOpacity="0.55" strokeWidth="1.1" strokeLinecap="round" />
    </svg>
  );
}

export function WallIcon({ className = "", size = 24 }: IconProps) {
  const uid = useId();
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      className={className}
      aria-hidden="true"
    >
      <defs>
        <linearGradient id={`${uid}-basalt`} x1="4" y1="6" x2="20" y2="19" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#cbd5e1" />
          <stop offset="100%" stopColor="#64748b" />
        </linearGradient>
      </defs>
      <path
        d="M3.5 18.5L7.8 9.2L11.4 12.8L15.4 6.2L20.5 18.5H3.5Z"
        fill="currentColor"
        fillOpacity="0.25"
        stroke={`url(#${uid}-basalt)`}
        strokeWidth="1.75"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M8.6 15.8L11.4 12.8L14.1 15.6"
        stroke="#cbd5e1"
        strokeOpacity="0.55"
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function EraserIcon({ className = "", size = 24 }: IconProps) {
  const uid = useId();
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      className={className}
      aria-hidden="true"
    >
      <defs>
        <linearGradient id={`${uid}-prism`} x1="5" y1="15" x2="18" y2="5" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#94a3b8" />
          <stop offset="100%" stopColor="#ffffff" />
        </linearGradient>
      </defs>
      <path
        d="M13.5 5.2L18.8 10.5L10.8 18.5H5.8L4.5 17.2C3.8 16.5 3.8 15.4 4.5 14.7L13.5 5.2Z"
        fill="currentColor"
        fillOpacity="0.22"
        stroke={`url(#${uid}-prism)`}
        strokeWidth="1.75"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path d="M9.2 9.8L14.5 15.1" stroke="#ffffff" strokeOpacity="0.58" strokeWidth="1.35" strokeLinecap="round" />
      <path d="M11 18.5H19.5" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" />
    </svg>
  );
}

export function ArticulatedAntIcon({ className = "", size = 20 }: IconProps) {
  const uid = useId();
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      className={className}
      aria-hidden="true"
    >
      <defs>
        <linearGradient id={`${uid}-ant`} x1="12" y1="3" x2="12" y2="21" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#e0ffff" />
          <stop offset="55%" stopColor="#00f0ff" />
          <stop offset="100%" stopColor="#ffae00" />
        </linearGradient>
      </defs>
      <g stroke={`url(#${uid}-ant)`} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
        <path d="M10.2 6.2L8 3.6L6 3" />
        <path d="M13.8 6.2L16 3.6L18 3" />
        <path d="M9.6 10.5L5.2 8.4L3.5 9.8" />
        <path d="M14.4 10.5L18.8 8.4L20.5 9.8" />
        <path d="M9.5 12.6L4.8 13.2L3.2 15.5" />
        <path d="M14.5 12.6L19.2 13.2L20.8 15.5" />
        <path d="M9.8 14.8L6 17.8L4.8 20.4" />
        <path d="M14.2 14.8L18 17.8L19.2 20.4" />
        <ellipse cx="12" cy="7.5" rx="2.1" ry="1.9" fill="#00f0ff" fillOpacity="0.25" />
        <ellipse cx="12" cy="12" rx="1.65" ry="2.4" fill="#00f0ff" fillOpacity="0.2" />
        <ellipse cx="12" cy="17.8" rx="3" ry="3.6" fill="#ffae00" fillOpacity="0.26" />
      </g>
    </svg>
  );
}

export function FacetedCrystalIcon({ className = "", size = 20 }: IconProps) {
  const uid = useId();
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      className={className}
      aria-hidden="true"
    >
      <defs>
        <linearGradient id={`${uid}-gem`} x1="12" y1="3" x2="12" y2="21" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#b9f6ca" />
          <stop offset="100%" stopColor="#00e676" />
        </linearGradient>
      </defs>
      <path
        d="M12 3.2L17.6 9.4L15.2 20.2H8.8L6.4 9.4L12 3.2Z"
        fill="#00e676"
        fillOpacity="0.25"
        stroke={`url(#${uid}-gem)`}
        strokeWidth="1.75"
        strokeLinejoin="round"
      />
      <path d="M12 3.4V20M6.8 9.6H17.2" stroke="#b9f6ca" strokeOpacity="0.55" strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  );
}

export function SparkleSweepIcon({ className = "", size = 18 }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      className={className}
      aria-hidden="true"
    >
      <path
        d="M12 3.5L13.6 8.4L18.5 10L13.6 11.6L12 16.5L10.4 11.6L5.5 10L10.4 8.4L12 3.5Z"
        fill="currentColor"
        fillOpacity="0.24"
        stroke="currentColor"
        strokeWidth="1.75"
        strokeLinejoin="round"
      />
      <path d="M18.5 15.5L19.3 17.7L21.5 18.5L19.3 19.3L18.5 21.5L17.7 19.3L15.5 18.5L17.7 17.7L18.5 15.5Z" fill="currentColor" fillOpacity="0.3" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round" />
      <path d="M4.5 18.5C6.5 17.5 8.2 17.5 10 18.8" stroke="currentColor" strokeWidth="1.65" strokeLinecap="round" />
    </svg>
  );
}

export function ResetArrowIcon({ className = "", size = 18 }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      className={className}
      aria-hidden="true"
    >
      <path
        d="M4.5 12C4.5 7.86 7.86 4.5 12 4.5C15.1 4.5 17.75 6.38 18.9 9.05"
        stroke="currentColor"
        strokeWidth="1.75"
        strokeLinecap="round"
      />
      <path
        d="M19.5 12C19.5 16.14 16.14 19.5 12 19.5C8.9 19.5 6.25 17.62 5.1 14.95"
        stroke="currentColor"
        strokeOpacity="0.45"
        strokeWidth="1.75"
        strokeLinecap="round"
      />
      <path
        d="M19.6 4.8V9.4H15"
        stroke="currentColor"
        strokeWidth="1.75"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function DottedBrushRingIcon({ className = "", size = 18 }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      className={className}
      aria-hidden="true"
    >
      <circle
        cx="12"
        cy="12"
        r="8.2"
        stroke="currentColor"
        strokeWidth="1.75"
        strokeDasharray="2.2 2.8"
        strokeLinecap="round"
      />
      <circle
        cx="12"
        cy="12"
        r="4"
        fill="currentColor"
        fillOpacity="0.25"
        stroke="currentColor"
        strokeWidth="1.65"
      />
    </svg>
  );
}

export function SlidersIcon({ className = "", size = 20 }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      className={className}
      aria-hidden="true"
    >
      <path d="M4 7H9M13 7H20" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" />
      <circle cx="11" cy="7" r="2.2" fill="currentColor" fillOpacity="0.25" stroke="currentColor" strokeWidth="1.75" />
      <path d="M4 12H14M18 12H20" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" />
      <circle cx="16" cy="12" r="2.2" fill="currentColor" fillOpacity="0.25" stroke="currentColor" strokeWidth="1.75" />
      <path d="M4 17H6M10 17H20" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" />
      <circle cx="8" cy="17" r="2.2" fill="currentColor" fillOpacity="0.25" stroke="currentColor" strokeWidth="1.75" />
    </svg>
  );
}

export function InfoEmblemIcon({ className = "", size = 20 }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      className={className}
      aria-hidden="true"
    >
      <circle
        cx="12"
        cy="12"
        r="8.8"
        fill="currentColor"
        fillOpacity="0.16"
        stroke="currentColor"
        strokeWidth="1.75"
      />
      <path d="M12 11.2V16.2" stroke="currentColor" strokeWidth="1.85" strokeLinecap="round" />
      <circle cx="12" cy="7.9" r="1.15" fill="currentColor" />
    </svg>
  );
}

export function PlayIcon({ className = "", size = 18 }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className} aria-hidden="true">
      <path
        d="M7.5 5.4L18.4 12L7.5 18.6V5.4Z"
        fill="currentColor"
        fillOpacity="0.32"
        stroke="currentColor"
        strokeWidth="1.75"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function PauseIcon({ className = "", size = 18 }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className} aria-hidden="true">
      <rect
        x="6.8"
        y="5.6"
        width="3.6"
        height="12.8"
        rx="1.2"
        fill="currentColor"
        fillOpacity="0.3"
        stroke="currentColor"
        strokeWidth="1.75"
      />
      <rect
        x="13.6"
        y="5.6"
        width="3.6"
        height="12.8"
        rx="1.2"
        fill="currentColor"
        fillOpacity="0.3"
        stroke="currentColor"
        strokeWidth="1.75"
      />
    </svg>
  );
}

export function ChevronDownIcon({ className = "", size = 14 }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className} aria-hidden="true">
      <path
        d="M6.5 9.5L12 15L17.5 9.5"
        stroke="currentColor"
        strokeWidth="1.85"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function CloseIcon({ className = "", size = 20 }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className} aria-hidden="true">
      <path
        d="M6.5 6.5L17.5 17.5M17.5 6.5L6.5 17.5"
        stroke="currentColor"
        strokeWidth="1.75"
        strokeLinecap="round"
      />
    </svg>
  );
}

/* ============================================================================
 * 3 SCIENTIFIC INLINE SVG DIAGRAMS (FIELD GUIDE)
 * ========================================================================== */

export function DiagramAntennaSensing() {
  const uid = useId();
  return (
    <svg viewBox="0 0 320 148" fill="none" className="w-full h-auto rounded-xl border border-white/10 bg-[#050811]">
      <defs>
        <radialGradient id={`${uid}-plume`} cx="220" cy="48" r="78" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#fff3b0" stopOpacity="0.5" />
          <stop offset="45%" stopColor="#ffae00" stopOpacity="0.25" />
          <stop offset="100%" stopColor="#ffae00" stopOpacity="0" />
        </radialGradient>
      </defs>
      <circle cx="220" cy="48" r="76" fill={`url(#${uid}-plume)`} />
      {/* Sensor cones */}
      <circle cx="136" cy="54" r="14" stroke="#00f0ff" strokeOpacity="0.55" strokeWidth="1.2" strokeDasharray="3 2" fill="#00f0ff" fillOpacity="0.08" />
      <circle cx="164" cy="40" r="14" stroke="#fff3b0" strokeOpacity="0.7" strokeWidth="1.2" strokeDasharray="3 2" fill="#ffae00" fillOpacity="0.12" />
      <circle cx="184" cy="64" r="16" stroke="#ffae00" strokeOpacity="0.95" strokeWidth="1.4" fill="#ffae00" fillOpacity="0.22" />
      {/* Ant silhouette */}
      <g stroke="#e0ffff" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
        <path d="M138 92 L136 56" stroke="#00f0ff" />
        <path d="M148 86 L164 42" stroke="#fff3b0" strokeOpacity="0.75" strokeDasharray="2.5 2.5" />
        <path d="M156 94 L182 66" stroke="#ffae00" />
        <ellipse cx="145" cy="96" rx="5.5" ry="4.5" transform="rotate(-32 145 96)" fill="#00f0ff" fillOpacity="0.2" />
        <ellipse cx="132" cy="107" rx="4" ry="5.2" transform="rotate(-32 132 107)" fill="#00f0ff" fillOpacity="0.18" />
        <ellipse cx="116" cy="120" rx="7" ry="9" transform="rotate(-32 116 120)" fill="#ffae00" fillOpacity="0.24" />
      </g>
      <text x="116" y="47" fill="#00f0ff" fontSize="10" fontFamily="sans-serif" textAnchor="middle">S_left</text>
      <text x="164" y="21" fill="#fff3b0" fontSize="10" fontFamily="sans-serif" textAnchor="middle">S_center</text>
      <text x="218" y="68" fill="#ffae00" fontSize="10" fontFamily="sans-serif">S_right &gt; S_left</text>
      <text x="16" y="138" fill="#94a3b8" fontSize="10" fontFamily="sans-serif">Weber-Fechner: S = ln(1 + C) | Torque = (S_right - S_left)</text>
    </svg>
  );
}

export function DiagramPheromoneLut() {
  const uid = useId();
  return (
    <svg viewBox="0 0 320 124" fill="none" className="w-full h-auto rounded-xl border border-white/10 bg-[#050811]">
      <defs>
        <linearGradient id={`${uid}-food`} x1="18" y1="0" x2="296" y2="0" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#080c14" />
          <stop offset="28%" stopColor="#4d1f00" />
          <stop offset="72%" stopColor="#ffae00" />
          <stop offset="100%" stopColor="#fff3b0" />
        </linearGradient>
        <linearGradient id={`${uid}-home`} x1="18" y1="0" x2="296" y2="0" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#080c14" />
          <stop offset="30%" stopColor="#003366" />
          <stop offset="75%" stopColor="#00f0ff" />
          <stop offset="100%" stopColor="#e0ffff" />
        </linearGradient>
        <linearGradient id={`${uid}-alarm`} x1="18" y1="0" x2="296" y2="0" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#080c14" />
          <stop offset="35%" stopColor="#66001a" />
          <stop offset="78%" stopColor="#ff0a43" />
          <stop offset="100%" stopColor="#ffd1dc" />
        </linearGradient>
      </defs>
      <text x="18" y="22" fill="#fff3b0" fontSize="10" fontFamily="sans-serif">Food Trail (Recruit): Rust #4d1f00 -&gt; Amber #ffae00 -&gt; #fff3b0</text>
      <rect x="18" y="28" width="284" height="12" rx="6" fill={`url(#${uid}-food)`} stroke="rgba(255,255,255,0.12)" />

      <text x="18" y="59" fill="#e0ffff" fontSize="10" fontFamily="sans-serif">Home Guide (Orientation): Cobalt #003366 -&gt; Cyan #00f0ff -&gt; #e0ffff</text>
      <rect x="18" y="65" width="284" height="12" rx="6" fill={`url(#${uid}-home)`} stroke="rgba(255,255,255,0.12)" />

      <text x="18" y="96" fill="#ffd1dc" fontSize="10" fontFamily="sans-serif">Alarm Pheromone (3.5x Decay): Crimson #ff0a43 -&gt; #ffd1dc</text>
      <rect x="18" y="102" width="284" height="12" rx="6" fill={`url(#${uid}-alarm)`} stroke="rgba(255,255,255,0.12)" />
    </svg>
  );
}

export function DiagramDoubleBridge() {
  const uid = useId();
  return (
    <svg viewBox="0 0 320 140" fill="none" className="w-full h-auto rounded-xl border border-white/10 bg-[#050811]">
      <defs>
        <linearGradient id={`${uid}-short`} x1="66" y1="70" x2="254" y2="70" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#ffae00" stopOpacity="0.45" />
          <stop offset="50%" stopColor="#fff3b0" />
          <stop offset="100%" stopColor="#00e676" stopOpacity="0.85" />
        </linearGradient>
        <linearGradient id={`${uid}-long`} x1="66" y1="70" x2="254" y2="70" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#00f0ff" stopOpacity="0.35" />
          <stop offset="50%" stopColor="#00f0ff" stopOpacity="0.5" />
          <stop offset="100%" stopColor="#00e676" stopOpacity="0.35" />
        </linearGradient>
      </defs>
      <path d="M115 8L205 8L182 32H138L115 8Z" fill="#101622" stroke="#26354d" strokeWidth="1.25" />
      <path d="M118 58H202L186 84H134L118 58Z" fill="#101622" stroke="#26354d" strokeWidth="1.25" />
      <path d="M115 132L205 132L182 110H138L115 132Z" fill="#101622" stroke="#26354d" strokeWidth="1.25" />
      <path d="M68 70C95 45 115 22 160 22C205 22 225 45 252 70" stroke={`url(#${uid}-long)`} strokeWidth="2" strokeDasharray="4 4" />
      <path d="M68 70C102 88 122 98 160 98C198 98 218 88 252 70" stroke={`url(#${uid}-short)`} strokeWidth="3.2" strokeLinecap="round" />
      <circle cx="54" cy="70" r="14" fill="#00f0ff" fillOpacity="0.14" stroke="#00f0ff" strokeWidth="1.5" />
      <circle cx="54" cy="70" r="7" fill="#ffae00" fillOpacity="0.28" stroke="#fff3b0" strokeWidth="1.2" />
      <text x="54" y="102" fill="#94a3b8" fontSize="10" fontFamily="sans-serif" textAnchor="middle">NEST</text>
      <polygon points="266,57 276,70 266,83 256,70" fill="#00e676" fillOpacity="0.3" stroke="#b9f6ca" strokeWidth="1.5" />
      <text x="266" y="102" fill="#94a3b8" fontSize="10" fontFamily="sans-serif" textAnchor="middle">FOOD</text>
      <text x="160" y="17" fill="#00f0ff" fontSize="9" fontFamily="sans-serif" textAnchor="middle" opacity="0.8">2x LONGER</text>
      <text x="160" y="116" fill="#fff3b0" fontSize="9" fontFamily="sans-serif" textAnchor="middle">1x SHORTEST CONVERGENCE</text>
    </svg>
  );
}
