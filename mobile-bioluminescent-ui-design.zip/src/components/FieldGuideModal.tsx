"use client";

import React, { useEffect, useRef, useState } from "react";
import {
  ChevronDownIcon,
  CloseIcon,
  DiagramAntennaSensing,
  DiagramDoubleBridge,
  DiagramPheromoneLut,
} from "./ui/icons";

export interface FieldGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface GuideEntry {
  id: string;
  title: string;
  subtitle: string;
  inNature: string;
  inSandbox: string;
  diagram?: React.ReactNode;
}

const GUIDE_ENTRIES: GuideEntry[] = [
  {
    id: "tropotaxis",
    title: "Bilateral Tropotaxis & Weber-Fechner Law",
    subtitle: "Paired antenna chemoreception",
    inNature:
      "Foraging ants such as Lasius niger and Linepithema humile compare volatile pheromone concentrations simultaneously across left and right antennae, steering toward the stronger gradient while integrating sensory input logarithmically.",
    inSandbox:
      "Each ant samples Left, Center, and Right sensor cones ahead of its head with wall line-of-sight occlusion. Raw concentrations pass through S = ln(1 + C) before driving bilateral steering torque blended with Ornstein-Uhlenbeck wander.",
    diagram: <DiagramAntennaSensing />,
  },
  {
    id: "pheromones",
    title: "Three-Channel Pheromone Dispersion",
    subtitle: "Trail, Orientation & Alarm fields",
    inNature:
      "Colonies coordinate complex logistics using specialized glands: persistent trail pheromones recruit workers to food, footprint hydrocarbons mark return paths, and volatile mandibular alarm scents trigger rapid scatter.",
    inSandbox:
      "Three double-buffered Float32Array fields evaporate exponentially (alarm decays 3.5x faster) and diffuse via a CFL-stable 3x3 Laplacian stencil with zero-flux Neumann boundaries at basalt walls, rendered through 256-entry RGB LUTs.",
    diagram: <DiagramPheromoneLut />,
  },
  {
    id: "double-bridge",
    title: "Deneubourg's Double-Bridge Convergence",
    subtitle: "Autocatalytic shortest-path selection",
    inNature:
      "When two asymmetric paths bridge a nest and nutrient source, ants on the shorter branch complete round trips sooner, reinforcing that branch exponentially faster until the whole colony locks onto the optimal route.",
    inSandbox:
      "Select Double Bridge in World controls to observe 340+ agents explore both 1x and 2x diamond branches, converge onto the shorter corridor, and trigger Trail-Damping extinction if a branch becomes depleted.",
    diagram: <DiagramDoubleBridge />,
  },
  {
    id: "neuro-evolution",
    title: "RL Reward-Penalty & Swarm Evolution",
    subtitle: "Lifetime plasticity + Hall of Fame breeding",
    inNature:
      "Experienced foragers improve obstacle navigation over repeated trips and share route cues via antennation contacts, elevating collective colony efficiency.",
    inSandbox:
      "Every ant carries 5 learnable policy weights (Trail Commitment, Curiosity, Wall Foresight, Vector-Memory Trust, Negative Feedback). Efficient trips earn shortest-path jackpots; scraping walls or hitting depleted crystals triggers penalties and active Trail-Damping. Every 3 delivered crystals spawns a new ant cross-bred from the top 10% Hall-of-Fame elites.",
  },
];

export function FieldGuideModal({ isOpen, onClose }: FieldGuideModalProps) {
  const [openId, setOpenId] = useState<string>("tropotaxis");
  const dialogRef = useRef<HTMLDivElement | null>(null);
  const closeBtnRef = useRef<HTMLButtonElement | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    closeBtnRef.current?.focus();

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.preventDefault();
        onClose();
        return;
      }
      if (e.key === "Tab" && dialogRef.current) {
        const focusables = dialogRef.current.querySelectorAll<HTMLElement>(
          'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
        );
        if (focusables.length === 0) return;
        const first = focusables[0];
        const last = focusables[focusables.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 backdrop-blur-sm sm:items-center sm:p-4"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby="field-guide-title"
        className="obsidian-glass flex h-[92dvh] w-full flex-col overflow-hidden rounded-t-[28px] sm:h-auto sm:max-h-[86dvh] sm:max-w-[560px] sm:rounded-[28px]"
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/10 px-5 py-4">
          <div className="flex items-center gap-3">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src="/logo.svg"
              alt="Bioluminescent Macro-Sanctuary emblem"
              className="h-9 w-9 shrink-0"
            />
            <div>
              <h2
                id="field-guide-title"
                className="font-display text-[19px] font-semibold leading-tight text-slate-100"
              >
                Field Guide &amp; Ethology
              </h2>
              <p className="text-[12px] text-slate-400">
                Lasius niger &amp; Linepithema humile computational model
              </p>
            </div>
          </div>

          <button
            ref={closeBtnRef}
            type="button"
            onClick={onClose}
            aria-label="Close field guide (Esc)"
            className="flex h-[40px] w-[40px] items-center justify-center rounded-xl bg-white/[0.06] text-slate-200 ring-1 ring-white/12 transition hover:bg-white/[0.12] active:scale-95"
          >
            <CloseIcon size={18} />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 space-y-3 overflow-y-auto px-5 py-4">
          {GUIDE_ENTRIES.map((entry) => {
            const expanded = openId === entry.id;
            return (
              <section
                key={entry.id}
                className="rounded-[20px] bg-slate-950/70 ring-1 ring-white/10 overflow-hidden"
              >
                <button
                  type="button"
                  aria-expanded={expanded}
                  onClick={() => setOpenId(expanded ? "" : entry.id)}
                  className="flex w-full items-center justify-between gap-3 px-4 py-3.5 text-left hover:bg-white/[0.03]"
                >
                  <div>
                    <h3 className="font-display text-[15.5px] font-semibold text-slate-100">
                      {entry.title}
                    </h3>
                    <p className="text-[11.5px] text-cyan-300/80">{entry.subtitle}</p>
                  </div>
                  <ChevronDownIcon
                    size={16}
                    className={`shrink-0 text-slate-400 transition-transform duration-200 ${
                      expanded ? "rotate-180 text-cyan-200" : ""
                    }`}
                  />
                </button>

                {expanded && (
                  <div className="space-y-3 border-t border-white/8 px-4 py-3.5 text-[12.5px] leading-relaxed">
                    <div className="grid gap-2.5 sm:grid-cols-2">
                      <div className="rounded-xl bg-white/[0.03] p-3 ring-1 ring-white/6">
                        <div className="mb-1 text-[10.5px] font-semibold uppercase tracking-[0.08em] text-amber-300">
                          In nature
                        </div>
                        <p className="text-slate-300">{entry.inNature}</p>
                      </div>
                      <div className="rounded-xl bg-white/[0.03] p-3 ring-1 ring-white/6">
                        <div className="mb-1 text-[10.5px] font-semibold uppercase tracking-[0.08em] text-cyan-300">
                          In this sandbox
                        </div>
                        <p className="text-slate-300">{entry.inSandbox}</p>
                      </div>
                    </div>
                    {entry.diagram && <div className="pt-1">{entry.diagram}</div>}
                  </div>
                )}
              </section>
            );
          })}

          {/* Credits & Procedural Architecture */}
          <section className="rounded-[20px] bg-slate-950/60 p-4 ring-1 ring-white/10 space-y-2">
            <h3 className="font-display text-[14.5px] font-semibold text-slate-100">
              Credits &amp; Procedural Architecture
            </h3>
            <p className="text-[12px] leading-relaxed text-slate-400">
              Zero external image assets or physics libraries. All soil albedos, basalt rock
              textures, 2x articulated 8-frame ant sprites, faceted emerald crystal clusters,
              spatial hash grids, and 256-entry RGB pheromone LUTs are procedurally synthesized
              in pure TypeScript and Canvas 2D.
            </p>
            <div className="flex flex-wrap gap-2 pt-1 text-[11px] text-slate-300">
              <span className="rounded-full bg-white/[0.06] px-2.5 py-1 ring-1 ring-white/10">
                1-6: Select tool
              </span>
              <span className="rounded-full bg-white/[0.06] px-2.5 py-1 ring-1 ring-white/10">
                Space: Play / Pause
              </span>
              <span className="rounded-full bg-white/[0.06] px-2.5 py-1 ring-1 ring-white/10">
                [ / ]: Brush size
              </span>
              <span className="rounded-full bg-white/[0.06] px-2.5 py-1 ring-1 ring-white/10">
                Esc: Close dialogs
              </span>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
