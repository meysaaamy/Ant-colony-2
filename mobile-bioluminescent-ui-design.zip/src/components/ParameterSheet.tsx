"use client";

import React, { useEffect, useRef, useState } from "react";
import { renderPresetPreviewCanvas } from "@/lib/presets";
import {
  DEFAULT_SIM_CONFIG,
  PRESET_DEFINITIONS,
  ParameterTab,
  PresetDefinition,
  PresetId,
  SheetSnap,
  SimSpeed,
  SimulationConfig,
  TelemetrySnapshot,
} from "@/lib/types";
import { BioSlider } from "./ui/BioSlider";
import {
  CloseIcon,
  ResetArrowIcon,
  SlidersIcon,
  SparkleSweepIcon,
} from "./ui/icons";

export interface ParameterSheetProps {
  snap: SheetSnap;
  activeTab: ParameterTab;
  activePreset: PresetId;
  config: SimulationConfig;
  telemetry: TelemetrySnapshot;
  onChangeSnap: (snap: SheetSnap) => void;
  onChangeTab: (tab: ParameterTab) => void;
  onUpdateConfig: (partial: Partial<SimulationConfig>) => void;
  onClearPheromones: () => void;
  onResetWorld: () => void;
  onSelectPreset: (preset: PresetId) => void;
}

function PresetPreviewCard({
  preset,
  isSelected,
  onSelect,
}: {
  preset: PresetDefinition;
  isSelected: boolean;
  onSelect: () => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    if (canvasRef.current) {
      renderPresetPreviewCanvas(canvasRef.current, preset.id);
    }
  }, [preset.id]);

  return (
    <button
      type="button"
      onClick={onSelect}
      className="snap-start shrink-0 w-[238px] rounded-[18px] p-2.5 text-left transition-all active:scale-[0.98]"
      style={{
        background: isSelected
          ? "radial-gradient(120% 100% at 50% 100%, rgba(0, 240, 255, 0.14), rgba(8, 12, 20, 0.85))"
          : "rgba(10, 15, 25, 0.72)",
        boxShadow: isSelected
          ? "inset 0 1px 0 rgba(255,255,255,0.18), 0 0 0 1.5px rgba(0, 240, 255, 0.58), 0 8px 24px rgba(0, 240, 255, 0.14)"
          : "inset 0 1px 0 rgba(255,255,255,0.08), 0 0 0 1px rgba(255,255,255,0.08)",
      }}
    >
      <div className="relative mb-2 overflow-hidden rounded-[12px] border border-white/10 bg-[#04070e]">
        <canvas
          ref={canvasRef}
          width={216}
          height={102}
          className="block w-full h-[96px] object-cover"
        />
        {isSelected && (
          <span className="absolute right-2 top-2 rounded-full bg-cyan-400/20 px-2 py-0.5 text-[10px] font-semibold text-cyan-200 ring-1 ring-cyan-300/40">
            Active
          </span>
        )}
      </div>
      <div className="font-display text-[15px] font-semibold leading-tight text-slate-100">
        {preset.title}
      </div>
      <div className="mt-0.5 text-[10.5px] font-medium uppercase tracking-[0.06em] text-cyan-300/80">
        {preset.subtitle}
      </div>
      <p className="mt-1 line-clamp-2 text-[11.5px] leading-snug text-slate-400">
        {preset.description}
      </p>
    </button>
  );
}

export function ParameterSheet({
  snap,
  activeTab,
  activePreset,
  config,
  telemetry,
  onChangeSnap,
  onChangeTab,
  onUpdateConfig,
  onClearPheromones,
  onResetWorld,
  onSelectPreset,
}: ParameterSheetProps) {
  const [resetArmed, setResetArmed] = useState(false);
  const armTimerRef = useRef<number | null>(null);
  const dragStartYRef = useRef<number | null>(null);

  const currentPresetMeta =
    PRESET_DEFINITIONS.find((p) => p.id === activePreset) ?? PRESET_DEFINITIONS[0];

  useEffect(() => {
    return () => {
      if (armTimerRef.current !== null) {
        window.clearTimeout(armTimerRef.current);
      }
    };
  }, []);

  const handleResetTap = () => {
    if (!resetArmed) {
      setResetArmed(true);
      if (armTimerRef.current !== null) window.clearTimeout(armTimerRef.current);
      armTimerRef.current = window.setTimeout(() => {
        setResetArmed(false);
      }, 3000);
      return;
    }
    if (armTimerRef.current !== null) window.clearTimeout(armTimerRef.current);
    setResetArmed(false);
    onResetWorld();
  };

  const handlePeekTap = () => {
    if (snap === "peek") onChangeSnap("half");
    else if (snap === "half") onChangeSnap("full");
    else onChangeSnap("peek");
  };

  const handleDragStart = (e: React.PointerEvent<HTMLDivElement>) => {
    dragStartYRef.current = e.clientY;
  };

  const handleDragEnd = (e: React.PointerEvent<HTMLDivElement>) => {
    if (dragStartYRef.current === null) return;
    const dy = e.clientY - dragStartYRef.current;
    dragStartYRef.current = null;
    if (dy < -36) {
      onChangeSnap(snap === "peek" ? "half" : "full");
    } else if (dy > 36) {
      onChangeSnap(snap === "full" ? "half" : "peek");
    }
  };

  const resetTabDefaults = () => {
    if (activeTab === "colony") {
      onUpdateConfig({ maxAnts: DEFAULT_SIM_CONFIG.maxAnts });
    } else if (activeTab === "pheromones") {
      onUpdateConfig({
        evaporationRate: DEFAULT_SIM_CONFIG.evaporationRate,
        diffusionRate: DEFAULT_SIM_CONFIG.diffusionRate,
        trailSensitivity: DEFAULT_SIM_CONFIG.trailSensitivity,
        antennaAngleDeg: DEFAULT_SIM_CONFIG.antennaAngleDeg,
      });
    } else if (activeTab === "brush") {
      onUpdateConfig({
        brushRadius: DEFAULT_SIM_CONFIG.brushRadius,
        depositionIntensity: DEFAULT_SIM_CONFIG.depositionIntensity,
        timeScale: DEFAULT_SIM_CONFIG.timeScale,
      });
    } else {
      onSelectPreset("open-sanctuary");
    }
  };

  const isExpanded = snap !== "peek";

  const tabs: Array<{ id: ParameterTab; label: string }> = [
    { id: "colony", label: "Colony" },
    { id: "pheromones", label: "Pheromones" },
    { id: "brush", label: "Brush" },
    { id: "world", label: "World" },
  ];

  const renderTabContent = () => (
    <div className="space-y-4">
      {/* Tab Bar */}
      <div
        role="tablist"
        aria-label="Simulation parameter categories"
        className="grid grid-cols-4 gap-1 rounded-[14px] bg-slate-950/75 p-1 shadow-[inset_0_1px_2px_rgba(0,0,0,0.7),0_0_0_1px_rgba(255,255,255,0.06)]"
      >
        {tabs.map((tab) => {
          const selected = tab.id === activeTab;
          return (
            <button
              key={tab.id}
              role="tab"
              type="button"
              aria-selected={selected}
              onClick={() => onChangeTab(tab.id)}
              className={`h-[34px] rounded-[10px] text-[12px] font-semibold transition-all ${
                selected
                  ? "bg-white/10 text-slate-100 shadow-[inset_0_1px_0_rgba(255,255,255,0.16),0_0_0_1px_rgba(255,255,255,0.1)]"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Tab Panels */}
      {activeTab === "colony" && (
        <div className="space-y-4">
          <BioSlider
            id="param-max-ants"
            label="Max colony population"
            technicalTerm="SoA cap"
            helperText="Every 3 delivered crystals spawns a new elite-bred ant up to this limit."
            value={config.maxAnts}
            defaultValue={DEFAULT_SIM_CONFIG.maxAnts}
            min={100}
            max={3000}
            step={50}
            unit="ants"
            accentColor="#00f0ff"
            coreColor="#e0ffff"
            ambientColor="rgba(0, 240, 255, 0.35)"
            onChange={(val) => onUpdateConfig({ maxAnts: val })}
          />

          {/* RL Swarm Neuro-Evolution Live Ledger */}
          <div className="rounded-[16px] bg-slate-950/70 p-3 shadow-[inset_0_1px_0_rgba(255,255,255,0.07),0_0_0_1px_rgba(0,240,255,0.16)]">
            <div className="mb-2 flex items-center justify-between">
              <span className="text-[11px] font-semibold uppercase tracking-[0.08em] text-cyan-300">
                Neuro-Evolutionary Telemetry
              </span>
              <span className="tabular-nums rounded-full bg-cyan-400/15 px-2 py-0.5 text-[10.5px] font-semibold text-cyan-200">
                Gen {telemetry.generation}
              </span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-[11.5px]">
              <div className="rounded-xl bg-white/[0.03] px-2.5 py-2">
                <div className="text-slate-400">Avg RL fitness</div>
                <div className="tabular-nums text-[14px] font-semibold text-amber-200">
                  {telemetry.avgFitness.toFixed(1)}
                </div>
              </div>
              <div className="rounded-xl bg-white/[0.03] px-2.5 py-2">
                <div className="text-slate-400">Elite peak / HoF</div>
                <div className="tabular-nums text-[14px] font-semibold text-emerald-200">
                  {telemetry.eliteScore.toFixed(1)}{" "}
                  <span className="text-[11px] text-slate-400">
                    ({telemetry.hallOfFameCount})
                  </span>
                </div>
              </div>
              <div className="rounded-xl bg-white/[0.03] px-2.5 py-2">
                <div className="text-slate-400">False trails damped</div>
                <div className="tabular-nums text-[14px] font-semibold text-rose-200">
                  {telemetry.suppressedTrails}
                </div>
              </div>
              <div className="rounded-xl bg-white/[0.03] px-2.5 py-2">
                <div className="text-slate-400">Foresight / Commit</div>
                <div className="tabular-nums text-[13px] font-semibold text-cyan-100">
                  {telemetry.avgForesight.toFixed(2)} / {telemetry.avgTrailCommit.toFixed(2)}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === "pheromones" && (
        <div className="space-y-3.5">
          <BioSlider
            id="param-evap"
            label="Trail fade"
            technicalTerm="evaporation, lambda"
            helperText="Exponential decay rate. Alarm pheromone evaporates 3.5x faster."
            value={config.evaporationRate}
            defaultValue={DEFAULT_SIM_CONFIG.evaporationRate}
            min={0.03}
            max={0.45}
            step={0.01}
            unit="/s"
            accentColor="#ffae00"
            coreColor="#fff3b0"
            ambientColor="rgba(255, 174, 0, 0.35)"
            onChange={(val) => onUpdateConfig({ evaporationRate: val })}
          />
          <BioSlider
            id="param-diff"
            label="Chemical spread"
            technicalTerm="diffusion coefficient"
            helperText="CFL-stable 3x3 dispersion bounded strictly by basalt walls."
            value={config.diffusionRate}
            defaultValue={DEFAULT_SIM_CONFIG.diffusionRate}
            min={0.0}
            max={0.45}
            step={0.01}
            accentColor="#00f0ff"
            coreColor="#e0ffff"
            ambientColor="rgba(0, 240, 255, 0.32)"
            onChange={(val) => onUpdateConfig({ diffusionRate: val })}
          />
          <BioSlider
            id="param-sens"
            label="Trail sensitivity"
            technicalTerm="alpha"
            helperText="Gain on bilateral Weber-Fechner antenna contrast."
            value={config.trailSensitivity}
            defaultValue={DEFAULT_SIM_CONFIG.trailSensitivity}
            min={0.4}
            max={3.0}
            step={0.05}
            accentColor="#00e676"
            coreColor="#b9f6ca"
            ambientColor="rgba(0, 230, 118, 0.32)"
            onChange={(val) => onUpdateConfig({ trailSensitivity: val })}
          />
          <BioSlider
            id="param-angle"
            label="Antenna sensor angle"
            technicalTerm="degrees"
            helperText="Angular spread between left and right tropotaxis chemoreceptors."
            value={config.antennaAngleDeg}
            defaultValue={DEFAULT_SIM_CONFIG.antennaAngleDeg}
            min={18}
            max={68}
            step={2}
            unit="deg"
            accentColor="#00f0ff"
            coreColor="#e0ffff"
            ambientColor="rgba(0, 240, 255, 0.3)"
            onChange={(val) => onUpdateConfig({ antennaAngleDeg: val })}
          />
        </div>
      )}

      {activeTab === "brush" && (
        <div className="space-y-4">
          <BioSlider
            id="sheet-brush-radius"
            label="Brush radius"
            technicalTerm="world units"
            helperText="Controls stroke width for scent ribbons, crystals, and basalt walls."
            value={config.brushRadius}
            defaultValue={DEFAULT_SIM_CONFIG.brushRadius}
            min={8}
            max={64}
            step={2}
            unit="px"
            accentColor="#ffae00"
            coreColor="#fff3b0"
            ambientColor="rgba(255, 174, 0, 0.35)"
            onChange={(val) => onUpdateConfig({ brushRadius: val })}
          />
          <BioSlider
            id="sheet-deposition"
            label="Deposition intensity"
            technicalTerm="concentration gain"
            helperText="Concentration strength deposited along each interpolated stroke segment."
            value={config.depositionIntensity}
            defaultValue={DEFAULT_SIM_CONFIG.depositionIntensity}
            min={0.2}
            max={1.5}
            step={0.04}
            formatValue={(v) => `${Math.round(v * 100)}%`}
            accentColor="#00e676"
            coreColor="#b9f6ca"
            ambientColor="rgba(0, 230, 118, 0.32)"
            onChange={(val) => onUpdateConfig({ depositionIntensity: val })}
          />

          {/* Simulation Time Scale Segmented Control */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-[13px] font-medium text-slate-200">
              <span>
                Simulation time scale{" "}
                <span className="text-[11px] font-normal text-slate-400">(fixed dt)</span>
              </span>
              <span className="tabular-nums text-[12px] font-semibold text-cyan-200">
                {config.timeScale}x
              </span>
            </div>
            <div className="grid grid-cols-3 gap-1.5 rounded-[14px] bg-slate-950/75 p-1 ring-1 ring-white/8">
              {([1, 2, 4] as SimSpeed[]).map((spd) => {
                const active = config.timeScale === spd;
                return (
                  <button
                    key={spd}
                    type="button"
                    onClick={() => onUpdateConfig({ timeScale: spd })}
                    className={`h-[36px] rounded-[10px] text-[12.5px] font-semibold tabular-nums transition ${
                      active
                        ? "bg-cyan-400/20 text-cyan-100 ring-1 ring-cyan-400/45 shadow-[0_0_12px_rgba(0,240,255,0.18)]"
                        : "text-slate-400 hover:text-slate-200"
                    }`}
                  >
                    {spd}x
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {activeTab === "world" && (
        <div className="space-y-2.5">
          <div className="flex gap-3 overflow-x-auto pb-1 snap-x snap-mandatory no-scrollbar">
            {PRESET_DEFINITIONS.map((p) => (
              <PresetPreviewCard
                key={p.id}
                preset={p}
                isSelected={p.id === activePreset}
                onSelect={() => onSelectPreset(p.id)}
              />
            ))}
          </div>
          <p className="text-[11px] text-slate-400">
            Select a deterministic habitat to reset terrain, nest, and nutrient groves.
          </p>
        </div>
      )}

      {/* Per-tab Reset to defaults */}
      {activeTab !== "world" && (
        <div className="flex justify-end pt-1">
          <button
            type="button"
            onClick={resetTabDefaults}
            className="inline-flex h-[34px] items-center gap-1.5 rounded-full bg-white/[0.05] px-3 text-[11.5px] font-medium text-slate-300 ring-1 ring-white/10 transition hover:bg-white/[0.09] active:scale-95"
          >
            <ResetArrowIcon size={13} />
            Reset to defaults
          </button>
        </div>
      )}
    </div>
  );

  return (
    <>
      {/* Tier 1 — Interactive World Controls & Preset Peek Card (Mobile Bottom Stack) */}
      <div className="w-full lg:hidden">
        <div
          className="obsidian-glass w-full overflow-hidden rounded-[22px] transition-all duration-300"
          style={{
            maxHeight:
              snap === "peek" ? "76px" : snap === "half" ? "44dvh" : "68dvh",
          }}
        >
          {/* Centered Top Drag-Handle Pill */}
          <div
            onPointerDown={handleDragStart}
            onPointerUp={handleDragEnd}
            className="flex w-full cursor-grab items-center justify-center pt-2 pb-1 active:cursor-grabbing"
          >
            <div
              className="h-[4px] w-[36px] rounded-full"
              style={{ backgroundColor: "rgba(255,255,255,0.22)" }}
            />
          </div>

          {/* Peek Strip Header Row */}
          <div className="flex items-center justify-between gap-2 px-3 pb-2.5">
            <button
              type="button"
              onClick={handlePeekTap}
              aria-expanded={isExpanded}
              aria-label={`World controls: ${currentPresetMeta.title}. Tap to expand or collapse settings.`}
              className="flex min-w-0 items-center gap-2.5 text-left"
            >
              <span className="flex h-[38px] w-[38px] shrink-0 items-center justify-center rounded-[12px] bg-white/[0.06] text-slate-200 ring-1 ring-white/12">
                <SlidersIcon size={17} />
              </span>
              <span className="min-w-0">
                <span className="block text-[11px] font-medium leading-tight text-slate-400">
                  World controls
                </span>
                <span className="block truncate text-[15px] font-bold leading-tight text-slate-100">
                  {currentPresetMeta.title}
                </span>
              </span>
            </button>

            {/* Right Tactile Pill Actions: Clear trails & 2-Tap Armed Reset */}
            <div className="flex shrink-0 items-center gap-1.5">
              <button
                type="button"
                onClick={onClearPheromones}
                aria-label="Clear pheromone trails"
                className="inline-flex h-[36px] items-center gap-1.5 rounded-full bg-white/[0.06] px-2.5 text-[11.5px] font-semibold text-slate-200 ring-1 ring-white/12 transition hover:bg-white/[0.11] active:scale-95"
              >
                <SparkleSweepIcon size={14} className="text-cyan-300" />
                <span className="hidden min-[380px]:inline">Clear trails</span>
                <span className="min-[380px]:hidden">Clear</span>
              </button>

              <button
                type="button"
                onClick={handleResetTap}
                aria-label={resetArmed ? "Tap again to reset world" : "Reset world"}
                className="inline-flex h-[36px] items-center gap-1.5 rounded-full px-2.5 text-[11.5px] font-semibold transition-all active:scale-95"
                style={
                  resetArmed
                    ? {
                        background: "rgba(255, 174, 0, 0.16)",
                        color: "#fff3b0",
                        boxShadow: "0 0 0 1px rgba(255, 174, 0, 0.58)",
                      }
                    : {
                        background: "rgba(255, 255, 255, 0.06)",
                        color: "#e2e8f0",
                        boxShadow: "0 0 0 1px rgba(255, 255, 255, 0.12)",
                      }
                }
              >
                <ResetArrowIcon
                  size={14}
                  className={resetArmed ? "text-amber-300" : "text-slate-300"}
                />
                <span>{resetArmed ? "Tap again" : "Reset"}</span>
              </button>
            </div>
          </div>

          {/* Scrollable Expanded Sheet Body */}
          {isExpanded && (
            <div className="max-h-[calc(68dvh-82px)] overflow-y-auto px-3.5 pb-4 pt-1 border-t border-white/8">
              {renderTabContent()}
            </div>
          )}
        </div>
      </div>

      {/* Desktop Right Side Inspector Panel (lg+) */}
      {isExpanded && (
        <aside
          aria-label="Simulation parameter inspector"
          className="obsidian-glass pointer-events-auto fixed right-5 top-[72px] bottom-5 z-30 hidden w-[360px] flex-col rounded-[24px] lg:flex overflow-hidden"
        >
          <div className="flex items-center justify-between border-b border-white/8 px-4 py-3.5">
            <div>
              <div className="text-[11px] font-medium uppercase tracking-[0.08em] text-slate-400">
                World controls
              </div>
              <div className="font-display text-[17px] font-semibold text-slate-100">
                {currentPresetMeta.title}
              </div>
            </div>
            <button
              type="button"
              onClick={() => onChangeSnap("peek")}
              aria-label="Close parameter panel"
              className="flex h-[36px] w-[36px] items-center justify-center rounded-xl bg-white/[0.06] text-slate-300 ring-1 ring-white/10 hover:bg-white/[0.1]"
            >
              <CloseIcon size={17} />
            </button>
          </div>

          <div className="flex items-center gap-2 border-b border-white/8 px-4 py-2.5">
            <button
              type="button"
              onClick={onClearPheromones}
              className="inline-flex h-[34px] flex-1 items-center justify-center gap-1.5 rounded-full bg-white/[0.06] px-3 text-[12px] font-semibold text-slate-200 ring-1 ring-white/12 hover:bg-white/[0.1]"
            >
              <SparkleSweepIcon size={14} className="text-cyan-300" />
              Clear trails
            </button>
            <button
              type="button"
              onClick={handleResetTap}
              className="inline-flex h-[34px] flex-1 items-center justify-center gap-1.5 rounded-full px-3 text-[12px] font-semibold transition"
              style={
                resetArmed
                  ? {
                      background: "rgba(255, 174, 0, 0.16)",
                      color: "#fff3b0",
                      boxShadow: "0 0 0 1px rgba(255, 174, 0, 0.58)",
                    }
                  : {
                      background: "rgba(255, 255, 255, 0.06)",
                      color: "#e2e8f0",
                      boxShadow: "0 0 0 1px rgba(255, 255, 255, 0.12)",
                    }
              }
            >
              <ResetArrowIcon size={14} />
              {resetArmed ? "Tap again" : "Reset"}
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-4">{renderTabContent()}</div>
        </aside>
      )}
    </>
  );
}
