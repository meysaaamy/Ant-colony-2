"use client";

import React, { useEffect, useImperativeHandle, useRef, useState } from "react";
import { AntColonySoA } from "@/lib/ant-soa-engine";
import { DirtyRect, PheromoneGrid } from "@/lib/pheromone-grid";
import { generatePresetWorld } from "@/lib/presets";
import { SanctuaryRenderer } from "@/lib/renderer";
import {
  ActiveStroke,
  FoodCluster,
  NestState,
  PresetId,
  SimulationConfig,
  TOOL_MAP,
  TelemetrySnapshot,
  ToolId,
} from "@/lib/types";

export interface SanctuaryCanvasHandle {
  clearPheromones: () => void;
  resetWorld: () => void;
  loadPreset: (preset: PresetId) => void;
}

export interface SanctuaryCanvasProps {
  activeTool: ToolId;
  activePreset: PresetId;
  isPlaying: boolean;
  config: SimulationConfig;
  onTelemetry: (snapshot: TelemetrySnapshot) => void;
  onPaintingChange: (painting: boolean) => void;
  onStrokeStarted: () => void;
  onFirstFoodDelivered: () => void;
  onCapacityReached: () => void;
  onShowCaption: (text: string, durationMs?: number) => void;
  onVisibilityAutoPause: (pausedByTab: boolean) => void;
}

let inMemoryOnboarded = false;

function hasCompletedOnboarding(): boolean {
  try {
    if (window.localStorage.getItem("sanctuary_onboarded") === "1") return true;
  } catch {
    // ignore storage errors
  }
  return inMemoryOnboarded;
}

function markOnboarded(): void {
  inMemoryOnboarded = true;
  try {
    window.localStorage.setItem("sanctuary_onboarded", "1");
  } catch {
    // ignore storage errors
  }
}

export const SanctuaryCanvas = React.forwardRef<
  SanctuaryCanvasHandle,
  SanctuaryCanvasProps
>(function SanctuaryCanvas(
  {
    activeTool,
    activePreset,
    isPlaying,
    config,
    onTelemetry,
    onPaintingChange,
    onStrokeStarted,
    onFirstFoodDelivered,
    onCapacityReached,
    onShowCaption,
    onVisibilityAutoPause,
  },
  ref
) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [splashPhase, setSplashPhase] = useState<"visible" | "fading" | "hidden">("visible");

  // Mutable simulation state refs (never reallocated on resize)
  const simRef = useRef<{
    grid: PheromoneGrid;
    colony: AntColonySoA;
    renderer: SanctuaryRenderer;
    nest: NestState;
    clusters: FoodCluster[];
    nextClusterId: number;
    lastPlantedX: number;
    lastPlantedY: number;
    ghostActive: boolean;
    ghostTimer: number;
    firstFoodNotified: boolean;
    tickCount: number;
  } | null>(null);

  const propsRef = useRef({
    activeTool,
    activePreset,
    isPlaying,
    config,
    onTelemetry,
    onPaintingChange,
    onStrokeStarted,
    onFirstFoodDelivered,
    onCapacityReached,
    onShowCaption,
    onVisibilityAutoPause,
  });

  useEffect(() => {
    propsRef.current = {
      activeTool,
      activePreset,
      isPlaying,
      config,
      onTelemetry,
      onPaintingChange,
      onStrokeStarted,
      onFirstFoodDelivered,
      onCapacityReached,
      onShowCaption,
      onVisibilityAutoPause,
    };
  }, [
    activeTool,
    activePreset,
    isPlaying,
    config,
    onTelemetry,
    onPaintingChange,
    onStrokeStarted,
    onFirstFoodDelivered,
    onCapacityReached,
    onShowCaption,
    onVisibilityAutoPause,
  ]);

  const strokeRef = useRef<ActiveStroke>({
    active: false,
    pointerId: null,
    tool: activeTool,
    points: [],
    lastX: 0,
    lastY: 0,
    rippleX: 0,
    rippleY: 0,
    rippleAge: 0,
  });

  const paintRestoreTimerRef = useRef<number | null>(null);
  const accumulatorRef = useRef<number>(0);

  // Imperative actions exposed to parent page
  useImperativeHandle(ref, () => ({
    clearPheromones: () => {
      if (!simRef.current) return;
      simRef.current.grid.clearPheromones();
    },
    resetWorld: () => {
      const sim = simRef.current;
      const canvas = canvasRef.current;
      if (!sim || !canvas) return;
      sim.renderer.triggerCrossfade(canvas);
      const gen = generatePresetWorld(propsRef.current.activePreset, sim.grid);
      sim.nest = gen.nest;
      sim.clusters = gen.clusters;
      sim.nextClusterId = gen.clusters.length + 10;
      sim.colony.reset(
        Math.min(gen.initialAnts, propsRef.current.config.maxAnts),
        sim.nest
      );
      sim.renderer.rebuildTerrainFull(sim.grid);
      sim.firstFoodNotified = false;
    },
    loadPreset: (preset: PresetId) => {
      const sim = simRef.current;
      const canvas = canvasRef.current;
      if (!sim || !canvas) return;
      sim.renderer.triggerCrossfade(canvas);
      const gen = generatePresetWorld(preset, sim.grid);
      sim.nest = gen.nest;
      sim.clusters = gen.clusters;
      sim.nextClusterId = gen.clusters.length + 10;
      sim.colony.reset(
        Math.min(gen.initialAnts, propsRef.current.config.maxAnts),
        sim.nest
      );
      sim.renderer.rebuildTerrainFull(sim.grid);
      sim.firstFoodNotified = false;
    },
  }));

  // Initialize simulation once on mount & manage RAF loop + Resize + Visibility
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d", { alpha: false });
    if (!ctx) return;

    const vw = window.innerWidth || 390;
    const vh = window.innerHeight || 844;
    const isPortrait = vh >= vw;

    // Fixed logical world coordinate space (minimum 720x1280 or 1280x720)
    const worldWidth = isPortrait
      ? 720
      : Math.max(1280, Math.round(720 * (vw / Math.max(1, vh))));
    const worldHeight = isPortrait
      ? Math.max(1280, Math.round(720 * (vh / Math.max(1, vw))))
      : 720;

    const grid = new PheromoneGrid(worldWidth, worldHeight, 6);
    const colony = new AntColonySoA(worldWidth, worldHeight);
    const gen = generatePresetWorld(propsRef.current.activePreset, grid);
    colony.reset(
      Math.min(gen.initialAnts, propsRef.current.config.maxAnts),
      gen.nest
    );
    const renderer = new SanctuaryRenderer(worldWidth, worldHeight, grid);

    const onboarded = hasCompletedOnboarding();

    simRef.current = {
      grid,
      colony,
      renderer,
      nest: gen.nest,
      clusters: gen.clusters,
      nextClusterId: gen.clusters.length + 10,
      lastPlantedX: -999,
      lastPlantedY: -999,
      ghostActive: !onboarded,
      ghostTimer: 0,
      firstFoodNotified: false,
      tickCount: 0,
    };

    if (!onboarded) {
      propsRef.current.onShowCaption(
        "Draw an amber trail from the nest to the crystals.",
        5000
      );
    }

    // Boot splash fade out after textures & sprites bake
    const splashTimer1 = window.setTimeout(() => setSplashPhase("fading"), 360);
    const splashTimer2 = window.setTimeout(() => setSplashPhase("hidden"), 680);

    // Display canvas sizing (DPR capped at 2) WITHOUT reallocating simulation state
    const applyDisplaySize = () => {
      const rect = canvas.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const targetW = Math.max(1, Math.round(rect.width * dpr));
      const targetH = Math.max(1, Math.round(rect.height * dpr));
      if (canvas.width !== targetW || canvas.height !== targetH) {
        canvas.width = targetW;
        canvas.height = targetH;
      }
    };
    applyDisplaySize();

    let resizeTimer: number | null = null;
    const handleResize = () => {
      if (resizeTimer !== null) window.clearTimeout(resizeTimer);
      resizeTimer = window.setTimeout(() => {
        applyDisplaySize();
      }, 150);
    };

    window.addEventListener("resize", handleResize);
    window.visualViewport?.addEventListener("resize", handleResize);

    // Visibility auto-pause & accumulator reset
    const handleVisibility = () => {
      if (document.hidden) {
        accumulatorRef.current = 0;
        propsRef.current.onVisibilityAutoPause(true);
      } else {
        accumulatorRef.current = 0;
        lastTime = performance.now();
        propsRef.current.onVisibilityAutoPause(false);
      }
    };
    document.addEventListener("visibilitychange", handleVisibility);

    // Main Fixed-Timestep Loop
    let rafId = 0;
    let lastTime = performance.now();
    let lastHudEmit = lastTime;

    const fixedDt = 1 / 60;

    const frame = (now: number) => {
      rafId = window.requestAnimationFrame(frame);
      const sim = simRef.current;
      if (!sim) return;

      const rawMs = Math.min(80, Math.max(1, now - lastTime));
      lastTime = now;
      sim.renderer.recordFrameDelta(rawMs);

      const dtSec = rawMs / 1000;
      const cfg = propsRef.current.config;
      const playing = propsRef.current.isPlaying;

      if (playing) {
        accumulatorRef.current = Math.min(0.18, accumulatorRef.current + dtSec * cfg.timeScale);
        let substeps = 0;
        const maxSubsteps = cfg.timeScale === 4 ? 6 : cfg.timeScale === 2 ? 4 : 3;

        while (accumulatorRef.current >= fixedDt && substeps < maxSubsteps) {
          sim.tickCount++;
          const doDiff =
            sim.renderer.qualityTier === "high" || (sim.tickCount & 1) === 0;

          sim.grid.step(fixedDt, cfg.evaporationRate, cfg.diffusionRate, doDiff);
          sim.colony.step(
            fixedDt,
            cfg,
            sim.grid,
            sim.nest,
            sim.clusters,
            (sx, sy) => sim.renderer.addSparks(sx, sy, "#b9f6ca", 5)
          );

          if (sim.colony.foodDeliveredJustHappened) {
            sim.colony.foodDeliveredJustHappened = false;
            if (!sim.firstFoodNotified) {
              sim.firstFoodNotified = true;
              propsRef.current.onFirstFoodDelivered();
            }
          }
          if (sim.colony.capacityReachedEvent) {
            sim.colony.capacityReachedEvent = false;
            propsRef.current.onCapacityReached();
          }

          accumulatorRef.current -= fixedDt;
          substeps++;
        }
      }

      // First-run Ghost Stroke guidance animation
      let ghostPoint: { x: number; y: number; active: boolean } | null = null;
      if (sim.ghostActive && sim.clusters.length > 0) {
        sim.ghostTimer = (sim.ghostTimer + dtSec * 0.48) % 1;
        // Find nearest cluster to nest
        let nearest = sim.clusters[0];
        let bestD = Infinity;
        for (const cl of sim.clusters) {
          const d = Math.hypot(cl.x - sim.nest.x, cl.y - sim.nest.y);
          if (d < bestD) {
            bestD = d;
            nearest = cl;
          }
        }
        const t = sim.ghostTimer;
        const easeT = t * t * (3 - 2 * t);
        ghostPoint = {
          x: sim.nest.x + (nearest.x - sim.nest.x) * easeT,
          y: sim.nest.y + (nearest.y - sim.nest.y) * easeT,
          active: true,
        };
      }

      sim.renderer.render(
        ctx,
        canvas.width,
        canvas.height,
        dtSec,
        sim.grid,
        sim.colony,
        sim.nest,
        sim.clusters,
        strokeRef.current,
        ghostPoint
      );

      // 10Hz Throttled Telemetry Snapshot
      if (now - lastHudEmit >= 100) {
        lastHudEmit = now;
        let remaining = 0;
        for (let i = 0; i < sim.clusters.length; i++) {
          remaining += sim.clusters[i].amount;
        }
        propsRef.current.onTelemetry({
          fps: sim.renderer.currentFps,
          activeAnts: sim.colony.activeCount,
          storedFood: sim.nest.storedFood,
          totalFoodRemaining: remaining,
          generation: sim.colony.maxGeneration,
          avgFitness: sim.colony.avgFitness,
          eliteScore: sim.colony.eliteScore,
          hallOfFameCount: sim.colony.hofCount,
          suppressedTrails: sim.grid.suppressedCount,
          avgTrailCommit: sim.colony.avgTrailCommit,
          avgCuriosity: sim.colony.avgCuriosity,
          avgForesight: sim.colony.avgForesight,
          qualityTier: sim.renderer.qualityTier,
        });
      }
    };

    rafId = window.requestAnimationFrame(frame);

    return () => {
      window.cancelAnimationFrame(rafId);
      window.clearTimeout(splashTimer1);
      window.clearTimeout(splashTimer2);
      if (resizeTimer !== null) window.clearTimeout(resizeTimer);
      window.removeEventListener("resize", handleResize);
      window.visualViewport?.removeEventListener("resize", handleResize);
      document.removeEventListener("visibilitychange", handleVisibility);
    };
  }, []);

  // Coordinate mapping helper: client pointer -> logical world space
  const clientToWorld = (clientX: number, clientY: number) => {
    const canvas = canvasRef.current;
    const sim = simRef.current;
    if (!canvas || !sim) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    const nx = (clientX - rect.left) / Math.max(1, rect.width);
    const ny = (clientY - rect.top) / Math.max(1, rect.height);
    return {
      x: nx * sim.grid.worldWidth,
      y: ny * sim.grid.worldHeight,
    };
  };

  // Apply active tool at a single interpolated world point
  const applyToolAtPoint = (wx: number, wy: number, tool: ToolId) => {
    const sim = simRef.current;
    if (!sim) return;
    const { brushRadius, depositionIntensity } = propsRef.current.config;
    const strength = 22 * depositionIntensity;

    if (tool === "food-trail") {
      sim.grid.paintPheromoneBrush("foodTrail", wx, wy, brushRadius, strength);
    } else if (tool === "home-trail") {
      sim.grid.paintPheromoneBrush("homeGuide", wx, wy, brushRadius, strength);
    } else if (tool === "alarm") {
      sim.grid.paintPheromoneBrush("alarm", wx, wy, brushRadius, strength * 1.25);
    } else if (tool === "wall") {
      // Do not seal the Nest itself
      const dNest = Math.hypot(wx - sim.nest.x, wy - sim.nest.y);
      if (dNest > sim.nest.radius + brushRadius * 0.45) {
        const dirty: DirtyRect = sim.grid.paintWallCircle(wx, wy, brushRadius, true);
        sim.renderer.rebuildTerrainDirty(sim.grid, dirty);
        sim.colony.ejectAntsFromWalls(sim.grid);
      } else {
        sim.nest.protectionPulse = 1.0;
      }
    } else if (tool === "food-cluster") {
      const distLast = Math.hypot(wx - sim.lastPlantedX, wy - sim.lastPlantedY);
      const minSpacing = Math.max(28, brushRadius * 1.25);
      if (distLast >= minSpacing && !sim.grid.isWallAtWorld(wx, wy)) {
        sim.lastPlantedX = wx;
        sim.lastPlantedY = wy;
        const r = Math.min(34, Math.max(18, brushRadius * 0.95));
        const amount = Math.round(140 + depositionIntensity * 120);
        sim.clusters.push({
          id: sim.nextClusterId++,
          x: wx,
          y: wy,
          radius: r,
          amount,
          maxAmount: amount,
          variant: sim.nextClusterId % 8,
          phase: Math.random() * Math.PI * 2,
          glintTimer: 0.35,
        });
        sim.renderer.addSparks(wx, wy, "#b9f6ca", 6);
      }
    } else if (tool === "eraser") {
      // Eraser dissolves scents, crystals, and basalt, while protecting the Nest
      const dNest = Math.hypot(wx - sim.nest.x, wy - sim.nest.y);
      if (dNest <= sim.nest.radius + brushRadius) {
        sim.nest.protectionPulse = 1.0;
      }
      sim.grid.erasePheromonesInCircle(wx, wy, brushRadius);
      const dirty: DirtyRect = sim.grid.paintWallCircle(wx, wy, brushRadius, false);
      sim.renderer.rebuildTerrainDirty(sim.grid, dirty);
      for (let i = sim.clusters.length - 1; i >= 0; i--) {
        const cl = sim.clusters[i];
        if (Math.hypot(cl.x - wx, cl.y - wy) <= brushRadius + cl.radius * 0.45) {
          sim.clusters.splice(i, 1);
        }
      }
    }
  };

  const applyInterpolatedSegment = (
    x0: number,
    y0: number,
    x1: number,
    y1: number,
    tool: ToolId
  ) => {
    const brushR = propsRef.current.config.brushRadius;
    const step = Math.max(3, brushR * 0.25);
    const dist = Math.hypot(x1 - x0, y1 - y0);
    const steps = Math.max(1, Math.ceil(dist / step));
    for (let i = 1; i <= steps; i++) {
      const t = i / steps;
      applyToolAtPoint(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t, tool);
    }
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    // Track single active drawing pointerId; ignore multi-touch >= 2
    if (strokeRef.current.active && strokeRef.current.pointerId !== e.pointerId) {
      return;
    }
    if (e.button !== 0 && e.pointerType === "mouse") return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    try {
      canvas.setPointerCapture(e.pointerId);
    } catch {
      // ignore if capture unavailable
    }

    if (paintRestoreTimerRef.current !== null) {
      window.clearTimeout(paintRestoreTimerRef.current);
      paintRestoreTimerRef.current = null;
    }

    const pt = clientToWorld(e.clientX, e.clientY);
    const sim = simRef.current;
    if (sim) {
      if (sim.ghostActive) {
        sim.ghostActive = false;
        markOnboarded();
      }
      sim.lastPlantedX = -999;
      sim.lastPlantedY = -999;
    }

    const tool = propsRef.current.activeTool;
    strokeRef.current = {
      active: true,
      pointerId: e.pointerId,
      tool,
      points: [pt],
      lastX: pt.x,
      lastY: pt.y,
      rippleX: pt.x,
      rippleY: pt.y,
      rippleAge: 0.001,
    };

    applyToolAtPoint(pt.x, pt.y, tool);
    sim?.renderer.addSparks(pt.x, pt.y, TOOL_MAP[tool].coreColor, 3);

    propsRef.current.onStrokeStarted();
    propsRef.current.onPaintingChange(true);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const st = strokeRef.current;
    if (!st.active || st.pointerId !== e.pointerId) return;

    const pt = clientToWorld(e.clientX, e.clientY);
    applyInterpolatedSegment(st.lastX, st.lastY, pt.x, pt.y, st.tool);

    st.lastX = pt.x;
    st.lastY = pt.y;
    st.points.push(pt);
    if (st.points.length > 20) st.points.shift();

    if (Math.random() < 0.35) {
      simRef.current?.renderer.addSparks(
        pt.x,
        pt.y,
        TOOL_MAP[st.tool].coreColor,
        1
      );
    }
  };

  const finishStroke = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const st = strokeRef.current;
    if (!st.active || st.pointerId !== e.pointerId) return;

    const canvas = canvasRef.current;
    if (canvas) {
      try {
        if (canvas.hasPointerCapture(e.pointerId)) {
          canvas.releasePointerCapture(e.pointerId);
        }
      } catch {
        // ignore
      }
    }

    st.active = false;
    st.pointerId = null;

    if (paintRestoreTimerRef.current !== null) {
      window.clearTimeout(paintRestoreTimerRef.current);
    }
    paintRestoreTimerRef.current = window.setTimeout(() => {
      propsRef.current.onPaintingChange(false);
    }, 200);
  };

  return (
    <div className="relative h-[100dvh] w-full overflow-hidden bg-[#03050a]">
      <canvas
        ref={canvasRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={finishStroke}
        onPointerCancel={finishStroke}
        onLostPointerCapture={finishStroke}
        className="block h-full w-full touch-none select-none cursor-crosshair"
        aria-label="Bioluminescent Macro-Sanctuary simulation canvas"
      />

      {/* Minimal Nest Concentric Ring Boot Splash */}
      {splashPhase !== "hidden" && (
        <div
          aria-hidden="true"
          className={`pointer-events-none fixed inset-0 z-50 flex items-center justify-center bg-[#03050a] transition-opacity duration-300 ${
            splashPhase === "fading" ? "opacity-0" : "opacity-100"
          }`}
        >
          <div className="splash-ring-anim flex flex-col items-center gap-3">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/logo.svg" alt="" className="h-20 w-20" />
          </div>
        </div>
      )}
    </div>
  );
});
