import { db } from "@/db";
import { AntColonySoA, MAX_ANTS } from "@/lib/ant-soa-engine";
import { PheromoneGrid, createPheromoneLUTs } from "@/lib/pheromone-grid";
import { generatePresetWorld } from "@/lib/presets";
import { PresetId } from "@/lib/types";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    // 1. Verify PostgreSQL connectivity
    await db.execute(sql`select 1`);

    // 2. Verify Pheromone LUTs (256 * 4 bytes per channel)
    const luts = createPheromoneLUTs();
    const lutValid =
      luts.food.length === 256 * 4 &&
      luts.home.length === 256 * 4 &&
      luts.alarm.length === 256 * 4;

    // 3. Verify Zero-Flux Neumann wall boundary blocks diffusion
    const testGrid = new PheromoneGrid(60, 60, 6);
    // Vertical wall at gx = 5
    for (let gy = 0; gy < testGrid.rows; gy++) {
      testGrid.wallMask[gy * testGrid.cols + 5] = 1;
    }
    testGrid.foodTrailA[5 * testGrid.cols + 4] = 80.0;
    testGrid.step(1 / 60, 0.05, 0.25, true);
    const leakedAcrossWall = testGrid.foodTrailA[5 * testGrid.cols + 6];
    const neumannValid = leakedAcrossWall === 0;

    // 4. Verify Weber-Fechner logarithmic perception
    const sLow = Math.log(1 + 2);
    const sHigh = Math.log(1 + 50);
    const weberValid = sLow > 0 && sHigh > sLow;

    // 5. Verify SoA allocation & all 3 deterministic presets
    const colony = new AntColonySoA(720, 1280);
    const presets: PresetId[] = [
      "open-sanctuary",
      "double-bridge",
      "subterranean-labyrinth",
    ];
    const presetCheck: Record<string, { clusters: number; ants: number }> = {};

    for (const pid of presets) {
      const g = new PheromoneGrid(720, 1280, 6);
      const gen = generatePresetWorld(pid, g);
      colony.reset(gen.initialAnts, gen.nest);
      presetCheck[pid] = {
        clusters: gen.clusters.length,
        ants: colony.activeCount,
      };
    }

    const ok =
      lutValid &&
      neumannValid &&
      weberValid &&
      colony.x.length === MAX_ANTS &&
      presetCheck["open-sanctuary"].clusters === 3 &&
      presetCheck["double-bridge"].clusters === 1 &&
      presetCheck["subterranean-labyrinth"].clusters === 2;

    if (!ok) {
      return Response.json(
        {
          ok: false,
          lutValid,
          neumannValid,
          weberValid,
          presetCheck,
        },
        { status: 500 }
      );
    }

    return Response.json({
      ok: true,
      diagnostics: {
        maxAntCapacity: MAX_ANTS,
        lutEntriesPerChannel: 256,
        zeroFluxNeumannVerified: neumannValid,
        leakedAcrossWall,
        presets: presetCheck,
      },
    });
  } catch (err) {
    return Response.json(
      { ok: false, error: err instanceof Error ? err.message : "Health check failed" },
      { status: 500 }
    );
  }
}
