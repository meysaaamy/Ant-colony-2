import { SanctuaryApp } from "@/components/SanctuaryApp";

export default function HomePage() {
  return <SanctuaryApp />;
}
