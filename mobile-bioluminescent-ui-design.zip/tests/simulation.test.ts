import { describe, expect, it } from "vitest";
import { AntColonySoA, MAX_ANTS } from "../src/lib/ant-soa-engine";
import { PheromoneGrid, createPheromoneLUTs } from "../src/lib/pheromone-grid";
import { generatePresetWorld } from "../src/lib/presets";
import { DEFAULT_SIM_CONFIG } from "../src/lib/types";

describe("Bioluminescent Macro-Sanctuary Simulation Kernel", () => {
  it("computes Weber-Fechner logarithmic neural stimulus correctly", () => {
    const c1 = 10;
    const c2 = 100;
    const s1 = Math.log(1.0 + c1);
    const s2 = Math.log(1.0 + c2);
    expect(s1).toBeCloseTo(Math.log(11), 6);
    expect(s2 - s1).toBeLessThan(s1 * 1.5);
  });

  it("evaporates alarm pheromone 3.5x faster than trail pheromones", () => {
    const grid = new PheromoneGrid(120, 120, 6);
    const idx = 5 * grid.cols + 5;
    grid.foodTrailA[idx] = 80;
    grid.alarmA[idx] = 80;

    const dt = 0.5;
    const lambda = 0.2;
    grid.step(dt, lambda, 0.0, false);

    expect(grid.foodTrailA[idx]).toBeCloseTo(80 * Math.exp(-dt * lambda), 3);
    expect(grid.alarmA[idx]).toBeCloseTo(80 * Math.exp(-dt * lambda * 3.5), 3);
    expect(grid.alarmA[idx]).toBeLessThan(grid.foodTrailA[idx]);
  });

  it("enforces zero-flux Neumann wall boundaries so chemicals never leak through walls", () => {
    const grid = new PheromoneGrid(120, 120, 6);
    for (let gy = 0; gy < grid.rows; gy++) {
      grid.wallMask[gy * grid.cols + 10] = 1;
    }
    const leftIdx = 10 * grid.cols + 9;
    const rightIdx = 10 * grid.cols + 11;
    grid.foodTrailA[leftIdx] = 95;

    for (let step = 0; step < 15; step++) {
      grid.step(1 / 60, 0.05, 0.3, true);
    }

    expect(grid.foodTrailA[10 * grid.cols + 10]).toBe(0);
    expect(grid.foodTrailA[rightIdx]).toBe(0);
    expect(grid.foodTrailA[leftIdx]).toBeGreaterThan(0);
  });

  it("applies saturating age-attenuated deposition to prevent dead-trail locking", () => {
    const grid = new PheromoneGrid(120, 120, 6);
    grid.depositAtWorld("foodTrail", 30, 30, 10, 1.0);
    const first = grid.sampleChannel("foodTrail", 30, 30);
    expect(first).toBeCloseTo(10, 4);

    // At high concentration (50), deposition is attenuated by 1 / (1 + 0.08 * 50) = 0.2
    const idx = grid.worldToCellY(30) * grid.cols + grid.worldToCellX(30);
    grid.foodTrailA[idx] = 50;
    grid.depositAtWorld("foodTrail", 30, 30, 10, 1.0);
    expect(grid.foodTrailA[idx]).toBeCloseTo(52, 4);
  });

  it("spawns 1 new ant per 3 stored food units and respects MAX_ANTS cap", () => {
    const grid = new PheromoneGrid(720, 1280, 6);
    const gen = generatePresetWorld("open-sanctuary", grid);
    const colony = new AntColonySoA(720, 1280);
    colony.reset(10, gen.nest);

    expect(colony.x.length).toBe(MAX_ANTS);
    expect(colony.activeCount).toBe(10);

    gen.nest.storedFood = 3;
    const spawned = colony.trySpawnFromStoredFood(gen.nest, DEFAULT_SIM_CONFIG.maxAnts);
    expect(spawned).toBe(true);
    expect(colony.activeCount).toBe(11);
  });

  it("damps obsolete food trails when RL Trail-Damping mode activates", () => {
    const grid = new PheromoneGrid(180, 180, 6);
    grid.paintPheromoneBrush("foodTrail", 90, 90, 24, 60);
    const before = grid.sampleChannel("foodTrail", 90, 90);
    expect(before).toBeGreaterThan(20);

    grid.dampFoodTrailAtWorld(90, 90, 24, 0.7);
    const after = grid.sampleChannel("foodTrail", 90, 90);
    expect(after).toBeLessThan(before);
    expect(grid.suppressedCount).toBeGreaterThan(0);
  });

  it("builds valid 256-entry RGBA pheromone LUTs", () => {
    const luts = createPheromoneLUTs();
    expect(luts.food.length).toBe(1024);
    expect(luts.home.length).toBe(1024);
    expect(luts.alarm.length).toBe(1024);
    expect(luts.food[3]).toBe(0); // transparent at 0 concentration
    expect(luts.food[255 * 4 + 3]).toBe(255); // opaque incandescent core
  });
});
