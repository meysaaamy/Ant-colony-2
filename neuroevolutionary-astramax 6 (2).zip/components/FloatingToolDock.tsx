'use client';
import { useState } from 'react';
import { CHANNEL_META,type ChannelIndex,type SimulationSettings,type Tool } from '@/lib/types';
import { Icon,type IconName } from './ui/icons';
export const TOOLS:ReadonlyArray<{id:Tool;label:string;icon:IconName;color:string;description:string}>=[
  {id:'food',label:'Food trail',icon:'food',color:'#e8be7b',description:'Paint a chemical path to a food source'},
  {id:'home',label:'Home',icon:'home',color:'#79d6d8',description:'Paint a guiding signal back to the nest'},
  {id:'alarm',label:'Alarm',icon:'alarm',color:'#e990a6',description:'Trigger a defensive pheromone cascade'},
  {id:'crystal',label:'Crystal',icon:'crystal',color:'#a0dcae',description:'Place a new emerald food reservoir'},
  {id:'wall',label:'Wall',icon:'wall',color:'#a7b9c5',description:'Paint organic basalt obstacles'},
  {id:'eraser',label:'Erase',icon:'eraser',color:'#c3b4cb',description:'Remove trails, walls, food, or emitters'},
  {id:'emitter',label:'Emitter',icon:'emitter',color:'#a4dec4',description:'Place a permanent pheromone point-source'}
];
export default function FloatingToolDock({tool,onTool,settings,onChange}:{tool:Tool;onTool:(tool:Tool)=>void;settings:SimulationSettings;onChange:(patch:Partial<SimulationSettings>)=>void}){
  const [radiusOpen,setRadiusOpen]=useState(false),active=TOOLS.find(t=>t.id===tool)??TOOLS[0],channelTools=tool==='food'||tool==='emitter';
  return <div className="floating-cockpit canvas-ui">
    <div className="tool-context">
      <div className="active-tool-label"><span style={{background:channelTools?CHANNEL_META[settings.emitterChannel].color:active.color}}/>{tool==='emitter'?'Pheromone emitter':tool==='food'?CHANNEL_META[settings.emitterChannel].name:active.label}</div>
      {channelTools&&<div className="channel-dots" aria-label="Pheromone channel">{CHANNEL_META.map((c,i)=><button key={c.name} className={settings.emitterChannel===i?'selected':''} style={{'--channel':c.color} as React.CSSProperties} aria-label={`Select ${c.name}`} aria-pressed={settings.emitterChannel===i} title={c.name} onClick={()=>onChange({emitterChannel:i as ChannelIndex})}><span/></button>)}</div>}
      <div className="context-divider"/><button className="radius-trigger" aria-expanded={radiusOpen} onClick={()=>setRadiusOpen(v=>!v)} aria-label="Adjust brush radius"><span className="radius-symbol"/>{settings.radius}<small>px</small><Icon name="chevron" size={12}/></button>
    </div>
    {radiusOpen&&<div className="radius-popover glass"><div className="section-label"><span>Brush radius</span><b>{settings.radius} px</b><button className="icon-button" onClick={()=>setRadiusOpen(false)} aria-label="Close brush radius"><Icon name="close" size={14}/></button></div><input aria-label="Brush radius" type="range" min="8" max="90" step="2" value={settings.radius} onChange={e=>onChange({radius:Number(e.target.value)})}/><div className="radius-presets">{[12,28,48,72].map(n=><button key={n} className={settings.radius===n?'active':''} onClick={()=>onChange({radius:n})}>{n} px</button>)}</div></div>}
    <div className="tool-dock glass" role="toolbar" aria-label="Sanctuary tools">{TOOLS.map((item,i)=><button key={item.id} className={`tool-button ${tool===item.id?'selected':''} ${item.id==='emitter'?'emitter-tool':''}`} onClick={()=>onTool(item.id)} style={{'--tool-color':item.color} as React.CSSProperties} title={`${item.description} (${i+1})`} aria-label={`${item.label} tool`} aria-pressed={tool===item.id}><span className="tool-key">{i+1}</span><Icon name={item.icon} size={23}/><span className="tool-name">{item.label}</span>{tool===item.id&&<span className="tool-active-mark"/>}</button>)}</div>
    <div className="tool-hint">{tool==='emitter'?'Click to place a permanent signal':tool==='crystal'?'Click to place a food source':tool==='eraser'?'Drag to remove from your world':'Click and drag to shape their world'}</div>
  </div>;
}
