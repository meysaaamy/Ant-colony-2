'use client';
import { Icon } from './ui/icons';
export interface ToastMessage {id:number;text:string;}
export default function ToastOverlay({toast,onClose}:{toast:ToastMessage|null;onClose:()=>void}){
  return <div className="toast-region" aria-live="polite" aria-atomic="true">{toast&&<div className="toast glass" key={toast.id}><span className="toast-icon"><Icon name="check" size={16}/></span><span>{toast.text}</span><button onClick={onClose} aria-label="Dismiss notification"><Icon name="close" size={14}/></button></div>}</div>;
}
