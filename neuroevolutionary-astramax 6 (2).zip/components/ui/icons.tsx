import type { CSSProperties } from 'react';
export type IconName = 'ant' | 'crystal' | 'play' | 'pause' | 'settings' | 'guide' | 'chevron' | 'arrow' | 'food' | 'home' | 'alarm' | 'emitter' | 'wall' | 'eraser' | 'brain' | 'chart' | 'close' | 'check' | 'reset' | 'download' | 'fullscreen' | 'leaf' | 'grid' | 'eye' | 'plus' | 'minus' | 'predator' | 'sun' | 'info' | 'upload' | 'spark' | 'volume';
export function Icon({ name, size = 20, className = '', style }: { name: IconName; size?: number; className?: string; style?: CSSProperties }) {
  const paths: Record<IconName, React.ReactNode> = {
    ant: <><ellipse cx="12" cy="16" rx="3" ry="4"/><ellipse cx="12" cy="9" rx="2.4" ry="2.5"/><circle cx="12" cy="4.5" r="1.8"/><path d="m10 8-4-2-2 2m6 3-5 1-2 3m7 0-3 4v3m7-14 4-2 2 2m-6 3 5 1 2 3m-7 0 3 4v3M11 3 9 1m4 2 2-2"/></>,
    crystal: <><path d="m12 2 7 6-2 10-5 4-5-4L5 8Z"/><path d="m12 2-2 7 2 13 3-13-3-7M5 8l5 1 5 0 4-1"/></>,
    play: <path d="m9 5 11 7-11 7Z" fill="currentColor" strokeWidth="0"/>,
    pause: <><path d="M8 5v14M16 5v14" strokeWidth="3"/></>,
    settings: <><path d="M4 7h16M4 17h16"/><circle cx="9" cy="7" r="2.5" fill="var(--panel, #111a1b)"/><circle cx="15" cy="17" r="2.5" fill="var(--panel, #111a1b)"/></>,
    guide: <><path d="M12 5c-3-2-6-2-9-1v15c3-1 6-1 9 1 3-2 6-2 9-1V4c-3-1-6-1-9 1Zm0 0v15"/><path d="M6 8h3m-3 4h3m6-4h3m-3 4h3"/></>,
    chevron: <path d="m8 10 4 4 4-4"/>, arrow: <path d="M4 12h16m-6-6 6 6-6 6"/>,
    food: <><path d="M4 20c0-6 16-3 16-10 0-5-12-2-12-7"/><path d="m5 17-1 3 3 1M7 3h2"/><circle cx="18" cy="4" r="1"/></>,
    home: <><path d="m3 11 9-8 9 8M6 9v12h12V9M10 21v-7h4v7"/></>,
    alarm: <><path d="m10.4 3.8-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.6-3.2l-8-14a1.8 1.8 0 0 0-3.2 0Z"/><path d="M12 9v5m0 3v.2"/></>,
    emitter: <><circle cx="12" cy="12" r="2.5"/><path d="M7.7 7.7a6 6 0 0 0 0 8.6m8.6-8.6a6 6 0 0 1 0 8.6M4.5 4.5a10.6 10.6 0 0 0 0 15m15-15a10.6 10.6 0 0 1 0 15M12 2v2m0 16v2"/></>,
    wall: <><path d="m3 18 2-9 6-5 7 2 3 12-5 3-8-1Z"/><path d="m5 9 7 3 6-6m-6 6 4 9m-4-9-4 8"/></>,
    eraser: <><path d="m4 13 9-10a2 2 0 0 1 3 0l5 5a2 2 0 0 1 0 3L12 21H9l-5-5a2 2 0 0 1 0-3Z"/><path d="m9 8 10 10m-7 3h9"/></>,
    brain: <><path d="M12 5c-3-5-8-1-7 3-4 1-3 7 0 7-2 4 3 8 7 4 4 4 9 0 7-4 3 0 4-6 0-7 1-4-4-8-7-3Zm0 0v14M5 8l3 2m-3 5 3-2m11-5-3 2m3 5-3-2"/></>,
    chart: <><path d="M4 3v17h17M7 14l4-5 4 3 5-7"/></>,
    close: <path d="m6 6 12 12M6 18 18 6"/>, check: <path d="m5 12 4 4L19 6"/>,
    reset: <><path d="M3 10a9 9 0 1 1 1 7M3 4v6h6"/></>,
    download: <><path d="M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5"/></>,
    upload: <><path d="M12 16V4m-5 5 5-5 5 5M4 16v5h16v-5"/></>,
    fullscreen: <path d="M9 3H3v6m12-6h6v6M3 15v6h6m6 0h6v-6"/>,
    leaf: <><path d="M20 3C9 2 2 7 5 16c7 8 16 0 15-13ZM4 21 15 9"/></>,
    grid: <><rect x="3" y="3" width="18" height="18" rx="3"/><path d="M3 9h18M3 15h18M9 3v18m6-18v18"/></>,
    eye: <><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></>,
    plus: <path d="M12 5v14M5 12h14"/>, minus: <path d="M5 12h14"/>,
    predator: <><path d="m6 7 6-4 6 4-1 10-5 4-5-4ZM3 4l3 3m12 0 3-3M7 11l-5 1m15-1 5 1M7 16l-4 4m14-4 4 4M9 8l2 3m4-3-2 3"/></>,
    sun: <><circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.5 1.5m11 11L19 19M5 19l1.5-1.5m11-11L19 5"/></>,
    info: <><circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10v.2"/></>,
    spark: <><path d="m12 2 2.5 7.5L22 12l-7.5 2.5L12 22l-2.5-7.5L2 12l7.5-2.5Z"/></>,
    volume: <><path d="m11 4-5 4H2v8h4l5 4ZM15 8a6 6 0 0 1 0 8m3-11a10 10 0 0 1 0 14"/></>
  };
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className={className} style={style}>{paths[name]}</svg>;
}
export function BrandMark({ size = 34 }: { size?: number }) {
  return <svg width={size} height={size} viewBox="0 0 40 40" fill="none" aria-hidden="true"><path d="M20 2 35.6 11v18L20 38 4.4 29V11Z" stroke="#a6e8c9" strokeWidth="1.2"/><path d="m20 7 11 6.5v13L20 33 9 26.5v-13Z" stroke="#a6e8c9" strokeOpacity=".25"/><ellipse cx="20" cy="24" rx="3" ry="5" stroke="#a6e8c9" strokeWidth="1.3"/><ellipse cx="20" cy="16" rx="2.4" ry="2.6" stroke="#a6e8c9"/><path d="m18 14-3-3m7 3 3-3m-7 7-5-2m9 2 5-2m-9 5-5 3m9-3 5 3m-8 1-4 6m6-6 4 6" stroke="#a6e8c9" strokeWidth="1.2" strokeLinecap="round"/></svg>;
}
