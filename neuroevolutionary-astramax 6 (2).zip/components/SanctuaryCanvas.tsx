'use client';
import { useEffect,useRef,useState,type PointerEvent } from 'react';
import { AntEngine } from '@/lib/ant-soa-engine';
import { deserializeBrain } from '@/lib/neat';
import { SanctuaryRenderer } from '@/lib/renderer';
import { clamp } from '@/lib/prng-noise';
import type { BrainJSON,BrushState,ChannelIndex,Emitter,SimulationCommand,SimulationSettings,Telemetry,Tool } from '@/lib/types';
import { Icon } from './ui/icons';
interface Props {settings:SimulationSettings;tool:Tool;brain:BrainJSON|null;command:SimulationCommand|null;onTelemetry:(telemetry:Telemetry)=>void;onPainting:(active:boolean)=>void;onToast:(message:string)=>void;}
interface Instance {engine:AntEngine;renderer:SanctuaryRenderer;}
export default function SanctuaryCanvas({settings,tool,brain,command,onTelemetry,onPainting,onToast}:Props){
  const canvasRef=useRef<HTMLCanvasElement>(null),instances=useRef<Instance[]>([]),settingsRef=useRef(settings),callbacks=useRef({onTelemetry,onPainting,onToast}),brainRef=useRef(brain),toolRef=useRef(tool);
  const brush=useRef<BrushState>({x:0,y:0,active:false,visible:false,radius:28,tool:'food'}),pointerId=useRef<number|null>(null),lastPoint=useRef<{x:number;y:number}|null>(null),activeInstance=useRef(0);
  const [zoom,setZoom]=useState(1),zoomRef=useRef(1),[resetKey,setResetKey]=useState(0),[ready,setReady]=useState(false);
  const isAB=settings.policy==='ab-random'||settings.policy==='ab-aco',rivalPolicy=settings.policy==='ab-aco'?'aco':'random';
  useEffect(()=>{settingsRef.current=settings;toolRef.current=tool;callbacks.current={onTelemetry,onPainting,onToast};brainRef.current=brain;brush.current.radius=settings.radius;brush.current.tool=tool;},[settings,tool,brain,onTelemetry,onPainting,onToast]);
  useEffect(()=>{zoomRef.current=zoom;},[zoom]);
  useEffect(()=>{
    const canvas=canvasRef.current;if(!canvas)return;const ctx=canvas.getContext('2d',{alpha:false});if(!ctx)return;
    let alive=true,raf=0,resizeTimer:ReturnType<typeof setTimeout>|undefined,width=1,height=1,dpr=1,previous=performance.now(),accumulator=0,telemetryTime=0,frameCount=0,frameDuration=0,fps=60,hidden=document.hidden;
    let appliedSettings=settingsRef.current,appliedBrain=brainRef.current;
    let sampled=false,healthyWindows=0;
    const create=(rival:boolean):Instance=>{
      const current=settingsRef.current,engineSettings={...current,population:isAB?(rival?Math.ceil(current.population/2):Math.floor(current.population/2)):current.population,policy:isAB?(rival?rivalPolicy:'trained'):current.policy};
      const engine=new AntEngine({population:engineSettings.population,width:isAB?800:1600,height:1000,settings:engineSettings,seed:371,brain:brainRef.current?deserializeBrain(brainRef.current):undefined});
      if(current.predators)engine.spawnPredator();
      if(!rival&&!isAB){try{const stored:unknown=JSON.parse(localStorage.getItem(`formica.emitters.${current.preset}`)??'[]');if(Array.isArray(stored))for(const value of stored.slice(0,64)){if(value&&typeof value==='object'){const e=value as Record<string,unknown>;if(typeof e.x==='number'&&typeof e.y==='number'&&typeof e.channel==='number'&&e.channel>=0&&e.channel<5&&Number.isInteger(e.channel))engine.paint('emitter',clamp(e.x,0,engine.width),clamp(e.y,0,engine.height),typeof e.radius==='number'?clamp(e.radius,12,90):28,e.channel as ChannelIndex);}}}catch{/* Storage may be unavailable in private browsing. */}}
      return{engine,renderer:new SanctuaryRenderer(engine)};
    };
    instances.current=[create(false)];if(isAB)instances.current.push(create(true));
    const resize=()=>{const rect=canvas.getBoundingClientRect();width=rect.width;height=rect.height;dpr=Math.min(window.devicePixelRatio||1,2);canvas.width=Math.round(width*dpr);canvas.height=Math.round(height*dpr);};resize();
    const observer=new ResizeObserver(()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(resize,150);});observer.observe(canvas);
    const visibility=()=>{hidden=document.hidden;previous=performance.now();accumulator=0;};document.addEventListener('visibilitychange',visibility);
    const render=(now:number)=>{
      if(!alive)return;const rawDelta=(now-previous)/1000,delta=Math.min(.1,rawDelta);previous=now;
      if(!hidden){
        const current=settingsRef.current;
        if(current!==appliedSettings){
          for(let i=0;i<instances.current.length;i++){
            const engine=instances.current[i].engine,wasPredators=engine.settings.predators;
            engine.applySettings({...current,population:isAB?(i===0?Math.floor(current.population/2):Math.ceil(current.population/2)):current.population,policy:isAB?(i===0?'trained':rivalPolicy):current.policy});
            if(current.predators&&!wasPredators)engine.spawnPredator();
          }appliedSettings=current;
        }
        if(brainRef.current!==appliedBrain&&brainRef.current){for(const instance of instances.current)instance.engine.brain=deserializeBrain(brainRef.current);appliedBrain=brainRef.current;}
        frameCount++;frameDuration+=rawDelta;
        if(frameCount>=60||(!sampled&&frameCount>=12)){
          fps=Math.round(frameCount/Math.max(.01,frameDuration));sampled=true;frameCount=0;frameDuration=0;
          if(fps<50){healthyWindows=0;for(const instance of instances.current)instance.engine.adaptive=true;}
          else if(fps>57){healthyWindows++;if(healthyWindows>=3)for(const instance of instances.current)instance.engine.adaptive=false;}
        }
        if(!current.paused){accumulator=Math.min(.2,accumulator+delta*current.speed);let steps=0;while(accumulator>=1/60&&steps<10){for(const instance of instances.current)instance.engine.step(1/60);accumulator-=1/60;steps++;}}else accumulator=0;
        for(let i=0;i<instances.current.length;i++)instances.current[i].renderer.render(ctx,width/instances.current.length,height,dpr,zoomRef.current,{...brush.current,visible:brush.current.visible&&activeInstance.current===i},i*width/instances.current.length);
        if(now-telemetryTime>100){
          const primary=instances.current[0].engine.telemetry(fps);
          if(instances.current[1]){const rival=instances.current[1].engine.telemetry(fps);primary.alive+=rival.alive;primary.deaths+=rival.deaths;primary.births+=rival.births;primary.food+=rival.food;primary.coverage=(primary.coverage+rival.coverage)/2;primary.entropy=(primary.entropy+rival.entropy)/2;primary.birthRate+=rival.birthRate;primary.deathRate+=rival.deathRate;primary.rivalFood=rival.food;primary.scouts+=rival.scouts;primary.haulers+=rival.haulers;primary.wardens+=rival.wardens;primary.emitters+=rival.emitters;}
          callbacks.current.onTelemetry(primary);telemetryTime=now;
        }
      }
      raf=requestAnimationFrame(render);
    };
    raf=requestAnimationFrame(render);setReady(true);
    return()=>{alive=false;cancelAnimationFrame(raf);clearTimeout(resizeTimer);observer.disconnect();document.removeEventListener('visibilitychange',visibility);for(const instance of instances.current)instance.renderer.dispose();instances.current=[];};
  },[settings.preset,isAB,rivalPolicy,resetKey]);
  useEffect(()=>{
    if(!command||!instances.current.length)return;
    if(command.type==='reset'){try{localStorage.removeItem(`formica.emitters.${settingsRef.current.preset}`);}catch{}setResetKey(v=>v+1);callbacks.current.onToast('A new colony. A fresh beginning.');return;}
    if(command.type==='clear'){for(const i of instances.current)i.engine.grid.clear();callbacks.current.onToast('Trails cleared. Permanent emitters remain active.');}
    if(command.type==='remove-emitters'){for(const i of instances.current)i.engine.emitters=[];try{localStorage.removeItem(`formica.emitters.${settingsRef.current.preset}`);}catch{}callbacks.current.onToast('All permanent emitters removed.');}
    if(command.type==='predator'){const spawned=instances.current[0].engine.spawnPredator();callbacks.current.onToast(spawned?'An abyssal stalker has entered the sanctuary.':'Maximum of six predators reached.');}
    if(command.type==='snapshot'){canvasRef.current?.toBlob(blob=>{if(!blob){callbacks.current.onToast('Could not capture this frame.');return;}const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`formica-${Date.now()}.png`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);});}
  },[command]);
  const locate=(event:PointerEvent<HTMLCanvasElement>)=>{const rect=event.currentTarget.getBoundingClientRect(),x=event.clientX-rect.left,y=event.clientY-rect.top;const index=instances.current.length===2&&x>rect.width/2?1:0;activeInstance.current=index;const instance=instances.current[index];return instance?{instance,point:instance.renderer.screenToWorld(x,y)}:null;};
  const pointerDown=(event:PointerEvent<HTMLCanvasElement>)=>{
    if(pointerId.current!==null||event.button!==0)return;const located=locate(event);if(!located)return;
    pointerId.current=event.pointerId;event.currentTarget.setPointerCapture(event.pointerId);lastPoint.current=located.point;brush.current={...located.point,active:true,visible:true,radius:settingsRef.current.radius,tool:toolRef.current};callbacks.current.onPainting(true);
    located.instance.engine.paint(toolRef.current,located.point.x,located.point.y,settingsRef.current.radius,settingsRef.current.emitterChannel);
    if(toolRef.current==='emitter')callbacks.current.onToast('Emitter placed. A permanent signal for the swarm.');
  };
  const pointerMove=(event:PointerEvent<HTMLCanvasElement>)=>{
    if(pointerId.current!==null&&event.pointerId!==pointerId.current)return;const located=locate(event);if(!located)return;
    brush.current={...brush.current,...located.point,visible:true};
    if(pointerId.current!==event.pointerId||!lastPoint.current)return;
    const currentTool=toolRef.current,settings=settingsRef.current,old=lastPoint.current,point=located.point;
    if(currentTool==='emitter'||currentTool==='crystal')return;
    if(currentTool==='food'||currentTool==='home'||currentTool==='alarm')located.instance.engine.grid.stroke(currentTool==='food'?settings.emitterChannel:currentTool==='home'?1:2,old,old,point,point,settings.radius,23);
    else if(Math.hypot(old.x-point.x,old.y-point.y)>settings.radius*.65)located.instance.engine.paint(currentTool,point.x,point.y,settings.radius,settings.emitterChannel);else return;
    lastPoint.current=point;
  };
  const pointerUp=(event:PointerEvent<HTMLCanvasElement>)=>{
    if(pointerId.current!==event.pointerId)return;pointerId.current=null;brush.current.active=false;lastPoint.current=null;callbacks.current.onPainting(false);
    if(event.currentTarget.hasPointerCapture(event.pointerId))event.currentTarget.releasePointerCapture(event.pointerId);
    const emitters:Emitter[]=instances.current[0]?.engine.emitters??[];try{localStorage.setItem(`formica.emitters.${settingsRef.current.preset}`,JSON.stringify(emitters));}catch{/* Nonessential persistence. */}
  };
  return <>
    <canvas ref={canvasRef} className={`sanctuary-canvas ${ready?'ready':''}`} aria-label="Interactive ant sanctuary. Drag to paint trails; select Emitter to place a permanent pheromone source." onPointerDown={pointerDown} onPointerMove={pointerMove} onPointerUp={pointerUp} onPointerCancel={pointerUp} onPointerLeave={()=>{if(pointerId.current===null)brush.current.visible=false;}} />
    {!ready&&<div className="canvas-loading"><span className="loading-orbit"/><p>A little world is waking up.</p></div>}
    {isAB&&<div className="arena-comparison"><span>TRAINED COLONY</span><span>{rivalPolicy==='aco'?'HAND-CRAFTED ACO':'RANDOM NETWORK'}</span></div>}
    <div className="zoom-controls canvas-ui"><button aria-label="Zoom out" title="Zoom out" onClick={()=>setZoom(z=>Math.max(.55,Number((z-.15).toFixed(2))))}><Icon name="minus" size={16}/></button><button className="zoom-number" title="Reset zoom" aria-label="Reset zoom" onClick={()=>setZoom(1)}>{Math.round(zoom*100)}%</button><button aria-label="Zoom in" title="Zoom in" onClick={()=>setZoom(z=>Math.min(2,Number((z+.15).toFixed(2))))}><Icon name="plus" size={16}/></button><span/><button title="Fullscreen arena" aria-label="Toggle fullscreen arena" onClick={()=>{if(document.fullscreenElement)void document.exitFullscreen();else void canvasRef.current?.closest('.arena')?.requestFullscreen().catch(()=>callbacks.current.onToast('Fullscreen is not available in this preview.'));}}><Icon name="fullscreen" size={15}/></button></div>
  </>;
}
