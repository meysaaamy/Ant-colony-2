'use client';
import { line,scaleLinear,curveMonotoneX } from 'd3';
import { Icon } from './ui/icons';
import type { DispersionSample,Telemetry } from '@/lib/types';
export default function TelemetryPill({stats,history}:{stats:Telemetry;history:DispersionSample[]}){
  const samples=history.slice(-25),x=scaleLinear().domain([0,Math.max(1,samples.length-1)]).range([0,46]),max=Math.max(1,...samples.map(s=>Math.max(s.births,s.deaths))),y=scaleLinear().domain([0,max]).range([15,1]);
  const birth=line<DispersionSample>().x((_,i)=>x(i)).y(d=>y(d.births)).curve(curveMonotoneX)(samples)??'',death=line<DispersionSample>().x((_,i)=>x(i)).y(d=>y(d.deaths)).curve(curveMonotoneX)(samples)??'';
  return <div className="telemetry-pill glass" aria-label="Live colony telemetry">
    <div className="fps-stat"><span className={`status-dot ${stats.fps<35?'warning':''}`}/><strong>{stats.fps}</strong><small>FPS</small></div>
    <div className="telemetry-divider"/>
    <div className="telemetry-stat population-stat"><Icon name="ant" size={20}/><div><strong>{stats.alive.toLocaleString('en-US')}</strong><small>living ants</small></div></div>
    <div className="telemetry-divider"/>
    <div className="telemetry-stat food-stat"><Icon name="crystal" size={19}/><div><strong>{stats.food.toLocaleString('en-US')}</strong><small>food delivered</small></div></div>
    <div className="telemetry-divider gen-divider"/><div className="generation-badge"><small>GEN</small><strong>{String(stats.generation).padStart(2,'0')}</strong></div>
    <div className="health-indicator" title={`Births: ${stats.birthRate.toFixed(1)}/min. Deaths: ${stats.deathRate.toFixed(1)}/min. ${stats.deaths} total deaths. Rates use the last 60 simulated seconds.`}><svg viewBox="0 0 48 17" width="48" height="17" aria-hidden="true"><path d={birth} fill="none" stroke="#95d9b8" strokeWidth="1.3"/><path d={death} fill="none" stroke="#c48b9d" strokeWidth="1" opacity=".65"/></svg><div><span>+{stats.birthRate.toFixed(1)}</span><span>-{stats.deathRate.toFixed(1)}</span></div><small>/ min</small></div>
  </div>;
}
