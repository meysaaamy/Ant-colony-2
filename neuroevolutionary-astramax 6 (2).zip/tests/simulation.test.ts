import { describe,it,expect } from 'vitest';
import { Random,SimplexNoise } from '../lib/prng-noise';
import { PheromoneGrid,mixRGB } from '../lib/pheromone-grid';
import { AntEngine,createSoA } from '../lib/ant-soa-engine';
import { createBrain,deserializeBrain,forward,serializeBrain,WEIGHT_COUNT,Evolution } from '../lib/neat';
import { evaluateEpisode,runBenchmarks } from '../lib/headless-sim';
import { MAX_ANTS } from '../lib/types';

describe('deterministic foundations',()=>{
  it('repeats its seeded sequence',()=>{const a=new Random(19),b=new Random(19);for(let i=0;i<100;i++)expect(a.next()).toBe(b.next());});
  it('has continuous seeded simplex noise',()=>{const a=new SimplexNoise(31),b=new SimplexNoise(31);expect(a.noise(.2,.3)).toBe(b.noise(.2,.3));expect(Math.abs(a.noise(.2,.3)-a.noise(.201,.301))).toBeLessThan(.05);});
  it('preallocates the requested 5,000-agent capacity',()=>{const soa=createSoA();expect(soa.x).toBeInstanceOf(Float32Array);expect(soa.x.length).toBe(MAX_ANTS);expect(soa.next).toBeInstanceOf(Int32Array);});
});
describe('pheromone alchemy',()=>{
  it('diffuses without negative concentrations or wall leakage',()=>{const g=new PheromoneGrid(60,60);for(let y=0;y<10;y++)g.walls[y*10+5]=1;g.deposit(0,24,24,100);for(let i=0;i<60;i++)g.step(1/60);expect(g.sample(0,18,24)).toBeGreaterThan(0);expect(g.sample(0,36,24)).toBe(0);expect(g.channels[0].every(v=>v>=0&&v<=100)).toBe(true);});
  it('lets viridian dissolve amber',()=>{const a=new PheromoneGrid(60,60),b=new PheromoneGrid(60,60);a.deposit(0,24,24,60);b.deposit(0,24,24,60);b.deposit(4,24,24,80);a.step(.1);b.step(.1);expect(b.sample(0,24,24)).toBeLessThan(a.sample(0,24,24));});
  it('permanent emitters replenish the actual grid',()=>{const g=new PheromoneGrid(60,60);const e={id:1,x:30,y:30,channel:1 as const,strength:90,radius:18};for(let i=0;i<60;i++)g.step(1/60,[e]);expect(g.sample(1,30,30)).toBeGreaterThan(20);g.clear();g.step(1/60,[e]);expect(g.sample(1,30,30)).toBeGreaterThan(0);});
  it('muting removes sensing and secretion',()=>{const g=new PheromoneGrid(60,60);g.muted[0]=1;g.deposit(0,30,30,100);g.step(.1);expect(g.sample(0,30,30)).toBe(0);});
  it('mixes five channels and changes themes',()=>{const mixed=mixRGB([50,50,20,10,10]);expect(mixed.every(v=>v>0&&v<=255)).toBe(true);expect(mixRGB([80,0,0,0,0],1)).not.toEqual(mixRGB([80,0,0,0,0],.1));expect(mixRGB([80,0,0,0,0],.75,'monochrome')).not.toEqual(mixed);});
});
describe('shared colony brain',()=>{
  it('runs a finite, bounded 19–16–9 forward pass',()=>{const b=createBrain(),out=new Float32Array(9);forward(b,new Float32Array(19).fill(.2),new Float32Array(16),out);expect(b.weights.length).toBe(WEIGHT_COUNT);expect(out.every(v=>Number.isFinite(v)&&v>=-1&&v<=1)).toBe(true);});
  it('round-trips weights and rejects invalid imports',()=>{const b=createBrain();expect(Array.from(deserializeBrain(serializeBrain(b)).weights)).toEqual(Array.from(b.weights));expect(()=>deserializeBrain({version:1,weights:[NaN]})).toThrow();});
  it('retains the best parent through elitism',()=>{const e=new Evolution(createBrain(),4);const weights=Array.from(e.population[2].weights);e.advance([1,2,9,3]);expect(Array.from(e.population[0].weights)).toEqual(weights);});
});
describe('colony mechanics and measured evaluation',()=>{
  it('supports live population changes without reallocating',()=>{const s=new AntEngine({population:500});const positions=s.ants.x;s.setPopulation(5000);expect(s.aliveCount).toBe(5000);expect(s.ants.x).toBe(positions);s.setPopulation(700);expect(s.aliveCount).toBe(700);});
  it('accounts for genuine mortality',()=>{const s=new AntEngine({headless:true,population:10,width:120,height:120});s.ants.energy[0]=0;s.step();expect(s.totalDeaths).toBe(1);expect(s.aliveCount).toBe(9);});
  it('adds and erases permanent sources',()=>{const s=new AntEngine({headless:true,population:10,width:120,height:120});s.paint('emitter',30,30,15,3);expect(s.emitters).toHaveLength(1);s.paint('eraser',30,30,20);expect(s.emitters).toHaveLength(0);});
  it('produces reproducible episode results',()=>{const b=createBrain();const a=evaluateEpisode(b,'trained',11,-1,{steps:90,population:10}),c=evaluateEpisode(b,'trained',11,-1,{steps:90,population:10});expect(a).toEqual(c);});
  it('reports all measured ablations with finite statistics',()=>{const results=runBenchmarks(createBrain(),{steps:48,population:6,seeds:[11]});expect(results).toHaveLength(9);expect(results.every(r=>Number.isFinite(r.mean)&&Number.isFinite(r.std)&&Number.isFinite(r.drop))).toBe(true);});
  it('hatches brood from delivered food after a vacancy',()=>{const s=new AntEngine({headless:true,population:4,width:120,height:120});for(let i=0;i<3;i++){s.ants.x[i]=s.preset.nest.x;s.ants.y[i]=s.preset.nest.y;s.ants.carryingFood[i]=1;}s.ants.age[3]=s.ants.maxLifespan[3]+1;for(let t=0;t<61;t++)s.step();expect(s.foodDelivered).toBeGreaterThanOrEqual(3);expect(s.totalBirths).toBeGreaterThanOrEqual(1);expect(s.aliveCount).toBe(4);});
  it('verifies the baked champion against three-seed baselines',()=>{const measured=runBenchmarks(createBrain());expect(measured[0].mean).toBeGreaterThan(measured[1].mean);expect(measured[1].mean).toBeGreaterThan(measured[2].mean);expect(measured[3].drop).toBeGreaterThan(0);expect(measured[4].drop).toBeGreaterThan(0);expect(measured[8].drop).toBeGreaterThan(0);},60000);
});
