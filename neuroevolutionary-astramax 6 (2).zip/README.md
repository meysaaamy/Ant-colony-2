# Formica — a living intelligence

An interactive, bioluminescent colony observatory built with strict TypeScript, Next.js App Router, React, Canvas 2D/WebGL, D3, and PostgreSQL through Drizzle.

## Run

- `npm run dev` — development server.
- `npm run build` — production build.
- `npx vitest run` — deterministic engine tests.
- `npx tsx scripts/train.ts` — eight offline evolutionary generations, three-seed policy/ablation benchmark, and champion/learning-curve baking.
- `npx tsx scripts/train.ts --generations=5 --no-bake` — evaluate without rewriting the baked source.
- `npx drizzle-kit push` — provision the experiment table after the local database is bootstrapped.

`DATABASE_URL` is read server-side by the existing `src/db/index.ts` connection. No credentials are exposed to the browser. Tailwind v4 is wired through `app/globals.css`; fonts use Next's Fraunces and Plus Jakarta Sans integration.

## Controls

Tools 1–7: food signal, home signal, alarm, food crystal, basalt wall, eraser, permanent pheromone emitter. Drag for brushes; click for crystals and emitters. The five channel swatches also expose scout and no-entry signals. Brackets change radius; Space pauses; Escape closes dialogs. The arena supports zoom, fullscreen, and PNG snapshots.

Settings expose 500–5,000 ants without reallocating the SoA, three spectral themes, continuous glow intensity, a WebGL bright-pass bloom toggle, channel ablation, diffusion/evaporation/reaction rates, energy burn, lifespan, optional predators, and three worlds. One primary pointer is captured at a time. Resize is debounced 150 ms without resetting simulation state. Hidden documents suspend simulation. All physics use a fixed 1/60 second timestep.

Settings, validated brain weights, learning history, and per-world emitters persist safely in localStorage. Persistence failures do not stop the simulation. Clear Trails removes concentrations but not emitters. The eraser removes individual sources; Reset removes all local sources for the active world.

## Engine

The live engine preallocates 5,000 agents in typed arrays and an Int32 spatial hash with 24 px cells. Agents forage, return food, burn ATP, age, die, transfer energy, recruit through tandem running, mark depleted sites, and defend against up to six predators. Wardens relocate corpse husks. Three delivered food can hatch an ant if below the chosen population cap; 25 births advance the colony generation. A low-population rescue wave prevents visual extinction.

The shared fixed-topology recurrent MLP is **19 inputs → 16 tanh hidden units → 9 outputs (473 weights)**. It samples bilateral log-concentration gradients and center concentrations for all five channels, three wall rays, body-frame home-vector components, carrying state, energy, and two recurrent states. The output controls torque, speed, five secretion rates, and the two recurrent states. Biological reflexes (contact food collection, near-source attraction, return path integration, and immediate predator response) surround the policy and are shared by evaluated agents. Neural decisions are staggered; every ant's movement and life-cycle still update on each physics tick.

Evolution uses tournament selection, crossover, Gaussian weight mutation with stagnation adaptation, and two elite survivors. The app boots with real CLI-evolved weights, not arbitrary weights labeled as trained. The topology is fixed; optional growing-topology NEAT is not claimed.

Five Float32 ping-pong fields use 6 px cells, a CFL-clamped 3×3 stencil, reflecting/zero-flux walls, concentration clamping, faster alarm decay, persistent food/home polymer, and no-entry dissolution of food signal. Emitters deposit into this same field. RGB synthesis uses exponential tonemapping and pairwise color interactions. Brushes interpolate a Catmull–Rom ribbon.

## Rendering

Ten compositing stages: cached procedural terrain, spectral fields, quarter-resolution WebGL bloom, corpses/crystals, nest reactor, animated caste/cohort sprites, interaction filaments, spores, brush cursor, and cached vignette. No Canvas `filter = blur(...)` or `shadowBlur` is used. If WebGL is unavailable or software-only, bilinear low-resolution additive compositing provides a fallback. All caste/cohort animation frames share one texture atlas, with direct per-agent transforms rather than Canvas state stacks. When measured 60-frame FPS falls below 50 (with an early startup sample), the renderer sheds bloom and reduces diffusion frequency while retaining all agents and physics. Recovery uses three healthy windows to avoid rapid quality oscillation.

The default world is fixed at 1,600 × 1,000 units. Live A/B creates two independent 800 × 1,000 arenas with the same seed, population, food, terrain, and rules; their pheromone grids never leak into one another. Policy comparisons restart the comparison worlds deliberately; ordinary resize, visual changes, and pause do not.

## Evidence and limitations

The baked six-generation training run uses seeds **11, 29, 47**, 36 agents, 900 fixed timesteps (15 simulated seconds), and a 384 × 288 headless world. The compact headless world is designed for quick, reproducible comparisons, not a speed-equivalent clone of the large live display.

Measured final delivery counts (mean ± population standard deviation):

| Policy or ablation | Food |
| --- | --- |
| Trained shared brain | 79.00 ± 0.82 |
| Hand-crafted ACO | 67.00 ± 2.16 |
| Random recurrent network | 0.00 ± 0.00 |
| Without food trail | 40.00 ± 4.32 |
| Without home guide | 58.67 ± 4.50 |
| Without alarm | 78.67 ± 1.25 |
| Without scout pulse | 76.67 ± 0.47 |
| Without no-entry | 78.67 ± 0.94 |
| Without path integration | 21.00 ± 6.38 |

These are in-environment results on the training seeds, **not held-out generalization evidence**. The model has an explicit sensory prior; it is not learning all behavior from scratch. Alarm/no-entry effects are small in this predator-free evaluation. No benchmark ordering or ablation loss is manufactured; future runs can report neutral or negative drops. The Random network's zero delivery result is an observation for these short episodes, not a theoretical floor. Training mutates all weights, not a small hidden policy vector.

The D3 dispersion graph reports the fraction of occupied 40 × 25 spatial bins (wall bins excluded), plus normalized occupancy entropy for the loop/concentration diagnosis. It measures instantaneous spatial distribution, not cumulative explored area. Birth and death overlays are events per simulated minute, using up to the preceding 60 simulated seconds. Population slider changes are not counted as biological mortality.

## Server-backed experiments

To respect the single-route application architecture, `/api/health` also exposes the experiment operations:

- `GET /api/health` — database, SoA, neural forward pass, RGB synthesis, and headless ablation checks.
- `GET /api/health?history=1` — 12 latest saved experiments.
- `POST /api/health` with `action: "benchmark"` — measured nine-way, three-seed comparison saved to PostgreSQL.
- `POST /api/health` with `action: "train"` — chunked five/ten-generation training streamed as NDJSON, then persisted.
- `POST /api/health` with `action: "snapshot"` — current settings, telemetry, and validated brain saved as a snapshot.

The lab can restore saved trained brains, inspect benchmark history, and import/export validated 473-weight JSON files. This is a local research sandbox; public multi-user deployment would additionally need authentication, rate limits, durable background training jobs, and per-user experiment ownership.

## Validation

Run in order: `npx next typegen`, `npm exec tsc -- --noEmit --pretty false`, `npm run build`, and the platform-managed production healthcheck. Tests cover deterministic noise, capacity, diffusion bounds, wall flux, chemical dissolution, permanent emitters, channel masks, RGB themes, finite neural output, validated serialization, elitism, live population resizing, mortality, source erasure, and reproducible measured ablations.
