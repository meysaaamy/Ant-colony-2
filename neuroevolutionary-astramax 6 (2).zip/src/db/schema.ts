import { jsonb,pgTable,serial,text,timestamp } from 'drizzle-orm/pg-core';
export const simulationExperiments=pgTable('simulation_experiments',{
  id:serial('id').primaryKey(),
  kind:text('kind').notNull(),
  title:text('title').notNull(),
  data:jsonb('data').$type<Record<string,unknown>>().notNull(),
  createdAt:timestamp('created_at',{withTimezone:true}).defaultNow().notNull()
});
