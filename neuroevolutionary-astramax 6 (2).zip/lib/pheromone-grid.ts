import { catmullRom, clamp } from './prng-noise';
import { CHANNEL_META, type ChannelIndex, type Emitter, type Point, type RGB, type Theme } from './types';

export const PALETTES: Record<Theme, readonly RGB[]> = {
  bioluminescent: CHANNEL_META.map(c => c.rgb),
  monochrome: [[215,234,227],[153,189,183],[255,255,255],[112,148,144],[193,215,206]],
  heatmap: [[255,80,12],[255,200,35],[255,15,85],[114,42,245],[255,235,120]]
};
export function mixRGB(concentrations: readonly number[] | Float32Array, glow = 0.75, theme: Theme = 'bioluminescent'): RGB {
  const p = PALETTES[theme]; let r = 0, g = 0, b = 0;
  for (let c = 0; c < 5; c++) { const v = Math.max(0, concentrations[c] ?? 0) / 100; r += v*p[c][0]/255; g += v*p[c][1]/255; b += v*p[c][2]/255; }
  if (theme === 'bioluminescent') {
    const polymer = Math.min(concentrations[0], concentrations[1])/100;
    r += polymer*0.65; g += polymer*0.85; b += polymer;
    const rose = Math.min(concentrations[0],concentrations[3])/100; r += rose*.6; g += rose*.15;
    const magenta = Math.min(concentrations[1],concentrations[2])/100; r += magenta*.6; b += magenta*.6;
    const sulfur = Math.min(concentrations[2],concentrations[4])/100; r += sulfur*.8; g += sulfur*.7;
  }
  const gamma = 1.35 + glow*2.1;
  return [Math.round(255*(1-Math.exp(-gamma*r))),Math.round(255*(1-Math.exp(-gamma*g))),Math.round(255*(1-Math.exp(-gamma*b)))];
}
export class PheromoneGrid {
  readonly cellSize = 6;
  readonly cols: number; readonly rows: number; readonly size: number;
  channels: Float32Array[]; private back: Float32Array[];
  walls: Uint8Array; muted = new Uint8Array(5);
  evaporation = 0.09; diffusion = 0.15; reactionRate = 1;
  constructor(readonly width: number, readonly height: number) {
    this.cols = Math.ceil(width/6); this.rows = Math.ceil(height/6); this.size = this.cols*this.rows;
    this.channels = Array.from({length:5}, () => new Float32Array(this.size));
    this.back = Array.from({length:5}, () => new Float32Array(this.size)); this.walls = new Uint8Array(this.size);
  }
  index(x: number,y: number): number { return clamp(Math.floor(y/6),0,this.rows-1)*this.cols+clamp(Math.floor(x/6),0,this.cols-1); }
  sample(channel: number,x: number,y: number): number { return this.muted[channel] ? 0 : this.channels[channel][this.index(x,y)]; }
  deposit(channel: number,x: number,y: number,amount: number): void {
    if(this.muted[channel]) return; const i=this.index(x,y); if(!this.walls[i]) this.channels[channel][i]=clamp(this.channels[channel][i]+amount,0,100);
  }
  brush(channel: ChannelIndex,x: number,y: number,radius: number,amount=24): void {
    const minX=Math.max(0,Math.floor((x-radius)/6)),maxX=Math.min(this.cols-1,Math.ceil((x+radius)/6));
    const minY=Math.max(0,Math.floor((y-radius)/6)),maxY=Math.min(this.rows-1,Math.ceil((y+radius)/6));
    if(this.muted[channel]) return;
    for(let gy=minY;gy<=maxY;gy++) for(let gx=minX;gx<=maxX;gx++) {
      const dx=gx*6+3-x,dy=gy*6+3-y, d=(dx*dx+dy*dy)/(radius*radius), i=gy*this.cols+gx;
      if(d<1&&!this.walls[i]) this.channels[channel][i]=Math.min(100,this.channels[channel][i]+amount*Math.pow(1-d,2));
    }
  }
  stroke(channel: ChannelIndex,p0: Point,p1: Point,p2: Point,p3: Point,radius: number,amount=22): void {
    const length=Math.hypot(p2.x-p1.x,p2.y-p1.y); const steps=Math.max(1,Math.ceil(length/(radius*.25)));
    for(let i=0;i<=steps;i++){ const t=i/steps;this.brush(channel,catmullRom(p0.x,p1.x,p2.x,p3.x,t),catmullRom(p0.y,p1.y,p2.y,p3.y,t),radius,amount); }
  }
  erase(x: number,y: number,radius: number): void {
    const r2=radius*radius;
    for(let gy=Math.max(0,Math.floor((y-radius)/6));gy<=Math.min(this.rows-1,Math.ceil((y+radius)/6));gy++)
      for(let gx=Math.max(0,Math.floor((x-radius)/6));gx<=Math.min(this.cols-1,Math.ceil((x+radius)/6));gx++)
        if((gx*6-x)**2+(gy*6-y)**2<r2) for(let c=0;c<5;c++) this.channels[c][gy*this.cols+gx]=0;
  }
  clear(): void { for(let c=0;c<5;c++){this.channels[c].fill(0);this.back[c].fill(0);} }
  step(dt: number,emitters: readonly Emitter[] = []): void {
    const alpha=Math.min(0.12,this.diffusion*dt*12), cols=this.cols, rows=this.rows;
    for(let c=0;c<5;c++) {
      const src=this.channels[c],dst=this.back[c];
      if(this.muted[c]){dst.fill(0);continue;}
      const decay=this.evaporation*(c===2?3.2:1)*dt;
      for(let y=0;y<rows;y++) for(let x=0;x<cols;x++) {
        const i=y*cols+x;if(this.walls[i]){dst[i]=0;continue;}
        const v=src[i];let lap=0;
        for(let dy=-1;dy<=1;dy++) for(let dx=-1;dx<=1;dx++) {
          if(dx===0&&dy===0)continue;
          const nx=x+dx,ny=y+dy;
          if(nx<0||nx>=cols||ny<0||ny>=rows)continue;
          const ni=ny*cols+nx;if(!this.walls[ni])lap+=(src[ni]-v)*(dx!==0&&dy!==0?.5:1);
        }
        const polymer=(c===0||c===1)&&this.channels[0][i]>3&&this.channels[1][i]>3?.65:1;
        let value=v+alpha*lap-v*decay*polymer;
        if(c===0)value-=.45*this.channels[4][i]*dt*this.reactionRate;
        dst[i]=clamp(value,0,100);
      }
    }
    const old=this.channels;this.channels=this.back;this.back=old;
    for(let i=0;i<emitters.length;i++){const e=emitters[i];this.brush(e.channel,e.x,e.y,e.radius,e.strength*dt);}
  }
  writeImage(out: Uint8ClampedArray,glow: number,theme: Theme): void {
    const palette=PALETTES[theme],gamma=1.35+glow*2.1;
    for(let i=0;i<this.size;i++) {
      let r=0,g=0,b=0,total=0;
      for(let c=0;c<5;c++) { if(this.muted[c])continue;const v=this.channels[c][i]/100;total+=v;r+=v*palette[c][0]/255;g+=v*palette[c][1]/255;b+=v*palette[c][2]/255; }
      if(theme==='bioluminescent'){
        const a=this.channels[0][i],h=this.channels[1][i],l=this.channels[2][i],s=this.channels[3][i],n=this.channels[4][i];
        const polymer=Math.min(a,h)/100,rose=Math.min(a,s)/100,magenta=Math.min(h,l)/100,sulfur=Math.min(l,n)/100;
        r+=polymer*.65+rose*.6+magenta*.6+sulfur*.8;g+=polymer*.85+rose*.15+sulfur*.7;b+=polymer+magenta*.6;
      }
      const k=i*4;
      out[k]=255*(1-Math.exp(-gamma*r));out[k+1]=255*(1-Math.exp(-gamma*g));out[k+2]=255*(1-Math.exp(-gamma*b));
      out[k+3]=total>0.002?Math.min(205,25+total*150)*(0.35+glow*.65):0;
    }
  }
}
