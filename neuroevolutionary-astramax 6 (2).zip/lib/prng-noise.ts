export class Random {
  private state: number;
  constructor(seed = 42) { this.state = seed >>> 0; }
  next(): number {
    this.state = (this.state + 0x6D2B79F5) >>> 0;
    let t = this.state;
    t = Math.imul(t ^ t >>> 15, t | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  }
  range(min: number, max: number): number { return min + this.next() * (max - min); }
  int(max: number): number { return Math.floor(this.next() * max); }
  gaussian(): number { return Math.sqrt(-2 * Math.log(Math.max(1e-12, this.next()))) * Math.cos(2 * Math.PI * this.next()); }
}
export class SimplexNoise {
  private perm = new Uint8Array(512);
  private grad = new Int8Array([1,1,-1,1,1,-1,-1,-1,1,0,-1,0,1,0,-1,0,0,1,0,-1,0,1,0,-1]);
  constructor(seed = 42) {
    const rng = new Random(seed); const p = new Uint8Array(256);
    for (let i = 0; i < 256; i++) p[i] = i;
    for (let i = 255; i > 0; i--) { const j = rng.int(i + 1); const v = p[i]; p[i] = p[j]; p[j] = v; }
    for (let i = 0; i < 512; i++) this.perm[i] = p[i & 255];
  }
  noise(x: number, y: number): number {
    const f = 0.3660254037844386, g = 0.21132486540518713;
    const s = (x + y) * f, i = Math.floor(x + s), j = Math.floor(y + s), t = (i + j) * g;
    const x0 = x - i + t, y0 = y - j + t, i1 = x0 > y0 ? 1 : 0, j1 = x0 > y0 ? 0 : 1;
    const x1 = x0 - i1 + g, y1 = y0 - j1 + g, x2 = x0 - 1 + 2*g, y2 = y0 - 1 + 2*g;
    const ii = i & 255, jj = j & 255;
    const a = this.perm[ii + this.perm[jj]] % 12 * 2;
    const b = this.perm[ii + i1 + this.perm[jj + j1]] % 12 * 2;
    const c = this.perm[ii + 1 + this.perm[jj + 1]] % 12 * 2;
    let n = 0;
    let z = 0.5 - x0*x0 - y0*y0; if (z > 0) { z *= z; n += z*z*(this.grad[a]*x0+this.grad[a+1]*y0); }
    z = 0.5-x1*x1-y1*y1; if (z > 0) { z *= z; n += z*z*(this.grad[b]*x1+this.grad[b+1]*y1); }
    z = 0.5-x2*x2-y2*y2; if (z > 0) { z *= z; n += z*z*(this.grad[c]*x2+this.grad[c+1]*y2); }
    return 70*n;
  }
}
export function clamp(value: number, min: number, max: number): number { return Math.max(min, Math.min(max, value)); }
export function angleDelta(target: number, current: number): number { return Math.atan2(Math.sin(target-current), Math.cos(target-current)); }
export function catmullRom(a: number, b: number, c: number, d: number, t: number): number {
  return 0.5*((2*b)+(-a+c)*t+(2*a-5*b+4*c-d)*t*t+(-a+3*b-3*c+d)*t*t*t);
}
