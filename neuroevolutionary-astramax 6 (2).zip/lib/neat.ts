import { Random } from './prng-noise';
import type { Brain, BrainJSON } from './types';
export const INPUTS=19, HIDDEN=16, OUTPUTS=9;
export const WEIGHT_COUNT=INPUTS*HIDDEN+HIDDEN+HIDDEN*OUTPUTS+OUTPUTS;
// Replaced by the reproducible offline trainer, never generated from displayed scores.
export const BAKED_CHAMPION: number[] = [2.4172366,0.0174301,-0.0194944,-0.0074062,0.0752765,0.0291715,0.0085014,-0.0262112,0.0194911,0.0373157,-0.006301,-0.0053029,-0.0122567,0.0400499,0.0267889,0.0102917,-0.0332542,0.0842858,-0.0036893,-0.0277342,2.0999999,0.0334967,-0.0285167,0.0038509,-0.0161797,0.0109928,0.0337152,0.1376405,0.0165017,0.0086949,0.0017508,0.0279811,-0.0658463,0.0374564,0.0066346,-0.008103,-0.0259932,-0.0147567,-0.0157962,-0.0406777,-2.4497051,0.0313969,0.0084794,0.0227175,0.2204776,0.000281,-0.0300474,-0.0343269,0.0096764,0.0752198,0.0111001,-0.0578695,0.0109355,-0.0777524,-0.13735,0.0037548,-0.0201467,-0.0392765,0.0144365,0.0289972,1.659717,0.0229598,0.0072961,0.019814,0.0122658,0.0140401,0.0211476,0.0219983,0.0072253,0.0199798,-0.0961894,0.0002369,0.0424908,-0.0468594,-0.0156691,0.0413366,0.0443119,0.0248867,0.0104099,-0.1128482,-2.2,-0.014129,0.024054,0.0274034,0.0186329,-0.0228728,-0.0581091,-0.0822108,0.0008776,-0.0340349,0.0309519,-0.0012844,-0.0328788,0.0071217,0.0135037,-0.0664262,0.0067688,-0.0468563,0.0849397,-0.0099099,-0.0188857,0.1311081,-0.0314589,-0.011437,0.0299801,-2,-0.0073774,2,-0.0589468,-0.0534396,0.0220058,0.0265119,-0.0065821,0.0019053,-0.0159703,0.0131444,-0.0026249,-0.0156891,-0.0262781,0.0067698,-0.0875426,-0.0278622,-0.0269571,0.0338384,0.0965404,-0.0166251,0.0114174,1.543728,0.0027351,0.0237332,0.045165,0.0265931,0.0405434,-0.0095338,-0.0170951,-0.0759239,0.0081628,-0.0181926,-0.0971222,-0.0592427,-0.016337,0.0194821,0.0272077,0.0352298,-0.012109,0.0635665,0.0308218,-0.0239051,1.873246,-0.0244914,0.0294758,0.0362258,-0.0038124,0.0338899,-0.0093248,-0.0443002,-0.0764223,0.0013412,0.1642026,0.0065901,-0.022387,0.0478023,0.0333976,-0.0119512,0.0122039,0.009901,0.0508955,0.0195493,1.5576265,-0.163885,-0.0012855,0.0064981,0.0040423,0.0071185,0.0080619,0.0047722,-0.0065158,0.0205388,-0.037236,-0.236515,-0.0155348,0.040126,-0.0225798,-0.0052196,-0.0389364,-0.0338962,-0.006608,0.0295204,0.7613338,0.0002183,-0.0440896,0.0135637,0.0160565,0.0614871,0.0337292,0.0052466,-0.1300978,-0.0978558,-0.0061984,0.0120152,0.0424067,0.0273077,-0.0284321,-0.007966,0.0247443,-0.0215531,0.0165248,0.0619022,0.8,0.0131686,0.0129808,0.0196444,-0.0128535,0.0093104,0.9823337,0.0498325,-0.0232695,-0.0054381,-0.0502446,0.0189906,-0.0102997,-0.2004262,-0.0351688,0.0250361,-0.0056786,0.0327616,0.0212884,0.0221338,0.0384868,-0.0017112,-0.0143189,0.0208306,-0.0319232,-0.0093139,1,0.0519447,0.0335822,-0.1047347,-0.0140274,0.0477134,-0.0047965,0.0276165,-0.033199,0.0449387,-0.0157018,0.0183547,0.0032153,0.0604341,0.2741175,-0.0311109,-0.1356132,0.0068813,0.0018895,-0.0176976,0.8161477,-0.0048112,-0.0556657,-0.014108,-0.0058636,0.0392319,0.0049844,0.0239026,0.0092515,-0.0013575,-0.0162919,0.0022372,0.0902884,0.0021994,0.0079831,0.0404313,-0.0022686,0.0228508,-0.0238734,0.0490417,0.9733285,0.0346206,-0.0419837,-0.0124436,0.0313239,-0.0226564,-0.0096863,0.1216172,0.0351625,-0.0127605,0.0196965,-0.1913888,0.1358349,0.0985078,0.0203926,0.0329246,-0.1330899,-0.0644731,0.0351584,-0.0044072,1,-0.0060547,0.0164076,-0.0059919,0.0065205,-0.0277824,-0.0056596,0.0345986,0.0189109,0.0036961,-0.0047314,0.0100472,0.0120249,0.1166169,0.0022054,0.0084271,0.0116571,-0.0350219,-0.0112772,-0.0996789,0.0316827,0.0648026,0.04776,0.2108613,0.0065739,-0.0264999,1.127102,0.3,0.7,0.65,0.75,1.6,-0.0136339,-0.0016545,-0.0276087,0.0012681,0.0103786,0.1601411,0.0058699,-0.0782329,-0.0482407,0.1280761,-0.1064265,0.0067403,-0.0031975,0.0607845,0.0877485,-0.0534162,-0.0175627,-0.0051777,0.4972519,0.008908,0.005562,-0.0114552,0.0354105,-0.0047703,0.0253917,-0.0017943,0.0099801,0.0036117,-0.0014156,0.0124125,0.0106747,-0.0041704,0.0765171,1.8,-0.0032257,-0.0215808,-0.027179,0.0258344,0.0001422,-0.0071009,0.0074298,0.0032585,0.0495996,-0.0605417,-0.055791,-0.0002908,-0.0590137,0.00228,0.0179643,-1.2,-0.0036573,0.037621,-0.0088483,-0.0249943,-0.0049927,0.0307532,-0.0582243,-0.0087157,0.0368809,0.0299959,0.001805,0.0033247,-0.0051753,-0.0265657,-0.0932615,0.0107147,0.0419528,0.0211644,0.0140407,0.0474717,-0.0150756,1.3512772,-0.0241266,-0.023176,0.0538456,0.0158221,0.3148274,0.0513066,0.2492147,-0.0172149,0.0280609,0.0345852,0.2639574,0.0162862,0.0422532,0.4157628,0.0000466,0.0142169,0.8480673,0.0341947,0.0641368,0.0003415,0.0352123,-0.0921849,-0.0244429,-0.0120038,-0.007045,-0.0383188,-0.0196398,0.0103439,-0.0905655,0.0191023,-0.0715363,-0.0262828,-0.0168213,0.9579168,-0.1105058,0.0061826,0.0201299,0.1258473,-0.0118348,-0.0375128,0.0377102,0.0148531,0.0067536,0.712602,-0.0216207,0.0580164,-0.0280139,-0.0406909,0.1007193,0.0170558,-0.0261167,-0.0161702,0.0216193,-0.0310525,-0.0479964,0.0544775,0.0037573,-0.0129472,0.0255745,0.0496263,0.8220603,0.0240529,-0.0323216,0.0972294,0.0044296,0.0237643,-0.1329449,0.5210738,-0.5,0.8,-2.7765059,-2,-3,-0.000012,0.1260918];
export const BAKED_GENERATION = 6;
export function randomBrain(seed=42,scale=.35): Brain {
  const rng=new Random(seed),weights=new Float32Array(WEIGHT_COUNT);
  for(let i=0;i<weights.length;i++)weights[i]=rng.gaussian()*scale;
  return {weights,generation:0,fitness:0};
}
export function createBrain(): Brain {
  if(BAKED_CHAMPION.length===WEIGHT_COUNT)return{weights:new Float32Array(BAKED_CHAMPION),generation:BAKED_GENERATION,fitness:0};
  const brain=randomBrain(82,.025),w=brain.weights;
  // Sensory prior: gradients, obstacle avoidance, and energy. Evolution refines all 473 weights.
  const hidden=(h:number,i:number,v:number)=>{w[h*INPUTS+i]=v;};
  hidden(0,0,2.4);hidden(1,1,2.1);hidden(2,2,-2.5);hidden(3,3,1.7);hidden(4,4,-2.2);
  hidden(5,10,-2);hidden(5,12,2);hidden(6,13,1.6);hidden(7,15,2);hidden(8,16,1.5);
  hidden(9,17,.8);hidden(10,18,.8);hidden(11,5,1);hidden(12,6,1);hidden(13,7,1);hidden(14,8,1);hidden(15,9,1);
  const base=INPUTS*HIDDEN+HIDDEN;
  w[base+0]=1.2;w[base+1]=.3;w[base+2]=.7;w[base+3]=.65;w[base+4]=.75;w[base+5]=1.6;
  w[base+HIDDEN+8]=.5;
  w[base+2*HIDDEN+7]=1.8;w[base+3*HIDDEN+7]=-1.2;
  w[base+4*HIDDEN+13]=1.4;w[base+5*HIDDEN+14]=.8;w[base+6*HIDDEN+15]=1;
  w[base+7*HIDDEN+9]=.8;w[base+8*HIDDEN+10]=.8;
  const bias=base+HIDDEN*OUTPUTS;
  w[bias+1]=.5;w[bias+2]=-.5;w[bias+3]=.8;w[bias+4]=-3;w[bias+5]=-2;w[bias+6]=-3;
  return brain;
}
export function forward(brain: Brain,inputs: Float32Array,hidden: Float32Array,outputs: Float32Array): void {
  const w=brain.weights;
  for(let h=0;h<HIDDEN;h++){let sum=w[INPUTS*HIDDEN+h];const base=h*INPUTS;for(let i=0;i<INPUTS;i++)sum+=inputs[i]*w[base+i];hidden[h]=Math.tanh(sum);}
  const base=INPUTS*HIDDEN+HIDDEN,bias=base+HIDDEN*OUTPUTS;
  for(let o=0;o<OUTPUTS;o++){let sum=w[bias+o];for(let h=0;h<HIDDEN;h++)sum+=hidden[h]*w[base+o*HIDDEN+h];outputs[o]=o===0||o>=7?Math.tanh(sum):1/(1+Math.exp(-sum));}
}
export function serializeBrain(brain: Brain): BrainJSON { return {version:1,topology:[19,16,9],weights:Array.from(brain.weights),generation:brain.generation,fitness:brain.fitness}; }
export function deserializeBrain(value: unknown): Brain {
  if(!value||typeof value!=='object')throw new Error('Invalid brain file');
  const obj=value as Record<string,unknown>;
  if(obj.version!==1||!Array.isArray(obj.weights)||obj.weights.length!==WEIGHT_COUNT||!obj.weights.every((n:unknown)=>typeof n==='number'&&Number.isFinite(n)&&Math.abs(n)<100))throw new Error('Expected 473 finite weights for the 19–16–9 brain');
  return {weights:new Float32Array(obj.weights as number[]),generation:typeof obj.generation==='number'?obj.generation:0,fitness:typeof obj.fitness==='number'?obj.fitness:0};
}
export function mutate(brain: Brain,rng: Random,strength=.12,rate=.16): Brain {
  const weights=new Float32Array(brain.weights);
  for(let i=0;i<weights.length;i++)if(rng.next()<rate)weights[i]+=rng.gaussian()*strength;
  return {weights,generation:brain.generation+1,fitness:0};
}
export function crossover(a: Brain,b: Brain,rng: Random): Brain {
  const weights=new Float32Array(WEIGHT_COUNT);for(let i=0;i<weights.length;i++)weights[i]=rng.next()<.5?a.weights[i]:b.weights[i];
  return {weights,generation:Math.max(a.generation,b.generation)+1,fitness:0};
}
export class Evolution {
  population: Brain[]; generation: number; private rng: Random; private stagnant=0; private best=-Infinity;
  constructor(champion: Brain,size=8,seed=782) {
    this.rng=new Random(seed);this.generation=champion.generation;
    this.population=[{...champion,weights:new Float32Array(champion.weights)}];
    for(let i=1;i<size;i++)this.population.push(mutate(champion,this.rng,.08+i*.025,.2));
  }
  advance(scores: readonly number[],bottleneck=false): Brain {
    for(let i=0;i<this.population.length;i++)this.population[i].fitness=scores[i];
    this.population.sort((a,b)=>b.fitness-a.fitness);
    const champion=this.population[0];if(champion.fitness>this.best+.001){this.best=champion.fitness;this.stagnant=0;}else this.stagnant++;
    this.generation++;champion.generation=this.generation;
    const next: Brain[]=[{...champion,weights:new Float32Array(champion.weights)}];
    if(this.population.length>2)next.push({...this.population[1],weights:new Float32Array(this.population[1].weights)});
    const strength=(.055+Math.min(this.stagnant,10)*.012)*(bottleneck?2.5:1);
    const tournament=():Brain=>{let best=this.population[this.rng.int(this.population.length)];for(let i=0;i<2;i++){const candidate=this.population[this.rng.int(this.population.length)];if(candidate.fitness>best.fitness)best=candidate;}return best;};
    while(next.length<this.population.length){const child=crossover(tournament(),tournament(),this.rng);next.push(mutate(child,this.rng,strength,.18));}
    this.population=next;return champion;
  }
}
