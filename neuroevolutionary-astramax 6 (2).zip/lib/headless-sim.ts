import { AntEngine } from './ant-soa-engine';
import { createBrain, Evolution } from './neat';
import type { BenchmarkResult, Brain, EpisodeResult, LearningPoint, PolicyMode } from './types';
export const BENCHMARK_SEEDS=[11,29,47];
export const PRETRAINED_LEARNING: LearningPoint[] = [{"generation":1,"trained":61.666666666666664,"aco":67,"random":0,"std":3.8586123009300755},{"generation":2,"trained":75.66666666666667,"aco":67,"random":0,"std":3.0912061651652345},{"generation":3,"trained":75.66666666666667,"aco":67,"random":0,"std":3.0912061651652345},{"generation":4,"trained":79,"aco":67,"random":0,"std":0.816496580927726},{"generation":5,"trained":79,"aco":67,"random":0,"std":0.816496580927726},{"generation":6,"trained":79,"aco":67,"random":0,"std":0.816496580927726}];
export interface EvaluationOptions { steps?:number; population?:number; seeds?:number[]; }
export function evaluateEpisode(brain:Brain,policy:PolicyMode,seed:number,ablation=-1,options:EvaluationOptions={}):EpisodeResult {
  const muted=[false,false,false,false,false];if(ablation>=0&&ablation<5)muted[ablation]=true;
  const sim=new AntEngine({headless:true,width:384,height:288,seed,population:options.population??36,brain,settings:{policy,mutedChannels:muted,pathIntegration:ablation!==5,predators:false,energyBurn:.35,lifespan:400}});
  for(let t=0;t<(options.steps??900);t++)sim.step(1/60);
  const telemetry=sim.telemetry();return{seed,food:sim.foodDelivered,fitness:sim.fitness(),coverage:telemetry.coverage,deaths:sim.totalDeaths};
}
export function summarize(values:readonly number[]):{mean:number;std:number} {
  const mean=values.reduce((a,b)=>a+b,0)/Math.max(1,values.length);
  return{mean,std:Math.sqrt(values.reduce((a,b)=>a+(b-mean)**2,0)/Math.max(1,values.length))};
}
export function evaluateSeeds(brain:Brain,policy:PolicyMode='trained',ablation=-1,options:EvaluationOptions={}):{mean:number;std:number;fitness:number;episodes:EpisodeResult[]} {
  const episodes=(options.seeds??BENCHMARK_SEEDS).map(seed=>evaluateEpisode(brain,policy,seed,ablation,options));
  return{...summarize(episodes.map(e=>e.food)),fitness:summarize(episodes.map(e=>e.fitness)).mean,episodes};
}
export function runBenchmarks(brain=createBrain(),options:EvaluationOptions={}):BenchmarkResult[] {
  const definitions:ReadonlyArray<readonly[string,string,PolicyMode,number]>=[
    ['Full trained brain','full','trained',-1],['Hand-crafted ACO','aco','aco',-1],['Random network','random','random',-1],
    ['Without food trail','foodTrail','trained',0],['Without home guide','homeGuide','trained',1],['Without alarm','alarm','trained',2],
    ['Without scout pulse','scoutPulse','trained',3],['Without no-entry','noEntry','trained',4],['Without path integration','pathIntegration','trained',5]
  ];
  const results:BenchmarkResult[]=[];
  for(const [label,key,policy,ablation] of definitions){const measured=evaluateSeeds(brain,policy,ablation,options);results.push({label,key,mean:measured.mean,std:measured.std,seeds:options.seeds??BENCHMARK_SEEDS,drop:0});}
  const full=results[0].mean;for(const result of results)result.drop=full===0?0:(full-result.mean)/full*100;
  return results;
}
export interface TrainingResult { champion:Brain; learning:LearningPoint[]; }
export function trainGenerations(champion:Brain,generations=5,options:EvaluationOptions={},onProgress?:(point:LearningPoint)=>void):TrainingResult {
  const evolution=new Evolution(champion,6,782+champion.generation),learning:LearningPoint[]=[];
  const aco=evaluateSeeds(champion,'aco',-1,options).mean,random=evaluateSeeds(champion,'random',-1,options).mean;
  let best=champion;
  for(let gen=0;gen<generations;gen++){
    const evaluations=evolution.population.map(candidate=>evaluateSeeds(candidate,'trained',-1,options));
    best=evolution.advance(evaluations.map(e=>e.fitness));
    const measured=evaluateSeeds(best,'trained',-1,options);
    const point={generation:best.generation,trained:measured.mean,aco,random,std:measured.std};learning.push(point);onProgress?.(point);
  }
  return {champion:best,learning};
}
export async function trainChunked(champion:Brain,generations:number,onProgress:(point:LearningPoint)=>void,options:EvaluationOptions={}):Promise<TrainingResult> {
  const evolution=new Evolution(champion,6,782+champion.generation),learning:LearningPoint[]=[];
  const aco=evaluateSeeds(champion,'aco',-1,options).mean,random=evaluateSeeds(champion,'random',-1,options).mean;
  let best=champion;
  for(let gen=0;gen<generations;gen++){
    const scores:number[]=[];
    for(const candidate of evolution.population){scores.push(evaluateSeeds(candidate,'trained',-1,options).fitness);await new Promise<void>(resolve=>setTimeout(resolve,0));}
    best=evolution.advance(scores);const measured=evaluateSeeds(best,'trained',-1,options);
    const point={generation:best.generation,trained:measured.mean,aco,random,std:measured.std};learning.push(point);onProgress(point);
    await new Promise<void>(resolve=>setTimeout(resolve,0));
  }
  return{champion:best,learning};
}
