import { Random, SimplexNoise } from './prng-noise';
import type { Theme, Wall } from './types';
export function makeCanvas(width: number,height: number): HTMLCanvasElement { const c=document.createElement('canvas');c.width=width;c.height=height;return c; }
export function context2d(c: HTMLCanvasElement): CanvasRenderingContext2D { const ctx=c.getContext('2d');if(!ctx)throw new Error('Canvas 2D is unavailable');return ctx; }
export function rockPath(ctx: CanvasRenderingContext2D,radius: number,seed: number): void {
  ctx.beginPath();for(let i=0;i<=72;i++){const a=i/72*Math.PI*2;const r=radius*(1+Math.sin(a*3+seed)*.12+Math.cos(a*5-seed)*.07+Math.sin(a*9+seed)*.035);if(i===0)ctx.moveTo(Math.cos(a)*r,Math.sin(a)*r);else ctx.lineTo(Math.cos(a)*r,Math.sin(a)*r);}ctx.closePath();
}
export function createTerrain(width: number,height: number,walls: readonly Wall[],seed=34): HTMLCanvasElement {
  const canvas=makeCanvas(width,height),ctx=context2d(canvas),rng=new Random(seed),noise=new SimplexNoise(seed);
  ctx.fillStyle='#060d11';ctx.fillRect(0,0,width,height);
  const ambient=ctx.createRadialGradient(width*.46,height*.5,40,width*.46,height*.5,width*.7);ambient.addColorStop(0,'#0b1b1c');ambient.addColorStop(.6,'#081215');ambient.addColorStop(1,'#050b10');ctx.fillStyle=ambient;ctx.fillRect(0,0,width,height);
  for(let i=0;i<22000;i++){const x=rng.next()*width,y=rng.next()*height;ctx.fillStyle=i%3===0?'rgba(105,154,145,.12)':'rgba(100,136,148,.07)';ctx.fillRect(x,y,rng.next()*1.5+.3,rng.next()*1.5+.3);}
  ctx.lineWidth=.65;
  for(let cluster=0;cluster<12;cluster++){
    const cx=rng.range(-100,width+100),cy=rng.range(-100,height+100),base=rng.range(45,130);
    for(let ring=0;ring<13;ring++){
      ctx.beginPath();const radius=base+ring*12;
      for(let j=0;j<=100;j++){const a=j/100*Math.PI*2;const r=radius*(1+.18*Math.sin(a*3+cluster)+noise.noise(Math.cos(a)*1.6+cluster,Math.sin(a)*1.6)*.2);const x=cx+Math.cos(a)*r*1.45,y=cy+Math.sin(a)*r;if(j===0)ctx.moveTo(x,y);else ctx.lineTo(x,y);}
      ctx.strokeStyle=`rgba(71,114,114,${.035+(ring%3)*.015})`;ctx.stroke();
    }
  }
  ctx.fillStyle='rgba(119,165,154,.15)';for(let y=32;y<height;y+=48)for(let x=32;x<width;x+=48)ctx.fillRect(x,y,1,1);
  for(let i=0;i<walls.length;i++){
    const w=walls[i];ctx.save();ctx.translate(w.x,w.y);ctx.rotate(w.rotation);ctx.scale(w.stretch,1);
    for(let layer=5;layer>=0;layer--){rockPath(ctx,w.radius+layer*7,i+3);ctx.fillStyle=layer===0?'#0d1820':`rgba(2,7,10,${.18+layer*.06})`;ctx.fill();ctx.strokeStyle=layer===0?'rgba(75,154,151,.28)':'rgba(57,87,102,.14)';ctx.lineWidth=1;ctx.stroke();}
    for(let ring=0;ring<6;ring++){rockPath(ctx,w.radius*(.4+ring*.1),i+3+ring*.08);ctx.strokeStyle=`rgba(63,100,115,${.08+ring*.02})`;ctx.lineWidth=.8;ctx.stroke();}
    ctx.restore();
  }
  return canvas;
}
export function createAntSprites(theme: Theme): HTMLCanvasElement[] {
  const sprites: HTMLCanvasElement[]=[];
  const colors=theme==='monochrome'?['#d6e8df','#aebfba','#f0f6f2','#71847e']:theme==='heatmap'?['#e993fe','#ffad55','#ff5977','#a876ad']:['#7ecac6','#e2be76','#a6cf99','#657986'];
  for(let cohort=0;cohort<2;cohort++)for(let caste=0;caste<4;caste++)for(let frame=0;frame<8;frame++){
    const c=makeCanvas(24,24),ctx=context2d(c),color=cohort===1?'#aa8f9e':colors[caste];ctx.translate(12,12);
    const glow=ctx.createRadialGradient(0,0,0,0,0,10);glow.addColorStop(0,cohort===1?'rgba(182,125,152,.16)':'rgba(116,209,183,.16)');glow.addColorStop(1,'transparent');ctx.fillStyle=glow;ctx.fillRect(-12,-12,24,24);
    ctx.strokeStyle=color;ctx.lineWidth=.7;ctx.globalAlpha=.65;
    const phase=Math.sin(frame/8*Math.PI*2)*1.7;
    for(let side=-1;side<=1;side+=2)for(let leg=0;leg<3;leg++){const y=-3+leg*3;ctx.beginPath();ctx.moveTo(side*1.5,y);ctx.lineTo(side*4,y+phase*(leg===1?-1:1));ctx.lineTo(side*6,y+2+phase*(leg===1?-1:1));ctx.stroke();}
    ctx.globalAlpha=1;ctx.fillStyle=color;ctx.beginPath();ctx.ellipse(0,4,1.8,3,0,0,Math.PI*2);ctx.fill();ctx.beginPath();ctx.ellipse(0,-.4,1.2,2,0,0,Math.PI*2);ctx.fill();ctx.beginPath();ctx.arc(0,-4,1.5,0,Math.PI*2);ctx.fill();
    ctx.beginPath();ctx.moveTo(-.7,-5);ctx.lineTo(-2,-7);ctx.moveTo(.7,-5);ctx.lineTo(2,-7);ctx.stroke();sprites.push(c);
  }
  return sprites;
}
export function createAntAtlas(theme: Theme): HTMLCanvasElement {
  const sprites=createAntSprites(theme),canvas=makeCanvas(192,192),ctx=context2d(canvas);
  for(let i=0;i<sprites.length;i++)ctx.drawImage(sprites[i],(i%8)*24,Math.floor(i/8)*24);
  return canvas;
}
export function createCrystalSprites(): HTMLCanvasElement[] {
  const sprites: HTMLCanvasElement[]=[];
  for(let variant=0;variant<8;variant++){
    const c=makeCanvas(128,128),ctx=context2d(c),rng=new Random(variant*21+7);
    const glow=ctx.createRadialGradient(64,65,0,64,65,60);glow.addColorStop(0,'rgba(43,226,157,.22)');glow.addColorStop(.4,'rgba(23,188,128,.08)');glow.addColorStop(1,'transparent');ctx.fillStyle=glow;ctx.fillRect(0,0,128,128);
    for(let k=0;k<7;k++){
      const x=64+rng.range(-25,25),y=67+rng.range(-17,17),h=rng.range(14,37),w=h*.38;
      ctx.save();ctx.translate(x,y);ctx.rotate(rng.range(-.4,.4));
      ctx.beginPath();ctx.moveTo(0,-h);ctx.lineTo(w,-h*.6);ctx.lineTo(w*.85,h*.3);ctx.lineTo(0,h*.5);ctx.lineTo(-w,h*.15);ctx.lineTo(-w*.8,-h*.55);ctx.closePath();
      const g=ctx.createLinearGradient(-w,0,w,0);g.addColorStop(0,'#174c40');g.addColorStop(.48,'#46ca8d');g.addColorStop(.5,'#a7edbe');g.addColorStop(.55,'#2b9369');g.addColorStop(1,'#115344');ctx.fillStyle=g;ctx.fill();ctx.strokeStyle='rgba(147,246,192,.7)';ctx.lineWidth=.65;ctx.stroke();
      ctx.beginPath();ctx.moveTo(0,-h);ctx.lineTo(0,h*.5);ctx.moveTo(-w*.8,-h*.55);ctx.lineTo(0,-h*.33);ctx.lineTo(w,-h*.6);ctx.strokeStyle='rgba(174,255,211,.55)';ctx.stroke();ctx.restore();
    }
    for(let s=0;s<12;s++){ctx.fillStyle=s%2?'#9ae6b8':'#287e61';ctx.fillRect(rng.range(22,105),rng.range(26,102),rng.range(1,2.5),rng.range(1,2.5));}sprites.push(c);
  }
  return sprites;
}
export function createPredatorSprite(): HTMLCanvasElement {
  const c=makeCanvas(70,70),ctx=context2d(c);ctx.translate(35,35);ctx.strokeStyle='#845062';ctx.lineWidth=2;
  for(let s=-1;s<=1;s+=2)for(let i=0;i<4;i++){ctx.beginPath();ctx.moveTo(s*6,-9+i*6);ctx.lineTo(s*16,-15+i*9);ctx.lineTo(s*22,-9+i*8);ctx.stroke();}
  ctx.fillStyle='#26313d';ctx.strokeStyle='#ae657c';ctx.beginPath();ctx.ellipse(0,1,10,17,0,0,Math.PI*2);ctx.fill();ctx.stroke();for(let i=0;i<4;i++){ctx.beginPath();ctx.moveTo(-8,-7+i*6);ctx.lineTo(8,-7+i*6);ctx.stroke();}
  ctx.fillStyle='#ff698a';ctx.fillRect(-6,-14,3,3);ctx.fillRect(3,-14,3,3);return c;
}
export function createVignette(width: number,height: number): HTMLCanvasElement {
  const c=makeCanvas(width,height),ctx=context2d(c),g=ctx.createRadialGradient(width*.5,height*.47,height*.15,width*.5,height*.5,width*.62);
  g.addColorStop(0,'transparent');g.addColorStop(.6,'rgba(2,6,10,.04)');g.addColorStop(1,'rgba(2,5,9,.66)');ctx.fillStyle=g;ctx.fillRect(0,0,width,height);return c;
}
