export const MAX_ANTS = 5000;
export const MAX_PREDATORS = 6;
export const WORLD_WIDTH = 1600;
export const WORLD_HEIGHT = 1000;
export const CHANNELS = ['foodTrail', 'homeGuide', 'alarm', 'scoutPulse', 'noEntry'] as const;
export type Channel = typeof CHANNELS[number];
export type ChannelIndex = 0 | 1 | 2 | 3 | 4;
export type RGB = readonly [number, number, number];
export type Theme = 'bioluminescent' | 'monochrome' | 'heatmap';
export type Tool = 'food' | 'home' | 'alarm' | 'crystal' | 'wall' | 'eraser' | 'emitter';
export type PresetId = 'sanctuary' | 'bridge' | 'labyrinth';
export type PolicyMode = 'trained' | 'aco' | 'random' | 'ab-random' | 'ab-aco';
export enum AntState { FORAGING, RETURNING, ALARMED, DEFENDING, TRAIL_DAMPING, TANDEM_FOLLOW, NECROPHORESIS, DEAD }
export enum Caste { SCOUT, HAULER, WARDEN }
export enum Policy { TRAINED_MLP, HANDCRAFTED_ACO, RANDOM_MLP }
export interface AntSoA {
  x: Float32Array; y: Float32Array; vx: Float32Array; vy: Float32Array; angle: Float32Array;
  homeDx: Float32Array; homeDy: Float32Array; targetX: Float32Array; targetY: Float32Array;
  legPhase: Float32Array; pheromoneTimer: Float32Array; timeSinceLastVisit: Float32Array;
  ouNoise: Float32Array; energy: Float32Array; age: Float32Array; maxLifespan: Float32Array;
  fitness: Float32Array; memA: Float32Array; memB: Float32Array; distance: Float32Array;
  state: Uint8Array; caste: Uint8Array; policyType: Uint8Array; carryingFood: Uint8Array;
  active: Uint8Array; generation: Uint16Array; next: Int32Array;
}
export interface Brain { weights: Float32Array; generation: number; fitness: number; }
export interface BrainJSON { version: 1; topology: readonly [19, 16, 9]; weights: number[]; generation: number; fitness: number; }
export interface Point { x: number; y: number; }
export interface FoodSite extends Point { amount: number; initial: number; radius: number; variant: number; }
export interface Wall extends Point { radius: number; stretch: number; rotation: number; }
export interface Emitter extends Point { id: number; channel: ChannelIndex; strength: number; radius: number; }
export interface Predator extends Point { hp: number; angle: number; active: boolean; }
export interface Preset { id: PresetId; name: string; description: string; difficulty: string; nest: Point; foods: FoodSite[]; walls: Wall[]; }
export interface SimulationSettings {
  population: number; glow: number; bloom: boolean; theme: Theme; evaporation: number; diffusion: number;
  reactionRate: number; energyBurn: number; lifespan: number; predators: boolean; policy: PolicyMode;
  preset: PresetId; showTrails: boolean; showGrid: boolean; paused: boolean; speed: 1 | 2 | 4;
  mutedChannels: boolean[]; pathIntegration: boolean; radius: number; emitterChannel: ChannelIndex;
}
export const DEFAULT_SETTINGS: SimulationSettings = {
  population: 3000, glow: 0.75, bloom: true, theme: 'bioluminescent', evaporation: 0.09,
  diffusion: 0.15, reactionRate: 1, energyBurn: 0.6, lifespan: 240, predators: false,
  policy: 'trained', preset: 'sanctuary', showTrails: true, showGrid: false, paused: false,
  speed: 1, mutedChannels: [false, false, false, false, false], pathIntegration: true, radius: 28, emitterChannel: 0
};
export interface Telemetry {
  alive: number; deaths: number; births: number; food: number; generation: number; fps: number;
  elapsed: number; coverage: number; entropy: number; birthRate: number; deathRate: number;
  scouts: number; haulers: number; wardens: number; emitters: number; trainedFood: number; rivalFood: number;
  meanEnergy: number; predatorCount: number; adaptive: boolean;
}
export const INITIAL_TELEMETRY: Telemetry = {
  alive: 3000, deaths: 0, births: 0, food: 0, generation: 1, fps: 60, elapsed: 0, coverage: 0, entropy: 0,
  birthRate: 0, deathRate: 0, scouts: 900, haulers: 1800, wardens: 300, emitters: 0, trainedFood: 0,
  rivalFood: 0, meanEnergy: 100, predatorCount: 0, adaptive: false
};
export interface DispersionSample { time: number; coverage: number; entropy: number; births: number; deaths: number; }
export interface EpisodeResult { seed: number; food: number; fitness: number; coverage: number; deaths: number; }
export interface BenchmarkResult { label: string; key: string; mean: number; std: number; seeds: number[]; drop: number; }
export interface LearningPoint { generation: number; trained: number; aco: number; random: number; std: number; }
export interface Experiment { id?: number; createdAt?: string; results: BenchmarkResult[]; learning: LearningPoint[]; seeds: number[]; }
export type SimulationCommand = { id: number; type: 'clear' | 'reset' | 'predator' | 'snapshot' | 'remove-emitters' };
export interface BrushState extends Point { active: boolean; visible: boolean; radius: number; tool: Tool; }
export const CHANNEL_META: ReadonlyArray<{ name: string; short: string; color: string; rgb: RGB; description: string }> = [
  { name: 'Food trail', short: 'Food', color: '#f2ba63', rgb: [255, 168, 0], description: 'Leads foragers toward a food source.' },
  { name: 'Home guide', short: 'Home', color: '#64d9dd', rgb: [0, 225, 255], description: 'A chemical compass back to the colony.' },
  { name: 'Alarm', short: 'Alarm', color: '#ee7792', rgb: [255, 12, 75], description: 'Warns foragers and recruits wardens.' },
  { name: 'Scout pulse', short: 'Scout', color: '#b197ee', rgb: [175, 50, 255], description: 'Shares discoveries with nearby scouts.' },
  { name: 'No entry', short: 'No entry', color: '#9cdd7e', rgb: [80, 255, 100], description: 'Closes dead ends and dissolves food trails.' }
];
