import { AntEngine } from './ant-soa-engine';
import { context2d,createAntAtlas,createCrystalSprites,createPredatorSprite,createTerrain,createVignette,makeCanvas,rockPath } from './procedural-assets';
import { Random } from './prng-noise';
import { CHANNEL_META,type BrushState,type Point,type Theme } from './types';

class BloomShader {
  readonly canvas:HTMLCanvasElement;
  private gl:WebGLRenderingContext|null;private program:WebGLProgram|null=null;private texture:WebGLTexture|null=null;private buffer:WebGLBuffer|null=null;
  constructor(width:number,height:number){
    this.canvas=makeCanvas(Math.ceil(width/4),Math.ceil(height/4));
    this.gl=this.canvas.getContext('webgl',{alpha:true,premultipliedAlpha:false,preserveDrawingBuffer:true,antialias:false,depth:false});
    const gl=this.gl;if(!gl)return;
    const rendererInfo=gl.getExtension('WEBGL_debug_renderer_info');
    const rendererName=rendererInfo?String(gl.getParameter(rendererInfo.UNMASKED_RENDERER_WEBGL)):'';
    if(/swiftshader|llvmpipe|software/i.test(rendererName)){
      gl.getExtension('WEBGL_lose_context')?.loseContext();this.gl=null;return;
    }
    const compile=(type:number,source:string):WebGLShader|null=>{const shader=gl.createShader(type);if(!shader)return null;gl.shaderSource(shader,source);gl.compileShader(shader);if(!gl.getShaderParameter(shader,gl.COMPILE_STATUS)){gl.deleteShader(shader);return null;}return shader;};
    const vertex=compile(gl.VERTEX_SHADER,'attribute vec2 a_position; varying vec2 v_uv; void main(){ v_uv=(a_position+1.0)*0.5; gl_Position=vec4(a_position,0.0,1.0); }');
    const fragment=compile(gl.FRAGMENT_SHADER,`precision mediump float;
      varying vec2 v_uv; uniform sampler2D u_image; uniform vec2 u_texel; uniform float u_glow;
      void main(){vec3 bloom=vec3(0.0);float weight=0.0;
        for(int x=-2;x<=2;x++){for(int y=-2;y<=2;y++){
          vec2 offset=vec2(float(x),float(y));float w=1.0/(1.0+dot(offset,offset));
          vec4 sampleColor=texture2D(u_image,v_uv+offset*u_texel*2.4);
          bloom+=max(sampleColor.rgb-vec3(0.07),vec3(0.0))*sampleColor.a*w;weight+=w;
        }}
        bloom=1.0-exp(-bloom/weight*u_glow*2.5);
        gl_FragColor=vec4(bloom,max(bloom.r,max(bloom.g,bloom.b)));
      }`);
    if(!vertex||!fragment){this.gl=null;return;}
    this.program=gl.createProgram();if(!this.program){this.gl=null;return;}
    gl.attachShader(this.program,vertex);gl.attachShader(this.program,fragment);gl.linkProgram(this.program);gl.deleteShader(vertex);gl.deleteShader(fragment);
    if(!gl.getProgramParameter(this.program,gl.LINK_STATUS)){this.gl=null;return;}
    gl.useProgram(this.program);this.buffer=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,this.buffer);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,1,1]),gl.STATIC_DRAW);
    const position=gl.getAttribLocation(this.program,'a_position');gl.enableVertexAttribArray(position);gl.vertexAttribPointer(position,2,gl.FLOAT,false,0,0);
    this.texture=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,this.texture);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,true);
  }
  render(source:HTMLCanvasElement,glow:number):HTMLCanvasElement|null {
    const gl=this.gl;if(!gl||!this.program)return null;
    gl.viewport(0,0,this.canvas.width,this.canvas.height);gl.useProgram(this.program);gl.bindTexture(gl.TEXTURE_2D,this.texture);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,source);
    gl.uniform2f(gl.getUniformLocation(this.program,'u_texel'),1/source.width,1/source.height);gl.uniform1f(gl.getUniformLocation(this.program,'u_glow'),glow);gl.uniform1i(gl.getUniformLocation(this.program,'u_image'),0);
    gl.drawArrays(gl.TRIANGLE_STRIP,0,4);return this.canvas;
  }
  dispose():void {if(this.gl){this.gl.deleteBuffer(this.buffer);this.gl.deleteTexture(this.texture);this.gl.deleteProgram(this.program);this.gl.getExtension('WEBGL_lose_context')?.loseContext();}}
}
function makeNest():HTMLCanvasElement {
  const c=makeCanvas(280,280),ctx=context2d(c);ctx.translate(140,140);
  const aura=ctx.createRadialGradient(0,0,15,0,0,136);aura.addColorStop(0,'rgba(95,202,171,.10)');aura.addColorStop(.45,'rgba(67,175,149,.08)');aura.addColorStop(1,'transparent');ctx.fillStyle=aura;ctx.fillRect(-140,-140,280,280);
  for(let i=6;i>=0;i--){rockPath(ctx,37+i*5,4);ctx.fillStyle=i===0?'#071714':`rgba(5,17,18,${.3+i*.09})`;ctx.fill();ctx.strokeStyle=i===0?'rgba(126,212,183,.48)':'rgba(70,128,117,.15)';ctx.lineWidth=.8;ctx.stroke();}
  for(const r of [67,76,95,115]){ctx.beginPath();ctx.arc(0,0,r,0,Math.PI*2);ctx.strokeStyle=r===76?'rgba(124,213,183,.3)':'rgba(110,174,158,.12)';ctx.lineWidth=r===76?1.2:.7;ctx.stroke();}
  ctx.strokeStyle='rgba(117,196,169,.5)';for(let i=0;i<48;i++){const a=i/48*Math.PI*2;ctx.beginPath();ctx.moveTo(Math.cos(a)*73,Math.sin(a)*73);ctx.lineTo(Math.cos(a)*(i%4===0?68:71),Math.sin(a)*(i%4===0?68:71));ctx.stroke();}
  ctx.fillStyle='#88bea2';for(let i=0;i<18;i++){const a=i/18*Math.PI*2;ctx.save();ctx.translate(Math.cos(a)*47,Math.sin(a)*47);ctx.rotate(a);ctx.globalAlpha=.2+(i%3)*.15;ctx.beginPath();ctx.ellipse(0,0,2,4,0,0,Math.PI*2);ctx.fill();ctx.restore();}
  ctx.globalAlpha=1;ctx.strokeStyle='#acd8bb';ctx.lineWidth=1;ctx.beginPath();ctx.ellipse(0,5,4,7,0,0,Math.PI*2);ctx.ellipse(0,-6,3,3.5,0,0,Math.PI*2);ctx.stroke();ctx.beginPath();ctx.moveTo(-2,-9);ctx.lineTo(-6,-14);ctx.moveTo(2,-9);ctx.lineTo(6,-14);for(let i=0;i<3;i++){ctx.moveTo(-3,-3+i*5);ctx.lineTo(-10,-6+i*7);ctx.moveTo(3,-3+i*5);ctx.lineTo(10,-6+i*7);}ctx.stroke();return c;
}
export class SanctuaryRenderer {
  private terrain:HTMLCanvasElement;private vignette:HTMLCanvasElement;private antAtlas:HTMLCanvasElement;private readonly crystals=createCrystalSprites();private readonly predator=createPredatorSprite();private readonly nest=makeNest();
  private readonly trailCanvas:HTMLCanvasElement;private readonly trailContext:CanvasRenderingContext2D;private readonly trailImage:ImageData;
  private readonly bloom:BloomShader;private bloomFrame:HTMLCanvasElement|null=null;private readonly fallback:HTMLCanvasElement;
  private terrainVersion=-1;private theme:Theme='bioluminescent';private frame=0;private readonly motes=new Float32Array(45*4);
  private view={scale:1,x:0,y:0};
  constructor(private readonly engine:AntEngine){
    this.terrain=createTerrain(engine.width,engine.height,engine.walls);this.vignette=createVignette(engine.width,engine.height);this.antAtlas=createAntAtlas(this.theme);
    this.trailCanvas=makeCanvas(engine.grid.cols,engine.grid.rows);this.trailContext=context2d(this.trailCanvas);this.trailImage=this.trailContext.createImageData(engine.grid.cols,engine.grid.rows);
    this.bloom=new BloomShader(engine.width,engine.height);this.fallback=makeCanvas(Math.ceil(engine.width/4),Math.ceil(engine.height/4));
    const rng=new Random(912);for(let i=0;i<45;i++){this.motes[i*4]=rng.next()*engine.width;this.motes[i*4+1]=rng.next()*engine.height;this.motes[i*4+2]=rng.next()*Math.PI*2;this.motes[i*4+3]=rng.range(.4,1.7);}
  }
  screenToWorld(x:number,y:number):Point {return{x:(x-this.view.x)/this.view.scale,y:(y-this.view.y)/this.view.scale};}
  render(ctx:CanvasRenderingContext2D,width:number,height:number,dpr:number,zoom:number,brush:BrushState,left=0):void {
    const e=this.engine,s=e.settings,w=e.width,h=e.height;this.frame++;
    if(s.theme!==this.theme){this.theme=s.theme;this.antAtlas=createAntAtlas(s.theme);}
    if(this.terrainVersion!==e.terrainVersion){this.terrain=createTerrain(w,h,e.walls);this.terrainVersion=e.terrainVersion;}
    const scale=Math.max(width/w,height/h)*zoom,ox=left+(width-w*scale)/2,oy=(height-h*scale)/2;
    this.view={scale,x:ox,y:oy};
    ctx.save();ctx.setTransform(dpr,0,0,dpr,0,0);ctx.beginPath();ctx.rect(left,0,width,height);ctx.clip();ctx.fillStyle='#060c10';ctx.fillRect(left,0,width,height);ctx.setTransform(scale*dpr,0,0,scale*dpr,ox*dpr,oy*dpr);
    // 1. Terrain cache: organic basalt, survey dots, soil micro-veins.
    ctx.drawImage(this.terrain,0,0);
    if(s.showGrid){ctx.strokeStyle='rgba(151,204,186,.08)';ctx.lineWidth=.6;ctx.beginPath();for(let x=0;x<w;x+=48){ctx.moveTo(x,0);ctx.lineTo(x,h);}for(let y=0;y<h;y+=48){ctx.moveTo(0,y);ctx.lineTo(w,y);}ctx.stroke();}
    // 2. Concentration-weighted five-channel radiance, no Canvas blur filters.
    if(s.showTrails){
      if(this.frame%2===1){e.grid.writeImage(this.trailImage.data,s.glow,s.theme);this.trailContext.putImageData(this.trailImage,0,0);}
      ctx.save();ctx.globalCompositeOperation='screen';ctx.imageSmoothingEnabled=true;ctx.globalAlpha=.72;ctx.drawImage(this.trailCanvas,0,0,w,h);ctx.restore();
      // 3. Quarter-resolution bright-pass fragment shader bloom.
      if(s.bloom&&!e.adaptive&&s.glow>0){
        if(this.frame%2===1){this.bloomFrame=this.bloom.render(this.trailCanvas,s.glow);if(!this.bloomFrame){const c=context2d(this.fallback);c.clearRect(0,0,this.fallback.width,this.fallback.height);c.imageSmoothingEnabled=true;c.drawImage(this.trailCanvas,0,0,this.fallback.width,this.fallback.height);this.bloomFrame=this.fallback;}}
        if(this.bloomFrame){ctx.save();ctx.globalCompositeOperation='lighter';ctx.globalAlpha=.45+s.glow*.3;ctx.drawImage(this.bloomFrame,0,0,w,h);ctx.restore();}
      }
    }
    // 4. Corpse husks and faceted emerald food reservoirs.
    ctx.strokeStyle='#47534d';ctx.lineWidth=1;
    for(let i=0;i<e.count;i++)if(e.corpseVisible[i]){ctx.beginPath();ctx.moveTo(e.ants.x[i]-2,e.ants.y[i]-2);ctx.lineTo(e.ants.x[i]+2,e.ants.y[i]+2);ctx.moveTo(e.ants.x[i]-2,e.ants.y[i]+1);ctx.lineTo(e.ants.x[i]+2,e.ants.y[i]-1);ctx.stroke();}
    for(let i=0;i<e.foods.length;i++){
      const food=e.foods[i];if(food.amount<=0)continue;const size=food.radius*2.2*Math.pow(Math.max(.05,food.amount/food.initial),.2);
      ctx.drawImage(this.crystals[food.variant%8],food.x-size/2,food.y-size/2,size,size);
      ctx.font='9px monospace';ctx.textAlign='center';ctx.fillStyle='rgba(144,185,159,.55)';ctx.fillText(`RESOURCE ${String(i+1).padStart(2,'0')}`,food.x,food.y+size*.54);
      ctx.fillStyle='rgba(107,164,136,.18)';ctx.fillRect(food.x-15,food.y+size*.54+9,30,1);ctx.fillStyle='#73b48f';ctx.fillRect(food.x-15,food.y+size*.54+9,30*food.amount/food.initial,1);
    }
    // 5. Brood reactor, harmonic mandala, larval pods and food storage arc.
    const nx=e.preset.nest.x,ny=e.preset.nest.y;ctx.drawImage(this.nest,nx-140,ny-140);
    ctx.strokeStyle='rgba(158,236,194,.7)';ctx.lineWidth=1.3;ctx.beginPath();ctx.arc(nx,ny,76,e.elapsed*.08,e.elapsed*.08+Math.PI*.37);ctx.stroke();
    ctx.strokeStyle='rgba(233,194,117,.65)';ctx.lineWidth=2;ctx.beginPath();ctx.arc(nx,ny,63,-Math.PI/2,-Math.PI/2+Math.PI*2*Math.min(.97,.1+e.foodDelivered/1200));ctx.stroke();
    ctx.textAlign='center';ctx.fillStyle='#a1c5b3';ctx.font='10px monospace';ctx.fillText('T H E  C O L O N Y',nx,ny-101);ctx.fillStyle='#6c9787';ctx.font='9px monospace';ctx.fillText(`GEN ${String(e.colonyGeneration).padStart(2,'0')}`,nx,ny+102);
    // Permanent emitters are physical sources, not a painted decoration.
    for(let i=0;i<e.emitters.length;i++){
      const emitter=e.emitters[i],color=s.theme==='monochrome'?'#deeee5':s.theme==='heatmap'?'#ffaf54':CHANNEL_META[emitter.channel].color;
      ctx.save();ctx.strokeStyle=color;ctx.fillStyle=color;const pulse=(e.elapsed*.5+i*.27)%1;
      ctx.globalAlpha=.3*(1-pulse);ctx.lineWidth=1;ctx.beginPath();ctx.arc(emitter.x,emitter.y,10+pulse*28,0,Math.PI*2);ctx.stroke();
      ctx.globalAlpha=.7;ctx.beginPath();ctx.arc(emitter.x,emitter.y,10,0,Math.PI*2);ctx.stroke();ctx.globalAlpha=1;ctx.beginPath();ctx.arc(emitter.x,emitter.y,3,0,Math.PI*2);ctx.fill();
      ctx.font='8px monospace';ctx.textAlign='center';ctx.globalAlpha=.65;ctx.fillText(`SOURCE ${String(i+1).padStart(2,'0')}`,emitter.x,emitter.y+30);ctx.restore();
    }
    // 6. All agents: articulated, pre-rendered caste and cohort sprite atlas.
    const a=e.ants;
    for(let i=0;i<e.count;i++){
      if(!a.active[i])continue;
      const screenX=a.x[i]*scale+ox,screenY=a.y[i]*scale+oy;if(screenX<left-12||screenX>left+width+12||screenY< -12||screenY>height+12)continue;
      const cohort=a.policyType[i]===0?0:1,caste=a.caste[i],frame=Math.floor(a.legPhase[i])%8,angle=a.angle[i]+Math.PI/2,c=Math.cos(angle),sin=Math.sin(angle),factor=scale*dpr;
      ctx.setTransform(c*factor,sin*factor,-sin*factor,c*factor,(a.x[i]*scale+ox)*dpr,(a.y[i]*scale+oy)*dpr);
      ctx.globalAlpha=.6+a.energy[i]/250;const size=a.caste[i]===2?15:12;
      ctx.drawImage(this.antAtlas,frame*24,(cohort*4+caste)*24,24,24,-size/2,-size/2,size,size);
      if(a.carryingFood[i]){ctx.fillStyle=s.theme==='heatmap'?'#ffac57':s.theme==='monochrome'?'#e4f1e8':'#98deb0';ctx.fillRect(-.9,-5.8,1.8,2);}
    }
    ctx.setTransform(scale*dpr,0,0,scale*dpr,ox*dpr,oy*dpr);ctx.globalAlpha=1;
    for(let i=0;i<e.predators.length;i++){const p=e.predators[i];if(!p.active)continue;ctx.save();ctx.translate(p.x,p.y);ctx.rotate(p.angle+Math.PI/2);ctx.drawImage(this.predator,-30,-30,60,60);ctx.strokeStyle='#d37891';ctx.lineWidth=1.2;ctx.beginPath();ctx.arc(0,0,28,-Math.PI/2,-Math.PI/2+Math.PI*2*p.hp/100);ctx.stroke();ctx.restore();}
    // 7. Brief synaptic, tandem and combat vector filaments.
    for(let i=0;i<e.arcData.length;i+=6){if(e.arcData[i+5]<=0)continue;ctx.save();ctx.globalAlpha=e.arcData[i+5]*2.5;ctx.strokeStyle=e.arcData[i+4]===0?'#d1ce8d':'#b69ee1';ctx.lineWidth=.8;ctx.beginPath();ctx.moveTo(e.arcData[i],e.arcData[i+1]);ctx.quadraticCurveTo((e.arcData[i]+e.arcData[i+2])/2,(e.arcData[i+1]+e.arcData[i+3])/2-8,e.arcData[i+2],e.arcData[i+3]);ctx.stroke();ctx.restore();}
    // 8. Forty-five atmospheric spores, deterministic and parallax-light.
    for(let i=0;i<45;i++){const k=i*4,phase=this.motes[k+2],x=this.motes[k]+Math.sin(e.elapsed*.035+phase)*15,y=this.motes[k+1]+Math.cos(e.elapsed*.03+phase)*12,r=this.motes[k+3];ctx.globalAlpha=.12+Math.abs(Math.sin(e.elapsed*.2+phase))*.23;ctx.fillStyle=i%4===0?'#d3c59d':'#99c9b5';ctx.fillRect(x,y,r,r);}
    ctx.globalAlpha=1;
    // 9. Spectral brush ring and rotating eraser reticle.
    if(brush.visible){ctx.save();ctx.translate(brush.x,brush.y);ctx.strokeStyle=brush.tool==='eraser'?'#d8cbe1':brush.tool==='emitter'?CHANNEL_META[s.emitterChannel].color:brush.tool==='home'?'#74d8d9':brush.tool==='alarm'?'#ee7792':'#d8c398';ctx.globalAlpha=.7;ctx.lineWidth=1;ctx.beginPath();if(brush.tool==='eraser'){ctx.rotate(e.elapsed*.3);ctx.setLineDash([5,5]);}ctx.arc(0,0,brush.radius,0,Math.PI*2);ctx.stroke();ctx.setLineDash([]);ctx.globalAlpha=brush.active?.8:.3;ctx.beginPath();ctx.arc(0,0,brush.radius+5,0,Math.PI*2);ctx.stroke();ctx.fillStyle='#eef5dc';ctx.fillRect(-1,-1,2,2);ctx.restore();}
    // 10. Cached vignette; no per-frame blur or shadowBlur.
    ctx.drawImage(this.vignette,0,0);
    ctx.restore();
  }
  dispose():void {this.bloom.dispose();}
}
