import { angleDelta, clamp, Random } from './prng-noise';
import { createBrain, forward, randomBrain } from './neat';
import { PheromoneGrid } from './pheromone-grid';
import { getPreset, routePoint } from './presets';
import { AntState, Caste, DEFAULT_SETTINGS, MAX_ANTS, MAX_PREDATORS, Policy, WORLD_HEIGHT, WORLD_WIDTH, type AntSoA, type Brain, type ChannelIndex, type Emitter, type FoodSite, type Predator, type Preset, type SimulationSettings, type Telemetry, type Tool, type Wall } from './types';

export function createSoA(size=MAX_ANTS): AntSoA {
  const f=()=>new Float32Array(size),u=()=>new Uint8Array(size);
  return {x:f(),y:f(),vx:f(),vy:f(),angle:f(),homeDx:f(),homeDy:f(),targetX:f(),targetY:f(),legPhase:f(),pheromoneTimer:f(),timeSinceLastVisit:f(),ouNoise:f(),energy:f(),age:f(),maxLifespan:f(),fitness:f(),memA:f(),memB:f(),distance:f(),state:u(),caste:u(),policyType:u(),carryingFood:u(),active:u(),generation:new Uint16Array(size),next:new Int32Array(size)};
}
interface EngineOptions { population?: number; seed?: number; width?: number; height?: number; headless?: boolean; settings?: Partial<SimulationSettings>; brain?: Brain; }
export class AntEngine {
  readonly ants=createSoA();readonly grid:PheromoneGrid;readonly width:number;readonly height:number;readonly rng:Random;
  settings:SimulationSettings;brain:Brain;readonly randomNetwork:Brain;readonly preset:Preset;foods:FoodSite[];walls:Wall[];
  emitters:Emitter[]=[];predators:Predator[]=[];terrainVersion=0;tick=0;elapsed=0;foodDelivered=0;totalDeaths=0;totalBirths=0;colonyGeneration=1;
  trainedFood=0;rivalFood=0;count=0;aliveCount=0;adaptive=false;bottleneck=false;
  readonly corpseVisible=new Uint8Array(MAX_ANTS);readonly carriedCorpse=new Int32Array(MAX_ANTS).fill(-1);
  readonly arcData=new Float32Array(64*6);private arcCursor=0;
  private readonly headless:boolean;private readonly heads:Int32Array;private readonly hashCols:number;
  private readonly inputs=new Float32Array(19);private readonly hidden=new Float32Array(16);private readonly outputs=new Float32Array(9);
  private readonly torque=new Float32Array(MAX_ANTS);private readonly speed=new Float32Array(MAX_ANTS);private readonly secretion=new Float32Array(MAX_ANTS*5);
  private readonly occupancy=new Uint16Array(40*25);private readonly birthBuckets=new Uint16Array(60);private readonly deathBuckets=new Uint16Array(60);
  private bucket=0;private bucketSecond=0;private emitterId=0;private brood=0;
  constructor(options:EngineOptions={}) {
    this.width=options.width??WORLD_WIDTH;this.height=options.height??WORLD_HEIGHT;this.headless=options.headless??false;
    this.rng=new Random(options.seed??371);this.settings={...DEFAULT_SETTINGS,...options.settings,population:clamp(options.population??options.settings?.population??3000,1,MAX_ANTS),mutedChannels:[...(options.settings?.mutedChannels??DEFAULT_SETTINGS.mutedChannels)]};
    this.brain=options.brain??createBrain();this.randomNetwork=randomBrain(943,.55);
    this.grid=new PheromoneGrid(this.width,this.height);this.preset=getPreset(this.settings.preset,this.width,this.height);this.foods=this.preset.foods;this.walls=this.preset.walls;
    this.hashCols=Math.ceil(this.width/24);this.heads=new Int32Array(this.hashCols*Math.ceil(this.height/24)).fill(-1);
    this.rasterWalls();this.applySettings(this.settings);this.seedTrails();
    for(let i=0;i<this.settings.population;i++)this.spawn(i,!this.headless);
    this.count=this.settings.population;this.rebuildHash();
  }
  private seedTrails():void {
    for(let f=0;f<this.foods.length;f++){
      const food=this.foods[f];const steps=Math.ceil(Math.hypot(food.x-this.preset.nest.x,food.y-this.preset.nest.y)/3);
      for(let j=0;j<=steps;j++){
        const t=j/steps,p=routePoint(this.preset.nest,food,t,f);
        this.grid.brush(1,p.x,p.y,this.headless?9:15,6*(1-t)+2);
        this.grid.brush(0,p.x+5,p.y+4,this.headless?8:10,5*t+2);
        if(f===2||f===3)this.grid.brush(3,p.x-6,p.y+8,this.headless?6:9,2);
      }
    }
  }
  private spawn(i:number,distributed=false):void {
    const a=this.ants,rng=this.rng,nest=this.preset.nest;
    let x=nest.x+rng.gaussian()*12,y=nest.y+rng.gaussian()*12,angle=rng.next()*Math.PI*2;
    if(distributed){
      const site=rng.int(this.foods.length),t=rng.next(),f=this.foods[site],p=routePoint(nest,f,t,site),p2=routePoint(nest,f,Math.min(1,t+.01),site);
      const spread=rng.next()<.78?10:65;
      x=p.x+rng.gaussian()*spread;y=p.y+rng.gaussian()*spread;angle=Math.atan2(p2.y-p.y,p2.x-p.x)+(i%2?Math.PI:0);
      if(i%2===1)a.carryingFood[i]=1;
    }
    a.x[i]=clamp(x,18,this.width-18);a.y[i]=clamp(y,18,this.height-18);a.angle[i]=angle;
    a.active[i]=1;a.state[i]=a.carryingFood[i]?AntState.RETURNING:AntState.FORAGING;
    a.caste[i]=i%10===0?Caste.WARDEN:i%10<4?Caste.SCOUT:Caste.HAULER;
    a.policyType[i]=this.settings.policy==='aco'?Policy.HANDCRAFTED_ACO:this.settings.policy==='random'?Policy.RANDOM_MLP:Policy.TRAINED_MLP;
    a.energy[i]=distributed?rng.range(60,100):100;a.maxLifespan[i]=this.settings.lifespan*rng.range(.7,1.4);a.age[i]=distributed?rng.next()*a.maxLifespan[i]*.92:0;
    a.generation[i]=this.colonyGeneration;a.targetX[i]=-1;a.targetY[i]=-1;a.distance[i]=0;a.timeSinceLastVisit[i]=0;a.memA[i]=0;a.memB[i]=0;
    this.speed[i]=.7;this.torque[i]=0;this.corpseVisible[i]=0;this.carriedCorpse[i]=-1;this.aliveCount++;
    if(this.grid.walls[this.grid.index(a.x[i],a.y[i])]){a.x[i]=nest.x+rng.gaussian()*8;a.y[i]=nest.y+rng.gaussian()*8;}
  }
  applySettings(settings:SimulationSettings):void {
    const old=this.settings;this.settings={...settings,mutedChannels:[...settings.mutedChannels]};
    this.grid.evaporation=settings.evaporation;this.grid.diffusion=settings.diffusion;this.grid.reactionRate=settings.reactionRate;
    for(let i=0;i<5;i++)this.grid.muted[i]=settings.mutedChannels[i]?1:0;
    if(old.policy!==settings.policy)for(let i=0;i<this.count;i++)this.ants.policyType[i]=settings.policy==='aco'?Policy.HANDCRAFTED_ACO:settings.policy==='random'?Policy.RANDOM_MLP:Policy.TRAINED_MLP;
    if(old.lifespan!==settings.lifespan)for(let i=0;i<this.count;i++)this.ants.maxLifespan[i]*=settings.lifespan/old.lifespan;
    if(this.count>0&&old.population!==settings.population)this.setPopulation(settings.population);
    if(!settings.predators)for(let i=0;i<this.predators.length;i++)this.predators[i].active=false;
  }
  setPopulation(value:number):void {
    const target=clamp(Math.round(value),1,MAX_ANTS),a=this.ants;
    if(target<this.aliveCount){let remove=this.aliveCount-target;for(let i=this.count-1;i>=0&&remove>0;i--)if(a.active[i]){a.active[i]=0;a.state[i]=AntState.DEAD;this.corpseVisible[i]=0;this.aliveCount--;remove--;}}
    else if(target>this.aliveCount){let add=target-this.aliveCount;for(let i=0;i<MAX_ANTS&&add>0;i++)if(!a.active[i]){a.carryingFood[i]=0;this.spawn(i,true);this.count=Math.max(this.count,i+1);add--;}}
    this.settings.population=target;
  }
  private rasterWalls():void {
    this.grid.walls.fill(0);
    for(let y=0;y<this.grid.rows;y++)for(let x=0;x<this.grid.cols;x++){
      const wx=x*6+3,wy=y*6+3;
      for(let j=0;j<this.walls.length;j++){const w=this.walls[j],dx=wx-w.x,dy=wy-w.y,c=Math.cos(w.rotation),s=Math.sin(w.rotation),lx=(dx*c+dy*s)/w.stretch,ly=-dx*s+dy*c;if(lx*lx+ly*ly<w.radius*w.radius*.95){this.grid.walls[y*this.grid.cols+x]=1;break;}}
    }
    this.terrainVersion++;
  }
  paint(tool:Tool,x:number,y:number,radius:number,channel:ChannelIndex=0):void {
    if(tool==='food'||tool==='home'||tool==='alarm'){this.grid.brush(tool==='food'?channel:tool==='home'?1:2,x,y,radius,35);return;}
    if(tool==='emitter'){if(this.emitters.length>=64)return;this.emitters.push({id:++this.emitterId,x,y,channel,strength:90,radius:Math.max(18,radius)});this.grid.brush(channel,x,y,radius,70);return;}
    if(tool==='crystal'){this.foods.push({x,y,radius:Math.max(24,radius),amount:2500,initial:2500,variant:this.rng.int(8)});return;}
    if(tool==='wall'){if(this.walls.length<180){this.walls.push({x,y,radius,stretch:1.1,rotation:this.rng.next()*Math.PI});this.rasterWalls();}return;}
    this.grid.erase(x,y,radius);const radius2=radius*radius;
    this.emitters=this.emitters.filter(e=>(e.x-x)**2+(e.y-y)**2>radius2);
    this.foods=this.foods.filter(f=>(f.x-x)**2+(f.y-y)**2>radius2);
    const previous=this.walls.length;this.walls=this.walls.filter(w=>Math.hypot(w.x-x,w.y-y)>radius+w.radius*.5);if(this.walls.length!==previous)this.rasterWalls();
  }
  spawnPredator(x=this.width*.8,y=this.height*.4):boolean {
    if(this.predators.filter(p=>p.active).length>=MAX_PREDATORS)return false;
    this.settings.predators=true;this.predators.push({x,y,hp:100,angle:0,active:true});return true;
  }
  private rebuildHash():void {
    const a=this.ants;this.heads.fill(-1);
    for(let i=0;i<this.count;i++){if(!a.active[i]&&!this.corpseVisible[i])continue;const index=clamp(Math.floor(a.y[i]/24),0,Math.ceil(this.height/24)-1)*this.hashCols+clamp(Math.floor(a.x[i]/24),0,this.hashCols-1);a.next[i]=this.heads[index];this.heads[index]=i;}
  }
  private arc(i:number,j:number,kind:number):void {
    const k=(this.arcCursor++%64)*6,a=this.ants;this.arcData[k]=a.x[i];this.arcData[k+1]=a.y[i];this.arcData[k+2]=a.x[j];this.arcData[k+3]=a.y[j];this.arcData[k+4]=kind;this.arcData[k+5]=.2;
  }
  private interact(i:number):void {
    const a=this.ants,cx=Math.floor(a.x[i]/24),cy=Math.floor(a.y[i]/24);let checked=0;
    for(let oy=-1;oy<=1;oy++)for(let ox=-1;ox<=1;ox++){
      const xx=cx+ox,yy=cy+oy;if(xx<0||xx>=this.hashCols||yy<0||yy>=Math.ceil(this.height/24))continue;
      let j=this.heads[yy*this.hashCols+xx];
      while(j>=0&&checked<12){checked++;if(j!==i&&(a.x[i]-a.x[j])**2+(a.y[i]-a.y[j])**2<24*24){
        if(a.active[j]&&a.energy[i]>65&&a.energy[j]<30){a.energy[i]-=8;a.energy[j]+=8;a.fitness[i]+=.3;this.arc(i,j,0);}
        if(a.active[j]&&a.caste[i]===Caste.SCOUT&&a.carryingFood[i]&&!a.carryingFood[j]&&a.targetX[i]>0){a.targetX[j]=a.targetX[i];a.targetY[j]=a.targetY[i];a.state[j]=AntState.TANDEM_FOLLOW;this.grid.deposit(3,a.x[i],a.y[i],20);this.arc(i,j,1);}
        if(!a.active[j]&&this.corpseVisible[j]&&a.caste[i]===Caste.WARDEN&&this.carriedCorpse[i]<0){this.carriedCorpse[i]=j;this.corpseVisible[j]=0;a.state[i]=AntState.NECROPHORESIS;}
      }j=a.next[j];}
    }
  }
  private sense(i:number):void {
    const a=this.ants,input=this.inputs,angle=a.angle[i],x=a.x[i],y=a.y[i],radius=this.headless?10:19;
    const lx=x+Math.cos(angle-.6)*radius,ly=y+Math.sin(angle-.6)*radius,rx=x+Math.cos(angle+.6)*radius,ry=y+Math.sin(angle+.6)*radius;
    for(let c=0;c<5;c++){input[c]=(Math.log1p(this.grid.sample(c,rx,ry))-Math.log1p(this.grid.sample(c,lx,ly)))/4.615;input[5+c]=Math.log1p(this.grid.sample(c,x,y))/4.615;}
    for(let ray=0;ray<3;ray++){const theta=angle+(ray-1)*.65;let distance=1;for(let d=1;d<=3;d++){const px=x+Math.cos(theta)*d*radius*.7,py=y+Math.sin(theta)*d*radius*.7;if(px<8||px>this.width-8||py<8||py>this.height-8||this.grid.walls[this.grid.index(px,py)]){distance=(d-1)/3;break;}}input[10+ray]=distance;}
    const dx=this.preset.nest.x-x,dy=this.preset.nest.y-y,length=Math.max(1,Math.hypot(dx,dy));
    a.homeDx[i]=dx;a.homeDy[i]=dy;input[13]=this.settings.pathIntegration?(-dx*Math.sin(angle)+dy*Math.cos(angle))/length:0;input[14]=this.settings.pathIntegration?(dx*Math.cos(angle)+dy*Math.sin(angle))/length:0;
    input[15]=a.carryingFood[i];input[16]=a.energy[i]/100;input[17]=a.memA[i];input[18]=a.memB[i];
    if(a.policyType[i]===Policy.HANDCRAFTED_ACO){this.torque[i]=clamp(input[a.carryingFood[i]?1:0]*4-input[2]*3-input[4]*2+(input[12]-input[10])*2,-1,1);this.speed[i]=.74;return;}
    forward(a.policyType[i]===Policy.RANDOM_MLP?this.randomNetwork:this.brain,input,this.hidden,this.outputs);
    this.torque[i]=this.outputs[0];this.speed[i]=.45+this.outputs[1]*.55;
    for(let c=0;c<5;c++)this.secretion[i*5+c]=this.outputs[2+c];
    a.memA[i]=this.outputs[7];a.memB[i]=this.outputs[8];
  }
  private die(i:number):void {
    const a=this.ants;a.active[i]=0;a.state[i]=AntState.DEAD;this.corpseVisible[i]=1;this.aliveCount--;this.totalDeaths++;this.deathBuckets[this.bucket]++;
    if(a.carryingFood[i]){this.grid.deposit(0,a.x[i],a.y[i],25);for(let f=0;f<this.foods.length;f++)if(Math.hypot(a.x[i]-this.foods[f].x,a.y[i]-this.foods[f].y)<50){this.foods[f].amount++;break;}}
    a.carryingFood[i]=0;this.grid.deposit(2,a.x[i],a.y[i],6);a.fitness[i]-=2;
  }
  step(dt=1/60):void {
    const a=this.ants;this.tick++;this.elapsed+=dt;
    const second=Math.floor(this.elapsed);if(second!==this.bucketSecond){this.bucketSecond=second;this.bucket=second%60;this.birthBuckets[this.bucket]=0;this.deathBuckets[this.bucket]=0;}
    const diffuseEvery=this.headless?8:this.adaptive?4:3;
    if(this.tick%diffuseEvery===0)this.grid.step(dt*diffuseEvery,this.emitters);
    if(this.tick%6===0)this.rebuildHash();
    for(let k=5;k<this.arcData.length;k+=6)this.arcData[k]=Math.max(0,this.arcData[k]-dt);
    const decisionStride=this.headless?8:12;
    for(let i=0;i<this.count;i++){
      if(!a.active[i]){if(this.corpseVisible[i]&&this.tick%120===i%120)this.grid.deposit(2,a.x[i],a.y[i],.5);continue;}
      a.age[i]+=dt;a.energy[i]-=dt*this.settings.energyBurn*(.65+this.speed[i]*.35+a.carryingFood[i]*.3);
      if(a.age[i]>=a.maxLifespan[i]||a.energy[i]<=0){this.die(i);continue;}
      if(i%decisionStride===this.tick%decisionStride)this.sense(i);
      if(i%90===this.tick%90)this.interact(i);
      let steer=this.torque[i]*2.6;
      a.ouNoise[i]=a.ouNoise[i]*.96+(this.rng.next()-.5)*.13;
      steer+=a.ouNoise[i]*.65;
      const homeAngle=Math.atan2(this.preset.nest.y-a.y[i],this.preset.nest.x-a.x[i]);
      if(a.carryingFood[i]&&this.settings.pathIntegration)steer+=clamp(angleDelta(homeAngle,a.angle[i])*3,-3,3);
      else if(a.state[i]===AntState.TANDEM_FOLLOW&&a.targetX[i]>=0){steer+=clamp(angleDelta(Math.atan2(a.targetY[i]-a.y[i],a.targetX[i]-a.x[i]),a.angle[i]),-1,1);if(Math.hypot(a.targetX[i]-a.x[i],a.targetY[i]-a.y[i])<30)a.state[i]=AntState.FORAGING;}
      if(a.state[i]===AntState.NECROPHORESIS){const gx=this.width*.1,gy=this.height*.88;steer=clamp(angleDelta(Math.atan2(gy-a.y[i],gx-a.x[i]),a.angle[i])*4,-4,4);if(Math.hypot(gx-a.x[i],gy-a.y[i])<24){const body=this.carriedCorpse[i];if(body>=0&&!a.active[body]){a.x[body]=gx+this.rng.range(-18,18);a.y[body]=gy+this.rng.range(-18,18);this.corpseVisible[body]=1;}this.carriedCorpse[i]=-1;a.state[i]=AntState.FORAGING;}}
      if(this.settings.predators)for(let j=0;j<this.predators.length;j++){
        const p=this.predators[j];if(!p.active)continue;const dx=p.x-a.x[i],dy=p.y-a.y[i],d2=dx*dx+dy*dy;
        if(d2<75*75){if(this.tick%30===i%30)this.grid.deposit(2,a.x[i],a.y[i],80);const warden=a.caste[i]===Caste.WARDEN;a.state[i]=warden?AntState.DEFENDING:AntState.ALARMED;const away=Math.atan2(dy,dx)+(warden?0:Math.PI);steer=clamp(angleDelta(away,a.angle[i])*4,-4,4);if(d2<18*18){a.energy[i]-=dt*(warden?7:26);if(warden){p.hp-=dt*3;a.fitness[i]+=dt*.5;}if(p.hp<=0)p.active=false;}}
      }
      a.angle[i]+=steer*dt;
      const speed=(this.headless?46:43)*this.speed[i]*(a.carryingFood[i]?.9:1),vx=Math.cos(a.angle[i])*speed,vy=Math.sin(a.angle[i])*speed;
      const nx=a.x[i]+vx*dt,ny=a.y[i]+vy*dt;
      if(nx<8||ny<8||nx>this.width-8||ny>this.height-8||this.grid.walls[this.grid.index(nx,ny)]){a.angle[i]+=Math.PI*.65+(this.rng.next()-.5)*.5;a.fitness[i]-=.015;a.timeSinceLastVisit[i]+=.25;if(a.timeSinceLastVisit[i]>4){this.grid.deposit(4,a.x[i],a.y[i],16);a.state[i]=AntState.TRAIL_DAMPING;a.timeSinceLastVisit[i]=0;}}
      else {a.x[i]=nx;a.y[i]=ny;a.vx[i]=vx;a.vy[i]=vy;a.distance[i]+=speed*dt;a.legPhase[i]+=speed*dt*.35;a.timeSinceLastVisit[i]+=dt;}
      if(this.tick%12===i%12){
        const returning=a.carryingFood[i]===1;
        if(a.policyType[i]===Policy.HANDCRAFTED_ACO)this.grid.deposit(returning?0:1,a.x[i],a.y[i],returning?5:2.5);
        else {for(let c=0;c<5;c++){let secretion=this.secretion[i*5+c];if(c===0)secretion*=returning?7:.12;else if(c===1)secretion*=returning?.3:3;else if(c===2)secretion*=a.state[i]===AntState.ALARMED?15:.02;else if(c===3)secretion*=a.caste[i]===Caste.SCOUT?.8:.05;else secretion*=a.state[i]===AntState.TRAIL_DAMPING?8:.01;this.grid.deposit(c,a.x[i],a.y[i],secretion);}}
      }
      if(this.tick%6===i%6){
        const distanceHome=Math.hypot(a.x[i]-this.preset.nest.x,a.y[i]-this.preset.nest.y);
        if(distanceHome<(this.headless?18:30)){
          a.energy[i]=100;
          if(a.carryingFood[i]){this.foodDelivered++;if(a.policyType[i]===Policy.TRAINED_MLP)this.trainedFood++;else this.rivalFood++;a.carryingFood[i]=0;a.state[i]=AntState.FORAGING;a.fitness[i]+=4+1/Math.max(1,a.distance[i]/Math.max(1,Math.hypot(a.targetX[i]-this.preset.nest.x,a.targetY[i]-this.preset.nest.y)));a.distance[i]=0;a.timeSinceLastVisit[i]=0;this.brood++;a.angle[i]+=Math.PI;}
        }
        if(!a.carryingFood[i]&&a.state[i]!==AntState.NECROPHORESIS){
          for(let j=0;j<this.foods.length;j++){
            const f=this.foods[j],dx=f.x-a.x[i],dy=f.y-a.y[i],d2=dx*dx+dy*dy;
            if(d2<(this.headless?24:60)**2&&f.amount>0){a.angle[i]+=clamp(angleDelta(Math.atan2(dy,dx),a.angle[i]),-.6,.6);}
            if(d2<(f.radius*.6+5)**2){
              if(f.amount>0){f.amount--;a.carryingFood[i]=1;a.state[i]=AntState.RETURNING;a.targetX[i]=f.x;a.targetY[i]=f.y;a.angle[i]+=Math.PI;this.grid.deposit(0,a.x[i],a.y[i],30);a.fitness[i]++;}
              else{a.state[i]=AntState.TRAIL_DAMPING;a.angle[i]+=Math.PI;this.grid.deposit(4,a.x[i],a.y[i],25);}break;
            }
          }
        }
      }
    }
    if(this.tick%60===0){
      if(this.brood>=3&&this.aliveCount<this.settings.population){for(let i=0;i<MAX_ANTS&&this.brood>=3&&this.aliveCount<this.settings.population;i++)if(!a.active[i]){a.carryingFood[i]=0;this.spawn(i);this.count=Math.max(this.count,i+1);this.totalBirths++;this.birthBuckets[this.bucket]++;this.brood-=3;this.colonyGeneration=1+Math.floor(this.totalBirths/25);}}
      if(this.aliveCount<35&&!this.headless){this.bottleneck=true;for(let i=0;i<MAX_ANTS&&this.aliveCount<Math.min(100,this.settings.population);i++)if(!a.active[i]){this.spawn(i);this.count=Math.max(this.count,i+1);this.totalBirths++;this.birthBuckets[this.bucket]++;}}
      this.brood=Math.min(this.brood,300);
    }
    if(this.settings.predators)for(let p=0;p<this.predators.length;p++){
      const predator=this.predators[p];if(!predator.active)continue;let nearest=-1,best=Infinity;
      for(let i=p;i<this.count;i+=12){if(!a.active[i])continue;const d=(a.x[i]-predator.x)**2+(a.y[i]-predator.y)**2;if(d<best){best=d;nearest=i;}}
      if(nearest>=0){predator.angle=Math.atan2(a.y[nearest]-predator.y,a.x[nearest]-predator.x);const nx=predator.x+Math.cos(predator.angle)*18*dt,ny=predator.y+Math.sin(predator.angle)*18*dt;if(!this.grid.walls[this.grid.index(nx,ny)]){predator.x=nx;predator.y=ny;}}
    }
    if(this.tick%60===0){for(let i=0;i<this.foods.length;i++)if(this.foods[i].amount>0)this.grid.brush(0,this.foods[i].x,this.foods[i].y,this.foods[i].radius*1.6,20);this.grid.brush(1,this.preset.nest.x,this.preset.nest.y,this.headless?25:65,30);}
  }
  telemetry(fps=60):Telemetry {
    const a=this.ants;let scouts=0,haulers=0,wardens=0,energy=0,occupied=0,entropy=0,available=0,births=0,deaths=0;this.occupancy.fill(0);
    for(let i=0;i<this.count;i++)if(a.active[i]){if(a.caste[i]===Caste.SCOUT)scouts++;else if(a.caste[i]===Caste.HAULER)haulers++;else wardens++;energy+=a.energy[i];const x=clamp(Math.floor(a.x[i]/this.width*40),0,39),y=clamp(Math.floor(a.y[i]/this.height*25),0,24);this.occupancy[y*40+x]++;}
    for(let i=0;i<this.occupancy.length;i++){if(!this.grid.walls[this.grid.index((i%40+.5)/40*this.width,(Math.floor(i/40)+.5)/25*this.height)])available++;if(this.occupancy[i]>0){occupied++;const p=this.occupancy[i]/Math.max(1,this.aliveCount);entropy-=p*Math.log(p);}}
    for(let i=0;i<60;i++){births+=this.birthBuckets[i];deaths+=this.deathBuckets[i];}
    const period=Math.max(1,Math.min(60,this.elapsed));
    return {alive:this.aliveCount,deaths:this.totalDeaths,births:this.totalBirths,food:this.foodDelivered,generation:this.colonyGeneration,fps,elapsed:this.elapsed,coverage:Math.min(100,occupied/Math.max(1,available)*100),entropy:entropy/Math.log(Math.max(2,available)),birthRate:births/period*60,deathRate:deaths/period*60,scouts,haulers,wardens,emitters:this.emitters.length,trainedFood:this.trainedFood,rivalFood:this.rivalFood,meanEnergy:energy/Math.max(1,this.aliveCount),predatorCount:this.predators.filter(p=>p.active).length,adaptive:this.adaptive};
  }
  fitness():number {let total=0;for(let i=0;i<this.count;i++)total+=this.ants.fitness[i];return this.foodDelivered*10+total*.04-this.totalDeaths*1.5;}
}
