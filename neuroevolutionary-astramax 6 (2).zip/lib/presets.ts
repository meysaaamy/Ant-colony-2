import type { Point, Preset, PresetId } from './types';
export const PRESETS: readonly Preset[] = [
  { id:'sanctuary', name:'Open Sanctuary', description:'An open world. A thousand possibilities.', difficulty:'EXPLORATION', nest:{x:660,y:510},
    foods:[{x:270,y:240,amount:6500,initial:6500,radius:48,variant:0},{x:1180,y:275,amount:8000,initial:8000,radius:54,variant:3},{x:1335,y:585,amount:5000,initial:5000,radius:44,variant:6},{x:410,y:815,amount:4500,initial:4500,radius:45,variant:2},{x:1000,y:820,amount:6000,initial:6000,radius:48,variant:5}],
    walls:[{x:790,y:195,radius:60,stretch:1.65,rotation:-.4},{x:1165,y:735,radius:64,stretch:1.55,rotation:.4},{x:270,y:585,radius:68,stretch:1.3,rotation:-.6}] },
  { id:'bridge', name:"Deneubourg’s Double Bridge", description:'Two paths. One collective decision.', difficulty:'PATH SELECTION',nest:{x:390,y:510},
    foods:[{x:1240,y:510,amount:18000,initial:18000,radius:62,variant:4}],
    walls:[{x:800,y:510,radius:190,stretch:1.15,rotation:0},{x:800,y:30,radius:150,stretch:4,rotation:0},{x:800,y:1010,radius:190,stretch:4,rotation:0}] },
  { id:'labyrinth', name:'Subterranean Labyrinth',description:'Find a way through the unknown.',difficulty:'NAVIGATION',nest:{x:320,y:550},
    foods:[{x:1330,y:250,amount:10000,initial:10000,radius:50,variant:2},{x:1220,y:820,amount:9000,initial:9000,radius:52,variant:6},{x:650,y:210,amount:4000,initial:4000,radius:42,variant:0}],
    walls:[{x:575,y:550,radius:73,stretch:3.9,rotation:Math.PI/2},{x:925,y:500,radius:73,stretch:3.5,rotation:Math.PI/2},{x:1250,y:515,radius:63,stretch:2.3,rotation:0},{x:130,y:255,radius:88,stretch:1.8,rotation:-.4}] }
];
export function getPreset(id: PresetId,width=1600,height=1000): Preset {
  const source=PRESETS.find(p=>p.id===id)??PRESETS[0],sx=width/1600,sy=height/1000;
  return {...source,nest:{x:source.nest.x*sx,y:source.nest.y*sy},foods:source.foods.map(f=>({...f,x:f.x*sx,y:f.y*sy,radius:Math.max(14,f.radius*Math.min(sx,sy))})),walls:source.walls.map(w=>({...w,x:w.x*sx,y:w.y*sy,radius:w.radius*Math.min(sx,sy)}))};
}
export function routePoint(start: Point,end: Point,t: number,index: number): Point {
  const dx=end.x-start.x,dy=end.y-start.y,length=Math.max(1,Math.hypot(dx,dy));
  const bend=Math.sin(t*Math.PI)*Math.sin(index*2.8+1)*length*.2+Math.sin(t*Math.PI*2)*length*.045;
  return {x:start.x+dx*t-dy/length*bend,y:start.y+dy*t+dx/length*bend};
}
