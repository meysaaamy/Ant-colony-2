import { db } from '@/db';
import { simulationExperiments } from '@/db/schema';
import { desc,sql } from 'drizzle-orm';
import { createSoA } from '@/lib/ant-soa-engine';
import { createBrain,deserializeBrain,forward,serializeBrain } from '@/lib/neat';
import { mixRGB } from '@/lib/pheromone-grid';
import { BENCHMARK_SEEDS,runBenchmarks,trainChunked } from '@/lib/headless-sim';
export const dynamic='force-dynamic';
export const runtime='nodejs';
export const maxDuration=120;
const runtimeState=globalThis as typeof globalThis & {__formicaTraining?:boolean};
export async function GET(request:Request){
  try{
    await db.execute(sql`select 1`);
    if(new URL(request.url).searchParams.has('history')){
      const runs=await db.select({id:simulationExperiments.id,kind:simulationExperiments.kind,title:simulationExperiments.title,data:simulationExperiments.data,createdAt:simulationExperiments.createdAt}).from(simulationExperiments).orderBy(desc(simulationExperiments.createdAt)).limit(12);
      return Response.json({runs});
    }
    const soa=createSoA(4),outputs=new Float32Array(9);forward(createBrain(),new Float32Array(19),new Float32Array(16),outputs);
    const mix=mixRGB([30,40,10,5,5]),ablation=runBenchmarks(createBrain(),{steps:24,population:4,seeds:[7]});
    const ok=soa.x.length===4&&outputs.every(Number.isFinite)&&mix.every(v=>Number.isFinite(v)&&v>=0)&&ablation.length===9;
    return Response.json({ok,database:'connected',engine:'19-16-9 recurrent MLP',channels:5,capacity:5000,checks:{soa:true,forward:true,rgb:true,ablation:true}},{status:ok?200:500});
  }catch(error){console.error('Sanctuary health:',error);return Response.json({ok:false,error:'The observatory database is unavailable.'},{status:503});}
}
export async function POST(request:Request){
  let body:Record<string,unknown>;
  try{const value:unknown=await request.json();if(!value||typeof value!=='object'||Array.isArray(value))throw new Error('Invalid request');body=value as Record<string,unknown>;}catch{return Response.json({error:'Send a valid JSON experiment.'},{status:400});}
  const action=body.action;
  if(action!=='benchmark'&&action!=='train'&&action!=='snapshot')return Response.json({error:'Unknown experiment action.'},{status:400});
  let brain;
  try{brain=body.brain?deserializeBrain(body.brain):createBrain();}catch(error){return Response.json({error:error instanceof Error?error.message:'Invalid brain.'},{status:400});}
  if(action==='train'){
    if(runtimeState.__formicaTraining)return Response.json({error:'A training run is already in progress. Please try again shortly.'},{status:409});
    const generations=body.generations===10?10:5;runtimeState.__formicaTraining=true;
    const encoder=new TextEncoder();let disconnected=false;
    const stream=new ReadableStream<Uint8Array>({
      async start(controller){
        const send=(value:unknown)=>{if(!disconnected)controller.enqueue(encoder.encode(JSON.stringify(value)+'\n'));};
        try{
          const result=await trainChunked(brain,generations,point=>send({type:'progress',point}));
          const [saved]=await db.insert(simulationExperiments).values({kind:'training',title:`Shared brain · generation ${result.champion.generation}`,data:{learning:result.learning,brain:serializeBrain(result.champion),seeds:BENCHMARK_SEEDS}}).returning({id:simulationExperiments.id});
          send({type:'done',brain:serializeBrain(result.champion),learning:result.learning,id:saved.id});
        }catch(error){console.error('Training:',error);send({type:'error',error:'Training could not be saved. Your current brain is unchanged.'});}
        finally{runtimeState.__formicaTraining=false;if(!disconnected)controller.close();}
      },cancel(){disconnected=true;}
    });
    return new Response(stream,{headers:{'Content-Type':'application/x-ndjson','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
  }
  try{
    if(action==='benchmark'){
      const results=runBenchmarks(brain);
      const [saved]=await db.insert(simulationExperiments).values({kind:'benchmark',title:`Three-seed benchmark · generation ${brain.generation}`,data:{results,seeds:BENCHMARK_SEEDS,generation:brain.generation}}).returning({id:simulationExperiments.id});
      return Response.json({results,seeds:BENCHMARK_SEEDS,id:saved.id});
    }
    const settings=body.settings,telemetry=body.telemetry;
    if(!settings||typeof settings!=='object'||!telemetry||typeof telemetry!=='object')return Response.json({error:'A snapshot needs settings and live telemetry.'},{status:400});
    if(JSON.stringify(body).length>100000)return Response.json({error:'Snapshot is too large.'},{status:413});
    const [saved]=await db.insert(simulationExperiments).values({kind:'snapshot',title:'Sanctuary snapshot',data:{settings,telemetry,brain:serializeBrain(brain)}}).returning({id:simulationExperiments.id});
    return Response.json({id:saved.id,saved:true});
  }catch(error){console.error('Experiment:',error);return Response.json({error:'The experiment could not be saved. Please try again.'},{status:503});}
}
