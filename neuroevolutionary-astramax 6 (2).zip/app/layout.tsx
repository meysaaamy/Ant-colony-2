import type { Metadata } from 'next';
import { Fraunces, Plus_Jakarta_Sans } from 'next/font/google';
import './globals.css';

const fraunces = Fraunces({ subsets: ['latin'], variable: '--font-display', display: 'swap', weight: ['400', '500', '600'] });
const jakarta = Plus_Jakarta_Sans({ subsets: ['latin'], variable: '--font-sans', display: 'swap', weight: ['400', '500', '600', '700', '800'] });
export const metadata: Metadata = {
  title: 'Formica — A living intelligence',
  description: 'A bioluminescent ant colony sandbox. Shape pheromone trails, evolve a shared neural brain, and discover the intelligence of a swarm.',
  icons: { icon: '/logo.svg' }
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body className={`${fraunces.variable} ${jakarta.variable}`}>{children}</body></html>;
}
