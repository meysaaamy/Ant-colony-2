import { readFileSync,writeFileSync } from 'node:fs';
import { createBrain, serializeBrain } from '../lib/neat';
import { BENCHMARK_SEEDS, runBenchmarks, trainGenerations } from '../lib/headless-sim';
const generations=Math.max(1,Number(process.argv.find(a=>a.startsWith('--generations='))?.split('=')[1]??8));
console.log(`Formica offline evolution | 19–16–9 recurrent MLP | ${generations} generations | seeds ${BENCHMARK_SEEDS.join(', ')}`);
const result=trainGenerations(createBrain(),generations,{steps:900,population:36},point=>console.log(`Generation ${point.generation}: food ${point.trained.toFixed(2)} +/- ${point.std.toFixed(2)} | ACO ${point.aco.toFixed(2)} | Random ${point.random.toFixed(2)}`));
const results=runBenchmarks(result.champion);
console.table(results.map(r=>({policy:r.label,food:r.mean.toFixed(2),std:r.std.toFixed(2),change:`${(-r.drop).toFixed(1)}%`})));
const trained=results[0].mean,aco=results[1].mean,random=results[2].mean;
console.log(`Measured ordering: ${trained>aco&&aco>random?'Trained > ACO > Random':'see table; no ranking is assumed or fabricated.'}`);
console.log('Ablation effects are environment-dependent; zero and negative drops are retained.');
if(!process.argv.includes('--no-bake')){
  const json=serializeBrain(result.champion);
  const brainFile=readFileSync('lib/neat.ts','utf8').replace(/export const BAKED_CHAMPION: number\[\] = \[[^\n]*\];/,`export const BAKED_CHAMPION: number[] = ${JSON.stringify(json.weights.map(w=>Number(w.toFixed(7))))};`).replace(/export const BAKED_GENERATION = \d+;/,`export const BAKED_GENERATION = ${json.generation};`);
  writeFileSync('lib/neat.ts',brainFile);
  const evaluator=readFileSync('lib/headless-sim.ts','utf8').replace(/export const PRETRAINED_LEARNING: LearningPoint\[\] = \[[^\n]*\];/,`export const PRETRAINED_LEARNING: LearningPoint[] = ${JSON.stringify(result.learning)};`);
  writeFileSync('lib/headless-sim.ts',evaluator);
  console.log('Baked the measured champion and learning curve into source.');
}
