export default {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: { extend: { borderRadius: { sm: '12px', md: '20px', lg: '28px' }, transitionTimingFunction: { sanctuary: 'cubic-bezier(0.2, 0.8, 0.2, 1)' } } }
};
