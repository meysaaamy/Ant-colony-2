# Prismatic Formicarium

A mobile-first, 3,000-ant neuroevolution sandbox built with Next.js (App Router), TypeScript (no `any`), Tailwind CSS and Canvas 2D. A single **shared colony brain** (a fixed-topology recurrent MLP, 19 inputs → 16 tanh → 9 outputs) drives every trained ant. It was evolved offline from random weights and baked into `src/lib/neat.ts`, so the app starts with a brain whose performance has been measured.

## Run

```bash
npm install
npm run dev                 # app
npx vitest run              # simulation test suite
npx tsx scripts/train.ts --gens 28 --pop 16 --seeds 2 --ticks 900 --bake   # re-evolve + bake champion
npx tsx scripts/train.ts --bench-only                                      # multi-seed A/B + ablation of baked brain
```

`GET /api/health` checks SoA allocation, the brain forward pass, the 5-channel RGB mixer and a small headless ablation, and returns `200` when all pass.

## Architecture (`src/` maps to the requested `app/`, `lib/`, `components/`)

| File | Role |
| --- | --- |
| `lib/types.ts` | SoA interfaces, 5 channels, states, castes, policies, brain, benchmark and telemetry types |
| `lib/prng-noise.ts` | Mulberry32, XorShift32, 2D Simplex + fBm |
| `lib/pheromone-grid.ts` | 5 ping-pong `Float32Array` channels (cell 6px), strict CFL 3x3 diffusion with zero-flux Neumann walls, per-channel evaporation (alarm 3.2x faster), food+home polymer (35% slower decay), noEntry dissolving foodTrail (`0.45*C*dt`), spectral RGB mixer, ablation masks, Catmull-Rom brush (`0.25 r`) |
| `lib/ant-soa-engine.ts` | 3,000-slot SoA, `Int32Array` spatial hash (24px), shared-brain forward pass, hand-crafted ACO and random-MLP baselines, mortality, necrophoresis, births and generations, founder bottleneck, trophallaxis, tandem running, dead-end and depleted-site sealing, Abyssal Stalker predators with alarm cascade |
| `lib/neat.ts` | Recurrent MLP, elitism, tournament selection, neuron-level crossover, self-adaptive Gaussian mutation, optional NEAT speciation and hidden-unit growth, JSON import/export, **baked champion + learning curve** |
| `lib/headless-sim.ts` | Headless episodes, fitness, multi-seed benchmark and ablation, time-sliced in-app trainer and benchmark |
| `lib/presets.ts` | Open Sanctuary, Deneubourg's Double Bridge, Subterranean Labyrinth |
| `lib/procedural-assets.ts` | Veined soil, terraced basalt with bioluminescent rims, 2 ant atlases (8 frames x 4 rows, 2x), predator, 8 crystal variants, husk, glow sprites, vignette + grain |
| `lib/renderer.ts` | 10-layer zero-blur compositor plus adaptive scaler |

## Shared Colony Brain I/O

**Inputs (19).** These are grouped as follows:
- 5 bilateral gradients `log(1+C_R) - log(1+C_L)`, one per channel (foodTrail, homeGuide, alarm, scoutPulse, noEntry).
- 5 centre concentrations.
- 3 wall raycasts.
- 2 egocentric path-integration components (`homeDx`, `homeDy`).
- carrying flag, energy, and recurrent `memA` and `memB`.

**Outputs (9).** These are steer torque, speed, 5 secretion rates and the 2 next memory states.

Fitness rewards food delivered, pickups, path efficiency (straight distance divided by distance walked), trophallaxis, defence and predator kills. It penalises wall scraping, saturated looping, starvation and deaths.

## Measured results (baked champion, seeds 7/21/42, 900 ticks, 64 ants, 1 predator)

Evolution started from **pure random initialisation** (`--prior 0`). The champion delivered 12.7 food at generation 0 and about 30 by generations 17–27.

| Condition | Food delivered (mean ± std) |
| --- | --- |
| Full Trained Brain | **29.0 ± 0.8** |
| Hand-Crafted ACO | 23.3 ± 7.4 |
| Random Brain | 1.0 ± 0.8 |
| −PathIntegration | 0.7 ± 0.5 (−98%) |
| −noEntry | 8.3 ± 1.9 (−71%) |
| −homeGuide | 16.0 ± 3.7 (−45%) |
| −scoutPulse | 27.3 ± 1.9 (−6%) |
| −foodTrail | 29.3 ± 0.5 (no drop) |
| −alarm | 30.0 ± 2.2 (no drop) |

How to read the ablations:
- The evolved policy depends on path integration, on noEntry (it uses it to avoid stale and depleted routes) and on homeGuide.
- It does **not** depend on foodTrail recruitment in this benchmark world. This is a real finding of the evolved strategy, not a rendering artefact.
- Alarm only matters through the innate flee and defend reflex. With one predator, that reflex does not change delivery.

Re-run `scripts/train.ts` with more generations, or with predators in the training world, to explore other strategies.

## UI

- **Top HUD.** Shows the FPS dot, alive and dead counts, food, a `GEN` badge, the A/B live score, the speed chip and play/pause.
- **Bottom cockpit.** A peek card with quick pills (Train +5 Gen, A/B vs Random, Predator Threat), Clear trails and a 2-tap Reset. It expands into a 3-snap sheet (a 390px side panel on desktop) with tabs for Proof of Learning, Colony & Threats, Pheromone Alchemy, Brush and World.
- **Tools.** Contextual pheromone and predator pills sit above a 6-tool jewel dock.
- **Shortcuts.** `1-6` select tools, `Space` pauses, `[`/`]` change the brush radius, `Esc` closes panels.
- **Saved settings.** Settings, in-app trained brains and training history are stored safely in `localStorage`.
