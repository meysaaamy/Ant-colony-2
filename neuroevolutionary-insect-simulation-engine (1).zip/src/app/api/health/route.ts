import { AntEngine } from "@/lib/ant-soa-engine";
import { runBenchmarkSync, sharedRandomBrain } from "@/lib/headless-sim";
import { createChampionBrain, forwardBrain, hasBakedChampion } from "@/lib/neat";
import { PheromoneGrid } from "@/lib/pheromone-grid";
import { getPreset } from "@/lib/presets";
import { BRAIN_HIDDEN, BRAIN_INPUTS, BRAIN_OUTPUTS, MAX_ANTS, defaultSimConfig } from "@/lib/types";

export const dynamic = "force-dynamic";

export async function GET() {
  const checks: Record<string, boolean | number | string> = {};
  try {
    // 1. SoA engine allocation + a few ticks
    const cfg = defaultSimConfig(720, 1280);
    cfg.initialAnts = 300;
    const brain = createChampionBrain();
    const engine = new AntEngine(cfg, brain, sharedRandomBrain(), getPreset("open-sanctuary").build(720, 1280, 1));
    for (let t = 0; t < 30; t++) engine.step();
    checks.soaCapacity = engine.ants.x.length;
    checks.soa = engine.ants.x.length === MAX_ANTS && engine.alive > 0 && Number.isFinite(engine.ants.x[0]);

    // 2. shared brain forward pass
    const input = new Float32Array(BRAIN_INPUTS).fill(0.1);
    const out = new Float32Array(BRAIN_OUTPUTS);
    forwardBrain(brain, input, out, new Float32Array(BRAIN_HIDDEN));
    checks.forwardPass = out.every((v) => Number.isFinite(v)) && out[1] >= 0 && out[1] <= 1;
    checks.bakedChampion = hasBakedChampion();

    // 3. 5-channel RGB mixer: food+home should synthesise a bright pearl/turquoise core
    const grid = new PheromoneGrid(60, 60);
    const [r, g, b] = grid.mixSample([70, 70, 0, 0, 0]);
    checks.rgbMix = `${r},${g},${b}`;
    checks.rgbMixOk = r > 200 && g > 200 && b > 150;

    // 4. tiny headless ablation
    const rep = runBenchmarkSync(brain, [3], 150, ["trained", "-foodTrail"]);
    checks.ablation = rep.results.map((x) => `${x.condition}:${x.mean}`).join(",");
    checks.ablationOk = rep.results.length === 2;

    const ok = checks.soa === true && checks.forwardPass === true && checks.rgbMixOk === true && checks.ablationOk === true;
    return Response.json({ ok, checks }, { status: ok ? 200 : 500 });
  } catch (err) {
    return Response.json({ ok: false, checks, error: err instanceof Error ? err.message : "unknown" }, { status: 500 });
  }
}
