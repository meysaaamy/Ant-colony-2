"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import SanctuaryCanvas, { DEFAULT_PARAMS, safeGet, safeSet, SimController, type SimParams, type SimSnapshot, type ToastTone } from "@/components/SanctuaryCanvas";
import TelemetryPill from "@/components/TelemetryPill";
import FloatingToolDock, { TOOL_ORDER } from "@/components/FloatingToolDock";
import ParameterSheet from "@/components/ParameterSheet";
import FieldGuideModal from "@/components/FieldGuideModal";
import ToastOverlay, { type ToastItem } from "@/components/ToastOverlay";
import { GENOME_SIZE } from "@/lib/neat";
import { defaultAblation, type AblationMask, type AlarmSubMode, type ArenaMode, type PresetId, type SheetSnap, type SheetTab, type ToolId } from "@/lib/types";

const LS_SETTINGS = "pf.settings.v1";
const LS_ONBOARD = "pf.onboarded.v1";
const PRESET_IDS: readonly PresetId[] = ["open-sanctuary", "double-bridge", "labyrinth"];
const ALARM_MODES: readonly AlarmSubMode[] = ["alarm", "scout", "noentry", "predator"];

interface StoredSettings {
  tool: ToolId;
  alarmMode: AlarmSubMode;
  radius: number;
  speed: 1 | 2 | 4;
  preset: PresetId;
  params: SimParams;
}

function num(v: unknown, lo: number, hi: number, d: number): number {
  return typeof v === "number" && Number.isFinite(v) ? Math.min(hi, Math.max(lo, v)) : d;
}

function loadSettings(): StoredSettings {
  const base: StoredSettings = { tool: "food-trail", alarmMode: "alarm", radius: 18, speed: 1, preset: "open-sanctuary", params: { ...DEFAULT_PARAMS } };
  const raw = safeGet(LS_SETTINGS);
  if (!raw) return base;
  try {
    const d: unknown = JSON.parse(raw);
    if (typeof d !== "object" || d === null) return base;
    const r = d as Record<string, unknown>;
    const tool = TOOL_ORDER.find((t) => t === r.tool) ?? base.tool;
    const alarmMode = ALARM_MODES.find((m) => m === r.alarmMode) ?? base.alarmMode;
    const preset = PRESET_IDS.find((p) => p === r.preset) ?? base.preset;
    const speed = r.speed === 2 ? 2 : r.speed === 4 ? 4 : 1;
    const pr = (typeof r.params === "object" && r.params !== null ? r.params : {}) as Record<string, unknown>;
    const D = DEFAULT_PARAMS;
    return {
      tool,
      alarmMode,
      preset,
      speed,
      radius: num(r.radius, 6, 60, 18),
      params: {
        maxPop: num(pr.maxPop, 100, 3000, D.maxPop),
        predatorCount: num(pr.predatorCount, 0, 6, D.predatorCount),
        atpBurn: num(pr.atpBurn, 0.25, 3, D.atpBurn),
        lifespanScale: num(pr.lifespanScale, 0.25, 3, D.lifespanScale),
        evaporation: num(pr.evaporation, 0.01, 0.3, D.evaporation),
        diffusion: num(pr.diffusion, 0, 1, D.diffusion),
        reactionRate: num(pr.reactionRate, 0, 2, D.reactionRate),
      },
    };
  } catch {
    return base;
  }
}

export default function Home() {
  const [ctrl, setCtrl] = useState<SimController | null>(null);
  const [snap, setSnap] = useState<SimSnapshot | null>(null);
  const [tool, setTool] = useState<ToolId>("food-trail");
  const [alarmMode, setAlarmMode] = useState<AlarmSubMode>("alarm");
  const [radius, setRadius] = useState(18);
  const [speed, setSpeed] = useState<1 | 2 | 4>(1);
  const [preset, setPreset] = useState<PresetId>("open-sanctuary");
  const [params, setParams] = useState<SimParams>(DEFAULT_PARAMS);
  const [ablation, setAblation] = useState<AblationMask>(defaultAblation());
  const [sheet, setSheet] = useState<SheetSnap>("peek");
  const [tab, setTab] = useState<SheetTab>("proof");
  const [guide, setGuide] = useState(false);
  const [dim, setDim] = useState(false);
  const [ghost, setGhost] = useState(false);
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const [weights, setWeights] = useState<Float32Array>(() => new Float32Array(GENOME_SIZE));
  const dimTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const toastId = useRef(0);
  const weightsRef = useRef<Float32Array | null>(null);

  const toast = useCallback((msg: string, tone: ToastTone = "info") => {
    const id = ++toastId.current;
    setToasts((t) => [...t.slice(-2), { id, msg, tone }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3200);
  }, []);

  useEffect(() => {
    const s = loadSettings();
    const c = new SimController(window.innerHeight >= window.innerWidth);
    c.tool = s.tool;
    c.alarmMode = s.alarmMode;
    c.brushRadius = s.radius;
    c.speed = s.speed;
    c.setParams(s.params);
    if (s.preset !== "open-sanctuary") c.loadPreset(s.preset);
    else c.reset();
    c.listener = (sn) => {
      setSnap(sn);
      if (weightsRef.current !== c.brain.weights) {
        weightsRef.current = c.brain.weights;
        setWeights(c.brain.weights);
      }
    };
    c.toaster = toast;
    c.onFirstStroke = () => {
      setGhost(false);
      safeSet(LS_ONBOARD, "1");
    };
    setTool(s.tool);
    setAlarmMode(s.alarmMode);
    setRadius(s.radius);
    setSpeed(s.speed);
    setPreset(s.preset);
    setParams(s.params);
    setCtrl(c);
    let t: ReturnType<typeof setTimeout> | null = null;
    if (!safeGet(LS_ONBOARD)) {
      setGhost(true);
      t = setTimeout(() => toast("Draw an amber trail from the nest toward a crystal", "info"), 700);
    }
    return () => {
      if (t) clearTimeout(t);
      c.listener = null;
      c.toaster = null;
    };
  }, [toast]);

  useEffect(() => {
    if (!ctrl) return;
    safeSet(LS_SETTINGS, JSON.stringify({ tool, alarmMode, radius, speed, preset, params }));
  }, [ctrl, tool, alarmMode, radius, speed, preset, params]);

  const chooseTool = useCallback(
    (t: ToolId) => {
      setTool(t);
      if (ctrl) ctrl.tool = t;
    },
    [ctrl],
  );
  const chooseAlarm = useCallback(
    (m: AlarmSubMode) => {
      setAlarmMode(m);
      if (ctrl) ctrl.alarmMode = m;
    },
    [ctrl],
  );
  const chooseRadius = useCallback(
    (r: number) => {
      const v = Math.min(60, Math.max(6, r));
      setRadius(v);
      if (ctrl) ctrl.brushRadius = v;
    },
    [ctrl],
  );
  const togglePause = useCallback(() => {
    if (!ctrl) return;
    ctrl.autoPaused = false;
    ctrl.setPaused(!ctrl.paused);
  }, [ctrl]);
  const cycleSpeed = useCallback(() => {
    const next: 1 | 2 | 4 = speed === 1 ? 2 : speed === 2 ? 4 : 1;
    setSpeed(next);
    if (ctrl) ctrl.speed = next;
  }, [ctrl, speed]);

  const onPointerActive = useCallback((active: boolean) => {
    if (dimTimer.current) clearTimeout(dimTimer.current);
    if (active) setDim(true);
    else dimTimer.current = setTimeout(() => setDim(false), 200);
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const el = e.target as HTMLElement | null;
      if (el && (el.tagName === "INPUT" || el.tagName === "TEXTAREA")) return;
      if (e.key >= "1" && e.key <= "6") chooseTool(TOOL_ORDER[Number(e.key) - 1]);
      else if (e.key === " ") {
        e.preventDefault();
        togglePause();
      } else if (e.key === "[") chooseRadius(radius - 2);
      else if (e.key === "]") chooseRadius(radius + 2);
      else if (e.key === "Escape") {
        setGuide(false);
        setSheet("peek");
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [chooseTool, chooseRadius, togglePause, radius]);

  const exportBrain = () => {
    if (!ctrl) return;
    const blob = new Blob([ctrl.exportBrain()], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "colony-brain.json";
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    toast("Colony brain exported as JSON", "success");
  };

  return (
    <main className="relative h-[100dvh] w-full overflow-hidden bg-[#020307]">
      {ctrl ? <SanctuaryCanvas controller={ctrl} onPointerActive={onPointerActive} /> : null}

      <div className="ui-layer" data-dim={dim ? "true" : "false"}>
        <TelemetryPill
          snap={snap}
          speed={speed}
          paused={snap?.paused ?? false}
          onTogglePause={togglePause}
          onCycleSpeed={cycleSpeed}
          onOpenGuide={() => setGuide(true)}
          onOpenSheet={() => setSheet((s) => (s === "peek" ? "half" : "peek"))}
        />
        <div className="pointer-events-none fixed inset-x-0 bottom-0 z-20 flex flex-col items-center gap-2 px-3 pb-[max(12px,env(safe-area-inset-bottom))]">
          {ctrl ? (
            <ParameterSheet
              snap={snap}
              snapState={sheet}
              onSnap={setSheet}
              tab={tab}
              onTab={setTab}
              presetId={preset}
              onPreset={(id) => {
                setPreset(id);
                ctrl.loadPreset(id);
                toast(`World: ${id === "open-sanctuary" ? "Open Sanctuary" : id === "double-bridge" ? "Deneubourg's Double Bridge" : "Subterranean Labyrinth"}`, "info");
              }}
              params={params}
              onParams={(p) => {
                setParams(p);
                ctrl.setParams(p);
              }}
              ablation={ablation}
              onAblation={(m) => {
                setAblation(m);
                ctrl.setAblation(m);
              }}
              brushRadius={radius}
              onBrushRadius={chooseRadius}
              weights={weights}
              worldW={ctrl.worldW}
              worldH={ctrl.worldH}
              onTrain={(n) => ctrl.train(n)}
              onBenchmark={() => ctrl.runBenchmark()}
              onArena={(m: ArenaMode) => ctrl.setArena(m)}
              onClearTrails={() => {
                ctrl.clearTrails();
                toast("Trails cleared", "info");
              }}
              onReset={() => {
                ctrl.reset();
                toast("Colony reset", "warn");
              }}
              onSpawnPredator={() => {
                if (ctrl.spawnPredator()) toast("Abyssal Stalker incoming", "warn");
              }}
              onExport={exportBrain}
              onImport={(json) => {
                const ok = ctrl.importBrain(json);
                toast(ok ? "Brain imported and active" : "Invalid brain JSON", ok ? "success" : "warn");
              }}
              onRestore={() => {
                ctrl.restoreChampion();
                toast("Baked champion restored", "success");
              }}
            />
          ) : null}
          <div className="pointer-events-auto">
            <FloatingToolDock tool={tool} alarmMode={alarmMode} radius={radius} onTool={chooseTool} onAlarmMode={chooseAlarm} onRadius={chooseRadius} />
          </div>
        </div>
      </div>

      <ToastOverlay toasts={toasts} />
      <FieldGuideModal open={guide} onClose={() => setGuide(false)} />

      {ghost ? (
        <svg className="pointer-events-none fixed inset-0 z-10 h-full w-full" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
          <path className="ghost-stroke" d="M50 62 C 44 52, 30 44, 24 26" fill="none" stroke="rgba(255,168,0,0.85)" strokeWidth="0.8" strokeLinecap="round" vectorEffect="non-scaling-stroke" />
        </svg>
      ) : null}

      <div className="splash pointer-events-none fixed inset-0 z-[60] flex flex-col items-center justify-center gap-3 bg-[#020307]">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/logo.svg" alt="" width={72} height={72} />
        <p className="font-display text-xl text-slate-100">Prismatic Formicarium</p>
      </div>
    </main>
  );
}
