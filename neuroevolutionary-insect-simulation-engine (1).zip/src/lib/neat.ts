/*
 * Shared Colony Brain: Fixed-Topology Recurrent MLP (19 -> 16 tanh -> 9) + neuroevolution.
 * Elitism, tournament selection, neuron-level crossover, self-adaptive Gaussian mutation,
 * optional NEAT-style speciation (fitness sharing) and hidden-unit topology growth.
 * Recurrence: outputs 7/8 (nextMemA/B) are fed back as inputs 17/18 on the next think tick.
 */
import { Mulberry32 } from "./prng-noise";
import {
  BRAIN_HIDDEN as NH,
  BRAIN_INPUTS as NI,
  BRAIN_OUTPUTS as NO,
  type Brain,
  type BrainJSON,
  type EvolutionParams,
  type Genome,
  type TrainingPoint,
} from "./types";

export const OFF_W1 = 0;
export const OFF_B1 = NH * NI;
export const OFF_W2 = OFF_B1 + NH;
export const OFF_B2 = OFF_W2 + NO * NH;
export const GENOME_SIZE = OFF_B2 + NO;

/* input layout */
export const IN_GRAD = 0; // 0..4 bilateral gradients (S_right - S_left), Weber-Fechner log(1+C)
export const IN_CENTER = 5; // 5..9 centre concentration
export const IN_WALL_L = 10;
export const IN_WALL_C = 11;
export const IN_WALL_R = 12;
export const IN_HOME_X = 13;
export const IN_HOME_Y = 14;
export const IN_CARRY = 15;
export const IN_ENERGY = 16;
export const IN_MEM_A = 17;
export const IN_MEM_B = 18;

/* output layout */
export const OUT_STEER = 0;
export const OUT_SPEED = 1;
export const OUT_EMIT = 2; // 2..6 emitFood, emitHome, emitAlarm, emitScout, emitNoEntry
export const OUT_MEM_A = 7;
export const OUT_MEM_B = 8;

export const INPUT_LABELS: readonly string[] = [
  "dFood", "dHome", "dAlarm", "dScout", "dNoEnt",
  "cFood", "cHome", "cAlarm", "cScout", "cNoEnt",
  "wallL", "wallC", "wallR", "homeX", "homeY", "carry", "ATP", "memA", "memB",
];
export const OUTPUT_LABELS: readonly string[] = ["steer", "speed", "eFood", "eHome", "eAlarm", "eScout", "eNoEnt", "memA'", "memB'"];

/** Pade-approximant tanh (|err| < 1e-4), branch-clamped. */
export function ftanh(x: number): number {
  if (x < -4.9) return -1;
  if (x > 4.9) return 1;
  const x2 = x * x;
  return (x * (135135 + x2 * (17325 + x2 * (378 + x2)))) / (135135 + x2 * (62370 + x2 * (3150 + x2 * 28)));
}

export function fsigmoid(x: number): number {
  return 0.5 * (ftanh(0.5 * x) + 1);
}

/** Zero-allocation forward pass. */
export function forwardBrain(brain: Brain, input: Float32Array, out: Float32Array, hidden: Float32Array): void {
  const w = brain.weights;
  const en = brain.enabled;
  for (let h = 0; h < NH; h++) {
    if (en[h] === 0) {
      hidden[h] = 0;
      continue;
    }
    let s = w[OFF_B1 + h];
    const row = OFF_W1 + h * NI;
    for (let i = 0; i < NI; i++) s += w[row + i] * input[i];
    hidden[h] = ftanh(s);
  }
  for (let o = 0; o < NO; o++) {
    let s = w[OFF_B2 + o];
    const row = OFF_W2 + o * NH;
    for (let h = 0; h < NH; h++) s += w[row + h] * hidden[h];
    out[o] = o === OUT_STEER || o >= OUT_MEM_A ? ftanh(s) : fsigmoid(s);
  }
}

export function createBrain(weights?: ArrayLike<number>, enabled?: ArrayLike<number>): Brain {
  const w = new Float32Array(GENOME_SIZE);
  if (weights) for (let i = 0; i < GENOME_SIZE && i < weights.length; i++) w[i] = weights[i];
  const e = new Uint8Array(NH).fill(1);
  if (enabled) for (let i = 0; i < NH && i < enabled.length; i++) e[i] = enabled[i] ? 1 : 0;
  return { weights: w, hidden: NH, enabled: e };
}

export function cloneBrain(b: Brain): Brain {
  return { weights: new Float32Array(b.weights), hidden: b.hidden, enabled: new Uint8Array(b.enabled) };
}

export function randomWeights(rng: Mulberry32, gain = 1): Float32Array {
  const w = new Float32Array(GENOME_SIZE);
  const s1 = gain / Math.sqrt(NI);
  const s2 = gain / Math.sqrt(NH);
  for (let i = OFF_W1; i < OFF_B1; i++) w[i] = rng.gauss() * s1 * 1.6;
  for (let i = OFF_B1; i < OFF_W2; i++) w[i] = rng.gauss() * 0.3 * gain;
  for (let i = OFF_W2; i < OFF_B2; i++) w[i] = rng.gauss() * s2 * 1.6;
  for (let i = OFF_B2; i < GENOME_SIZE; i++) w[i] = rng.gauss() * 0.3 * gain;
  return w;
}

export function createRandomBrain(seed: number): Brain {
  return createBrain(randomWeights(new Mulberry32(seed), 1.6));
}

/** Hand-wired innate reflex prior (optional evolutionary seed, documented as such). */
export function createInnatePrior(): Brain {
  const b = createBrain();
  const w = b.weights;
  const set = (h: number, i: number, v: number) => {
    w[OFF_W1 + h * NI + i] = v;
  };
  const out = (o: number, h: number, v: number) => {
    w[OFF_W2 + o * NH + h] = v;
  };
  const G = 3;
  // h0/h1: food gradient when NOT carrying (carry = -1)
  set(0, IN_GRAD + 0, 2.2);
  set(0, IN_CARRY, -G);
  w[OFF_B1 + 0] = -G;
  set(1, IN_GRAD + 0, -2.2);
  set(1, IN_CARRY, -G);
  w[OFF_B1 + 1] = -G;
  out(OUT_STEER, 0, 1.1);
  out(OUT_STEER, 1, -1.1);
  // h2/h3: path-integration bearing when carrying
  set(2, IN_HOME_Y, 2.4);
  set(2, IN_CARRY, G);
  w[OFF_B1 + 2] = -G;
  set(3, IN_HOME_Y, -2.4);
  set(3, IN_CARRY, G);
  w[OFF_B1 + 3] = -G;
  out(OUT_STEER, 2, 1.3);
  out(OUT_STEER, 3, -1.3);
  // h4: wall avoidance
  set(4, IN_WALL_R, 2);
  set(4, IN_WALL_L, -2);
  out(OUT_STEER, 4, -1.4);
  // h5: carry detector -> emissions
  set(5, IN_CARRY, 2.5);
  out(OUT_EMIT + 0, 5, 4);
  out(OUT_EMIT + 1, 5, -4);
  w[OFF_B2 + OUT_SPEED] = 2;
  w[OFF_B2 + OUT_EMIT + 2] = -4;
  w[OFF_B2 + OUT_EMIT + 3] = -3;
  w[OFF_B2 + OUT_EMIT + 4] = -4;
  return b;
}

export function brainToJSON(b: Brain, meta?: BrainJSON["meta"]): BrainJSON {
  return {
    format: "prismatic-colony-brain",
    version: 1,
    inputs: NI,
    hidden: NH,
    outputs: NO,
    weights: Array.from(b.weights, (v) => Math.round(v * 1e5) / 1e5),
    enabled: Array.from(b.enabled),
    meta,
  };
}

export function exportBrainJSON(b: Brain, meta?: BrainJSON["meta"]): string {
  return JSON.stringify(brainToJSON(b, meta));
}

function isRecord(v: unknown): v is Record<string, unknown> {
  return typeof v === "object" && v !== null;
}

/** Validating import; returns null on any shape mismatch. */
export function brainFromJSON(src: unknown): Brain | null {
  let data: unknown = src;
  if (typeof src === "string") {
    try {
      data = JSON.parse(src) as unknown;
    } catch {
      return null;
    }
  }
  if (!isRecord(data)) return null;
  if (data.format !== "prismatic-colony-brain" || data.inputs !== NI || data.hidden !== NH || data.outputs !== NO) return null;
  const weights = data.weights;
  if (!Array.isArray(weights) || weights.length !== GENOME_SIZE) return null;
  const nums: number[] = [];
  for (const v of weights) {
    if (typeof v !== "number" || !Number.isFinite(v)) return null;
    nums.push(v);
  }
  const en: number[] = [];
  if (Array.isArray(data.enabled)) for (const v of data.enabled) en.push(v === 0 ? 0 : 1);
  return createBrain(nums, en.length === NH ? en : undefined);
}

export const DEFAULT_EVOLUTION: EvolutionParams = {
  populationSize: 20,
  eliteCount: 2,
  tournamentSize: 3,
  mutationRate: 0.14,
  initialSigma: 0.32,
  crossoverRate: 0.6,
  useSpeciation: false,
  compatibilityThreshold: 0.55,
};

export class NeuroEvolution {
  readonly params: EvolutionParams;
  population: Genome[] = [];
  generation = 0;
  best: Genome | null = null;
  mutationBoost = 1;
  private rng: Mulberry32;
  private nextId = 1;
  private representatives: Genome[] = [];

  constructor(params: EvolutionParams, seed: number, seedBrain?: Brain, seedFraction = 0) {
    this.params = params;
    this.rng = new Mulberry32(seed);
    const n = params.populationSize;
    const seeded = seedBrain ? Math.max(1, Math.round(n * seedFraction)) : 0;
    for (let k = 0; k < n; k++) {
      let g: Genome;
      if (seedBrain && k < seeded) {
        g = this.makeGenome(new Float32Array(seedBrain.weights), new Uint8Array(seedBrain.enabled));
        if (k > 0) this.mutate(g, 1);
      } else {
        const en = new Uint8Array(NH).fill(1);
        if (params.useSpeciation) for (let h = 8; h < NH; h++) en[h] = this.rng.next() < 0.3 ? 1 : 0;
        g = this.makeGenome(randomWeights(this.rng, 1.6), en);
      }
      this.population.push(g);
    }
  }

  private makeGenome(weights: Float32Array, enabled: Uint8Array): Genome {
    return { id: this.nextId++, weights, enabled, sigma: this.params.initialSigma, fitness: 0, species: 0 };
  }

  brainOf(g: Genome): Brain {
    return { weights: g.weights, hidden: NH, enabled: g.enabled };
  }

  private distance(a: Genome, b: Genome): number {
    let d = 0;
    for (let i = 0; i < GENOME_SIZE; i++) d += Math.abs(a.weights[i] - b.weights[i]);
    let topo = 0;
    for (let h = 0; h < NH; h++) if (a.enabled[h] !== b.enabled[h]) topo++;
    return d / GENOME_SIZE + (0.5 * topo) / NH;
  }

  private speciate(): Map<number, number> {
    const sizes = new Map<number, number>();
    const reps = this.representatives;
    for (const g of this.population) {
      let assigned = -1;
      for (let r = 0; r < reps.length; r++) {
        if (this.distance(g, reps[r]) < this.params.compatibilityThreshold) {
          assigned = r;
          break;
        }
      }
      if (assigned < 0) {
        reps.push(g);
        assigned = reps.length - 1;
      }
      g.species = assigned;
      sizes.set(assigned, (sizes.get(assigned) ?? 0) + 1);
    }
    return sizes;
  }

  private tournament(pool: Genome[], score: (g: Genome) => number): Genome {
    let best = pool[this.rng.int(pool.length)];
    for (let k = 1; k < this.params.tournamentSize; k++) {
      const c = pool[this.rng.int(pool.length)];
      if (score(c) > score(best)) best = c;
    }
    return best;
  }

  /** Neuron-level crossover keeps each hidden unit's fan-in and fan-out together. */
  private crossover(a: Genome, b: Genome): Genome {
    const w = new Float32Array(GENOME_SIZE);
    const en = new Uint8Array(NH);
    for (let h = 0; h < NH; h++) {
      const p = this.rng.next() < 0.5 ? a : b;
      for (let i = 0; i < NI; i++) w[OFF_W1 + h * NI + i] = p.weights[OFF_W1 + h * NI + i];
      w[OFF_B1 + h] = p.weights[OFF_B1 + h];
      for (let o = 0; o < NO; o++) w[OFF_W2 + o * NH + h] = p.weights[OFF_W2 + o * NH + h];
      en[h] = p.enabled[h];
    }
    for (let o = 0; o < NO; o++) w[OFF_B2 + o] = (this.rng.next() < 0.5 ? a : b).weights[OFF_B2 + o];
    const g = this.makeGenome(w, en);
    g.sigma = Math.sqrt(a.sigma * b.sigma);
    return g;
  }

  private mutate(g: Genome, boost: number): void {
    g.sigma = Math.min(0.9, Math.max(0.03, g.sigma * Math.exp(0.22 * this.rng.gauss())));
    const s = g.sigma * boost;
    const rate = Math.min(0.6, this.params.mutationRate * (boost > 1 ? 1.5 : 1));
    for (let i = 0; i < GENOME_SIZE; i++) {
      const r = this.rng.next();
      if (r < rate) {
        let v = g.weights[i] + this.rng.gauss() * s;
        if (v > 8) v = 8;
        else if (v < -8) v = -8;
        g.weights[i] = v;
      } else if (r > 0.9985) {
        g.weights[i] = this.rng.gauss() * 0.8;
      }
    }
    if (this.params.useSpeciation) {
      if (this.rng.next() < 0.06) {
        const h = this.rng.int(NH);
        if (g.enabled[h] === 0) {
          g.enabled[h] = 1;
          for (let i = 0; i < NI; i++) g.weights[OFF_W1 + h * NI + i] = this.rng.gauss() * 0.3;
        }
      }
      if (this.rng.next() < 0.01) g.enabled[this.rng.int(NH)] = 0;
    }
  }

  /** Produce the next generation; call after every genome has a fitness. */
  evolve(): void {
    const pop = this.population;
    pop.sort((a, b) => b.fitness - a.fitness);
    if (!this.best || pop[0].fitness >= this.best.fitness || this.generation === 0) {
      this.best = { ...pop[0], weights: new Float32Array(pop[0].weights), enabled: new Uint8Array(pop[0].enabled) };
    }
    let score = (g: Genome): number => g.fitness;
    if (this.params.useSpeciation) {
      this.representatives = [];
      const sizes = this.speciate();
      score = (g: Genome) => g.fitness / Math.max(1, sizes.get(g.species) ?? 1);
    }
    const next: Genome[] = [];
    for (let e = 0; e < this.params.eliteCount && e < pop.length; e++) {
      const el = this.makeGenome(new Float32Array(pop[e].weights), new Uint8Array(pop[e].enabled));
      el.sigma = pop[e].sigma;
      next.push(el);
    }
    const parentPool = pop.slice(0, Math.max(2, Math.ceil(pop.length * 0.6)));
    while (next.length < this.params.populationSize) {
      const a = this.tournament(parentPool, score);
      let child: Genome;
      if (this.rng.next() < this.params.crossoverRate) {
        const b = this.tournament(parentPool, score);
        child = this.crossover(a, b);
      } else {
        child = this.makeGenome(new Float32Array(a.weights), new Uint8Array(a.enabled));
        child.sigma = a.sigma;
      }
      this.mutate(child, this.mutationBoost);
      next.push(child);
    }
    this.population = next;
    this.generation++;
  }
}

/* ============================ BAKED CHAMPION ============================
 * Replaced in place by `npx tsx scripts/train.ts --bake`. Do not edit by hand.
 */
// <CHAMPION-BEGIN>
export const CHAMPION_WEIGHTS: readonly number[] = [
  0.5569, -0.5078, 1.7706, 0.1175, -0.3032, -1.5386, -0.6289, 0.5547, -0.391, 0.0498, 0.4288, 1.41, 0.2319, -0.4245, 0.9112, -0.5344,
  -0.5502, -0.4551, 0.8271, 0.3422, -0.9348, 0.1314, 0.699, 0.4913, -0.201, -1.3368, -0.4223, 0.4074, -0.2668, -0.9477, 0.2429, 0.0713,
  -0.4225, -0.0508, -0.0368, 0.2494, -1.3466, -1.034, -0.4613, 0.0799, -0.3337, -1.0848, -0.4045, 0.1582, 1.4229, -0.859, -0.404, 0.0682,
  0.6323, 0.8146, -0.374, -0.8215, -0.3011, 0.7554, 1.1258, -0.0565, -1.1957, 0.9822, 0.0192, 0.4233, -0.1076, 0.9402, 0.2088, 0.1623,
  -0.6074, 0.354, 0.8503, 1.1126, -0.2764, 0.7332, 0.75, -0.0967, 0.164, -1.707, 0.8892, -0.6396, 0.1863, 0.8976, -0.2959, 0.8201,
  0.3001, 0.0853, -0.2078, -1.7901, -0.0855, 0.5141, -0.3396, -0.3295, -0.0983, -0.3281, -0.6302, 0.6508, -0.3083, -0.6734, -0.3792, -0.12,
  -0.5623, -1.1005, -0.3905, -1.0353, -0.6475, 0.2455, -0.6749, -0.7116, -0.0674, 0.4012, -0.4178, -0.6469, 0.2512, 0.1327, 0.9392, 0.2786,
  -1.0125, 0.2646, -0.4388, 0.2182, 0.4722, -0.4777, -0.5286, -0.0108, 0.6361, 0.3588, -0.4939, -0.0916, 0.8439, 0.1918, -0.6638, 0.5899,
  -0.8461, 0.3253, -0.2146, -0.6337, 0.9823, -0.9297, -0.0753, -0.273, 0.3604, 0.1735, -0.5992, -0.721, 0.2104, 0.4712, 1.1104, -0.2069,
  0.1447, -0.4797, 0.1304, -0.0755, -0.682, 0.3002, -1.1524, 0.0055, 0.5201, -0.0254, -1.6648, 0.6587, 0.0584, 0.5296, 0.0094, 0.3999,
  -0.4849, 0.0229, 0.1738, -0.4574, 0.5687, -0.7638, -1.0607, -0.5758, -0.2415, -1.2171, 0.7514, 1.4984, -0.2601, 0.9422, 0.9796, 0.2236,
  -0.3222, -0.9721, 0.4178, -0.196, -0.566, 0.2702, 0.4583, 0.3904, 0.6602, -0.176, 0.0873, 1.3641, -0.2112, 0.1934, 1.0354, -1.296,
  0.5968, 0.0505, 0.1074, 0.0787, 0.4016, -0.8177, 0.3426, 0.39, 0.209, 0.2056, -0.6173, -0.5647, -0.8065, 0.1958, 0.3005, -1.0768,
  0.8292, 0.4956, 0.0568, 0.3241, 1.2348, -0.9343, -0.0523, 0.0351, 0.3321, 0.0806, -0.3078, -0.6599, 0.2763, -0.9266, -0.0198, -0.3504,
  -0.2601, 0.7343, 0.4278, -0.9319, -0.7568, -0.2417, -0.35, -1.5823, 0.4307, -0.933, -0.0096, -0.1659, 0.2689, 1.3424, -0.4604, -0.2938,
  -0.3393, 1.0376, -0.3463, -0.3128, 1.406, 0.4589, -0.0882, 0.6821, 0.5972, 0.3906, 0.2027, -0.5271, -0.4518, -0.2481, -0.499, 0.7192,
  -0.2421, -0.2231, -0.3708, 1.3051, 0.2821, 0.4569, -0.3639, -0.1199, -1.0619, 0.1576, -0.2988, 0.5379, -0.4634, -0.8651, -0.989, 0.5096,
  -0.1476, -0.662, 0.2629, 0.369, -0.6912, 0.4146, 0.1315, 0.3911, 0.4886, -0.2204, 0.0397, -0.2246, -0.2929, -2.103, -0.7104, -1.0563,
  -0.0257, -0.156, 0.8465, 0.5777, -0.3515, 0.6793, -0.3279, -0.9777, 0.7045, 0.2897, 0.8833, -0.7587, 0.4951, 0.7996, -0.5594, 1.2622,
  0.098, -0.5379, -2.3896, -0.1371, 0.1886, -0.2813, 0.5049, -0.1988, 0.0566, -0.7121, -0.2782, -0.7093, 0.5257, -0.0456, -0.722, -0.1232,
  -0.4883, -0.079, 0.5348, 1.6595, -0.4638, -0.5109, 0.2418, -0.4325, -0.8044, -0.2555, 0.5462, 3.1688, 0.0929, 0.2704, 0.5011, 0.6799,
  1.1712, -0.0802, 0.5595, -0.5068, 1.2867, 0.5492, 0.4025, 0.0041, 0.3943, -0.328, 1.3458, 1.1182, 0.003, -0.195, 0.4519, 0.7449,
  -1.0139, 0.7419, -0.2303, -0.5202, -0.9039, -0.5153, -0.2181, 1.0823, 1.4247, 0.4799, 0.2533, 0.9953, -0.976, 1.1987, -0.868, 0.8568,
  -1.4522, 0.1978, 0.0639, 0.2713, -0.5146, -0.4015, 0.2574, 1.1822, -0.3703, 0.8414, -0.1664, 0.0875, -0.5243, -0.0337, -0.2611, -0.1417,
  0.0857, -0.4165, -0.4701, 0.5552, -0.5371, -1.4963, -0.9155, -0.7036, 0.4055, 0.545, 0.5299, 0.7059, 0.73, 0.2601, 0.0786, 0.6434,
  0.5433, 0.4143, -0.6217, -0.2589, 0.0643, 0.1539, -0.1551, 0.2684, -0.5671, -0.4448, 0.6279, -0.0254, 0.0201, -0.2918, 0.6765, 0.6451,
  0.6847, -0.1659, 0.4157, -0.5593, -0.7498, -0.051, 0.7281, -0.004, 0.0992, -1.6316, -0.2111, -0.5352, 0.5859, 0.1683, 0.4912, 0.228,
  0.7869, -0.0952, 0.5204, 0.061, 0.7881, 0.2384, -0.0615, -0.8749, -0.7075, -0.7761, -0.5385, 0.4591, -0.4147, 0.3922, 0.735, -1.0416,
  0.5754, 0.6265, -0.2886, 1.9861, 0.9932, 0.0715, -0.1811, -0.7054, 1.8281, 0.258, -0.0352, -0.0018, 0.7275, 0.0833, -0.2092, 0.1592,
  0.333, 0.7241, -0.0581, 0.6308, 0.6868, 0.4151, -0.3961, 0.2078, -0.3508,
];
export const CHAMPION_ENABLED: readonly number[] = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1];
export const CHAMPION_HISTORY: readonly TrainingPoint[] = [
  { generation: 0, trained: 12.67, trainedStd: 6.02, aco: 23.33, random: 1.00 },
  { generation: 1, trained: 2.33, trainedStd: 2.62, aco: 23.33, random: 1.00 },
  { generation: 2, trained: 15.33, trainedStd: 4.11, aco: 23.33, random: 1.00 },
  { generation: 3, trained: 15.33, trainedStd: 4.11, aco: 23.33, random: 1.00 },
  { generation: 4, trained: 23.00, trainedStd: 2.16, aco: 23.33, random: 1.00 },
  { generation: 5, trained: 23.00, trainedStd: 2.16, aco: 23.33, random: 1.00 },
  { generation: 6, trained: 23.67, trainedStd: 4.50, aco: 23.33, random: 1.00 },
  { generation: 7, trained: 23.67, trainedStd: 0.47, aco: 23.33, random: 1.00 },
  { generation: 8, trained: 22.67, trainedStd: 2.87, aco: 23.33, random: 1.00 },
  { generation: 9, trained: 29.33, trainedStd: 3.68, aco: 23.33, random: 1.00 },
  { generation: 10, trained: 27.67, trainedStd: 4.99, aco: 23.33, random: 1.00 },
  { generation: 11, trained: 31.67, trainedStd: 3.68, aco: 23.33, random: 1.00 },
  { generation: 12, trained: 30.00, trainedStd: 1.63, aco: 23.33, random: 1.00 },
  { generation: 13, trained: 32.33, trainedStd: 1.70, aco: 23.33, random: 1.00 },
  { generation: 14, trained: 29.33, trainedStd: 5.79, aco: 23.33, random: 1.00 },
  { generation: 15, trained: 28.33, trainedStd: 2.36, aco: 23.33, random: 1.00 },
  { generation: 16, trained: 27.33, trainedStd: 1.25, aco: 23.33, random: 1.00 },
  { generation: 17, trained: 33.33, trainedStd: 1.70, aco: 23.33, random: 1.00 },
  { generation: 18, trained: 29.00, trainedStd: 1.41, aco: 23.33, random: 1.00 },
  { generation: 19, trained: 31.67, trainedStd: 1.70, aco: 23.33, random: 1.00 },
  { generation: 20, trained: 31.00, trainedStd: 1.63, aco: 23.33, random: 1.00 },
  { generation: 21, trained: 31.00, trainedStd: 1.63, aco: 23.33, random: 1.00 },
  { generation: 22, trained: 26.67, trainedStd: 2.62, aco: 23.33, random: 1.00 },
  { generation: 23, trained: 30.67, trainedStd: 3.09, aco: 23.33, random: 1.00 },
  { generation: 24, trained: 29.00, trainedStd: 0.82, aco: 23.33, random: 1.00 },
  { generation: 25, trained: 28.00, trainedStd: 3.56, aco: 23.33, random: 1.00 },
  { generation: 26, trained: 30.00, trainedStd: 0.00, aco: 23.33, random: 1.00 },
  { generation: 27, trained: 30.00, trainedStd: 0.00, aco: 23.33, random: 1.00 },
];
export const CHAMPION_META = { generation: 24, fitness: 522.15, trainedAt: "2026-11-13T19:09:20.185Z", benchmark: "Full Trained Brain=29.0+-0.8; Hand-Crafted ACO=23.3+-7.4; Random Brain=1.0+-0.8; -foodTrail=29.3+-0.5; -homeGuide=16.0+-3.7; -alarm=30.0+-2.2; -scoutPulse=27.3+-1.9; -noEntry=8.3+-1.9; -PathIntegration=0.7+-0.5" };
// <CHAMPION-END>

export function createChampionBrain(): Brain {
  if (CHAMPION_WEIGHTS.length === GENOME_SIZE) return createBrain(CHAMPION_WEIGHTS, CHAMPION_ENABLED.length === NH ? CHAMPION_ENABLED : undefined);
  return createInnatePrior();
}

export function hasBakedChampion(): boolean {
  return CHAMPION_WEIGHTS.length === GENOME_SIZE;
}
