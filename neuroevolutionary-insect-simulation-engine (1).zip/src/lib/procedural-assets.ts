/*
 * Procedural, zero-blur canvas assets (browser only):
 *  - #020307 veined soil with survey reticles + wall ambient occlusion
 *  - #0d1322 terraced basalt walls with #2dd4bf / #38bdf8 bioluminescent rims (organic circle-union contours)
 *  - 2 atlases (caste + cohort) x 8 leg frames x 4 rows, rendered at 2x
 *  - armored Abyssal Stalker predator (4 frames), 8 emerald crystal variants, chitin corpse husk
 *  - radial glow sprites, cached vignette + grain overlay
 */
import { Mulberry32, Simplex2D } from "./prng-noise";
import type { PheromoneGrid } from "./pheromone-grid";

export const SPRITE_SCALE = 2;
export const ANT_FRAME_WORLD = 16;
export const ANT_FRAMES = 8;
export const PREDATOR_FRAME_WORLD = 36;
export const PREDATOR_FRAMES = 4;
export const CRYSTAL_WORLD = 26;
export const CRYSTAL_VARIANTS = 8;
export const CORPSE_WORLD = 14;

export function makeCanvas(w: number, h: number): HTMLCanvasElement {
  const c = document.createElement("canvas");
  c.width = Math.max(1, Math.round(w));
  c.height = Math.max(1, Math.round(h));
  return c;
}

export function ctx2d(c: HTMLCanvasElement): CanvasRenderingContext2D {
  const ctx = c.getContext("2d");
  if (!ctx) throw new Error("2D context unavailable");
  return ctx;
}

/* ---------------------------------- terrain ---------------------------------- */

interface Vein {
  pts: Float32Array;
  width: number;
  shade: string;
}

export class TerrainPainter {
  private veins: Vein[] = [];
  private noise: Simplex2D;
  constructor(
    readonly worldW: number,
    readonly worldH: number,
    seed: number,
  ) {
    this.noise = new Simplex2D(seed ^ 0x5eed);
    const rng = new Mulberry32(seed);
    const count = Math.round((worldW * worldH) / 9000);
    const shades = ["#06080f", "#070a13", "#080c17", "#090e1a"];
    for (let v = 0; v < count; v++) {
      const n = 10 + rng.int(18);
      const pts = new Float32Array(n * 2);
      let x = rng.range(0, worldW);
      let y = rng.range(0, worldH);
      let a = rng.range(0, Math.PI * 2);
      for (let i = 0; i < n; i++) {
        pts[i * 2] = x;
        pts[i * 2 + 1] = y;
        a += this.noise.noise(x * 0.01, y * 0.01) * 0.9 + rng.range(-0.25, 0.25);
        const step = rng.range(6, 16);
        x += Math.cos(a) * step;
        y += Math.sin(a) * step;
      }
      this.veins.push({ pts, width: rng.range(0.5, 1.6), shade: shades[rng.int(shades.length)] });
    }
  }

  /** Render terrain into the cache. rect in world px (null = full). scale = cache px per world px. */
  render(ctx: CanvasRenderingContext2D, grid: PheromoneGrid, scale: number, rect: { x0: number; y0: number; x1: number; y1: number } | null): void {
    const margin = 14;
    const x0 = rect ? Math.max(0, rect.x0 - margin) : 0;
    const y0 = rect ? Math.max(0, rect.y0 - margin) : 0;
    const x1 = rect ? Math.min(this.worldW, rect.x1 + margin) : this.worldW;
    const y1 = rect ? Math.min(this.worldH, rect.y1 + margin) : this.worldH;
    ctx.save();
    ctx.setTransform(scale, 0, 0, scale, 0, 0);
    ctx.beginPath();
    ctx.rect(x0, y0, x1 - x0, y1 - y0);
    ctx.clip();
    ctx.fillStyle = "#020307";
    ctx.fillRect(x0, y0, x1 - x0, y1 - y0);

    // crystalline micro-veins
    ctx.lineCap = "round";
    for (const v of this.veins) {
      ctx.strokeStyle = v.shade;
      ctx.lineWidth = v.width;
      ctx.beginPath();
      ctx.moveTo(v.pts[0], v.pts[1]);
      for (let i = 2; i < v.pts.length; i += 2) ctx.lineTo(v.pts[i], v.pts[i + 1]);
      ctx.stroke();
    }
    // survey reticles
    ctx.strokeStyle = "rgba(56,189,248,0.07)";
    ctx.lineWidth = 0.75;
    const sp = 160;
    for (let gx = sp / 2; gx < this.worldW; gx += sp) {
      for (let gy = sp / 2; gy < this.worldH; gy += sp) {
        if (gx < x0 - 12 || gx > x1 + 12 || gy < y0 - 12 || gy > y1 + 12) continue;
        ctx.beginPath();
        ctx.moveTo(gx - 6, gy);
        ctx.lineTo(gx - 2, gy);
        ctx.moveTo(gx + 2, gy);
        ctx.lineTo(gx + 6, gy);
        ctx.moveTo(gx, gy - 6);
        ctx.lineTo(gx, gy - 2);
        ctx.moveTo(gx, gy + 2);
        ctx.lineTo(gx, gy + 6);
        ctx.stroke();
        ctx.beginPath();
        ctx.arc(gx, gy, 9, 0, Math.PI * 2);
        ctx.stroke();
      }
    }

    // walls: circle-union passes
    const cs = grid.cellSize;
    const gx0 = Math.max(0, Math.floor(x0 / cs) - 2);
    const gy0 = Math.max(0, Math.floor(y0 / cs) - 2);
    const gx1 = Math.min(grid.cols - 1, Math.ceil(x1 / cs) + 2);
    const gy1 = Math.min(grid.rows - 1, Math.ceil(y1 / cs) + 2);
    const st = grid.stride;
    const w = grid.wall;
    const pass = (radius: number, fill: string, filter: (i: number) => boolean, ox = 0, oy = 0): void => {
      ctx.fillStyle = fill;
      ctx.beginPath();
      for (let gy = gy0; gy <= gy1; gy++) {
        for (let gx = gx0; gx <= gx1; gx++) {
          const i = (gy + 1) * st + gx + 1;
          if (w[i] !== 1 || !filter(i)) continue;
          const cx = (gx + 0.5) * cs + ox;
          const cy = (gy + 0.5) * cs + oy;
          ctx.moveTo(cx + radius, cy);
          ctx.arc(cx, cy, radius, 0, Math.PI * 2);
        }
      }
      ctx.fill();
    };
    const all = (): boolean => true;
    const depth = (i: number, d: number): boolean => {
      for (let dy = -d; dy <= d; dy++) for (let dx = -d; dx <= d; dx++) if (w[i + dy * st + dx] !== 1) return false;
      return true;
    };
    pass(cs * 2.1, "rgba(0,0,0,0.28)", all);
    pass(cs * 1.55, "rgba(45,212,191,0.07)", all);
    pass(cs * 1.22, "rgba(56,189,248,0.22)", all);
    pass(cs * 1.08, "#2dd4bf", all);
    pass(cs * 0.9, "#0d1322", all);
    pass(cs * 0.82, "#111a2d", (i) => depth(i, 1), -0.6, -0.6);
    pass(cs * 0.76, "#152036", (i) => depth(i, 2), -1, -1);
    pass(cs * 0.7, "#19263f", (i) => depth(i, 4), -1.4, -1.4);
    ctx.restore();
  }
}

/* ---------------------------------- ants ---------------------------------- */

interface AntPalette {
  body: string;
  rim: string;
  glow: string;
  leg: string;
  eye: string;
  headScale: number;
}

const CASTE_PALETTES: AntPalette[] = [
  { body: "#1b1238", rim: "#c084fc", glow: "175,50,255", leg: "#67e8f9", eye: "#00e1ff", headScale: 0.95 },
  { body: "#2a1a06", rim: "#ffd27a", glow: "255,168,0", leg: "#fbbf24", eye: "#fff3c4", headScale: 1 },
  { body: "#062314", rim: "#50ff64", glow: "80,255,100", leg: "#86efac", eye: "#ff0c4b", headScale: 1.25 },
  { body: "#2a0612", rim: "#ff5c85", glow: "255,12,75", leg: "#fda4af", eye: "#ffe4e6", headScale: 1.05 },
];

const COHORT_PALETTES: AntPalette[] = [
  { body: "#231a05", rim: "#ffd166", glow: "0,225,255", leg: "#67e8f9", eye: "#ffffff", headScale: 1 },
  { body: "#1e1a24", rim: "#fb7185", glow: "251,113,133", leg: "#94a3b8", eye: "#fecdd3", headScale: 1 },
  { body: "#1a1d26", rim: "#f9a8d4", glow: "148,163,184", leg: "#cbd5e1", eye: "#fbcfe8", headScale: 1 },
  { body: "#2a0612", rim: "#ff5c85", glow: "255,12,75", leg: "#fda4af", eye: "#ffe4e6", headScale: 1.05 },
];

function drawAnt(ctx: CanvasRenderingContext2D, pal: AntPalette, phase: number): void {
  // ant faces +x, centered at origin, length ~11 world units
  const glow = ctx.createRadialGradient(-1, 0, 0, -1, 0, 7.5);
  glow.addColorStop(0, `rgba(${pal.glow},0.55)`);
  glow.addColorStop(1, `rgba(${pal.glow},0)`);
  ctx.fillStyle = glow;
  ctx.beginPath();
  ctx.arc(-1, 0, 7.5, 0, Math.PI * 2);
  ctx.fill();
  // legs (tripod gait)
  ctx.strokeStyle = pal.leg;
  ctx.lineWidth = 0.55;
  ctx.lineCap = "round";
  for (let k = 0; k < 3; k++) {
    for (let side = -1; side <= 1; side += 2) {
      const tri = (k + (side > 0 ? 1 : 0)) % 2 === 0 ? 1 : -1;
      const swing = Math.sin(phase) * 1.6 * tri;
      const bx = 0.6 - k * 1.3;
      const kx = bx + (k - 1) * 1.2 + swing * 0.5;
      const ky = side * 2.6;
      const fx = bx + (k - 1) * 2.4 + swing;
      const fy = side * 4.4;
      ctx.beginPath();
      ctx.moveTo(bx, side * 0.6);
      ctx.lineTo(kx, ky);
      ctx.lineTo(fx, fy);
      ctx.stroke();
    }
  }
  // antennae
  ctx.beginPath();
  const aw = Math.sin(phase * 0.5) * 0.5;
  ctx.moveTo(4.6, -0.6);
  ctx.quadraticCurveTo(6.2, -2.2 + aw, 7.6, -2.6 + aw);
  ctx.moveTo(4.6, 0.6);
  ctx.quadraticCurveTo(6.2, 2.2 - aw, 7.6, 2.6 - aw);
  ctx.stroke();
  // body segments
  const seg = (cx: number, rx: number, ry: number): void => {
    ctx.beginPath();
    ctx.ellipse(cx, 0, rx, ry, 0, 0, Math.PI * 2);
    ctx.fillStyle = pal.body;
    ctx.fill();
    ctx.lineWidth = 0.55;
    ctx.strokeStyle = pal.rim;
    ctx.stroke();
  };
  seg(-3.3, 2.7, 2.0);
  seg(0.4, 1.7, 1.15);
  seg(3.6, 1.35 * pal.headScale, 1.25 * pal.headScale);
  ctx.fillStyle = `rgba(${pal.glow},0.9)`;
  ctx.beginPath();
  ctx.ellipse(-3.6, -0.5, 1.2, 0.6, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = pal.eye;
  ctx.beginPath();
  ctx.arc(4.2, -0.7, 0.35, 0, Math.PI * 2);
  ctx.arc(4.2, 0.7, 0.35, 0, Math.PI * 2);
  ctx.fill();
}

function buildAtlas(palettes: AntPalette[]): HTMLCanvasElement {
  const fs = ANT_FRAME_WORLD * SPRITE_SCALE;
  const c = makeCanvas(fs * ANT_FRAMES, fs * palettes.length);
  const ctx = ctx2d(c);
  for (let row = 0; row < palettes.length; row++) {
    for (let f = 0; f < ANT_FRAMES; f++) {
      ctx.setTransform(SPRITE_SCALE, 0, 0, SPRITE_SCALE, f * fs + fs / 2, row * fs + fs / 2);
      drawAnt(ctx, palettes[row], (f / ANT_FRAMES) * Math.PI * 2);
    }
  }
  return c;
}

export interface AntAtlases {
  caste: HTMLCanvasElement;
  cohort: HTMLCanvasElement;
  framePx: number;
}

export function buildAntAtlases(): AntAtlases {
  return { caste: buildAtlas(CASTE_PALETTES), cohort: buildAtlas(COHORT_PALETTES), framePx: ANT_FRAME_WORLD * SPRITE_SCALE };
}

/* ---------------------------------- predator ---------------------------------- */

export function buildPredatorAtlas(): HTMLCanvasElement {
  const fs = PREDATOR_FRAME_WORLD * SPRITE_SCALE;
  const c = makeCanvas(fs * PREDATOR_FRAMES, fs);
  const ctx = ctx2d(c);
  for (let f = 0; f < PREDATOR_FRAMES; f++) {
    ctx.setTransform(SPRITE_SCALE, 0, 0, SPRITE_SCALE, f * fs + fs / 2, fs / 2);
    const ph = (f / PREDATOR_FRAMES) * Math.PI * 2;
    const g = ctx.createRadialGradient(0, 0, 2, 0, 0, 17);
    g.addColorStop(0, "rgba(255,12,75,0.28)");
    g.addColorStop(1, "rgba(255,12,75,0)");
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(0, 0, 17, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "#475569";
    ctx.lineWidth = 1.1;
    ctx.lineCap = "round";
    for (let k = 0; k < 4; k++) {
      for (let s = -1; s <= 1; s += 2) {
        const sw = Math.sin(ph + k * 1.4 + (s > 0 ? Math.PI : 0)) * 2.2;
        const bx = 5 - k * 3.6;
        ctx.beginPath();
        ctx.moveTo(bx, s * 3);
        ctx.lineTo(bx + sw * 0.4 - 1, s * 8);
        ctx.lineTo(bx + sw - 3, s * 12.5);
        ctx.stroke();
      }
    }
    // segmented armor plates
    const plates = [
      [-9, 5.6, 4.4],
      [-4, 5.2, 4.8],
      [1, 4.6, 4.4],
      [6.5, 4.0, 3.8],
    ];
    for (const [px, rx, ry] of plates) {
      ctx.beginPath();
      ctx.ellipse(px, 0, rx, ry, 0, 0, Math.PI * 2);
      const pg = ctx.createLinearGradient(px, -ry, px, ry);
      pg.addColorStop(0, "#2b3548");
      pg.addColorStop(0.5, "#141b29");
      pg.addColorStop(1, "#0a0e17");
      ctx.fillStyle = pg;
      ctx.fill();
      ctx.strokeStyle = "rgba(56,189,248,0.55)";
      ctx.lineWidth = 0.7;
      ctx.stroke();
      ctx.strokeStyle = "rgba(255,255,255,0.12)";
      ctx.beginPath();
      ctx.ellipse(px - 0.6, -0.8, rx * 0.6, ry * 0.45, 0, Math.PI * 1.1, Math.PI * 1.9);
      ctx.stroke();
    }
    // mandibles
    ctx.strokeStyle = "#e2e8f0";
    ctx.lineWidth = 1;
    const m = Math.sin(ph * 2) * 0.6;
    ctx.beginPath();
    ctx.moveTo(9.5, -2);
    ctx.quadraticCurveTo(13, -3.5 - m, 14, -0.6);
    ctx.moveTo(9.5, 2);
    ctx.quadraticCurveTo(13, 3.5 + m, 14, 0.6);
    ctx.stroke();
    // crimson oculars
    for (const s of [-1, 1]) {
      const og = ctx.createRadialGradient(8, s * 1.8, 0, 8, s * 1.8, 2.6);
      og.addColorStop(0, "#ffffff");
      og.addColorStop(0.35, "#ff0c4b");
      og.addColorStop(1, "rgba(255,12,75,0)");
      ctx.fillStyle = og;
      ctx.beginPath();
      ctx.arc(8, s * 1.8, 2.6, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  return c;
}

/* ---------------------------------- crystals ---------------------------------- */

export function buildCrystalAtlas(seed: number): HTMLCanvasElement {
  const fs = CRYSTAL_WORLD * SPRITE_SCALE;
  const c = makeCanvas(fs * CRYSTAL_VARIANTS, fs);
  const ctx = ctx2d(c);
  const rng = new Mulberry32(seed);
  for (let v = 0; v < CRYSTAL_VARIANTS; v++) {
    ctx.setTransform(SPRITE_SCALE, 0, 0, SPRITE_SCALE, v * fs + fs / 2, fs / 2);
    const g = ctx.createRadialGradient(0, 0, 1, 0, 0, 12.5);
    g.addColorStop(0, "rgba(0,230,118,0.45)");
    g.addColorStop(1, "rgba(0,230,118,0)");
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(0, 0, 12.5, 0, Math.PI * 2);
    ctx.fill();
    const shards = 3 + rng.int(3);
    for (let s = 0; s < shards; s++) {
      const a = -Math.PI / 2 + rng.range(-0.9, 0.9);
      const len = rng.range(6, 10.5);
      const wid = rng.range(1.8, 3.2);
      const bx = rng.range(-3, 3);
      const by = rng.range(1, 4);
      const tx = bx + Math.cos(a) * len;
      const ty = by + Math.sin(a) * len;
      const nx = -Math.sin(a) * wid;
      const ny = Math.cos(a) * wid;
      const mx = bx + Math.cos(a) * len * 0.62;
      const my = by + Math.sin(a) * len * 0.62;
      ctx.beginPath();
      ctx.moveTo(bx - nx * 0.6, by - ny * 0.6);
      ctx.lineTo(mx - nx, my - ny);
      ctx.lineTo(tx, ty);
      ctx.lineTo(mx + nx, my + ny);
      ctx.lineTo(bx + nx * 0.6, by + ny * 0.6);
      ctx.closePath();
      const sg = ctx.createLinearGradient(bx - nx, by - ny, bx + nx, by + ny);
      sg.addColorStop(0, "#00794a");
      sg.addColorStop(0.45, "#00e676");
      sg.addColorStop(1, "#a7f3d0");
      ctx.fillStyle = sg;
      ctx.fill();
      ctx.strokeStyle = "rgba(167,243,208,0.85)";
      ctx.lineWidth = 0.45;
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(bx, by);
      ctx.lineTo(mx, my);
      ctx.lineTo(tx, ty);
      ctx.strokeStyle = "rgba(236,253,245,0.55)";
      ctx.stroke();
    }
    ctx.fillStyle = "#ecfdf5";
    for (let k = 0; k < 3; k++) {
      const sx = rng.range(-6, 6);
      const sy = rng.range(-8, 2);
      ctx.fillRect(sx - 0.2, sy - 1.2, 0.4, 2.4);
      ctx.fillRect(sx - 1.2, sy - 0.2, 2.4, 0.4);
    }
  }
  return c;
}

/* ---------------------------------- corpse husk ---------------------------------- */

export function buildCorpseSprite(): HTMLCanvasElement {
  const fs = CORPSE_WORLD * SPRITE_SCALE;
  const c = makeCanvas(fs, fs);
  const ctx = ctx2d(c);
  ctx.setTransform(SPRITE_SCALE, 0, 0, SPRITE_SCALE, fs / 2, fs / 2);
  ctx.strokeStyle = "#4b5263";
  ctx.lineWidth = 0.5;
  for (let k = 0; k < 3; k++) {
    for (const s of [-1, 1]) {
      ctx.beginPath();
      ctx.moveTo(0.5 - k * 1.3, s * 0.6);
      ctx.quadraticCurveTo(-k * 1.2, s * 2.6, 0.8 - k * 1.6, s * 1.6);
      ctx.stroke();
    }
  }
  const seg = (x: number, rx: number, ry: number, fill: string): void => {
    ctx.beginPath();
    ctx.ellipse(x, 0, rx, ry, 0.25, 0, Math.PI * 2);
    ctx.fillStyle = fill;
    ctx.fill();
    ctx.strokeStyle = "rgba(255,12,75,0.35)";
    ctx.stroke();
  };
  seg(-3, 2.5, 1.8, "#2b2f3a");
  seg(0.4, 1.5, 1.0, "#353a47");
  seg(3.2, 1.2, 1.1, "#3d4352");
  return c;
}

/* ---------------------------------- glow + overlays ---------------------------------- */

export function buildGlowSprite(rgb: string, size = 64, alpha = 1): HTMLCanvasElement {
  const c = makeCanvas(size, size);
  const ctx = ctx2d(c);
  const g = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  g.addColorStop(0, `rgba(${rgb},${alpha})`);
  g.addColorStop(0.35, `rgba(${rgb},${alpha * 0.35})`);
  g.addColorStop(1, `rgba(${rgb},0)`);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);
  return c;
}

export function buildVignette(w: number, h: number, seed: number): HTMLCanvasElement {
  const c = makeCanvas(w, h);
  const ctx = ctx2d(c);
  const r = Math.hypot(w, h) / 2;
  const g = ctx.createRadialGradient(w / 2, h / 2, r * 0.35, w / 2, h / 2, r);
  g.addColorStop(0, "rgba(2,3,7,0)");
  g.addColorStop(0.75, "rgba(2,3,7,0.35)");
  g.addColorStop(1, "rgba(0,0,0,0.78)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, w, h);
  // grain: sparse noise tile, repeated
  const tile = makeCanvas(128, 128);
  const tctx = ctx2d(tile);
  const img = tctx.createImageData(128, 128);
  const rng = new Mulberry32(seed);
  for (let i = 0; i < img.data.length; i += 4) {
    const v = rng.next();
    const lum = v > 0.5 ? 255 : 0;
    img.data[i] = lum;
    img.data[i + 1] = lum;
    img.data[i + 2] = lum;
    img.data[i + 3] = Math.round(rng.next() * 14);
  }
  tctx.putImageData(img, 0, 0);
  const pat = ctx.createPattern(tile, "repeat");
  if (pat) {
    ctx.fillStyle = pat;
    ctx.fillRect(0, 0, w, h);
  }
  return c;
}
