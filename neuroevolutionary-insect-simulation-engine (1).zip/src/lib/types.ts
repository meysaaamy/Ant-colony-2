/* Core shared types for the Prismatic Formicarium engine. Zero `any`. */

export const CHANNEL_COUNT = 5;
export const CH_FOOD = 0;
export const CH_HOME = 1;
export const CH_ALARM = 2;
export const CH_SCOUT = 3;
export const CH_NOENTRY = 4;
export type ChannelId = 0 | 1 | 2 | 3 | 4;

export const CHANNEL_NAMES = ["foodTrail", "homeGuide", "alarm", "scoutPulse", "noEntry"] as const;
export type ChannelName = (typeof CHANNEL_NAMES)[number];

export const CHANNEL_LABELS: readonly string[] = ["Food Amber", "Home Cyan", "Alarm Crimson", "Scout Violet", "No-Entry Viridian"];

/** Pure spectral primaries in 0..255 */
export const CHANNEL_RGB: ReadonlyArray<readonly [number, number, number]> = [
  [255, 168, 0],
  [0, 225, 255],
  [255, 12, 75],
  [175, 50, 255],
  [80, 255, 100],
];

/* Ant states */
export const ST_FORAGING = 0;
export const ST_RETURNING = 1;
export const ST_ALARMED = 2;
export const ST_DEFENDING = 3;
export const ST_TRAIL_DAMPING = 4;
export const ST_TANDEM_FOLLOW = 5;
export const ST_NECROPHORESIS = 6;
export const ST_DEAD = 7;
export const STATE_NAMES = ["FORAGING", "RETURNING", "ALARMED", "DEFENDING", "TRAIL_DAMPING", "TANDEM_FOLLOW", "NECROPHORESIS", "DEAD"] as const;

/* Castes */
export const CASTE_SCOUT = 0;
export const CASTE_HAULER = 1;
export const CASTE_WARDEN = 2;
export const CASTE_NAMES = ["SCOUT", "HAULER", "WARDEN"] as const;

/* Policies */
export const POLICY_TRAINED = 0;
export const POLICY_ACO = 1;
export const POLICY_RANDOM = 2;
export const POLICY_NAMES = ["TRAINED_MLP", "HANDCRAFTED_ACO", "RANDOM_MLP"] as const;

export type ArenaMode = "trained" | "ab-random" | "ab-aco" | "aco";

/* Arc events */
export const ARC_TROPHALLAXIS = 0;
export const ARC_TANDEM = 1;
export const ARC_COMBAT = 2;

export const MAX_ANTS = 3000;
export const MAX_PREDATORS = 6;
export const MAX_CORPSES = 512;
export const MAX_FOOD_SOURCES = 48;
export const MAX_ARCS = 256;

/** Structure-of-arrays ant storage (preallocated, zero allocation in the loop). */
export interface AntSoA {
  x: Float32Array;
  y: Float32Array;
  vx: Float32Array;
  vy: Float32Array;
  angle: Float32Array;
  homeDx: Float32Array;
  homeDy: Float32Array;
  targetX: Float32Array;
  targetY: Float32Array;
  legPhase: Float32Array;
  pheromoneTimer: Float32Array;
  timeSinceLastVisit: Float32Array;
  ouNoise: Float32Array;
  energy: Float32Array;
  age: Float32Array;
  maxLifespan: Float32Array;
  fitness: Float32Array;
  memA: Float32Array;
  memB: Float32Array;
  tripDist: Float32Array;
  speedTrait: Float32Array;
  noiseTrait: Float32Array;
  stall: Float32Array;
  steer: Float32Array;
  speedOut: Float32Array;
  emit: Float32Array; // 5 per ant
  state: Uint8Array;
  caste: Uint8Array;
  policyType: Uint8Array;
  carryingFood: Uint8Array;
  active: Uint8Array;
  hasTarget: Uint8Array;
  carryCorpse: Int16Array;
  generation: Uint16Array;
}

export interface FoodSourceData {
  x: Float32Array;
  y: Float32Array;
  amount: Float32Array;
  max: Float32Array;
  variant: Uint8Array;
  active: Uint8Array;
  sealed: Uint8Array;
}

export interface PredatorData {
  x: Float32Array;
  y: Float32Array;
  angle: Float32Array;
  hp: Float32Array;
  maxHp: Float32Array;
  cooldown: Float32Array;
  legPhase: Float32Array;
  hitFlash: Float32Array;
  active: Uint8Array;
}

export interface CorpseData {
  x: Float32Array;
  y: Float32Array;
  rot: Float32Array;
  ttl: Float32Array;
  carrier: Int16Array;
  active: Uint8Array;
}

export interface ArcData {
  x1: Float32Array;
  y1: Float32Array;
  x2: Float32Array;
  y2: Float32Array;
  type: Uint8Array;
  ttl: Uint8Array;
}

/** Channel ablation: true = muted (no sensing, no secretion). */
export interface AblationMask {
  channels: [boolean, boolean, boolean, boolean, boolean];
  pathIntegration: boolean;
}

export interface PheromoneParams {
  evaporation: number; // base 1/s
  diffusion: number; // 0..1 (CFL clamped)
  reactionRate: number; // 0..2
}

export interface SimConfig {
  worldW: number;
  worldH: number;
  initialAnts: number;
  maxPop: number;
  predatorCount: number;
  atpBurn: number;
  lifespanScale: number;
  pheromone: PheromoneParams;
  arena: ArenaMode;
  ablation: AblationMask;
  thinkInterval: number;
  diffusionInterval: number;
  interactionInterval: number;
  enableBirths: boolean;
  enableMortality: boolean;
  seed: number;
}

export interface Vec2 {
  x: number;
  y: number;
}

export type WallStroke = { kind: "circle"; x: number; y: number; r: number } | { kind: "capsule"; x1: number; y1: number; x2: number; y2: number; r: number };

export type PresetId = "open-sanctuary" | "double-bridge" | "labyrinth";

export interface PresetLayout {
  nest: Vec2;
  graveyard: Vec2;
  foods: Array<{ x: number; y: number; amount: number }>;
  walls: WallStroke[];
  carve: WallStroke[];
}

export interface PresetDef {
  id: PresetId;
  name: string;
  subtitle: string;
  build: (w: number, h: number, seed: number) => PresetLayout;
}

export interface Telemetry {
  alive: number;
  deaths: number;
  births: number;
  foodDelivered: number;
  storedFood: number;
  colonyGeneration: number;
  predators: number;
  simTime: number;
  tick: number;
  cohortTrained: number;
  cohortOther: number;
  bottlenecks: number;
  foodRemaining: number;
}

/* Brain / neuroevolution */
export const BRAIN_INPUTS = 19;
export const BRAIN_HIDDEN = 16;
export const BRAIN_OUTPUTS = 9;

export interface Brain {
  weights: Float32Array;
  hidden: number;
  /** NEAT-style optional hidden-unit enable mask (topology growth). */
  enabled: Uint8Array;
}

export interface Genome {
  id: number;
  weights: Float32Array;
  enabled: Uint8Array;
  sigma: number;
  fitness: number;
  species: number;
}

export interface BrainJSON {
  format: "prismatic-colony-brain";
  version: 1;
  inputs: number;
  hidden: number;
  outputs: number;
  weights: number[];
  enabled: number[];
  meta?: { generation: number; fitness: number; note: string };
}

export interface EvolutionParams {
  populationSize: number;
  eliteCount: number;
  tournamentSize: number;
  mutationRate: number;
  initialSigma: number;
  crossoverRate: number;
  useSpeciation: boolean;
  compatibilityThreshold: number;
}

export interface TrainingPoint {
  generation: number;
  trained: number;
  trainedStd: number;
  aco: number;
  random: number;
}

export type BenchmarkCondition =
  | "trained"
  | "aco"
  | "random"
  | "-foodTrail"
  | "-homeGuide"
  | "-alarm"
  | "-scoutPulse"
  | "-noEntry"
  | "-pathIntegration";

export interface BenchmarkResult {
  condition: BenchmarkCondition;
  label: string;
  mean: number;
  std: number;
  samples: number[];
}

export interface BenchmarkReport {
  seeds: number[];
  ticks: number;
  results: BenchmarkResult[];
}

export interface EpisodeResult {
  foodDelivered: number;
  pickups: number;
  deaths: number;
  fitness: number;
  efficiency: number;
}

/* UI-level types */
export type ToolId = "food-trail" | "home-trail" | "alarm" | "crystal" | "wall" | "eraser";
export type AlarmSubMode = "alarm" | "scout" | "noentry" | "predator";
export type SheetSnap = "peek" | "half" | "full";
export type SheetTab = "proof" | "colony" | "alchemy" | "brush" | "world";

export interface UiSettings {
  tool: ToolId;
  alarmMode: AlarmSubMode;
  brushRadius: number;
  brushStrength: number;
  speed: 1 | 2 | 4;
  preset: PresetId;
}

export function defaultAblation(): AblationMask {
  return { channels: [false, false, false, false, false], pathIntegration: false };
}

export function defaultSimConfig(worldW: number, worldH: number): SimConfig {
  return {
    worldW,
    worldH,
    initialAnts: 900,
    maxPop: 2400,
    predatorCount: 0,
    atpBurn: 1,
    lifespanScale: 1,
    pheromone: { evaporation: 0.07, diffusion: 0.35, reactionRate: 1 },
    arena: "trained",
    ablation: defaultAblation(),
    thinkInterval: 2,
    diffusionInterval: 1,
    interactionInterval: 4,
    enableBirths: true,
    enableMortality: true,
    seed: 1337,
  };
}
