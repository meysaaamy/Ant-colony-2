/*
 * 10-layer zero-blur compositor (no ctx.filter blur, no shadowBlur):
 *  1 static terrain cache (dirty rects)   2 5-channel RGB pheromone ImageData ('screen')
 *  3 1/4-res prismatic bloom (every 2nd frame, bilinear upscale, 'lighter')
 *  4 corpse husks + emerald crystals      5 brood reactor nest crater
 *  6 articulated ants + predators         7 synaptic / combat arcs
 *  8 spore motes (45)                     9 active brush ribbon        10 cached vignette + grain
 * Adaptive scaler: 60-frame FPS < 50 -> shed bloom + signal diffusion every 2nd tick.
 */
import { FOOD_RADIUS, NEST_RADIUS, type AntEngine } from "./ant-soa-engine";
import {
  ANT_FRAMES,
  ANT_FRAME_WORLD,
  CORPSE_WORLD,
  CRYSTAL_WORLD,
  PREDATOR_FRAMES,
  PREDATOR_FRAME_WORLD,
  SPRITE_SCALE,
  TerrainPainter,
  buildAntAtlases,
  buildCorpseSprite,
  buildCrystalAtlas,
  buildGlowSprite,
  buildPredatorAtlas,
  buildVignette,
  ctx2d,
  makeCanvas,
  type AntAtlases,
} from "./procedural-assets";
import type { DirtyRect } from "./pheromone-grid";
import { ARC_COMBAT, ARC_TANDEM, MAX_ARCS, MAX_CORPSES, MAX_FOOD_SOURCES, MAX_PREDATORS, POLICY_RANDOM, POLICY_TRAINED, ST_ALARMED, ST_DEFENDING } from "./types";

export interface BrushOverlay {
  active: boolean;
  xs: Float32Array;
  ys: Float32Array;
  count: number;
  rgb: string;
  radius: number;
  mode: "paint" | "erase" | "wall" | "crystal";
  startX: number;
  startY: number;
  startT: number;
  cursorX: number;
  cursorY: number;
  hasCursor: boolean;
}

export function createBrushOverlay(): BrushOverlay {
  return { active: false, xs: new Float32Array(48), ys: new Float32Array(48), count: 0, rgb: "255,168,0", radius: 18, mode: "paint", startX: 0, startY: 0, startT: -1e9, cursorX: 0, cursorY: 0, hasCursor: false };
}

export interface RenderOptions {
  cohortMode: boolean;
  time: number;
}

const SPORES = 45;
const TAU = Math.PI * 2;

export class Renderer {
  readonly canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private engine: AntEngine;
  private terrain: HTMLCanvasElement;
  private terrainCtx: CanvasRenderingContext2D;
  private terrainScale = 1;
  private painter: TerrainPainter;
  private dirty: DirtyRect | null = null;
  private pher: HTMLCanvasElement;
  private pherCtx: CanvasRenderingContext2D;
  private pherImage: ImageData;
  private bloom: HTMLCanvasElement;
  private bloomCtx: CanvasRenderingContext2D;
  private bloomSmall: HTMLCanvasElement;
  private bloomSmallCtx: CanvasRenderingContext2D;
  private vignette: HTMLCanvasElement | null = null;
  private atlases: AntAtlases;
  private predatorAtlas: HTMLCanvasElement;
  private crystals: HTMLCanvasElement;
  private corpse: HTMLCanvasElement;
  private glowEmerald: HTMLCanvasElement;
  private glowCyan: HTMLCanvasElement;
  private glowAmber: HTMLCanvasElement;
  private glowSpore: HTMLCanvasElement;
  private spores = new Float32Array(SPORES * 5);
  private frame = 0;
  scale = 1;
  ox = 0;
  oy = 0;
  dpr = 1;
  cssW = 1;
  cssH = 1;
  /* adaptive scaler */
  private frameTimes = new Float32Array(60);
  private ftHead = 0;
  private lastT = 0;
  fps = 60;
  lowPerf = false;
  private goodFrames = 0;

  constructor(canvas: HTMLCanvasElement, engine: AntEngine) {
    this.canvas = canvas;
    this.ctx = ctx2d(canvas);
    this.engine = engine;
    const W = engine.cfg.worldW;
    const H = engine.cfg.worldH;
    this.painter = new TerrainPainter(W, H, engine.cfg.seed);
    this.terrain = makeCanvas(W, H);
    this.terrainCtx = ctx2d(this.terrain);
    this.pher = makeCanvas(engine.grid.cols, engine.grid.rows);
    this.pherCtx = ctx2d(this.pher);
    this.pherImage = this.pherCtx.createImageData(engine.grid.cols, engine.grid.rows);
    this.bloom = makeCanvas(Math.ceil(W / 4), Math.ceil(H / 4));
    this.bloomCtx = ctx2d(this.bloom);
    this.bloomSmall = makeCanvas(Math.ceil(W / 16), Math.ceil(H / 16));
    this.bloomSmallCtx = ctx2d(this.bloomSmall);
    this.atlases = buildAntAtlases();
    this.predatorAtlas = buildPredatorAtlas();
    this.crystals = buildCrystalAtlas(engine.cfg.seed);
    this.corpse = buildCorpseSprite();
    this.glowEmerald = buildGlowSprite("0,230,118", 64, 0.9);
    this.glowCyan = buildGlowSprite("45,212,191", 64, 0.8);
    this.glowAmber = buildGlowSprite("255,168,0", 64, 0.9);
    this.glowSpore = buildGlowSprite("167,243,208", 16, 0.9);
    let s = (engine.cfg.seed * 9301 + 49297) % 233280;
    const rnd = (): number => {
      s = (s * 9301 + 49297) % 233280;
      return s / 233280;
    };
    for (let k = 0; k < SPORES; k++) {
      const o = k * 5;
      this.spores[o] = rnd() * W;
      this.spores[o + 1] = rnd() * H;
      this.spores[o + 2] = 0.3 + rnd() * 0.9; // depth / parallax
      this.spores[o + 3] = rnd() * TAU; // phase
      this.spores[o + 4] = 0.6 + rnd() * 1.4; // size
    }
  }

  setEngine(engine: AntEngine): void {
    this.engine = engine;
    this.dirty = null;
    this.renderTerrainFull();
  }

  resize(cssW: number, cssH: number, dpr: number): void {
    const W = this.engine.cfg.worldW;
    const H = this.engine.cfg.worldH;
    this.cssW = cssW;
    this.cssH = cssH;
    this.dpr = Math.min(2, Math.max(1, dpr));
    this.canvas.width = Math.round(cssW * this.dpr);
    this.canvas.height = Math.round(cssH * this.dpr);
    this.scale = Math.min(cssW / W, cssH / H);
    this.ox = (cssW - W * this.scale) / 2;
    this.oy = (cssH - H * this.scale) / 2;
    const ts = Math.min(2, Math.max(1, this.scale * this.dpr));
    if (Math.abs(ts - this.terrainScale) > 0.05 || this.terrain.width !== Math.round(W * ts)) {
      this.terrainScale = ts;
      this.terrain.width = Math.round(W * ts);
      this.terrain.height = Math.round(H * ts);
    }
    this.renderTerrainFull();
    this.vignette = buildVignette(this.canvas.width, this.canvas.height, 77);
  }

  renderTerrainFull(): void {
    this.painter.render(this.terrainCtx, this.engine.grid, this.terrainScale, null);
  }

  markTerrainDirty(r: DirtyRect): void {
    if (!this.dirty) this.dirty = { ...r };
    else {
      this.dirty.x0 = Math.min(this.dirty.x0, r.x0);
      this.dirty.y0 = Math.min(this.dirty.y0, r.y0);
      this.dirty.x1 = Math.max(this.dirty.x1, r.x1);
      this.dirty.y1 = Math.max(this.dirty.y1, r.y1);
    }
  }

  screenToWorld(px: number, py: number): { x: number; y: number } {
    return { x: (px - this.ox) / this.scale, y: (py - this.oy) / this.scale };
  }

  /** Track frame cadence; returns true when the adaptive scaler is engaged. */
  trackFrame(t: number): boolean {
    if (this.lastT > 0) {
      const dt = Math.min(250, t - this.lastT);
      this.frameTimes[this.ftHead] = dt;
      this.ftHead = (this.ftHead + 1) % 60;
      let sum = 0;
      for (let k = 0; k < 60; k++) sum += this.frameTimes[k] || 16.7;
      this.fps = 60000 / sum;
      if (this.fps < 50) {
        this.lowPerf = true;
        this.goodFrames = 0;
      } else if (this.lowPerf && this.fps > 57) {
        if (++this.goodFrames > 180) this.lowPerf = false;
      }
    }
    this.lastT = t;
    return this.lowPerf;
  }

  render(opts: RenderOptions, brush: BrushOverlay): void {
    const e = this.engine;
    const ctx = this.ctx;
    const W = e.cfg.worldW;
    const H = e.cfg.worldH;
    const d = this.dpr;
    const s = this.scale * d;
    const ox = this.ox * d;
    const oy = this.oy * d;
    this.frame++;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.globalCompositeOperation = "source-over";
    ctx.globalAlpha = 1;
    ctx.fillStyle = "#020307";
    ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

    /* 1. terrain cache */
    if (this.dirty) {
      this.painter.render(this.terrainCtx, e.grid, this.terrainScale, this.dirty);
      this.dirty = null;
    }
    ctx.setTransform(s, 0, 0, s, ox, oy);
    ctx.imageSmoothingEnabled = true;
    ctx.drawImage(this.terrain, 0, 0, W, H);

    /* 2. pheromone RGB mixer */
    e.grid.mixToRGBA(this.pherImage.data, 1);
    this.pherCtx.putImageData(this.pherImage, 0, 0);
    const gw = e.grid.cols * e.grid.cellSize;
    const gh = e.grid.rows * e.grid.cellSize;
    ctx.globalCompositeOperation = "screen";
    ctx.drawImage(this.pher, 0, 0, gw, gh);

    /* 3. bloom (1/4 res, every 2nd frame) */
    if (!this.lowPerf) {
      if (this.frame % 2 === 0) this.updateBloom(gw, gh);
      ctx.globalCompositeOperation = "lighter";
      ctx.globalAlpha = 0.5;
      ctx.drawImage(this.bloomSmall, 0, 0, W, H);
      ctx.globalAlpha = 0.22;
      ctx.drawImage(this.bloom, 0, 0, W, H);
      ctx.globalAlpha = 1;
    }
    ctx.globalCompositeOperation = "source-over";

    /* 4. corpses + crystals */
    this.drawCorpses(s, ox, oy);
    ctx.setTransform(s, 0, 0, s, ox, oy);
    this.drawCrystals(opts.time);

    /* 5. nest crater */
    this.drawNest(opts.time);

    /* 6. ants + predators */
    this.drawAnts(s, ox, oy, opts.cohortMode);
    this.drawPredators(s, ox, oy);
    ctx.setTransform(s, 0, 0, s, ox, oy);

    /* 7. arcs */
    this.drawArcs();

    /* 8. spores */
    this.drawSpores(opts.time, W, H);

    /* 9. brush ribbon */
    this.drawBrush(brush, opts.time);

    /* 10. vignette + grain */
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.globalCompositeOperation = "source-over";
    ctx.globalAlpha = 1;
    if (this.vignette) ctx.drawImage(this.vignette, 0, 0);
  }

  private updateBloom(gw: number, gh: number): void {
    const b = this.bloomCtx;
    const e = this.engine;
    b.setTransform(1, 0, 0, 1, 0, 0);
    b.globalCompositeOperation = "source-over";
    b.clearRect(0, 0, this.bloom.width, this.bloom.height);
    b.imageSmoothingEnabled = true;
    b.setTransform(0.25, 0, 0, 0.25, 0, 0);
    b.drawImage(this.pher, 0, 0, gw, gh);
    b.globalCompositeOperation = "lighter";
    const f = e.foods;
    for (let k = 0; k < MAX_FOOD_SOURCES; k++) {
      if (!f.active[k] || f.amount[k] < 1) continue;
      const r = 26 + 18 * Math.sqrt(f.amount[k] / Math.max(1, f.max[k]));
      b.drawImage(this.glowEmerald, f.x[k] - r, f.y[k] - r, r * 2, r * 2);
    }
    b.drawImage(this.glowCyan, e.nestX - 60, e.nestY - 60, 120, 120);
    const p = e.predators;
    for (let k = 0; k < MAX_PREDATORS; k++) if (p.active[k]) b.drawImage(this.glowAmber, p.x[k] - 30, p.y[k] - 30, 60, 60);
    const sc = this.bloomSmallCtx;
    sc.setTransform(1, 0, 0, 1, 0, 0);
    sc.clearRect(0, 0, this.bloomSmall.width, this.bloomSmall.height);
    sc.imageSmoothingEnabled = true;
    sc.drawImage(this.bloom, 0, 0, this.bloomSmall.width, this.bloomSmall.height);
  }

  private drawCorpses(s: number, ox: number, oy: number): void {
    const ctx = this.ctx;
    const c = this.engine.corpses;
    const size = CORPSE_WORLD;
    for (let k = 0; k < MAX_CORPSES; k++) {
      if (!c.active[k]) continue;
      const cos = Math.cos(c.rot[k]) * s;
      const sin = Math.sin(c.rot[k]) * s;
      ctx.globalAlpha = Math.min(1, c.ttl[k] / 20);
      ctx.setTransform(cos, sin, -sin, cos, ox + c.x[k] * s, oy + c.y[k] * s);
      ctx.drawImage(this.corpse, -size / 2, -size / 2, size, size);
    }
    ctx.globalAlpha = 1;
  }

  private drawCrystals(time: number): void {
    const ctx = this.ctx;
    const f = this.engine.foods;
    const fs = CRYSTAL_WORLD * SPRITE_SCALE;
    for (let k = 0; k < MAX_FOOD_SOURCES; k++) {
      if (!f.active[k]) continue;
      const frac = f.amount[k] / Math.max(1, f.max[k]);
      if (f.amount[k] < 1) {
        ctx.globalAlpha = 0.22;
        ctx.strokeStyle = "#50ff64";
        ctx.lineWidth = 1;
        ctx.setLineDash([3, 3]);
        ctx.beginPath();
        ctx.arc(f.x[k], f.y[k], FOOD_RADIUS, 0, TAU);
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.globalAlpha = 1;
        continue;
      }
      const size = CRYSTAL_WORLD * (0.42 + 0.58 * Math.sqrt(frac));
      const pulse = 1 + 0.03 * Math.sin(time * 2 + k);
      ctx.drawImage(this.crystals, f.variant[k] * fs, 0, fs, fs, f.x[k] - (size * pulse) / 2, f.y[k] - (size * pulse) / 2, size * pulse, size * pulse);
    }
  }

  private drawNest(time: number): void {
    const ctx = this.ctx;
    const e = this.engine;
    const x = e.nestX;
    const y = e.nestY;
    const R = NEST_RADIUS;
    ctx.save();
    ctx.translate(x, y);
    ctx.fillStyle = "rgba(2,3,7,0.85)";
    ctx.beginPath();
    ctx.arc(0, 0, R + 6, 0, TAU);
    ctx.fill();
    ctx.lineWidth = 1;
    for (let ring = 0; ring < 3; ring++) {
      ctx.strokeStyle = ring === 0 ? "rgba(45,212,191,0.85)" : `rgba(56,189,248,${0.45 - ring * 0.12})`;
      ctx.beginPath();
      ctx.arc(0, 0, R + 6 + ring * 7, 0, TAU);
      ctx.stroke();
    }
    // harmonic mandala
    ctx.rotate(time * 0.25);
    ctx.strokeStyle = "rgba(167,243,208,0.35)";
    ctx.beginPath();
    for (let k = 0; k < 12; k++) {
      const a = (k / 12) * TAU;
      ctx.moveTo(Math.cos(a) * 6, Math.sin(a) * 6);
      ctx.quadraticCurveTo(Math.cos(a + 0.4) * (R + 4), Math.sin(a + 0.4) * (R + 4), Math.cos(a + 0.8) * (R - 2), Math.sin(a + 0.8) * (R - 2));
    }
    ctx.stroke();
    ctx.rotate(-time * 0.25);
    // stored food arc
    const frac = (e.storedFood % 60) / 60;
    ctx.strokeStyle = "#ffa800";
    ctx.lineWidth = 2.5;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.arc(0, 0, R + 13, -Math.PI / 2, -Math.PI / 2 + frac * TAU);
    ctx.stroke();
    // larval pods
    const pods = Math.min(12, e.deliveredSinceBirth * 4 + 3);
    ctx.fillStyle = "rgba(255,243,196,0.85)";
    for (let k = 0; k < pods; k++) {
      const a = (k / 12) * TAU - time * 0.1;
      ctx.beginPath();
      ctx.ellipse(Math.cos(a) * (R - 6), Math.sin(a) * (R - 6), 2.4, 1.4, a, 0, TAU);
      ctx.fill();
    }
    ctx.fillStyle = "#e0fbff";
    ctx.beginPath();
    ctx.arc(0, 0, 3.5 + Math.sin(time * 3) * 0.6, 0, TAU);
    ctx.fill();
    ctx.font = "600 9px ui-sans-serif, system-ui";
    ctx.textAlign = "center";
    ctx.fillStyle = "rgba(224,251,255,0.9)";
    ctx.fillText(`GEN ${e.colonyGeneration}`, 0, R + 34);
    // graveyard marker
    ctx.restore();
    ctx.strokeStyle = "rgba(148,163,184,0.25)";
    ctx.setLineDash([2, 4]);
    ctx.beginPath();
    ctx.arc(e.graveX, e.graveY, 22, 0, TAU);
    ctx.stroke();
    ctx.setLineDash([]);
  }

  private drawAnts(s: number, ox: number, oy: number, cohort: boolean): void {
    const ctx = this.ctx;
    const a = this.engine.ants;
    const atlas = cohort ? this.atlases.cohort : this.atlases.caste;
    const fp = this.atlases.framePx;
    const size = ANT_FRAME_WORLD;
    const half = size / 2;
    const hi = this.engine.hi;
    for (let i = 0; i < hi; i++) {
      if (!a.active[i]) continue;
      const st = a.state[i];
      let row: number;
      if (cohort) row = st === ST_ALARMED || st === ST_DEFENDING ? 3 : a.policyType[i] === POLICY_TRAINED ? 0 : a.policyType[i] === POLICY_RANDOM ? 1 : 2;
      else row = st === ST_ALARMED || st === ST_DEFENDING ? 3 : a.caste[i];
      const frame = ((a.legPhase[i] / TAU) * ANT_FRAMES) & (ANT_FRAMES - 1);
      const cos = Math.cos(a.angle[i]) * s;
      const sin = Math.sin(a.angle[i]) * s;
      ctx.setTransform(cos, sin, -sin, cos, ox + a.x[i] * s, oy + a.y[i] * s);
      ctx.drawImage(atlas, frame * fp, row * fp, fp, fp, -half, -half, size, size);
    }
    // carried crystal crumbs (batched)
    ctx.setTransform(s, 0, 0, s, ox, oy);
    ctx.fillStyle = "#7dffb6";
    ctx.beginPath();
    for (let i = 0; i < hi; i++) {
      if (!a.active[i] || a.carryingFood[i] === 0) continue;
      const cx = a.x[i] + Math.cos(a.angle[i]) * 6.5;
      const cy = a.y[i] + Math.sin(a.angle[i]) * 6.5;
      ctx.rect(cx - 1.3, cy - 1.3, 2.6, 2.6);
    }
    ctx.fill();
  }

  private drawPredators(s: number, ox: number, oy: number): void {
    const ctx = this.ctx;
    const p = this.engine.predators;
    const fp = PREDATOR_FRAME_WORLD * SPRITE_SCALE;
    const size = PREDATOR_FRAME_WORLD;
    for (let k = 0; k < MAX_PREDATORS; k++) {
      if (!p.active[k]) continue;
      const frame = Math.floor((p.legPhase[k] / TAU) * PREDATOR_FRAMES) % PREDATOR_FRAMES;
      const cos = Math.cos(p.angle[k]) * s;
      const sin = Math.sin(p.angle[k]) * s;
      ctx.setTransform(cos, sin, -sin, cos, ox + p.x[k] * s, oy + p.y[k] * s);
      ctx.drawImage(this.predatorAtlas, frame * fp, 0, fp, fp, -size / 2, -size / 2, size, size);
      ctx.setTransform(s, 0, 0, s, ox, oy);
      const hp = Math.max(0, p.hp[k] / p.maxHp[k]);
      ctx.lineWidth = 2;
      ctx.strokeStyle = "rgba(255,255,255,0.12)";
      ctx.beginPath();
      ctx.arc(p.x[k], p.y[k], 21, 0, TAU);
      ctx.stroke();
      ctx.strokeStyle = p.hitFlash[k] > 0 ? "#ffffff" : hp > 0.4 ? "#ff0c4b" : "#ffb020";
      ctx.beginPath();
      ctx.arc(p.x[k], p.y[k], 21, -Math.PI / 2, -Math.PI / 2 + hp * TAU);
      ctx.stroke();
    }
  }

  private drawArcs(): void {
    const ctx = this.ctx;
    const r = this.engine.arcs;
    ctx.globalCompositeOperation = "lighter";
    ctx.lineCap = "round";
    for (let pass = 0; pass < 2; pass++) {
      for (let k = 0; k < MAX_ARCS; k++) {
        if (r.ttl[k] === 0) continue;
        const t = r.type[k];
        const alpha = r.ttl[k] / 3;
        if (pass === 0) {
          ctx.lineWidth = 3;
          ctx.strokeStyle = t === ARC_COMBAT ? `rgba(255,12,75,${0.25 * alpha})` : t === ARC_TANDEM ? `rgba(175,50,255,${0.3 * alpha})` : `rgba(0,230,118,${0.3 * alpha})`;
        } else {
          ctx.lineWidth = 0.9;
          ctx.strokeStyle = t === ARC_COMBAT ? `rgba(255,214,224,${alpha})` : t === ARC_TANDEM ? `rgba(103,232,249,${alpha})` : `rgba(255,214,102,${alpha})`;
        }
        const mx = (r.x1[k] + r.x2[k]) / 2 + (r.y2[k] - r.y1[k]) * 0.25;
        const my = (r.y1[k] + r.y2[k]) / 2 - (r.x2[k] - r.x1[k]) * 0.25;
        ctx.beginPath();
        ctx.moveTo(r.x1[k], r.y1[k]);
        ctx.quadraticCurveTo(mx, my, r.x2[k], r.y2[k]);
        ctx.stroke();
      }
    }
    ctx.globalCompositeOperation = "source-over";
  }

  private drawSpores(time: number, W: number, H: number): void {
    const ctx = this.ctx;
    const sp = this.spores;
    ctx.globalCompositeOperation = "lighter";
    for (let k = 0; k < SPORES; k++) {
      const o = k * 5;
      const depth = sp[o + 2];
      sp[o] += Math.sin(time * 0.3 + sp[o + 3]) * 0.12 * depth + 0.05 * depth;
      sp[o + 1] -= 0.08 * depth;
      if (sp[o] > W + 10) sp[o] = -10;
      if (sp[o + 1] < -10) sp[o + 1] = H + 10;
      const tw = 0.35 + 0.65 * (0.5 + 0.5 * Math.sin(time * 1.3 + sp[o + 3] * 3));
      const size = sp[o + 4] * 3 * depth;
      ctx.globalAlpha = tw * 0.5 * depth;
      ctx.drawImage(this.glowSpore, sp[o] - size, sp[o + 1] - size, size * 2, size * 2);
    }
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = "source-over";
  }

  private drawBrush(b: BrushOverlay, time: number): void {
    const ctx = this.ctx;
    const age = time - b.startT;
    if (age < 0.5) {
      const rr = b.radius * (0.6 + age * 3);
      ctx.strokeStyle = `rgba(${b.rgb},${(0.5 - age) * 1.6})`;
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(b.startX, b.startY, rr, 0, TAU);
      ctx.stroke();
    }
    if (b.active && b.count > 1 && b.mode !== "erase") {
      ctx.lineCap = "round";
      ctx.lineJoin = "round";
      const widths = [b.radius * 1.6, b.radius * 0.7, 1.6];
      const styles = [`rgba(${b.rgb},0.14)`, `rgba(${b.rgb},0.45)`, "rgba(255,255,255,0.95)"];
      ctx.globalCompositeOperation = "lighter";
      for (let p = 0; p < 3; p++) {
        ctx.lineWidth = widths[p];
        ctx.strokeStyle = styles[p];
        ctx.beginPath();
        ctx.moveTo(b.xs[0], b.ys[0]);
        for (let k = 1; k < b.count; k++) ctx.lineTo(b.xs[k], b.ys[k]);
        ctx.stroke();
      }
      ctx.globalCompositeOperation = "source-over";
    }
    if (b.hasCursor) {
      if (b.mode === "erase") {
        ctx.save();
        ctx.translate(b.cursorX, b.cursorY);
        ctx.rotate(time * 1.4);
        ctx.setLineDash([5, 4]);
        ctx.strokeStyle = "rgba(226,232,240,0.85)";
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.arc(0, 0, b.radius, 0, TAU);
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.restore();
      } else {
        ctx.strokeStyle = `rgba(${b.rgb},0.9)`;
        ctx.lineWidth = 1.4;
        ctx.beginPath();
        ctx.arc(b.cursorX, b.cursorY, b.radius, 0, TAU);
        ctx.stroke();
      }
    }
  }
}
