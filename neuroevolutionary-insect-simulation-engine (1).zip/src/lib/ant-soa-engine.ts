/*
 * Zero-allocation Structure-of-Arrays ant colony engine (MAX_ANTS = 3000), fixed dt = 1/60.
 * Shared Colony Brain forward pass / Hand-Crafted ACO / Random MLP policies, Int32Array spatial hash (24px),
 * mortality + necrophoresis + generations, trophallaxis, tandem running, dead-end sealing, optional predators.
 */
import { PheromoneGrid, type DirtyRect } from "./pheromone-grid";
import { Mulberry32, XorShift32 } from "./prng-noise";
import { forwardBrain, IN_CARRY, IN_ENERGY, IN_HOME_X, IN_HOME_Y, IN_MEM_A, IN_MEM_B, IN_WALL_C, IN_WALL_L, IN_WALL_R } from "./neat";
import {
  ARC_COMBAT,
  ARC_TANDEM,
  ARC_TROPHALLAXIS,
  BRAIN_HIDDEN,
  BRAIN_INPUTS,
  BRAIN_OUTPUTS,
  CASTE_HAULER,
  CASTE_SCOUT,
  CASTE_WARDEN,
  CHANNEL_COUNT,
  CH_ALARM,
  CH_FOOD,
  CH_HOME,
  CH_NOENTRY,
  CH_SCOUT,
  MAX_ANTS,
  MAX_ARCS,
  MAX_CORPSES,
  MAX_FOOD_SOURCES,
  MAX_PREDATORS,
  POLICY_ACO,
  POLICY_RANDOM,
  POLICY_TRAINED,
  ST_ALARMED,
  ST_DEAD,
  ST_DEFENDING,
  ST_FORAGING,
  ST_NECROPHORESIS,
  ST_RETURNING,
  ST_TANDEM_FOLLOW,
  ST_TRAIL_DAMPING,
  type AblationMask,
  type AntSoA,
  type ArcData,
  type ArenaMode,
  type Brain,
  type CorpseData,
  type FoodSourceData,
  type PredatorData,
  type PresetLayout,
  type SimConfig,
  type Telemetry,
  type WallStroke,
} from "./types";

export const DT = 1 / 60;
const SQRT_DT = Math.sqrt(DT);
export const BASE_SPEED = 52;
const MAX_TURN = 4.6;
const SENSOR_DIST = 10;
const SENSOR_ANGLE = 0.62;
export const NEST_RADIUS = 20;
export const FOOD_RADIUS = 11;
export const HASH_CELL = 24;
const ALARM_TRIGGER = 6;
export const DANGER_RADIUS = 75;
const LOG_NORM = 1 / Math.log(101);
const DEPOSIT_RATE: readonly number[] = [55, 40, 30, 34, 36];
const CASTE_SPEED: readonly number[] = [1.15, 0.95, 0.9];
const TRAIL_TAU = 1 / 22;
const PREDATOR_SPEED = 44;
const PREDATOR_HP = 60;
const GRAVE_RADIUS = 26;

export interface EngineStats {
  foodDelivered: number;
  pickups: number;
  effSum: number;
  wallScrapes: number;
  spin: number;
  trophallaxis: number;
  defense: number;
  deaths: number;
  predatorKills: number;
  tandem: number;
  sealed: number;
}

function f32(n: number): Float32Array {
  return new Float32Array(n);
}

function clamp1(v: number): number {
  return v > 1 ? 1 : v < -1 ? -1 : v;
}

export class AntEngine {
  cfg: SimConfig;
  grid: PheromoneGrid;
  readonly ants: AntSoA;
  readonly stateTimer = f32(MAX_ANTS);
  readonly foods: FoodSourceData;
  readonly predators: PredatorData;
  readonly predTarget = new Int32Array(MAX_PREDATORS).fill(-1);
  readonly corpses: CorpseData;
  readonly arcs: ArcData;
  arcHead = 0;
  nestX = 0;
  nestY = 0;
  graveX = 0;
  graveY = 0;
  brain: Brain;
  randomBrain: Brain;
  piMuted = false;
  hi = 0;
  alive = 0;
  tick = 0;
  colonyGeneration = 1;
  births = 0;
  totalDeaths = 0;
  storedFood = 0;
  deliveredSinceBirth = 0;
  bottlenecks = 0;
  graveyardCount = 0;
  traitSpeed = 1;
  traitNoise = 1;
  mutationBoost = 1;
  readonly cohortDelivered = new Float64Array(3);
  readonly stats: EngineStats = { foodDelivered: 0, pickups: 0, effSum: 0, wallScrapes: 0, spin: 0, trophallaxis: 0, defense: 0, deaths: 0, predatorKills: 0, tandem: 0, sealed: 0 };
  readonly telemetry: Telemetry;
  foodCell: Int16Array;

  private rng: Mulberry32;
  private xr: XorShift32;
  private freeStack = new Int32Array(MAX_ANTS);
  private freeTop = 0;
  private corpseCursor = 0;
  private bottleneckCooldown = 0;
  private predatorRespawn = 0;
  readonly hashCols: number;
  readonly hashRows: number;
  readonly cellStart: Int32Array;
  readonly cellCount: Int32Array;
  readonly cellItems = new Int32Array(MAX_ANTS);
  private readonly input = f32(BRAIN_INPUTS);
  private readonly output = f32(BRAIN_OUTPUTS);
  private readonly hidden = f32(BRAIN_HIDDEN);
  private readonly sensGrad = f32(CHANNEL_COUNT);
  private readonly sensCenter = f32(CHANNEL_COUNT);

  constructor(cfg: SimConfig, brain: Brain, randomBrain: Brain, layout?: PresetLayout) {
    this.cfg = cfg;
    this.brain = brain;
    this.randomBrain = randomBrain;
    this.grid = new PheromoneGrid(cfg.worldW, cfg.worldH);
    this.grid.params = { ...cfg.pheromone };
    this.foodCell = new Int16Array(this.grid.size).fill(-1);
    this.rng = new Mulberry32(cfg.seed);
    this.xr = new XorShift32(cfg.seed ^ 0xa5a5a5);
    this.ants = {
      x: f32(MAX_ANTS), y: f32(MAX_ANTS), vx: f32(MAX_ANTS), vy: f32(MAX_ANTS), angle: f32(MAX_ANTS),
      homeDx: f32(MAX_ANTS), homeDy: f32(MAX_ANTS), targetX: f32(MAX_ANTS), targetY: f32(MAX_ANTS),
      legPhase: f32(MAX_ANTS), pheromoneTimer: f32(MAX_ANTS), timeSinceLastVisit: f32(MAX_ANTS), ouNoise: f32(MAX_ANTS),
      energy: f32(MAX_ANTS), age: f32(MAX_ANTS), maxLifespan: f32(MAX_ANTS), fitness: f32(MAX_ANTS),
      memA: f32(MAX_ANTS), memB: f32(MAX_ANTS), tripDist: f32(MAX_ANTS), speedTrait: f32(MAX_ANTS), noiseTrait: f32(MAX_ANTS),
      stall: f32(MAX_ANTS), steer: f32(MAX_ANTS), speedOut: f32(MAX_ANTS), emit: f32(MAX_ANTS * CHANNEL_COUNT),
      state: new Uint8Array(MAX_ANTS), caste: new Uint8Array(MAX_ANTS), policyType: new Uint8Array(MAX_ANTS),
      carryingFood: new Uint8Array(MAX_ANTS), active: new Uint8Array(MAX_ANTS), hasTarget: new Uint8Array(MAX_ANTS),
      carryCorpse: new Int16Array(MAX_ANTS).fill(-1), generation: new Uint16Array(MAX_ANTS),
    };
    this.foods = { x: f32(MAX_FOOD_SOURCES), y: f32(MAX_FOOD_SOURCES), amount: f32(MAX_FOOD_SOURCES), max: f32(MAX_FOOD_SOURCES), variant: new Uint8Array(MAX_FOOD_SOURCES), active: new Uint8Array(MAX_FOOD_SOURCES), sealed: new Uint8Array(MAX_FOOD_SOURCES) };
    this.predators = { x: f32(MAX_PREDATORS), y: f32(MAX_PREDATORS), angle: f32(MAX_PREDATORS), hp: f32(MAX_PREDATORS), maxHp: f32(MAX_PREDATORS), cooldown: f32(MAX_PREDATORS), legPhase: f32(MAX_PREDATORS), hitFlash: f32(MAX_PREDATORS), active: new Uint8Array(MAX_PREDATORS) };
    this.corpses = { x: f32(MAX_CORPSES), y: f32(MAX_CORPSES), rot: f32(MAX_CORPSES), ttl: f32(MAX_CORPSES), carrier: new Int16Array(MAX_CORPSES).fill(-1), active: new Uint8Array(MAX_CORPSES) };
    this.arcs = { x1: f32(MAX_ARCS), y1: f32(MAX_ARCS), x2: f32(MAX_ARCS), y2: f32(MAX_ARCS), type: new Uint8Array(MAX_ARCS), ttl: new Uint8Array(MAX_ARCS) };
    this.hashCols = Math.ceil(cfg.worldW / HASH_CELL);
    this.hashRows = Math.ceil(cfg.worldH / HASH_CELL);
    this.cellStart = new Int32Array(this.hashCols * this.hashRows + 1);
    this.cellCount = new Int32Array(this.hashCols * this.hashRows);
    this.telemetry = { alive: 0, deaths: 0, births: 0, foodDelivered: 0, storedFood: 0, colonyGeneration: 1, predators: 0, simTime: 0, tick: 0, cohortTrained: 0, cohortOther: 0, bottlenecks: 0, foodRemaining: 0 };
    this.setAblation(cfg.ablation);
    this.reset(layout);
  }

  /* ------------------------------ setup ------------------------------ */

  reset(layout?: PresetLayout): void {
    const a = this.ants;
    a.active.fill(0);
    a.state.fill(ST_DEAD);
    a.carryCorpse.fill(-1);
    this.freeTop = 0;
    for (let i = MAX_ANTS - 1; i >= 0; i--) this.freeStack[this.freeTop++] = i;
    this.hi = 0;
    this.alive = 0;
    this.tick = 0;
    this.colonyGeneration = 1;
    this.births = 0;
    this.totalDeaths = 0;
    this.storedFood = 0;
    this.deliveredSinceBirth = 0;
    this.bottlenecks = 0;
    this.graveyardCount = 0;
    this.mutationBoost = 1;
    this.cohortDelivered.fill(0);
    const s = this.stats;
    s.foodDelivered = s.pickups = s.effSum = s.wallScrapes = s.spin = s.trophallaxis = s.defense = s.deaths = s.predatorKills = s.tandem = s.sealed = 0;
    this.foods.active.fill(0);
    this.foods.amount.fill(0);
    this.foodCell.fill(-1);
    this.predators.active.fill(0);
    this.corpses.active.fill(0);
    this.corpses.carrier.fill(-1);
    this.arcs.ttl.fill(0);
    this.grid.clear();
    this.rng.reseed(this.cfg.seed);
    if (layout) this.applyLayout(layout);
    else {
      this.nestX = this.cfg.worldW / 2;
      this.nestY = this.cfg.worldH / 2;
      this.graveX = 30;
      this.graveY = 30;
    }
    for (let k = 0; k < this.cfg.initialAnts; k++) this.hatch(false);
    for (let p = 0; p < this.cfg.predatorCount; p++) this.spawnPredator();
    this.updateTelemetry();
  }

  applyLayout(layout: PresetLayout): void {
    this.grid.clearWalls();
    for (const w of layout.walls) this.stampStroke(w, true);
    for (const w of layout.carve) this.stampStroke(w, false);
    this.nestX = layout.nest.x;
    this.nestY = layout.nest.y;
    this.graveX = layout.graveyard.x;
    this.graveY = layout.graveyard.y;
    this.grid.setWallCircle(this.nestX, this.nestY, 42, false);
    for (const f of layout.foods) this.addFood(f.x, f.y, f.amount);
  }

  stampStroke(w: WallStroke, on: boolean): void {
    if (w.kind === "circle") {
      this.grid.setWallCircle(w.x, w.y, w.r, on);
      return;
    }
    const len = Math.hypot(w.x2 - w.x1, w.y2 - w.y1);
    const steps = Math.max(1, Math.ceil(len / Math.max(2, w.r * 0.5)));
    for (let k = 0; k <= steps; k++) {
      const t = k / steps;
      this.grid.setWallCircle(w.x1 + (w.x2 - w.x1) * t, w.y1 + (w.y2 - w.y1) * t, w.r, on);
    }
  }

  setBrain(brain: Brain): void {
    this.brain = brain;
  }

  setAblation(mask: AblationMask): void {
    this.cfg.ablation = { channels: [...mask.channels] as AblationMask["channels"], pathIntegration: mask.pathIntegration };
    for (let c = 0; c < CHANNEL_COUNT; c++) {
      const m = mask.channels[c] ? 1 : 0;
      if (this.grid.muted[c] !== m) this.grid.setMuted(c, m === 1);
    }
    this.piMuted = mask.pathIntegration;
  }

  setPheromoneParams(evaporation: number, diffusion: number, reactionRate: number): void {
    this.cfg.pheromone = { evaporation, diffusion, reactionRate };
    this.grid.params = { evaporation, diffusion, reactionRate };
  }

  policyFor(slot: number): number {
    switch (this.cfg.arena) {
      case "trained":
        return POLICY_TRAINED;
      case "aco":
        return POLICY_ACO;
      case "ab-random":
        return slot % 2 === 0 ? POLICY_TRAINED : POLICY_RANDOM;
      case "ab-aco":
        return slot % 2 === 0 ? POLICY_TRAINED : POLICY_ACO;
    }
  }

  setArena(mode: ArenaMode): void {
    this.cfg.arena = mode;
    for (let i = 0; i < this.hi; i++) if (this.ants.active[i]) this.ants.policyType[i] = this.policyFor(i);
    this.cohortDelivered.fill(0);
  }

  /* ------------------------------ entities ------------------------------ */

  hatch(boosted: boolean): number {
    if (this.freeTop === 0) return -1;
    const i = this.freeStack[--this.freeTop];
    const a = this.ants;
    const r = this.rng;
    const ang = r.range(0, Math.PI * 2);
    const d = r.range(0, NEST_RADIUS * 0.7);
    a.x[i] = this.nestX + Math.cos(ang) * d;
    a.y[i] = this.nestY + Math.sin(ang) * d;
    a.angle[i] = ang;
    a.vx[i] = 0;
    a.vy[i] = 0;
    a.homeDx[i] = this.nestX - a.x[i];
    a.homeDy[i] = this.nestY - a.y[i];
    a.targetX[i] = 0;
    a.targetY[i] = 0;
    a.hasTarget[i] = 0;
    a.legPhase[i] = r.range(0, Math.PI * 2);
    a.pheromoneTimer[i] = 0;
    a.timeSinceLastVisit[i] = 0;
    a.ouNoise[i] = 0;
    a.energy[i] = 100;
    a.age[i] = 0;
    a.maxLifespan[i] = r.range(150, 240) * this.cfg.lifespanScale;
    a.fitness[i] = 0;
    a.memA[i] = 0;
    a.memB[i] = 0;
    a.tripDist[i] = 0;
    a.stall[i] = 0;
    a.steer[i] = 0;
    a.speedOut[i] = 0.8;
    for (let c = 0; c < CHANNEL_COUNT; c++) a.emit[i * CHANNEL_COUNT + c] = 0;
    const sigma = 0.06 * (boosted ? 2.5 : 1) * this.mutationBoost;
    a.speedTrait[i] = Math.min(1.35, Math.max(0.7, this.traitSpeed + r.gauss() * sigma));
    a.noiseTrait[i] = Math.min(1.6, Math.max(0.5, this.traitNoise + r.gauss() * sigma * 2));
    const roll = r.next();
    a.caste[i] = roll < 0.2 ? CASTE_SCOUT : roll < 0.8 ? CASTE_HAULER : CASTE_WARDEN;
    a.state[i] = ST_FORAGING;
    a.carryingFood[i] = 0;
    a.carryCorpse[i] = -1;
    a.policyType[i] = this.policyFor(i);
    a.generation[i] = this.colonyGeneration;
    a.active[i] = 1;
    this.stateTimer[i] = 0;
    if (i + 1 > this.hi) this.hi = i + 1;
    this.alive++;
    return i;
  }

  killAnt(i: number): void {
    const a = this.ants;
    if (!a.active[i]) return;
    a.active[i] = 0;
    a.state[i] = ST_DEAD;
    a.carryingFood[i] = 0;
    const cc = a.carryCorpse[i];
    if (cc >= 0) this.corpses.carrier[cc] = -1;
    a.carryCorpse[i] = -1;
    this.freeStack[this.freeTop++] = i;
    this.alive--;
    this.totalDeaths++;
    this.stats.deaths++;
    this.spawnCorpse(a.x[i], a.y[i], a.angle[i]);
  }

  spawnCorpse(x: number, y: number, rot: number): void {
    const c = this.corpses;
    let slot = -1;
    for (let k = 0; k < MAX_CORPSES; k++) {
      const s = (this.corpseCursor + k) % MAX_CORPSES;
      if (!c.active[s]) {
        slot = s;
        break;
      }
    }
    if (slot < 0) slot = this.corpseCursor;
    this.corpseCursor = (slot + 1) % MAX_CORPSES;
    if (c.carrier[slot] >= 0) this.ants.carryCorpse[c.carrier[slot]] = -1;
    c.x[slot] = x;
    c.y[slot] = y;
    c.rot[slot] = rot;
    c.ttl[slot] = 120;
    c.carrier[slot] = -1;
    c.active[slot] = 1;
  }

  addFood(x: number, y: number, amount: number): number {
    const f = this.foods;
    let slot = -1;
    for (let k = 0; k < MAX_FOOD_SOURCES; k++) if (!f.active[k]) {
      slot = k;
      break;
    }
    if (slot < 0) return -1;
    if (this.grid.isWallAt(x, y)) this.grid.setWallCircle(x, y, FOOD_RADIUS + 6, false);
    f.x[slot] = x;
    f.y[slot] = y;
    f.amount[slot] = amount;
    f.max[slot] = amount;
    f.variant[slot] = this.rng.int(8);
    f.active[slot] = 1;
    f.sealed[slot] = 0;
    this.stampFood(slot, slot);
    return slot;
  }

  private stampFood(slot: number, value: number): void {
    const g = this.grid;
    const r = FOOD_RADIUS;
    const x = this.foods.x[slot];
    const y = this.foods.y[slot];
    for (let dy = -r; dy <= r; dy += 3) {
      for (let dx = -r; dx <= r; dx += 3) {
        if (dx * dx + dy * dy > r * r) continue;
        const px = x + dx;
        const py = y + dy;
        if (px < 0 || py < 0 || px >= g.worldW || py >= g.worldH) continue;
        const i = g.index(px, py);
        if (value >= 0 || this.foodCell[i] === slot) this.foodCell[i] = value;
      }
    }
  }

  removeFoodNear(x: number, y: number, r: number): number {
    let removed = 0;
    const f = this.foods;
    for (let k = 0; k < MAX_FOOD_SOURCES; k++) {
      if (!f.active[k]) continue;
      const dx = f.x[k] - x;
      const dy = f.y[k] - y;
      if (dx * dx + dy * dy < (r + FOOD_RADIUS) * (r + FOOD_RADIUS)) {
        this.stampFood(k, -1);
        f.active[k] = 0;
        removed++;
      }
    }
    return removed;
  }

  eraseAt(x: number, y: number, r: number): void {
    this.grid.eraseRadius(x, y, r);
    this.removeFoodNear(x, y, r);
    const c = this.corpses;
    for (let k = 0; k < MAX_CORPSES; k++) {
      if (!c.active[k] || c.carrier[k] >= 0) continue;
      const dx = c.x[k] - x;
      const dy = c.y[k] - y;
      if (dx * dx + dy * dy < r * r) c.active[k] = 0;
    }
  }

  paintWall(x: number, y: number, r: number, on: boolean): DirtyRect {
    if (on) {
      const dn = Math.hypot(x - this.nestX, y - this.nestY);
      if (dn < NEST_RADIUS + r + 8) return { x0: x, y0: y, x1: x, y1: y };
    }
    return this.grid.setWallCircle(x, y, r, on);
  }

  spawnPredator(x?: number, y?: number): number {
    const p = this.predators;
    let slot = -1;
    for (let k = 0; k < MAX_PREDATORS; k++) if (!p.active[k]) {
      slot = k;
      break;
    }
    if (slot < 0) return -1;
    let px = x ?? 0;
    let py = y ?? 0;
    if (x === undefined || y === undefined) {
      for (let tries = 0; tries < 40; tries++) {
        const edge = this.rng.int(4);
        const W = this.cfg.worldW;
        const H = this.cfg.worldH;
        px = edge === 0 ? 24 : edge === 1 ? W - 24 : this.rng.range(24, W - 24);
        py = edge === 2 ? 24 : edge === 3 ? H - 24 : this.rng.range(24, H - 24);
        if (!this.grid.isWallAt(px, py) && Math.hypot(px - this.nestX, py - this.nestY) > 120) break;
      }
    }
    p.x[slot] = px;
    p.y[slot] = py;
    p.angle[slot] = Math.atan2(this.nestY - py, this.nestX - px);
    p.hp[slot] = PREDATOR_HP;
    p.maxHp[slot] = PREDATOR_HP;
    p.cooldown[slot] = 1.5;
    p.legPhase[slot] = 0;
    p.hitFlash[slot] = 0;
    p.active[slot] = 1;
    this.predTarget[slot] = -1;
    return slot;
  }

  activePredators(): number {
    let n = 0;
    for (let k = 0; k < MAX_PREDATORS; k++) n += this.predators.active[k];
    return n;
  }

  clearTrails(): void {
    this.grid.clear();
  }

  private addArc(x1: number, y1: number, x2: number, y2: number, type: number): void {
    const k = this.arcHead;
    const r = this.arcs;
    r.x1[k] = x1;
    r.y1[k] = y1;
    r.x2[k] = x2;
    r.y2[k] = y2;
    r.type[k] = type;
    r.ttl[k] = 3;
    this.arcHead = (k + 1) % MAX_ARCS;
  }

  /* ------------------------------ sensing + policy ------------------------------ */

  private ray(x: number, y: number, c: number, s: number): number {
    const g = this.grid;
    for (let k = 1; k <= 4; k++) {
      if (g.isWallAt(x + c * 6 * k, y + s * 6 * k)) return 1 - (k - 1) * 0.25;
    }
    return 0;
  }

  private steerToward(i: number, tx: number, ty: number): number {
    const a = this.ants;
    const dx = tx - a.x[i];
    const dy = ty - a.y[i];
    const ca = Math.cos(a.angle[i]);
    const sa = Math.sin(a.angle[i]);
    const d = Math.hypot(dx, dy) + 1e-4;
    const fwd = (dx * ca + dy * sa) / d;
    const lat = (-dx * sa + dy * ca) / d;
    if (fwd < 0) return lat >= 0 ? 1 : -1;
    return clamp1(lat * 2.2);
  }

  private think(i: number): void {
    const a = this.ants;
    const g = this.grid;
    const inp = this.input;
    const x = a.x[i];
    const y = a.y[i];
    const ang = a.angle[i];
    const ca = Math.cos(ang);
    const sa = Math.sin(ang);
    const cl = Math.cos(ang - SENSOR_ANGLE);
    const sl = Math.sin(ang - SENSOR_ANGLE);
    const cr = Math.cos(ang + SENSOR_ANGLE);
    const sr = Math.sin(ang + SENSOR_ANGLE);
    const li = g.index(x + cl * SENSOR_DIST, y + sl * SENSOR_DIST);
    const ri = g.index(x + cr * SENSOR_DIST, y + sr * SENSOR_DIST);
    const ci = g.index(x + ca * SENSOR_DIST * 0.8, y + sa * SENSOR_DIST * 0.8);
    for (let c = 0; c < CHANNEL_COUNT; c++) {
      if (g.muted[c] === 1) {
        inp[c] = 0;
        inp[5 + c] = 0;
        this.sensGrad[c] = 0;
        this.sensCenter[c] = 0;
        continue;
      }
      const arr = g.front[c];
      const L = Math.log1p(arr[li]);
      const R = Math.log1p(arr[ri]);
      const C = arr[ci];
      inp[c] = R - L;
      inp[5 + c] = Math.log1p(C) * LOG_NORM;
      this.sensGrad[c] = R - L;
      this.sensCenter[c] = C;
    }
    inp[IN_WALL_L] = this.ray(x, y, cl, sl);
    inp[IN_WALL_C] = this.ray(x, y, ca, sa);
    inp[IN_WALL_R] = this.ray(x, y, cr, sr);
    if (this.piMuted) {
      inp[IN_HOME_X] = 0;
      inp[IN_HOME_Y] = 0;
    } else {
      const hx = a.homeDx[i];
      const hy = a.homeDy[i];
      const d = Math.hypot(hx, hy) + 1e-3;
      inp[IN_HOME_X] = (hx * ca + hy * sa) / d;
      inp[IN_HOME_Y] = (-hx * sa + hy * ca) / d;
    }
    const carry = a.carryingFood[i] === 1;
    inp[IN_CARRY] = carry ? 1 : -1;
    inp[IN_ENERGY] = a.energy[i] * 0.01;
    inp[IN_MEM_A] = a.memA[i];
    inp[IN_MEM_B] = a.memB[i];

    const out = this.output;
    const pol = a.policyType[i];
    if (pol === POLICY_ACO) this.acoPolicy(i, carry, out);
    else forwardBrain(pol === POLICY_TRAINED ? this.brain : this.randomBrain, inp, out, this.hidden);

    let steer = out[0];
    let speed = out[1];
    a.memA[i] = out[7];
    a.memB[i] = out[8];
    const eb = i * CHANNEL_COUNT;
    for (let c = 0; c < CHANNEL_COUNT; c++) a.emit[eb + c] = out[2 + c];
    if (steer > 0.95 || steer < -0.95) this.stats.spin++;

    /* ---- innate reflex layer (shared by all policies; driven by masked sensors) ---- */
    const st = a.state[i];
    const alarmC = this.sensCenter[CH_ALARM];
    if (st !== ST_NECROPHORESIS && st !== ST_TRAIL_DAMPING && alarmC > ALARM_TRIGGER) {
      if (a.caste[i] === CASTE_WARDEN && !carry) {
        a.state[i] = ST_DEFENDING;
        steer = clamp1(2.6 * this.sensGrad[CH_ALARM]);
        speed = 1;
      } else {
        a.state[i] = ST_ALARMED;
        const homeLat = this.piMuted ? clamp1(2 * this.sensGrad[CH_HOME]) : inp[IN_HOME_Y];
        steer = clamp1(0.35 * steer - 2.2 * this.sensGrad[CH_ALARM] * 0.7 + homeLat * 0.7);
        speed = 1;
      }
    } else if (st === ST_ALARMED || st === ST_DEFENDING) {
      if (alarmC < ALARM_TRIGGER * 0.5) a.state[i] = carry ? ST_RETURNING : ST_FORAGING;
    } else if (st === ST_TANDEM_FOLLOW) {
      steer = clamp1(0.3 * steer + 0.9 * this.steerToward(i, a.targetX[i], a.targetY[i]));
      speed = Math.max(speed, 0.85);
      if (g.muted[CH_SCOUT] === 1) a.state[i] = ST_FORAGING;
    } else if (st === ST_NECROPHORESIS) {
      steer = this.steerToward(i, this.graveX, this.graveY);
      speed = 0.8;
    } else if (st === ST_TRAIL_DAMPING) {
      a.emit[eb + CH_NOENTRY] = 1;
      a.emit[eb + CH_FOOD] = 0;
      speed = 1;
    }
    if (!carry && st !== ST_TRAIL_DAMPING && this.sensCenter[CH_NOENTRY] > 4) steer = clamp1(steer - 1.6 * this.sensGrad[CH_NOENTRY]);
    if (a.caste[i] === CASTE_SCOUT && carry && a.hasTarget[i] === 1) a.emit[eb + CH_SCOUT] = Math.max(a.emit[eb + CH_SCOUT], 0.6);
    a.steer[i] = steer;
    a.speedOut[i] = speed < 0 ? 0 : speed > 1 ? 1 : speed;
  }

  /** Hand-crafted classical stigmergic ACO (no path integration). */
  private acoPolicy(i: number, carry: boolean, out: Float32Array): void {
    const inp = this.input;
    const g = carry ? inp[CH_HOME] : inp[CH_FOOD];
    const has = carry ? inp[5 + CH_HOME] : inp[5 + CH_FOOD];
    let steer = has > 0.02 ? clamp1(2.6 * g) : 0;
    steer -= 1.2 * (inp[IN_WALL_R] - inp[IN_WALL_L]);
    out[0] = clamp1(steer);
    out[1] = 1;
    out[2] = carry ? 1 : 0;
    out[3] = carry ? 0 : 1;
    out[4] = 0;
    out[5] = 0;
    out[6] = 0;
    out[7] = 0;
    out[8] = 0;
    void i;
  }

  /* ------------------------------ spatial hash ------------------------------ */

  private buildHash(): void {
    const a = this.ants;
    const cc = this.cellCount;
    const cs = this.cellStart;
    cc.fill(0);
    const cols = this.hashCols;
    const rows = this.hashRows;
    for (let i = 0; i < this.hi; i++) {
      if (!a.active[i]) continue;
      let hx = (a.x[i] / HASH_CELL) | 0;
      let hy = (a.y[i] / HASH_CELL) | 0;
      if (hx < 0) hx = 0;
      else if (hx >= cols) hx = cols - 1;
      if (hy < 0) hy = 0;
      else if (hy >= rows) hy = rows - 1;
      cc[hy * cols + hx]++;
    }
    let acc = 0;
    for (let c = 0; c < cc.length; c++) {
      cs[c] = acc;
      acc += cc[c];
      cc[c] = cs[c];
    }
    cs[cc.length] = acc;
    for (let i = 0; i < this.hi; i++) {
      if (!a.active[i]) continue;
      let hx = (a.x[i] / HASH_CELL) | 0;
      let hy = (a.y[i] / HASH_CELL) | 0;
      if (hx < 0) hx = 0;
      else if (hx >= cols) hx = cols - 1;
      if (hy < 0) hy = 0;
      else if (hy >= rows) hy = rows - 1;
      this.cellItems[cc[hy * cols + hx]++] = i;
    }
  }

  /** Iterate hash neighbours within radius r. Callback returns true to stop. */
  private query(x: number, y: number, r: number, fn: (j: number, d2: number) => boolean): void {
    const a = this.ants;
    const x0 = Math.max(0, ((x - r) / HASH_CELL) | 0);
    const x1 = Math.min(this.hashCols - 1, ((x + r) / HASH_CELL) | 0);
    const y0 = Math.max(0, ((y - r) / HASH_CELL) | 0);
    const y1 = Math.min(this.hashRows - 1, ((y + r) / HASH_CELL) | 0);
    const r2 = r * r;
    for (let hy = y0; hy <= y1; hy++) {
      for (let hx = x0; hx <= x1; hx++) {
        const c = hy * this.hashCols + hx;
        for (let k = this.cellStart[c]; k < this.cellStart[c + 1]; k++) {
          const j = this.cellItems[k];
          if (!a.active[j]) continue;
          const dx = a.x[j] - x;
          const dy = a.y[j] - y;
          const d2 = dx * dx + dy * dy;
          if (d2 <= r2 && fn(j, d2)) return;
        }
      }
    }
  }

  /* ------------------------------ main tick ------------------------------ */

  step(diffuse = true): void {
    const a = this.ants;
    const g = this.grid;
    const cfg = this.cfg;
    const tick = this.tick;
    const think = Math.max(1, cfg.thinkInterval);
    const burn = cfg.atpBurn;
    const nr2 = NEST_RADIUS * NEST_RADIUS;
    for (let i = 0; i < this.hi; i++) {
      if (!a.active[i]) continue;
      if ((i + tick) % think === 0) this.think(i);
      const carry = a.carryingFood[i];
      let ou = a.ouNoise[i];
      ou += -2.2 * ou * DT + 4.6 * a.noiseTrait[i] * SQRT_DT * this.xr.signed() * 1.7;
      a.ouNoise[i] = ou;
      let ang = a.angle[i] + (a.steer[i] * MAX_TURN + ou) * DT;
      const st = a.state[i];
      if (st === ST_TRAIL_DAMPING || st === ST_TANDEM_FOLLOW) {
        this.stateTimer[i] -= DT;
        if (this.stateTimer[i] <= 0) a.state[i] = carry ? ST_RETURNING : ST_FORAGING;
      }
      let v = BASE_SPEED * CASTE_SPEED[a.caste[i]] * a.speedTrait[i] * (0.3 + 0.7 * a.speedOut[i]);
      if (carry) v *= 0.86;
      if (a.energy[i] < 10) v *= 0.6;
      const x = a.x[i];
      const y = a.y[i];
      const c = Math.cos(ang);
      const s = Math.sin(ang);
      const nx = x + c * v * DT;
      const ny = y + s * v * DT;
      if (g.isWallAt(nx, ny) && !g.isWallAt(x, y)) {
        const leftFree = !g.isWallAt(x + Math.cos(ang - 0.9) * 6, y + Math.sin(ang - 0.9) * 6);
        const rightFree = !g.isWallAt(x + Math.cos(ang + 0.9) * 6, y + Math.sin(ang + 0.9) * 6);
        const dir = leftFree && !rightFree ? -1 : rightFree && !leftFree ? 1 : this.xr.signed() > 0 ? 1 : -1;
        ang += dir * (0.7 + 0.6 * this.xr.next());
        a.stall[i] += DT;
        this.stats.wallScrapes++;
        a.vx[i] = 0;
        a.vy[i] = 0;
        if (a.stall[i] > 1.4 && !carry && (st === ST_FORAGING || st === ST_TANDEM_FOLLOW)) {
          a.state[i] = ST_TRAIL_DAMPING;
          this.stateTimer[i] = 1.6;
          ang += Math.PI;
          a.stall[i] = 0;
          a.hasTarget[i] = 0;
          this.stats.sealed++;
        }
      } else {
        a.x[i] = nx;
        a.y[i] = ny;
        a.vx[i] = c * v;
        a.vy[i] = s * v;
        a.homeDx[i] -= nx - x;
        a.homeDy[i] -= ny - y;
        a.tripDist[i] += v * DT;
        if (a.stall[i] > 0) a.stall[i] -= DT * 0.5;
      }
      if (ang > Math.PI) ang -= Math.PI * 2;
      else if (ang < -Math.PI) ang += Math.PI * 2;
      a.angle[i] = ang;
      a.legPhase[i] += v * DT * 0.55;
      a.age[i] += DT;
      const tslv = (a.timeSinceLastVisit[i] += DT);
      if (a.pheromoneTimer[i] > 0) a.pheromoneTimer[i] -= DT;

      // secretion (food/home strength decays with time since last source visit -> gradients point to sources)
      const px = a.x[i];
      const py = a.y[i];
      const strength = Math.exp(-tslv * TRAIL_TAU);
      const eb = i * CHANNEL_COUNT;
      let secrete = 0;
      for (let ch = 0; ch < CHANNEL_COUNT; ch++) {
        const e = a.emit[eb + ch];
        if (e < 0.03) continue;
        secrete += e;
        g.deposit(ch, px, py, e * DEPOSIT_RATE[ch] * DT * (ch <= CH_HOME ? strength : 1));
      }
      if (cfg.enableMortality) {
        a.energy[i] -= (0.3 + v * 0.006 + carry * 0.15 + secrete * 0.05) * burn * DT;
        if (a.energy[i] <= 0 || a.age[i] >= a.maxLifespan[i]) {
          this.killAnt(i);
          continue;
        }
      }

      // food pickup / depleted-site sealing
      const gi = g.index(px, py);
      const fi = this.foodCell[gi];
      if (fi >= 0 && !carry && st !== ST_NECROPHORESIS) {
        if (this.foods.amount[fi] >= 1) {
          this.foods.amount[fi] -= 1;
          a.carryingFood[i] = 1;
          a.state[i] = ST_RETURNING;
          a.timeSinceLastVisit[i] = 0;
          a.angle[i] += Math.PI;
          a.targetX[i] = this.foods.x[fi];
          a.targetY[i] = this.foods.y[fi];
          a.hasTarget[i] = 1;
          a.tripDist[i] = 0;
          this.stats.pickups++;
          a.fitness[i] += 0.3;
          if (this.foods.amount[fi] < 1) this.foods.sealed[fi] = 1;
        } else if (st !== ST_TRAIL_DAMPING) {
          a.state[i] = ST_TRAIL_DAMPING;
          this.stateTimer[i] = 2;
          a.angle[i] += Math.PI;
          a.hasTarget[i] = 0;
          this.stats.sealed++;
        }
      }
      // nest: refuel + delivery
      const dxn = px - this.nestX;
      const dyn = py - this.nestY;
      if (dxn * dxn + dyn * dyn < nr2) {
        a.energy[i] = 100;
        a.homeDx[i] = -dxn;
        a.homeDy[i] = -dyn;
        if (a.carryingFood[i] === 1) {
          a.carryingFood[i] = 0;
          a.state[i] = ST_FORAGING;
          a.timeSinceLastVisit[i] = 0;
          a.angle[i] += Math.PI;
          const straight = Math.max(1, Math.hypot(a.targetX[i] - this.nestX, a.targetY[i] - this.nestY) - NEST_RADIUS - FOOD_RADIUS);
          const eff = Math.min(1, straight / Math.max(1, a.tripDist[i]));
          a.tripDist[i] = 0;
          this.stats.effSum += eff;
          this.stats.foodDelivered++;
          this.cohortDelivered[a.policyType[i]]++;
          this.storedFood++;
          this.deliveredSinceBirth++;
          a.fitness[i] += 1 + eff;
        } else if (st === ST_FORAGING) {
          a.timeSinceLastVisit[i] = 0;
        }
      }
    }

    if (tick % Math.max(1, cfg.interactionInterval) === 0) {
      this.buildHash();
      this.interactions(cfg.interactionInterval * DT);
    }
    this.updatePredators();
    this.updateCorpses();
    this.updateBirths();
    for (let k = 0; k < MAX_ARCS; k++) if (this.arcs.ttl[k] > 0) this.arcs.ttl[k]--;
    if (diffuse && tick % Math.max(1, cfg.diffusionInterval) === 0) g.step(DT * Math.max(1, cfg.diffusionInterval));
    this.tick++;
    this.updateTelemetry();
  }

  /* ------------------------------ swarm interactions ------------------------------ */

  private interactions(dtI: number): void {
    const a = this.ants;
    const scoutMuted = this.grid.muted[CH_SCOUT] === 1;
    for (let i = 0; i < this.hi; i++) {
      if (!a.active[i]) continue;
      // trophallaxis: starving ant seeks a rich donor
      if (a.energy[i] < 30) {
        const xi = a.x[i];
        const yi = a.y[i];
        this.query(xi, yi, 11, (j) => {
          if (j === i || a.energy[j] < 60) return false;
          a.energy[j] -= 14;
          a.energy[i] += 14;
          this.stats.trophallaxis++;
          a.fitness[j] += 0.05;
          this.addArc(a.x[j], a.y[j], xi, yi, ARC_TROPHALLAXIS);
          return true;
        });
      }
      // tandem running: returning scout shares crystal coordinates
      if (!scoutMuted && a.caste[i] === CASTE_SCOUT && a.carryingFood[i] === 1 && a.hasTarget[i] === 1) {
        const xi = a.x[i];
        const yi = a.y[i];
        const tx = a.targetX[i];
        const ty = a.targetY[i];
        this.query(xi, yi, 16, (j) => {
          if (j === i || a.carryingFood[j] === 1 || a.hasTarget[j] === 1 || a.state[j] !== ST_FORAGING) return false;
          a.state[j] = ST_TANDEM_FOLLOW;
          a.targetX[j] = tx;
          a.targetY[j] = ty;
          a.hasTarget[j] = 1;
          this.stateTimer[j] = 8;
          this.grid.deposit(CH_SCOUT, xi, yi, 12);
          this.stats.tandem++;
          this.addArc(xi, yi, a.x[j], a.y[j], ARC_TANDEM);
          return true;
        });
      }
      if (a.state[i] === ST_TANDEM_FOLLOW) {
        const dx = a.targetX[i] - a.x[i];
        const dy = a.targetY[i] - a.y[i];
        if (dx * dx + dy * dy < 400) a.state[i] = ST_FORAGING;
      }
    }
    // corpses: necrotic alarm + warden necrophoresis
    const c = this.corpses;
    for (let k = 0; k < MAX_CORPSES; k++) {
      if (!c.active[k] || c.carrier[k] >= 0) continue;
      const gx = c.x[k] - this.graveX;
      const gy = c.y[k] - this.graveY;
      if (gx * gx + gy * gy < GRAVE_RADIUS * GRAVE_RADIUS) continue;
      this.grid.deposit(CH_ALARM, c.x[k], c.y[k], 1.4 * dtI * 10);
      this.query(c.x[k], c.y[k], 22, (j) => {
        if (a.caste[j] !== CASTE_WARDEN || a.carryingFood[j] === 1 || a.carryCorpse[j] >= 0 || a.state[j] === ST_DEFENDING) return false;
        a.state[j] = ST_NECROPHORESIS;
        a.carryCorpse[j] = k;
        c.carrier[k] = j;
        return true;
      });
    }
    // predators: hunting target, danger broadcast, warden defence
    const p = this.predators;
    for (let k = 0; k < MAX_PREDATORS; k++) {
      if (!p.active[k]) continue;
      const px = p.x[k];
      const py = p.y[k];
      let best = -1;
      let bestD = 1e12;
      this.query(px, py, 150, (j, d2) => {
        if (d2 < bestD) {
          bestD = d2;
          best = j;
        }
        return false;
      });
      this.predTarget[k] = best;
      const alarmMuted = this.grid.muted[CH_ALARM] === 1;
      this.query(px, py, DANGER_RADIUS, (j) => {
        if (!alarmMuted && a.pheromoneTimer[j] <= 0) {
          this.grid.deposit(CH_ALARM, a.x[j], a.y[j], 80);
          a.pheromoneTimer[j] = 1.5;
        }
        return false;
      });
      let defenders = 0;
      this.query(px, py, 14, (j) => {
        if (a.state[j] === ST_DEFENDING || a.caste[j] === CASTE_WARDEN) {
          defenders++;
          a.energy[j] -= 6 * dtI;
          if (defenders <= 3) this.addArc(a.x[j], a.y[j], px, py, ARC_COMBAT);
        }
        return false;
      });
      if (defenders > 0) {
        p.hp[k] -= defenders * 7 * dtI;
        p.hitFlash[k] = 1;
        this.stats.defense += defenders * dtI;
        if (p.hp[k] <= 0) {
          p.active[k] = 0;
          this.stats.predatorKills++;
          if (!alarmMuted) this.grid.depositRadius(CH_ALARM, px, py, 30, 40);
          this.predatorRespawn = 12;
        }
      }
    }
  }

  private updatePredators(): void {
    const p = this.predators;
    const a = this.ants;
    const g = this.grid;
    let activeCount = 0;
    for (let k = 0; k < MAX_PREDATORS; k++) {
      if (!p.active[k]) continue;
      activeCount++;
      if (p.cooldown[k] > 0) p.cooldown[k] -= DT;
      if (p.hitFlash[k] > 0) p.hitFlash[k] -= DT * 3;
      const t = this.predTarget[k];
      let desired = p.angle[k] + this.xr.signed() * 0.5;
      if (t >= 0 && a.active[t]) {
        const dx = a.x[t] - p.x[k];
        const dy = a.y[t] - p.y[k];
        desired = Math.atan2(dy, dx);
        if (dx * dx + dy * dy < 100 && p.cooldown[k] <= 0) {
          this.addArc(p.x[k], p.y[k], a.x[t], a.y[t], ARC_COMBAT);
          this.killAnt(t);
          p.cooldown[k] = 1.7;
          this.predTarget[k] = -1;
        }
      }
      let diff = desired - p.angle[k];
      while (diff > Math.PI) diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;
      p.angle[k] += Math.max(-3 * DT, Math.min(3 * DT, diff));
      const nx = p.x[k] + Math.cos(p.angle[k]) * PREDATOR_SPEED * DT;
      const ny = p.y[k] + Math.sin(p.angle[k]) * PREDATOR_SPEED * DT;
      if (g.isWallAt(nx, ny)) p.angle[k] += 1.2;
      else {
        p.x[k] = nx;
        p.y[k] = ny;
      }
      p.legPhase[k] += PREDATOR_SPEED * DT * 0.2;
    }
    if (activeCount < this.cfg.predatorCount) {
      this.predatorRespawn -= DT;
      if (this.predatorRespawn <= 0) {
        this.spawnPredator();
        this.predatorRespawn = 12;
      }
    }
  }

  private updateCorpses(): void {
    const c = this.corpses;
    const a = this.ants;
    for (let k = 0; k < MAX_CORPSES; k++) {
      if (!c.active[k]) continue;
      const j = c.carrier[k];
      if (j >= 0) {
        if (!a.active[j] || a.carryCorpse[j] !== k) {
          c.carrier[k] = -1;
          continue;
        }
        c.x[k] = a.x[j] + Math.cos(a.angle[j]) * 5;
        c.y[k] = a.y[j] + Math.sin(a.angle[j]) * 5;
        c.rot[k] = a.angle[j];
        const dx = c.x[k] - this.graveX;
        const dy = c.y[k] - this.graveY;
        if (dx * dx + dy * dy < 18 * 18) {
          c.carrier[k] = -1;
          c.ttl[k] = 90;
          a.carryCorpse[j] = -1;
          a.state[j] = ST_FORAGING;
          this.graveyardCount++;
          a.fitness[j] += 0.1;
        }
      } else {
        c.ttl[k] -= DT;
        if (c.ttl[k] <= 0) c.active[k] = 0;
      }
    }
  }

  private updateBirths(): void {
    if (!this.cfg.enableBirths) return;
    if (this.deliveredSinceBirth > 30) this.deliveredSinceBirth = 30;
    while (this.deliveredSinceBirth >= 3 && this.alive < this.cfg.maxPop && this.freeTop > 0) {
      this.deliveredSinceBirth -= 3;
      this.storedFood = Math.max(0, this.storedFood - 3);
      this.hatch(false);
      this.births++;
      if (this.births % 25 === 0) {
        this.colonyGeneration++;
        this.mutationBoost = 1;
      }
    }
    if (this.bottleneckCooldown > 0) this.bottleneckCooldown -= DT;
    else if (this.alive < 35) {
      this.mutationBoost = 2.5;
      for (let k = 0; k < 30; k++) this.hatch(true);
      this.births += 30;
      this.bottlenecks++;
      this.colonyGeneration++;
      this.bottleneckCooldown = 20;
    }
  }

  private updateTelemetry(): void {
    const t = this.telemetry;
    t.alive = this.alive;
    t.deaths = this.totalDeaths;
    t.births = this.births;
    t.foodDelivered = this.stats.foodDelivered;
    t.storedFood = this.storedFood;
    t.colonyGeneration = this.colonyGeneration;
    t.simTime = this.tick * DT;
    t.tick = this.tick;
    t.cohortTrained = this.cohortDelivered[POLICY_TRAINED];
    t.cohortOther = this.cohortDelivered[POLICY_RANDOM] + this.cohortDelivered[POLICY_ACO];
    t.bottlenecks = this.bottlenecks;
    if (this.tick % 15 === 0) {
      t.predators = this.activePredators();
      let rem = 0;
      for (let k = 0; k < MAX_FOOD_SOURCES; k++) if (this.foods.active[k]) rem += this.foods.amount[k];
      t.foodRemaining = rem;
    }
  }

  /** Count ants with low energy (starvation penalty for fitness). */
  starvingCount(): number {
    let n = 0;
    for (let i = 0; i < this.hi; i++) if (this.ants.active[i] && this.ants.energy[i] < 20) n++;
    return n;
  }

  /** Brush deposit helper used by the UI. */
  brushDeposit(ch: number, x: number, y: number, r: number, amount: number): void {
    this.grid.depositRadius(ch, x, y, r, amount);
  }
}

export { CASTE_HAULER as CASTE_HAULER_ID };
