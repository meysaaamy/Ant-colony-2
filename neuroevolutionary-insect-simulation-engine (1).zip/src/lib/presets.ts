/* World presets: Open Sanctuary, Deneubourg's Double Bridge, Subterranean Labyrinth. Orientation-aware. */
import { Mulberry32 } from "./prng-noise";
import type { PresetDef, PresetId, PresetLayout, Vec2, WallStroke } from "./types";

/** Map (u across, v along the nest->food axis) into world coords for portrait or landscape worlds. */
function mapper(w: number, h: number): (u: number, v: number) => Vec2 {
  const portrait = h >= w;
  return (u, v) => (portrait ? { x: u * w, y: v * h } : { x: v * w, y: u * h });
}

function capsule(a: Vec2, b: Vec2, r: number): WallStroke {
  return { kind: "capsule", x1: a.x, y1: a.y, x2: b.x, y2: b.y, r };
}

function openSanctuary(w: number, h: number, seed: number): PresetLayout {
  const P = mapper(w, h);
  const rng = new Mulberry32(seed ^ 0x51);
  const nest = P(0.5, 0.62);
  const foods = [
    { ...P(0.2, 0.2), amount: 240 },
    { ...P(0.8, 0.28), amount: 200 },
    { ...P(0.78, 0.84), amount: 160 },
    { ...P(0.18, 0.66), amount: 150 },
    { ...P(0.52, 0.1), amount: 260 },
  ];
  const walls: WallStroke[] = [];
  const minDim = Math.min(w, h);
  for (let b = 0; b < 9; b++) {
    let cx = 0;
    let cy = 0;
    for (let t = 0; t < 30; t++) {
      cx = rng.range(0.08, 0.92) * w;
      cy = rng.range(0.08, 0.92) * h;
      const farNest = Math.hypot(cx - nest.x, cy - nest.y) > minDim * 0.2;
      const farFood = foods.every((f) => Math.hypot(cx - f.x, cy - f.y) > minDim * 0.12);
      if (farNest && farFood) break;
    }
    const lobes = 3 + rng.int(4);
    let ang = rng.range(0, Math.PI * 2);
    for (let l = 0; l < lobes; l++) {
      const r = rng.range(10, 24);
      walls.push({ kind: "circle", x: cx, y: cy, r });
      ang += rng.range(-1, 1);
      cx += Math.cos(ang) * r * 0.9;
      cy += Math.sin(ang) * r * 0.9;
    }
  }
  return { nest, graveyard: P(0.1, 0.94), foods, walls, carve: [] };
}

function doubleBridge(w: number, h: number): PresetLayout {
  const P = mapper(w, h);
  const portrait = h >= w;
  const along = portrait ? h : w;
  const across = portrait ? w : h;
  const walls: WallStroke[] = [];
  const r = 14;
  const v0 = 0.3;
  const v1 = 0.7;
  const rows = Math.ceil(((v1 - v0) * along) / (r * 1.2));
  for (let k = 0; k <= rows; k++) {
    const v = v0 + ((v1 - v0) * k) / rows;
    walls.push(capsule(P(0, v), P(1, v), r));
  }
  const cr = Math.max(16, across * 0.025);
  const carve: WallStroke[] = [
    capsule(P(0.38, v0 - 0.03), P(0.38, v1 + 0.03), cr),
    capsule(P(0.58, v1 + 0.03), P(0.88, v1 - 0.06), cr),
    capsule(P(0.88, v1 - 0.06), P(0.9, v0 + 0.06), cr),
    capsule(P(0.9, v0 + 0.06), P(0.58, v0 - 0.03), cr),
  ];
  return {
    nest: P(0.48, 0.86),
    graveyard: P(0.08, 0.95),
    foods: [{ ...P(0.48, 0.12), amount: 600 }],
    walls,
    carve,
  };
}

function labyrinth(w: number, h: number, seed: number): PresetLayout {
  const portrait = h >= w;
  const cols = portrait ? 5 : 9;
  const rows = portrait ? 9 : 5;
  const cw = w / cols;
  const ch = h / rows;
  const rng = new Mulberry32(seed ^ 0x1abe);
  const visited = new Uint8Array(cols * rows);
  const open: Array<[number, number]> = [];
  const stack: number[] = [];
  const start = Math.floor(rows / 2) * cols + Math.floor(cols / 2);
  visited[start] = 1;
  stack.push(start);
  while (stack.length) {
    const cur = stack[stack.length - 1];
    const cx = cur % cols;
    const cy = Math.floor(cur / cols);
    const nbrs: number[] = [];
    if (cx > 0 && !visited[cur - 1]) nbrs.push(cur - 1);
    if (cx < cols - 1 && !visited[cur + 1]) nbrs.push(cur + 1);
    if (cy > 0 && !visited[cur - cols]) nbrs.push(cur - cols);
    if (cy < rows - 1 && !visited[cur + cols]) nbrs.push(cur + cols);
    if (!nbrs.length) {
      stack.pop();
      continue;
    }
    const nx = nbrs[rng.int(nbrs.length)];
    visited[nx] = 1;
    open.push([cur, nx]);
    stack.push(nx);
  }
  // a few loops for alternative routes
  for (let k = 0; k < Math.round(cols * rows * 0.12); k++) {
    const c = rng.int(cols * rows);
    if (c % cols < cols - 1) open.push([c, c + 1]);
  }
  const center = (c: number): Vec2 => ({ x: ((c % cols) + 0.5) * cw, y: (Math.floor(c / cols) + 0.5) * ch });
  const walls: WallStroke[] = [];
  const wr = 7;
  for (let x = 0; x <= cols; x++) walls.push(capsule({ x: x * cw, y: 0 }, { x: x * cw, y: h }, wr));
  for (let y = 0; y <= rows; y++) walls.push(capsule({ x: 0, y: y * ch }, { x: w, y: y * ch }, wr));
  const carve: WallStroke[] = [];
  const pr = Math.min(cw, ch) * 0.3;
  for (const [a, b] of open) carve.push(capsule(center(a), center(b), pr));
  const nest = center(start);
  const corners = [0, cols - 1, (rows - 1) * cols, rows * cols - 1, Math.floor(cols / 2), (rows - 1) * cols + Math.floor(cols / 2)];
  const foods = corners.map((c, k) => ({ ...center(c), amount: 140 + k * 20 }));
  return { nest, graveyard: center(cols - 1 + cols), foods, walls, carve };
}

export const PRESETS: readonly PresetDef[] = [
  { id: "open-sanctuary", name: "Open Sanctuary", subtitle: "Five crystal fields, basalt outcrops", build: openSanctuary },
  { id: "double-bridge", name: "Deneubourg's Double Bridge", subtitle: "Short vs long branch selection", build: (w, h) => doubleBridge(w, h) },
  { id: "labyrinth", name: "Subterranean Labyrinth", subtitle: "Dead ends, loops and sealing", build: labyrinth },
];

export function getPreset(id: PresetId): PresetDef {
  return PRESETS.find((p) => p.id === id) ?? PRESETS[0];
}
