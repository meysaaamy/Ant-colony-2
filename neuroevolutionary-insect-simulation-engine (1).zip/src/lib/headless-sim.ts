/*
 * Fast headless evaluator: identical AntEngine physics, no rendering.
 *  - training episodes (fitness), multi-seed Food/Gen learning curve vs Hand-Crafted ACO and Random floor
 *  - multi-seed A/B + single-channel ablation benchmark (mean +- std)
 *  - time-sliced (chunked) trainer + benchmark for the UI, synchronous variants for CLI/tests/health
 */
import { AntEngine } from "./ant-soa-engine";
import { createRandomBrain, DEFAULT_EVOLUTION, NeuroEvolution } from "./neat";
import { Mulberry32 } from "./prng-noise";
import {
  defaultAblation,
  defaultSimConfig,
  type AblationMask,
  type ArenaMode,
  type BenchmarkCondition,
  type BenchmarkReport,
  type BenchmarkResult,
  type Brain,
  type EpisodeResult,
  type EvolutionParams,
  type PresetLayout,
  type TrainingPoint,
  type WallStroke,
} from "./types";

export const TRAIN_WORLD = 336;
export const RANDOM_BRAIN_SEED = 424242;
export const BENCHMARK_SEEDS: readonly number[] = [7, 21, 42];
export const DEFAULT_TICKS = 900;
export const EPISODE_ANTS = 64;

export interface EpisodeSpec {
  seed: number;
  ticks: number;
  ants: number;
  arena: ArenaMode;
  ablation: AblationMask;
  predators: number;
}

export function episodeSpec(seed: number, ticks = DEFAULT_TICKS, ablation: AblationMask = defaultAblation(), arena: ArenaMode = "trained"): EpisodeSpec {
  return { seed, ticks, ants: EPISODE_ANTS, arena, ablation, predators: 1 };
}

export function buildTrainingLayout(size: number, seed: number): PresetLayout {
  const rng = new Mulberry32(Math.imul(seed, 7919) + 13);
  const c = size / 2;
  const base = rng.range(0, Math.PI * 2);
  const foods: PresetLayout["foods"] = [];
  for (let k = 0; k < 3; k++) {
    const a = base + (k * Math.PI * 2) / 3 + rng.range(-0.4, 0.4);
    const d = rng.range(100, 132);
    foods.push({ x: c + Math.cos(a) * d, y: c + Math.sin(a) * d, amount: 45 });
  }
  const walls: WallStroke[] = [];
  for (let b = 0; b < 2; b++) {
    const a = base + Math.PI / 3 + (b * Math.PI * 2) / 3 + rng.range(-0.3, 0.3);
    const d = rng.range(60, 80);
    walls.push({ kind: "circle", x: c + Math.cos(a) * d, y: c + Math.sin(a) * d, r: rng.range(12, 18) });
  }
  return { nest: { x: c, y: c }, graveyard: { x: 22, y: 22 }, foods, walls, carve: [] };
}

let cachedRandom: Brain | null = null;
export function sharedRandomBrain(): Brain {
  if (!cachedRandom) cachedRandom = createRandomBrain(RANDOM_BRAIN_SEED);
  return cachedRandom;
}

export function createEpisodeEngine(brain: Brain, spec: EpisodeSpec): AntEngine {
  const cfg = defaultSimConfig(TRAIN_WORLD, TRAIN_WORLD);
  cfg.initialAnts = spec.ants;
  cfg.maxPop = spec.ants;
  cfg.predatorCount = spec.predators;
  cfg.arena = spec.arena;
  cfg.ablation = spec.ablation;
  cfg.thinkInterval = 2;
  cfg.diffusionInterval = 3;
  cfg.interactionInterval = 4;
  cfg.enableBirths = false;
  cfg.seed = spec.seed;
  return new AntEngine(cfg, brain, sharedRandomBrain(), buildTrainingLayout(TRAIN_WORLD, spec.seed));
}

export function scoreEpisode(e: AntEngine): EpisodeResult {
  const s = e.stats;
  const starving = e.starvingCount();
  const fitness =
    s.foodDelivered * 10 +
    s.pickups * 3 +
    s.effSum * 4 +
    s.trophallaxis * 0.1 +
    s.defense * 0.5 +
    s.predatorKills * 5 -
    s.wallScrapes * 0.0015 -
    s.spin * 0.002 -
    starving * 0.5 -
    s.deaths * 1;
  return { foodDelivered: s.foodDelivered, pickups: s.pickups, deaths: s.deaths, fitness, efficiency: s.foodDelivered > 0 ? s.effSum / s.foodDelivered : 0 };
}

export function runEpisode(brain: Brain, spec: EpisodeSpec): EpisodeResult {
  const e = createEpisodeEngine(brain, spec);
  for (let t = 0; t < spec.ticks; t++) e.step();
  return scoreEpisode(e);
}

export function meanStd(xs: readonly number[]): { mean: number; std: number } {
  if (!xs.length) return { mean: 0, std: 0 };
  const mean = xs.reduce((s, v) => s + v, 0) / xs.length;
  const v = xs.reduce((s, x) => s + (x - mean) * (x - mean), 0) / xs.length;
  return { mean, std: Math.sqrt(v) };
}

export const BENCHMARK_CONDITIONS: ReadonlyArray<{ condition: BenchmarkCondition; label: string }> = [
  { condition: "trained", label: "Full Trained Brain" },
  { condition: "aco", label: "Hand-Crafted ACO" },
  { condition: "random", label: "Random Brain" },
  { condition: "-foodTrail", label: "-foodTrail" },
  { condition: "-homeGuide", label: "-homeGuide" },
  { condition: "-alarm", label: "-alarm" },
  { condition: "-scoutPulse", label: "-scoutPulse" },
  { condition: "-noEntry", label: "-noEntry" },
  { condition: "-pathIntegration", label: "-PathIntegration" },
];

export function conditionSetup(cond: BenchmarkCondition, brain: Brain, seed: number, ticks: number): { brain: Brain; spec: EpisodeSpec } {
  const abl = defaultAblation();
  let arena: ArenaMode = "trained";
  let b = brain;
  switch (cond) {
    case "aco":
      arena = "aco";
      break;
    case "random":
      b = sharedRandomBrain();
      break;
    case "-foodTrail":
      abl.channels[0] = true;
      break;
    case "-homeGuide":
      abl.channels[1] = true;
      break;
    case "-alarm":
      abl.channels[2] = true;
      break;
    case "-scoutPulse":
      abl.channels[3] = true;
      break;
    case "-noEntry":
      abl.channels[4] = true;
      break;
    case "-pathIntegration":
      abl.pathIntegration = true;
      break;
    case "trained":
      break;
  }
  return { brain: b, spec: episodeSpec(seed, ticks, abl, arena) };
}

export function runBenchmarkSync(
  brain: Brain,
  seeds: readonly number[] = BENCHMARK_SEEDS,
  ticks = DEFAULT_TICKS,
  conditions: readonly BenchmarkCondition[] = BENCHMARK_CONDITIONS.map((c) => c.condition),
): BenchmarkReport {
  const results: BenchmarkResult[] = [];
  for (const cond of conditions) {
    const samples: number[] = [];
    for (const seed of seeds) {
      const { brain: b, spec } = conditionSetup(cond, brain, seed, ticks);
      samples.push(runEpisode(b, spec).foodDelivered);
    }
    const { mean, std } = meanStd(samples);
    const label = BENCHMARK_CONDITIONS.find((c) => c.condition === cond)?.label ?? cond;
    results.push({ condition: cond, label, mean, std, samples });
  }
  return { seeds: [...seeds], ticks, results };
}

/* ---------------------------- time-sliced execution ---------------------------- */

interface EpisodeTask {
  brain: Brain;
  spec: EpisodeSpec;
  onDone: (r: EpisodeResult) => void;
}

const now = (): number => (typeof performance !== "undefined" ? performance.now() : Date.now());

export class EpisodeQueue {
  private tasks: EpisodeTask[] = [];
  private head = 0;
  private current: AntEngine | null = null;
  private currentTask: EpisodeTask | null = null;
  private ticksDone = 0;
  totalTicks = 0;
  doneTicks = 0;

  push(task: EpisodeTask): void {
    this.tasks.push(task);
    this.totalTicks += task.spec.ticks;
  }

  get idle(): boolean {
    return this.current === null && this.head >= this.tasks.length;
  }

  run(budgetMs: number): void {
    const t0 = now();
    while (now() - t0 < budgetMs) {
      if (!this.current) {
        if (this.head >= this.tasks.length) return;
        const task = this.tasks[this.head++];
        this.current = createEpisodeEngine(task.brain, task.spec);
        this.currentTask = task;
        this.ticksDone = 0;
      }
      const eng = this.current;
      const task = this.currentTask;
      if (!task) return;
      for (let k = 0; k < 20 && this.ticksDone < task.spec.ticks; k++) {
        eng.step();
        this.ticksDone++;
        this.doneTicks++;
      }
      if (this.ticksDone >= task.spec.ticks) {
        task.onDone(scoreEpisode(eng));
        this.current = null;
        this.currentTask = null;
      }
    }
  }
}

export class ChunkedBenchmark {
  readonly report: BenchmarkReport;
  private queue = new EpisodeQueue();

  constructor(brain: Brain, seeds: readonly number[] = BENCHMARK_SEEDS, ticks = DEFAULT_TICKS) {
    this.report = { seeds: [...seeds], ticks, results: [] };
    for (const { condition, label } of BENCHMARK_CONDITIONS) {
      const entry: BenchmarkResult = { condition, label, mean: 0, std: 0, samples: [] };
      this.report.results.push(entry);
      for (const seed of seeds) {
        const setup = conditionSetup(condition, brain, seed, ticks);
        this.queue.push({
          brain: setup.brain,
          spec: setup.spec,
          onDone: (r) => {
            entry.samples.push(r.foodDelivered);
            const ms = meanStd(entry.samples);
            entry.mean = ms.mean;
            entry.std = ms.std;
          },
        });
      }
    }
  }

  step(budgetMs: number): boolean {
    this.queue.run(budgetMs);
    return this.queue.idle;
  }

  get progress(): number {
    return this.queue.totalTicks ? this.queue.doneTicks / this.queue.totalTicks : 1;
  }
}

export interface TrainerOptions {
  populationSize: number;
  seeds: readonly number[];
  ticks: number;
  evolution?: Partial<EvolutionParams>;
}

/** In-app chunked neuroevolution trainer (continues from a seed brain, appends to the learning curve). */
export class ChunkedTrainer {
  readonly evo: NeuroEvolution;
  readonly history: TrainingPoint[];
  private queue = new EpisodeQueue();
  private remaining = 0;
  private pending = 0;
  private fit: number[][] = [];
  private food: number[][] = [];
  private baselineAco = 0;
  private baselineRandom = 0;
  private baselinesReady = false;
  private generationBase: number;
  readonly opts: TrainerOptions;

  constructor(seedBrain: Brain, history: readonly TrainingPoint[], opts: TrainerOptions, seed = 99) {
    this.opts = opts;
    const params: EvolutionParams = { ...DEFAULT_EVOLUTION, populationSize: opts.populationSize, ...opts.evolution };
    this.evo = new NeuroEvolution(params, seed, seedBrain, 1);
    this.history = [...history];
    this.generationBase = history.length ? history[history.length - 1].generation + 1 : 0;
    this.queueBaselines();
  }

  private queueBaselines(): void {
    const aco: number[] = [];
    const rnd: number[] = [];
    for (const seed of this.opts.seeds) {
      const a = conditionSetup("aco", sharedRandomBrain(), seed, this.opts.ticks);
      this.queue.push({ brain: a.brain, spec: a.spec, onDone: (r) => aco.push(r.foodDelivered) });
      const rr = conditionSetup("random", sharedRandomBrain(), seed, this.opts.ticks);
      this.queue.push({
        brain: rr.brain,
        spec: rr.spec,
        onDone: (r) => {
          rnd.push(r.foodDelivered);
          if (rnd.length === this.opts.seeds.length) {
            this.baselineAco = meanStd(aco).mean;
            this.baselineRandom = meanStd(rnd).mean;
            this.baselinesReady = true;
          }
        },
      });
    }
  }

  private requested = 0;
  private completed = 0;

  addGenerations(n: number): void {
    const wasIdle = this.remaining === 0 && this.pending === 0;
    this.remaining += n;
    this.requested += n;
    if (wasIdle) this.queueGeneration();
  }

  get busy(): boolean {
    return this.remaining > 0 || this.pending > 0;
  }

  /** Overall progress across every requested generation (0..1). */
  get progress(): number {
    if (this.requested === 0) return 1;
    const per = this.evo.population.length * this.opts.seeds.length;
    const genFrac = this.pending > 0 ? 1 - this.pending / per : 0;
    return Math.min(1, (this.completed + genFrac) / this.requested);
  }

  private queueGeneration(): void {
    const pop = this.evo.population;
    this.fit = pop.map(() => []);
    this.food = pop.map(() => []);
    this.pending = pop.length * this.opts.seeds.length;
    pop.forEach((g, gi) => {
      for (const seed of this.opts.seeds) {
        this.queue.push({
          brain: this.evo.brainOf(g),
          spec: episodeSpec(seed, this.opts.ticks),
          onDone: (r) => {
            this.fit[gi].push(r.fitness);
            this.food[gi].push(r.foodDelivered);
            this.pending--;
            if (this.pending === 0) this.finishGeneration();
          },
        });
      }
    });
  }

  private finishGeneration(): void {
    const pop = this.evo.population;
    let bi = 0;
    pop.forEach((g, gi) => {
      g.fitness = meanStd(this.fit[gi]).mean;
      if (g.fitness > pop[bi].fitness) bi = gi;
    });
    const ms = meanStd(this.food[bi]);
    this.history.push({
      generation: this.generationBase + this.evo.generation,
      trained: ms.mean,
      trainedStd: ms.std,
      aco: this.baselinesReady ? this.baselineAco : 0,
      random: this.baselinesReady ? this.baselineRandom : 0,
    });
    this.evo.evolve();
    this.remaining--;
    this.completed++;
    if (this.remaining > 0) this.queueGeneration();
  }

  step(budgetMs: number): void {
    this.queue.run(budgetMs);
  }

  championBrain(): Brain | null {
    const b = this.evo.best;
    return b ? { weights: new Float32Array(b.weights), hidden: b.enabled.length, enabled: new Uint8Array(b.enabled) } : null;
  }
}
