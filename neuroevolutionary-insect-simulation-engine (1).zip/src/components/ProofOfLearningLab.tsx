"use client";

import { useRef } from "react";
import { BRAIN_HIDDEN, BRAIN_INPUTS, CHANNEL_NAMES, type AblationMask, type ArenaMode, type BenchmarkReport, type TrainingPoint } from "@/lib/types";
import { INPUT_LABELS } from "@/lib/neat";
import { ChartIcon, DownloadIcon, ResetIcon, SparkIcon, UploadIcon } from "./ui/icons";

interface LabProps {
  history: TrainingPoint[];
  training: boolean;
  trainProgress: number;
  benchReport: BenchmarkReport | null;
  benchmarking: boolean;
  benchProgress: number;
  arena: ArenaMode;
  ablation: AblationMask;
  weights: Float32Array;
  onTrain: (n: number) => void;
  onBenchmark: () => void;
  onArena: (m: ArenaMode) => void;
  onAblation: (m: AblationMask) => void;
  onExport: () => void;
  onImport: (json: string) => void;
  onRestore: () => void;
}

const ARENAS: ReadonlyArray<{ id: ArenaMode; label: string }> = [
  { id: "trained", label: "100% Trained Brain" },
  { id: "ab-random", label: "50/50 Trained vs Random" },
  { id: "ab-aco", label: "50/50 Trained vs Hand-Crafted ACO" },
  { id: "aco", label: "100% Hand-Crafted ACO" },
];

const CH_COLORS = ["#ffa800", "#00e1ff", "#ff0c4b", "#af32ff", "#50ff64"];

function LearningCurve({ history }: { history: TrainingPoint[] }) {
  const W = 340;
  const H = 168;
  const pl = 30;
  const pr = 8;
  const pt = 10;
  const pb = 22;
  if (history.length === 0) {
    return (
      <div className="flex h-[168px] items-center justify-center rounded-[20px] border border-dashed border-white/10 text-[12px] text-slate-500">
        No training history yet. Run Train +5 Gen.
      </div>
    );
  }
  const g0 = history[0].generation;
  const g1 = Math.max(g0 + 1, history[history.length - 1].generation);
  const ymax = Math.max(5, ...history.map((h) => Math.max(h.trained + h.trainedStd, h.aco, h.random))) * 1.1;
  const X = (g: number) => pl + ((g - g0) / (g1 - g0)) * (W - pl - pr);
  const Y = (v: number) => pt + (1 - v / ymax) * (H - pt - pb);
  const line = (sel: (p: TrainingPoint) => number) => history.map((p, i) => `${i ? "L" : "M"}${X(p.generation).toFixed(1)},${Y(sel(p)).toFixed(1)}`).join(" ");
  const band =
    history.map((p, i) => `${i ? "L" : "M"}${X(p.generation).toFixed(1)},${Y(p.trained + p.trainedStd).toFixed(1)}`).join(" ") +
    " " +
    [...history].reverse().map((p) => `L${X(p.generation).toFixed(1)},${Y(Math.max(0, p.trained - p.trainedStd)).toFixed(1)}`).join(" ") +
    " Z";
  const ticks = 4;
  const last = history[history.length - 1];
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full" role="img" aria-label="Food delivered per generation learning curve">
      <defs>
        <linearGradient id="lc-trained" x1="0" x2="1">
          <stop offset="0" stopColor="#ffd166" />
          <stop offset="1" stopColor="#00e1ff" />
        </linearGradient>
      </defs>
      {Array.from({ length: ticks + 1 }, (_, k) => {
        const v = (ymax / ticks) * k;
        return (
          <g key={k}>
            <line x1={pl} x2={W - pr} y1={Y(v)} y2={Y(v)} stroke="rgba(255,255,255,0.06)" />
            <text x={pl - 4} y={Y(v) + 3} textAnchor="end" fontSize="8" fill="#64748b">
              {v.toFixed(0)}
            </text>
          </g>
        );
      })}
      <text x={W - pr} y={H - 6} textAnchor="end" fontSize="8" fill="#64748b">
        generation {g1}
      </text>
      <text x={pl} y={H - 6} fontSize="8" fill="#64748b">
        gen {g0}
      </text>
      <path d={band} fill="rgba(0,225,255,0.10)" />
      <path d={line((p) => p.random)} fill="none" stroke="#fb7185" strokeWidth="1.25" strokeDasharray="2 3" />
      <path d={line((p) => p.aco)} fill="none" stroke="#cbd5e1" strokeWidth="1.25" strokeDasharray="6 4" />
      <path d={line((p) => p.trained)} fill="none" stroke="url(#lc-trained)" strokeWidth="2" strokeLinejoin="round" />
      <circle cx={X(last.generation)} cy={Y(last.trained)} r="3" fill="#00e1ff" />
    </svg>
  );
}

function BenchmarkBars({ report }: { report: BenchmarkReport }) {
  const rows = report.results;
  const trained = rows.find((r) => r.condition === "trained")?.mean ?? 0;
  const max = Math.max(1, ...rows.map((r) => r.mean + r.std)) * 1.08;
  const W = 340;
  const rowH = 17;
  const H = rows.length * rowH + 6;
  const lx = 104;
  const color = (c: string) => (c === "trained" ? "#00e1ff" : c === "aco" ? "#cbd5e1" : c === "random" ? "#fb7185" : "#af32ff");
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full" role="img" aria-label="Multi-seed benchmark and ablation bar chart">
      {rows.map((r, i) => {
        const y = 4 + i * rowH;
        const w = ((W - lx - 64) * r.mean) / max;
        const sw = ((W - lx - 64) * r.std) / max;
        const drop = r.condition.startsWith("-") && trained > 0 ? ((r.mean - trained) / trained) * 100 : null;
        return (
          <g key={r.condition}>
            <text x={lx - 6} y={y + 10} textAnchor="end" fontSize="9" fill="#cbd5e1">
              {r.label}
            </text>
            <rect x={lx} y={y + 2} width={W - lx - 64} height={rowH - 6} rx="4" fill="rgba(255,255,255,0.04)" />
            <rect x={lx} y={y + 2} width={Math.max(0, w)} height={rowH - 6} rx="4" fill={color(r.condition)} fillOpacity={r.samples.length ? 0.85 : 0.2} />
            {r.std > 0 ? <line x1={lx + w - sw} x2={lx + w + sw} y1={y + 7.5} y2={y + 7.5} stroke="#f8fafc" strokeWidth="1" /> : null}
            <text x={W - 60} y={y + 10} fontSize="9" fill="#e2e8f0" className="tnum">
              {r.samples.length ? `${r.mean.toFixed(1)}±${r.std.toFixed(1)}` : "..."}
            </text>
            {drop !== null && r.samples.length ? (
              <text x={W - 2} y={y + 10} textAnchor="end" fontSize="8" fill={drop < 0 ? "#fb7185" : "#86efac"}>
                {drop > 0 ? "+" : ""}
                {drop.toFixed(0)}%
              </text>
            ) : null}
          </g>
        );
      })}
    </svg>
  );
}

function WeightHeatmap({ weights }: { weights: Float32Array }) {
  const cell = 8;
  return (
    <svg viewBox={`0 0 ${BRAIN_INPUTS * cell + 40} ${BRAIN_HIDDEN * cell + 14}`} className="w-full" role="img" aria-label="Input to hidden weight heatmap">
      {Array.from({ length: BRAIN_HIDDEN }, (_, h) =>
        Array.from({ length: BRAIN_INPUTS }, (_, i) => {
          const v = weights[h * BRAIN_INPUTS + i] ?? 0;
          const a = Math.min(1, Math.abs(v) / 3);
          return <rect key={`${h}-${i}`} x={40 + i * cell} y={h * cell} width={cell - 1} height={cell - 1} rx="1.5" fill={v >= 0 ? `rgba(0,225,255,${a})` : `rgba(255,168,0,${a})`} />;
        }),
      )}
      {INPUT_LABELS.map((l, i) =>
        i % 3 === 0 ? (
          <text key={l} x={40 + i * cell + 3} y={BRAIN_HIDDEN * cell + 10} fontSize="6" fill="#64748b" textAnchor="middle">
            {l}
          </text>
        ) : null,
      )}
      <text x="0" y="10" fontSize="7" fill="#94a3b8">
        W1
      </text>
      <text x="0" y="22" fontSize="6" fill="#64748b">
        16x19
      </text>
    </svg>
  );
}

export default function ProofOfLearningLab(p: LabProps) {
  const fileRef = useRef<HTMLInputElement | null>(null);
  const last = p.history[p.history.length - 1];
  const muteToggles: ReadonlyArray<{ key: string; label: string; color: string; on: boolean; toggle: () => void }> = [
    ...CHANNEL_NAMES.map((n, c) => ({
      key: n,
      label: n,
      color: CH_COLORS[c],
      on: p.ablation.channels[c],
      toggle: () => {
        const ch = [...p.ablation.channels] as AblationMask["channels"];
        ch[c] = !ch[c];
        p.onAblation({ channels: ch, pathIntegration: p.ablation.pathIntegration });
      },
    })),
    { key: "pi", label: "PathIntegration", color: "#e2e8f0", on: p.ablation.pathIntegration, toggle: () => p.onAblation({ channels: p.ablation.channels, pathIntegration: !p.ablation.pathIntegration }) },
  ];
  return (
    <div className="space-y-4">
      <section className="rounded-[20px] border border-white/10 bg-black/20 p-3">
        <div className="mb-1 flex items-center justify-between">
          <h3 className="font-display text-[15px] text-slate-100">Food delivered per generation</h3>
          <span className="text-[10px] text-slate-500">mean of 3 seeds</span>
        </div>
        <LearningCurve history={p.history} />
        <div className="mt-1 flex flex-wrap items-center gap-3 text-[10px] text-slate-400">
          <span className="flex items-center gap-1">
            <svg width="16" height="4" aria-hidden="true"><line x1="0" y1="2" x2="16" y2="2" stroke="#00e1ff" strokeWidth="2" /></svg>Shared MLP Brain
          </span>
          <span className="flex items-center gap-1">
            <svg width="16" height="4" aria-hidden="true"><line x1="0" y1="2" x2="16" y2="2" stroke="#cbd5e1" strokeDasharray="4 3" /></svg>Hand-Crafted ACO
          </span>
          <span className="flex items-center gap-1">
            <svg width="16" height="4" aria-hidden="true"><line x1="0" y1="2" x2="16" y2="2" stroke="#fb7185" strokeDasharray="2 2" /></svg>Random network
          </span>
          {last ? <span className="ml-auto text-slate-300 tnum">gen {last.generation}: {last.trained.toFixed(1)} vs ACO {last.aco.toFixed(1)}</span> : null}
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          <button type="button" disabled={p.training} onClick={() => p.onTrain(10)} className="flex items-center gap-1.5 rounded-[12px] bg-cyan-400/15 px-3 py-2 text-[12px] font-semibold text-cyan-100 ring-1 ring-cyan-300/30 disabled:opacity-60">
            <SparkIcon size={16} /> {p.training ? `Training ${(p.trainProgress * 100).toFixed(0)}%` : "+10 Gen headless"}
          </button>
          <button type="button" onClick={p.onExport} className="flex items-center gap-1.5 rounded-[12px] bg-white/5 px-3 py-2 text-[12px] text-slate-200 ring-1 ring-white/10">
            <DownloadIcon size={16} /> Export JSON
          </button>
          <button type="button" onClick={() => fileRef.current?.click()} className="flex items-center gap-1.5 rounded-[12px] bg-white/5 px-3 py-2 text-[12px] text-slate-200 ring-1 ring-white/10">
            <UploadIcon size={16} /> Import
          </button>
          <button type="button" onClick={p.onRestore} className="flex items-center gap-1.5 rounded-[12px] bg-white/5 px-3 py-2 text-[12px] text-slate-200 ring-1 ring-white/10">
            <ResetIcon size={16} /> Baked champion
          </button>
          <input
            ref={fileRef}
            type="file"
            accept="application/json,.json"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) void f.text().then(p.onImport);
              e.target.value = "";
            }}
          />
        </div>
        {p.training ? (
          <div className="mt-2 h-1 overflow-hidden rounded-full bg-white/5">
            <div className="h-full bg-gradient-to-r from-amber-300 to-cyan-300 transition-[width] duration-200" style={{ width: `${p.trainProgress * 100}%` }} />
          </div>
        ) : null}
      </section>

      <section className="rounded-[20px] border border-white/10 bg-black/20 p-3">
        <div className="mb-2 flex items-center justify-between gap-2">
          <h3 className="font-display text-[15px] text-slate-100">Multi-seed benchmark and ablation</h3>
          <button type="button" disabled={p.benchmarking} onClick={p.onBenchmark} className="flex shrink-0 items-center gap-1.5 rounded-[12px] bg-violet-400/15 px-3 py-2 text-[12px] font-semibold text-violet-100 ring-1 ring-violet-300/30 disabled:opacity-60">
            <ChartIcon size={16} /> {p.benchmarking ? `${(p.benchProgress * 100).toFixed(0)}%` : "Run N=3"}
          </button>
        </div>
        {p.benchReport ? <BenchmarkBars report={p.benchReport} /> : <p className="text-[12px] text-slate-500">Runs the full trained brain, hand-crafted ACO, a random brain and six single-channel ablations headless across 3 deterministic seeds, then reports mean and std of food delivered.</p>}
        <h4 className="mb-1 mt-3 text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-400">Live channel mutes</h4>
        <div className="flex flex-wrap gap-1.5">
          {muteToggles.map((m) => (
            <button
              key={m.key}
              type="button"
              onClick={m.toggle}
              aria-pressed={m.on}
              className="rounded-[12px] px-2.5 py-1.5 text-[11px] font-medium ring-1 transition-all duration-200 jewel-ease"
              style={m.on ? { color: "#94a3b8", background: "rgba(255,255,255,0.03)", textDecoration: "line-through", boxShadow: "none" } : { color: m.color, background: "rgba(255,255,255,0.05)" }}
            >
              {m.on ? "muted " : ""}
              {m.label}
            </button>
          ))}
        </div>
      </section>

      <section className="rounded-[20px] border border-white/10 bg-black/20 p-3">
        <h3 className="mb-2 font-display text-[15px] text-slate-100">Live arena policy</h3>
        <div className="grid grid-cols-2 gap-1.5">
          {ARENAS.map((a) => (
            <button
              key={a.id}
              type="button"
              onClick={() => p.onArena(a.id)}
              aria-pressed={p.arena === a.id}
              className={`rounded-[12px] px-2 py-2 text-left text-[11px] font-medium ring-1 transition-all duration-200 jewel-ease ${p.arena === a.id ? "bg-amber-300/15 text-amber-100 ring-amber-300/40" : "bg-white/[0.03] text-slate-300 ring-white/10"}`}
            >
              {a.label}
            </button>
          ))}
        </div>
        <p className="mt-2 text-[11px] text-slate-500">In 50/50 modes, trained ants glow gold-cyan and baseline ants glow rose-slate. The HUD shows the live A/B delivery score.</p>
      </section>

      <section className="rounded-[20px] border border-white/10 bg-black/20 p-3">
        <h3 className="mb-2 font-display text-[15px] text-slate-100">Colony brain weights</h3>
        <WeightHeatmap weights={p.weights} />
      </section>
    </div>
  );
}
