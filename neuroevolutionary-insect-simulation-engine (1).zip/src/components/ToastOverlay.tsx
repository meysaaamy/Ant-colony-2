"use client";

import type { ToastTone } from "./SanctuaryCanvas";

export interface ToastItem {
  id: number;
  msg: string;
  tone: ToastTone;
}

const TONE: Record<ToastTone, string> = {
  info: "0,225,255",
  success: "0,230,118",
  warn: "255,12,75",
};

export default function ToastOverlay({ toasts }: { toasts: ToastItem[] }) {
  return (
    <div className="pointer-events-none fixed inset-x-0 top-[76px] z-40 flex flex-col items-center gap-2 px-4" aria-live="polite">
      {toasts.map((t) => (
        <div key={t.id} className="glass toast-in flex max-w-md items-center gap-2 rounded-[20px] px-4 py-2 text-[13px] text-slate-100">
          <svg width="10" height="10" viewBox="0 0 10 10" aria-hidden="true">
            <circle cx="5" cy="5" r="4" fill={`rgb(${TONE[t.tone]})`} />
            <circle cx="5" cy="5" r="4.5" fill="none" stroke={`rgba(${TONE[t.tone]},0.4)`} />
          </svg>
          {t.msg}
        </div>
      ))}
    </div>
  );
}
