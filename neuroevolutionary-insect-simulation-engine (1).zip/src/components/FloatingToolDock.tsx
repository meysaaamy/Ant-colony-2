"use client";

import { useState } from "react";
import type { AlarmSubMode, ToolId } from "@/lib/types";
import { AlarmIcon, EraserIcon, FoodClusterIcon, FoodTrailIcon, HomeTrailIcon, PredatorIcon, WallIcon } from "./ui/icons";

interface ToolDockProps {
  tool: ToolId;
  alarmMode: AlarmSubMode;
  radius: number;
  onTool: (t: ToolId) => void;
  onAlarmMode: (m: AlarmSubMode) => void;
  onRadius: (r: number) => void;
}

export const TOOL_ORDER: readonly ToolId[] = ["food-trail", "home-trail", "alarm", "crystal", "wall", "eraser"];
const TOOL_LABEL: Record<ToolId, string> = {
  "food-trail": "Food",
  "home-trail": "Home",
  alarm: "Alarm",
  crystal: "Crystal",
  wall: "Wall",
  eraser: "Eraser",
};
const TOOL_COLOR: Record<ToolId, string> = {
  "food-trail": "255,168,0",
  "home-trail": "0,225,255",
  alarm: "255,12,75",
  crystal: "0,230,118",
  wall: "56,189,248",
  eraser: "226,232,240",
};

interface SubPill {
  id: string;
  label: string;
  rgb: string;
  tool: ToolId;
  mode?: AlarmSubMode;
}
const SUB_PILLS: readonly SubPill[] = [
  { id: "food", label: "Food Amber", rgb: "255,168,0", tool: "food-trail" },
  { id: "home", label: "Home Cyan", rgb: "0,225,255", tool: "home-trail" },
  { id: "alarm", label: "Alarm Crimson", rgb: "255,12,75", tool: "alarm", mode: "alarm" },
  { id: "scout", label: "Scout Violet", rgb: "175,50,255", tool: "alarm", mode: "scout" },
  { id: "noentry", label: "No-Entry Viridian", rgb: "80,255,100", tool: "alarm", mode: "noentry" },
  { id: "predator", label: "Spawn Predator", rgb: "255,92,133", tool: "alarm", mode: "predator" },
];

function ToolGlyph({ tool, alarmMode }: { tool: ToolId; alarmMode: AlarmSubMode }) {
  const p = { size: 24, strokeWidth: 1.75 };
  switch (tool) {
    case "food-trail":
      return <FoodTrailIcon {...p} />;
    case "home-trail":
      return <HomeTrailIcon {...p} />;
    case "alarm":
      return alarmMode === "predator" ? <PredatorIcon {...p} /> : <AlarmIcon {...p} />;
    case "crystal":
      return <FoodClusterIcon {...p} />;
    case "wall":
      return <WallIcon {...p} />;
    case "eraser":
      return <EraserIcon {...p} />;
  }
}

export default function FloatingToolDock({ tool, alarmMode, radius, onTool, onAlarmMode, onRadius }: ToolDockProps) {
  const [radiusOpen, setRadiusOpen] = useState(false);
  const showSub = tool === "food-trail" || tool === "home-trail" || tool === "alarm";
  const isActiveSub = (p: SubPill) => p.tool === tool && (p.mode === undefined || p.mode === alarmMode);
  return (
    <div className="flex w-full flex-col items-center gap-2">
      {/* Tier 2: contextual pills */}
      <div className="no-scrollbar flex max-w-full items-center gap-2 overflow-x-auto px-1">
        <span className="glass shrink-0 rounded-[20px] px-3 py-1.5 text-[12px] font-semibold" style={{ color: `rgb(${TOOL_COLOR[tool]})` }}>
          {TOOL_LABEL[tool]}
        </span>
        {showSub
          ? SUB_PILLS.map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => {
                  onTool(p.tool);
                  if (p.mode) onAlarmMode(p.mode);
                }}
                className="glass shrink-0 rounded-[20px] px-3 py-1.5 text-[12px] font-medium transition-all duration-200 jewel-ease"
                style={isActiveSub(p) ? { color: "#020307", background: `rgb(${p.rgb})` } : { color: `rgb(${p.rgb})` }}
              >
                {p.label}
              </button>
            ))
          : (
            <span className="glass shrink-0 rounded-[20px] px-3 py-1.5 text-[12px] text-slate-300">
              {tool === "wall" ? "Paint terraced basalt" : tool === "crystal" ? "Tap or drag to seed emerald crystals" : "Erase trails, crystals, walls"}
            </span>
          )}
        <div className="relative shrink-0">
          <button type="button" onClick={() => setRadiusOpen((o) => !o)} className="glass rounded-[20px] px-3 py-1.5 text-[12px] font-medium text-slate-200 tnum" aria-expanded={radiusOpen}>
            r {radius}
          </button>
          {radiusOpen ? (
            <div className="glass absolute bottom-[calc(100%+8px)] right-0 w-56 rounded-[20px] p-3">
              <label className="flex items-center justify-between text-[12px] text-slate-300 tnum">
                Brush radius <span>{radius}px</span>
              </label>
              <input className="jewel-range" type="range" min={6} max={60} step={2} value={radius} onChange={(e) => onRadius(Number(e.target.value))} />
            </div>
          ) : null}
        </div>
      </div>
      {/* Tier 3: 6-tool jewel dock */}
      <div className="glass flex items-center gap-1 rounded-[24px] p-1.5" role="toolbar" aria-label="Tools">
        {TOOL_ORDER.map((t, i) => {
          const active = t === tool;
          return (
            <button
              key={t}
              type="button"
              onClick={() => onTool(t)}
              aria-pressed={active}
              aria-label={`${TOOL_LABEL[t]} tool (${i + 1})`}
              className="relative flex h-[52px] w-[52px] flex-col items-center justify-center rounded-[18px] transition-all duration-200 jewel-ease sm:w-[60px]"
              style={{
                color: active ? `rgb(${TOOL_COLOR[t]})` : "rgb(148,163,184)",
                background: active ? `radial-gradient(circle at 50% 70%, rgba(${TOOL_COLOR[t]},0.28), rgba(${TOOL_COLOR[t]},0.04) 70%)` : "transparent",
                boxShadow: active ? `inset 0 1px 0 rgba(255,255,255,0.18), 0 0 0 1px rgba(${TOOL_COLOR[t]},0.35)` : "none",
              }}
            >
              <ToolGlyph tool={t} alarmMode={alarmMode} />
              <span className="absolute right-1.5 top-1 text-[9px] font-semibold text-slate-500 tnum">{i + 1}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
