"use client";

import type { SimSnapshot } from "./SanctuaryCanvas";
import { AntIcon, BookIcon, CrystalIcon, PauseIcon, PlayIcon, SlidersIcon } from "./ui/icons";

interface TelemetryPillProps {
  snap: SimSnapshot | null;
  speed: 1 | 2 | 4;
  paused: boolean;
  onTogglePause: () => void;
  onCycleSpeed: () => void;
  onOpenGuide: () => void;
  onOpenSheet: () => void;
}

export default function TelemetryPill({ snap, speed, paused, onTogglePause, onCycleSpeed, onOpenGuide, onOpenSheet }: TelemetryPillProps) {
  const t = snap?.telemetry;
  const fps = snap?.fps ?? 60;
  const dot = fps >= 55 ? "#00e676" : fps >= 40 ? "#ffa800" : "#ff0c4b";
  const ab = snap && (snap.arena === "ab-random" || snap.arena === "ab-aco");
  return (
    <div className="pointer-events-none fixed inset-x-0 top-0 z-30 flex items-start justify-between gap-2 px-3 pt-[max(12px,env(safe-area-inset-top))]">
      <div className="glass pointer-events-auto flex min-w-0 items-center gap-2 rounded-[28px] py-1 pl-3 pr-1 text-[13px] tnum">
        <span className="flex items-center gap-1" title={`${fps.toFixed(0)} FPS${snap?.lowPerf ? " (adaptive scaler on)" : ""}`}>
          <span className="inline-block h-2 w-2 rounded-full" style={{ background: dot, boxShadow: `0 0 0 3px ${dot}22` }} />
          <span className="hidden text-[11px] text-slate-400 sm:inline">{fps.toFixed(0)}</span>
        </span>
        <span className="flex items-center gap-1 text-amber-200">
          <AntIcon size={16} />
          <span className="font-semibold text-slate-100">{t?.alive ?? 0}</span>
          <span className="hidden text-[11px] text-slate-400 min-[380px]:inline">({t?.deaths ?? 0} dead)</span>
        </span>
        <span className="flex items-center gap-1 text-emerald-300">
          <CrystalIcon size={16} />
          <span className="font-semibold text-slate-100">{t?.foodDelivered ?? 0}</span>
        </span>
        <span className="rounded-[12px] border border-cyan-300/30 bg-cyan-400/10 px-2 py-0.5 text-[11px] font-bold tracking-wider text-cyan-200">GEN {t?.colonyGeneration ?? 1}</span>
        {ab && t ? (
          <span className="hidden rounded-[12px] border border-amber-300/30 bg-amber-400/10 px-2 py-0.5 text-[11px] font-semibold text-amber-100 min-[420px]:inline" title="A/B live score: trained cohort vs baseline cohort">
            A/B {t.cohortTrained}:{t.cohortOther}
          </span>
        ) : null}
        <button
          type="button"
          onClick={onCycleSpeed}
          className="rounded-[12px] border border-white/10 px-2 py-1 text-[11px] font-semibold text-slate-200 transition-colors duration-200 jewel-ease hover:bg-white/10"
          aria-label="Cycle simulation speed"
        >
          {speed}x
        </button>
        <button
          type="button"
          onClick={onTogglePause}
          className="flex h-12 w-12 items-center justify-center rounded-full bg-white/5 text-slate-100 transition-colors duration-200 jewel-ease hover:bg-white/15"
          aria-label={paused ? "Play" : "Pause"}
        >
          {paused ? <PlayIcon size={22} /> : <PauseIcon size={22} />}
        </button>
      </div>
      <div className="pointer-events-auto flex gap-2">
        <button type="button" onClick={onOpenGuide} className="glass flex h-[46px] w-[46px] items-center justify-center rounded-[14px] text-slate-100" aria-label="Open field guide">
          <BookIcon size={22} />
        </button>
        <button type="button" onClick={onOpenSheet} className="glass flex h-[46px] w-[46px] items-center justify-center rounded-[14px] text-slate-100" aria-label="Open parameters and proof lab">
          <SlidersIcon size={22} />
        </button>
      </div>
    </div>
  );
}
