import type { ReactNode, SVGProps } from "react";

export interface IconProps extends Omit<SVGProps<SVGSVGElement>, "children"> {
  size?: number;
  stroke?: string;
  strokeWidth?: number;
}

function Base({ size = 24, stroke = "currentColor", strokeWidth = 1.75, children, ...rest }: IconProps & { children: ReactNode }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke={stroke}
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      {...rest}
    >
      {children}
    </svg>
  );
}

export const AntIcon = (p: IconProps) => (
  <Base {...p}>
    <ellipse cx="12" cy="7" rx="2" ry="2.2" />
    <ellipse cx="12" cy="12" rx="2.2" ry="2.6" />
    <ellipse cx="12" cy="18" rx="3" ry="3.6" />
    <path d="M10 11l-4-2M14 11l4-2M10 13l-5 1M14 13l5 1M10 15l-3 4M14 15l3 4M11 5l-2-3M13 5l2-3" />
  </Base>
);

export const CrystalIcon = (p: IconProps) => (
  <Base {...p}>
    <path d="M12 2l6 7-6 13-6-13z" />
    <path d="M6 9h12M12 2v20" strokeOpacity={0.55} />
  </Base>
);

export const PlayIcon = (p: IconProps) => (
  <Base {...p}>
    <path d="M8 5l11 7-11 7z" fill="currentColor" fillOpacity={0.25} />
  </Base>
);

export const PauseIcon = (p: IconProps) => (
  <Base {...p}>
    <path d="M8 5v14M16 5v14" />
  </Base>
);

export const BookIcon = (p: IconProps) => (
  <Base {...p}>
    <path d="M4 5c3-1.5 5.5-1.5 8 0v15c-2.5-1.5-5-1.5-8 0z" />
    <path d="M12 5c2.5-1.5 5-1.5 8 0v15c-3-1.5-5.5-1.5-8 0" />
  </Base>
);

export const SlidersIcon = (p: IconProps) => (
  <Base {...p}>
    <path d="M4 7h10M18 7h2M4 17h4M12 17h8" />
    <circle cx="16" cy="7" r="2" />
    <circle cx="10" cy="17" r="2" />
  </Base>
);

export const FoodTrailIcon = (p: IconProps) => (
  <Base {...p}>
    <path d="M3 18c3-1 4-5 7-6s5 2 8 0 2-6 3-7" />
    <circle cx="4" cy="18" r="1.4" fill="currentColor" />
  </Base>
);

export const HomeTrailIcon = (p: IconProps) => (
  <Base {...p}>
    <circle cx="12" cy="13" r="7" />
    <circle cx="12" cy="13" r="3" />
    <path d="M12 2v3" />
  </Base>
);

export const AlarmIcon = (p: IconProps) => (
  <Base {...p}>
    <path d="M12 3l9 16H3z" />
    <path d="M12 9v5" />
    <circle cx="12" cy="16.8" r="0.5" fill="currentColor" />
  </Base>
);

export const PredatorIcon = (p: IconProps) => (
  <Base {...p}>
    <path d="M12 3c4 0 6 3 6 7s-2 10-6 11c-4-1-6-7-6-11s2-7 6-7z" />
    <path d="M9 9h.01M15 9h.01" strokeWidth={2.6} />
    <path d="M6 10l-3-2M18 10l3-2M6 14l-3 1M18 14l3 1M9 13c2 1 4 1 6 0" />
  </Base>
);

export const FoodClusterIcon = (p: IconProps) => (
  <Base {...p}>
    <path d="M8 3l4 5-4 8-4-8z" />
    <path d="M16 8l3.5 4-3.5 8-3.5-8z" />
  </Base>
);

export const WallIcon = (p: IconProps) => (
  <Base {...p}>
    <path d="M3 17c2-4 5-3 7-6s5-4 11-3v8c-5 0-6 3-10 4s-6-1-8-3z" />
    <path d="M6 15c3-2 5-1 7-3s4-2 6-2" strokeOpacity={0.55} />
  </Base>
);

export const EraserIcon = (p: IconProps) => (
  <Base {...p}>
    <circle cx="12" cy="12" r="8" strokeDasharray="3 2.4" />
    <path d="M9 9l6 6M15 9l-6 6" />
  </Base>
);

export const CloseIcon = (p: IconProps) => (
  <Base {...p}>
    <path d="M6 6l12 12M18 6L6 18" />
  </Base>
);

export const ResetIcon = (p: IconProps) => (
  <Base {...p}>
    <path d="M4 12a8 8 0 1 0 2.4-5.7" />
    <path d="M4 4v4h4" />
  </Base>
);

export const SparkIcon = (p: IconProps) => (
  <Base {...p}>
    <path d="M12 3v5M12 16v5M3 12h5M16 12h5M6 6l3 3M15 15l3 3M18 6l-3 3M9 15l-3 3" />
  </Base>
);

export const SplitIcon = (p: IconProps) => (
  <Base {...p}>
    <rect x="3" y="4" width="18" height="16" rx="4" />
    <path d="M12 4v16" />
    <circle cx="7.5" cy="12" r="1.5" />
    <path d="M15 12h3" />
  </Base>
);

export const BrushIcon = (p: IconProps) => (
  <Base {...p}>
    <path d="M20 4l-9 9" />
    <path d="M11 13c-3 0-5 2-5 4s-1 3-3 3c3 1 8 1 9-3 .5-2-1-4-1-4z" />
  </Base>
);

export const GlobeIcon = (p: IconProps) => (
  <Base {...p}>
    <circle cx="12" cy="12" r="9" />
    <path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18" />
  </Base>
);

export const FlaskIcon = (p: IconProps) => (
  <Base {...p}>
    <path d="M9 3h6M10 3v6l-5 9a2 2 0 0 0 2 3h10a2 2 0 0 0 2-3l-5-9V3" />
    <path d="M7.5 15h9" />
  </Base>
);

export const ChartIcon = (p: IconProps) => (
  <Base {...p}>
    <path d="M4 20V4M4 20h16" />
    <path d="M7 16l4-5 3 3 5-7" />
  </Base>
);

export const ShieldIcon = (p: IconProps) => (
  <Base {...p}>
    <path d="M12 3l8 3v6c0 5-4 8-8 9-4-1-8-4-8-9V6z" />
  </Base>
);

export const DownloadIcon = (p: IconProps) => (
  <Base {...p}>
    <path d="M12 4v11M7 10l5 5 5-5M5 20h14" />
  </Base>
);

export const UploadIcon = (p: IconProps) => (
  <Base {...p}>
    <path d="M12 20V9M7 14l5-5 5 5M5 4h14" />
  </Base>
);

export const BroomIcon = (p: IconProps) => (
  <Base {...p}>
    <path d="M14 4l-4 8" />
    <path d="M6 12h8l2 8H4z" />
    <path d="M8 16v4M12 16v4" />
  </Base>
);
