"use client";

import { useEffect, useMemo, useRef, useState, type CSSProperties, type ReactNode } from "react";
import { PheromoneGrid } from "@/lib/pheromone-grid";
import { PRESETS } from "@/lib/presets";
import { CHANNEL_LABELS, CHANNEL_RGB, type AblationMask, type ArenaMode, type PresetDef, type PresetId, type SheetSnap, type SheetTab } from "@/lib/types";
import ProofOfLearningLab from "./ProofOfLearningLab";
import type { SimParams, SimSnapshot } from "./SanctuaryCanvas";
import { BroomIcon, BrushIcon, ChartIcon, FlaskIcon, GlobeIcon, PredatorIcon, ResetIcon, ShieldIcon, SparkIcon, SplitIcon } from "./ui/icons";

interface ParameterSheetProps {
  snap: SimSnapshot | null;
  snapState: SheetSnap;
  onSnap: (s: SheetSnap) => void;
  tab: SheetTab;
  onTab: (t: SheetTab) => void;
  presetId: PresetId;
  onPreset: (id: PresetId) => void;
  params: SimParams;
  onParams: (p: SimParams) => void;
  ablation: AblationMask;
  onAblation: (m: AblationMask) => void;
  brushRadius: number;
  onBrushRadius: (r: number) => void;
  weights: Float32Array;
  worldW: number;
  worldH: number;
  onTrain: (n: number) => void;
  onBenchmark: () => void;
  onArena: (m: ArenaMode) => void;
  onClearTrails: () => void;
  onReset: () => void;
  onSpawnPredator: () => void;
  onExport: () => void;
  onImport: (json: string) => void;
  onRestore: () => void;
}

const TABS: ReadonlyArray<{ id: SheetTab; label: string; icon: ReactNode }> = [
  { id: "proof", label: "Proof of Learning", icon: <ChartIcon size={16} /> },
  { id: "colony", label: "Colony & Threats", icon: <ShieldIcon size={16} /> },
  { id: "alchemy", label: "Pheromone Alchemy", icon: <FlaskIcon size={16} /> },
  { id: "brush", label: "Brush", icon: <BrushIcon size={16} /> },
  { id: "world", label: "World", icon: <GlobeIcon size={16} /> },
];

function Slider({ label, value, min, max, step, fmt, onChange }: { label: string; value: number; min: number; max: number; step: number; fmt?: (v: number) => string; onChange: (v: number) => void }) {
  return (
    <label className="block">
      <span className="flex items-center justify-between text-[12px] text-slate-300 tnum">
        {label}
        <span className="text-slate-100">{fmt ? fmt(value) : value}</span>
      </span>
      <input className="jewel-range" type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(Number(e.target.value))} />
    </label>
  );
}

function PresetPreview({ preset, w, h }: { preset: PresetDef; w: number; h: number }) {
  const ref = useRef<HTMLCanvasElement | null>(null);
  useEffect(() => {
    const c = ref.current;
    if (!c) return;
    const ctx = c.getContext("2d");
    if (!ctx) return;
    const L = preset.build(w, h, 1337);
    const s = Math.min(c.width / w, c.height / h);
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.fillStyle = "#020307";
    ctx.fillRect(0, 0, c.width, c.height);
    ctx.setTransform(s, 0, 0, s, (c.width - w * s) / 2, (c.height - h * s) / 2);
    const strokes = (list: typeof L.walls, fill: string, rim: string | null) => {
      for (const st of list) {
        ctx.lineCap = "round";
        if (st.kind === "circle") {
          ctx.beginPath();
          ctx.arc(st.x, st.y, st.r, 0, Math.PI * 2);
          ctx.fillStyle = fill;
          ctx.fill();
          if (rim) {
            ctx.strokeStyle = rim;
            ctx.lineWidth = 3;
            ctx.stroke();
          }
        } else {
          ctx.strokeStyle = fill;
          ctx.lineWidth = st.r * 2;
          ctx.beginPath();
          ctx.moveTo(st.x1, st.y1);
          ctx.lineTo(st.x2, st.y2);
          ctx.stroke();
        }
      }
    };
    strokes(L.walls, "#0d1322", "#2dd4bf");
    strokes(L.carve, "#020307", null);
    for (const f of L.foods) {
      ctx.fillStyle = "#00e676";
      ctx.beginPath();
      ctx.arc(f.x, f.y, 16, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.strokeStyle = "#00e1ff";
    ctx.lineWidth = 8;
    ctx.beginPath();
    ctx.arc(L.nest.x, L.nest.y, 26, 0, Math.PI * 2);
    ctx.stroke();
  }, [preset, w, h]);
  return <canvas ref={ref} width={w > h ? 160 : 90} height={w > h ? 90 : 160} className="rounded-[12px] border border-white/10" />;
}

export default function ParameterSheet(p: ParameterSheetProps) {
  const [confirmReset, setConfirmReset] = useState(false);
  const drag = useRef<{ y: number; id: number } | null>(null);
  const mixer = useMemo(() => new PheromoneGrid(12, 12), []);
  useEffect(() => {
    if (!confirmReset) return;
    const t = setTimeout(() => setConfirmReset(false), 2500);
    return () => clearTimeout(t);
  }, [confirmReset]);

  const preset = PRESETS.find((x) => x.id === p.presetId) ?? PRESETS[0];
  const arena = p.snap?.arena ?? "trained";
  const expanded = p.snapState !== "peek";
  const order: SheetSnap[] = ["peek", "half", "full"];
  const step = (dir: 1 | -1) => {
    const i = order.indexOf(p.snapState);
    p.onSnap(order[Math.max(0, Math.min(2, i + dir))]);
  };
  const sheetStyle = { "--sheet-h": p.snapState === "full" ? "78dvh" : p.snapState === "half" ? "48dvh" : "auto" } as CSSProperties;
  const swatches: ReadonlyArray<{ label: string; c: number[] }> = [
    ...CHANNEL_LABELS.map((l, i) => ({ label: l, c: [0, 0, 0, 0, 0].map((_, k) => (k === i ? 70 : 0)) })),
    { label: "Food+Home highway", c: [70, 70, 0, 0, 0] },
    { label: "Food+Scout coral", c: [60, 0, 0, 60, 0] },
    { label: "Home+Alarm magenta", c: [0, 60, 60, 0, 0] },
    { label: "Alarm+NoEntry sulfur", c: [0, 0, 60, 0, 60] },
  ];

  return (
    <section
      className={`glass pointer-events-auto flex w-full max-w-[520px] flex-col overflow-hidden rounded-[22px] transition-[height] duration-300 jewel-ease md:fixed md:right-4 md:top-[76px] md:w-[390px] md:max-w-none ${expanded ? "h-[var(--sheet-h)] md:bottom-4 md:h-auto" : "md:h-auto"}`}
      style={sheetStyle}
      aria-label="Colony control sheet"
    >
      {/* Tier 1 peek card */}
      <div className="shrink-0 px-4 pb-3 pt-2">
        <button
          type="button"
          className="mx-auto mb-2 block h-5 w-16 touch-none"
          aria-label="Drag or tap to resize sheet"
          onPointerDown={(e) => {
            drag.current = { y: e.clientY, id: e.pointerId };
            e.currentTarget.setPointerCapture(e.pointerId);
          }}
          onPointerUp={(e) => {
            const d = drag.current;
            drag.current = null;
            if (!d) return;
            const dy = e.clientY - d.y;
            if (dy < -30) step(1);
            else if (dy > 30) step(-1);
            else p.onSnap(expanded ? "peek" : "half");
          }}
        >
          <span className="mx-auto block h-1.5 w-10 rounded-full bg-white/25" />
        </button>
        <div className="flex items-center justify-between gap-2">
          <div className="min-w-0">
            <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-cyan-300/80">Sanctuary</p>
            <h2 className="truncate font-display text-[17px] text-slate-50">{preset.name}</h2>
          </div>
          <div className="flex shrink-0 gap-1.5">
            <button type="button" onClick={p.onClearTrails} className="flex h-9 items-center gap-1 rounded-[12px] bg-white/5 px-2.5 text-[12px] text-slate-200 ring-1 ring-white/10" aria-label="Clear trails">
              <BroomIcon size={16} /> <span className="hidden min-[400px]:inline">Clear trails</span>
            </button>
            <button
              type="button"
              onClick={() => {
                if (confirmReset) {
                  setConfirmReset(false);
                  p.onReset();
                } else setConfirmReset(true);
              }}
              className={`flex h-9 items-center gap-1 rounded-[12px] px-2.5 text-[12px] ring-1 transition-colors duration-200 ${confirmReset ? "bg-rose-500/25 text-rose-100 ring-rose-400/50" : "bg-white/5 text-slate-200 ring-white/10"}`}
            >
              <ResetIcon size={16} /> {confirmReset ? "Tap again" : "Reset"}
            </button>
          </div>
        </div>
        <div className="no-scrollbar mt-2 flex gap-1.5 overflow-x-auto">
          <button type="button" disabled={p.snap?.training} onClick={() => p.onTrain(5)} className="flex shrink-0 items-center gap-1 rounded-[20px] bg-cyan-400/15 px-3 py-1.5 text-[12px] font-semibold text-cyan-100 ring-1 ring-cyan-300/30 disabled:opacity-70">
            <SparkIcon size={14} /> {p.snap?.training ? `Training ${((p.snap?.trainProgress ?? 0) * 100).toFixed(0)}%` : "Train +5 Gen"}
          </button>
          <button
            type="button"
            onClick={() => p.onArena(arena === "ab-random" ? "trained" : "ab-random")}
            aria-pressed={arena === "ab-random"}
            className={`flex shrink-0 items-center gap-1 rounded-[20px] px-3 py-1.5 text-[12px] font-semibold ring-1 ${arena === "ab-random" ? "bg-amber-300/20 text-amber-100 ring-amber-300/40" : "bg-white/5 text-slate-200 ring-white/10"}`}
          >
            <SplitIcon size={14} /> A/B vs Random
          </button>
          <button
            type="button"
            onClick={() => {
              const on = p.params.predatorCount > 0;
              p.onParams({ ...p.params, predatorCount: on ? 0 : 2 });
              if (!on) p.onSpawnPredator();
            }}
            aria-pressed={p.params.predatorCount > 0}
            className={`flex shrink-0 items-center gap-1 rounded-[20px] px-3 py-1.5 text-[12px] font-semibold ring-1 ${p.params.predatorCount > 0 ? "bg-rose-500/20 text-rose-100 ring-rose-400/40" : "bg-white/5 text-slate-200 ring-white/10"}`}
          >
            <PredatorIcon size={14} /> Predator Threat
          </button>
        </div>
      </div>

      {expanded ? (
        <>
          <div className="no-scrollbar flex shrink-0 gap-1 overflow-x-auto border-y border-white/5 px-3 py-2" role="tablist">
            {TABS.map((t) => (
              <button
                key={t.id}
                role="tab"
                type="button"
                aria-selected={p.tab === t.id}
                onClick={() => p.onTab(t.id)}
                className={`flex shrink-0 items-center gap-1.5 rounded-[12px] px-2.5 py-1.5 text-[12px] font-medium transition-colors duration-200 ${p.tab === t.id ? "bg-white/10 text-slate-50" : "text-slate-400 hover:text-slate-200"}`}
              >
                {t.icon}
                {t.label}
              </button>
            ))}
          </div>
          <div className="no-scrollbar min-h-0 flex-1 overflow-y-auto px-4 py-3">
            {p.tab === "proof" ? (
              <ProofOfLearningLab
                history={p.snap?.history ?? []}
                training={p.snap?.training ?? false}
                trainProgress={p.snap?.trainProgress ?? 0}
                benchReport={p.snap?.benchReport ?? null}
                benchmarking={p.snap?.benchmarking ?? false}
                benchProgress={p.snap?.benchProgress ?? 0}
                arena={arena}
                ablation={p.ablation}
                weights={p.weights}
                onTrain={p.onTrain}
                onBenchmark={p.onBenchmark}
                onArena={p.onArena}
                onAblation={p.onAblation}
                onExport={p.onExport}
                onImport={p.onImport}
                onRestore={p.onRestore}
              />
            ) : null}
            {p.tab === "colony" ? (
              <div className="space-y-3">
                <Slider label="Max population" value={p.params.maxPop} min={100} max={3000} step={50} onChange={(v) => p.onParams({ ...p.params, maxPop: v })} />
                <Slider label="Abyssal Stalkers (0-6)" value={p.params.predatorCount} min={0} max={6} step={1} onChange={(v) => p.onParams({ ...p.params, predatorCount: v })} />
                <button type="button" onClick={p.onSpawnPredator} className="flex w-full items-center justify-center gap-2 rounded-[12px] bg-rose-500/15 py-2.5 text-[13px] font-semibold text-rose-100 ring-1 ring-rose-400/30">
                  <PredatorIcon size={18} /> Spawn predator now
                </button>
                <Slider label="ATP burn rate" value={p.params.atpBurn} min={0.25} max={3} step={0.05} fmt={(v) => `${v.toFixed(2)}x`} onChange={(v) => p.onParams({ ...p.params, atpBurn: v })} />
                <Slider label="Lifespan" value={p.params.lifespanScale} min={0.25} max={3} step={0.05} fmt={(v) => `${v.toFixed(2)}x`} onChange={(v) => p.onParams({ ...p.params, lifespanScale: v })} />
                <div className="grid grid-cols-3 gap-2 text-center text-[11px] text-slate-400 tnum">
                  <div className="rounded-[12px] bg-white/[0.03] p-2">
                    <div className="text-[15px] text-slate-100">{p.snap?.telemetry.births ?? 0}</div>births
                  </div>
                  <div className="rounded-[12px] bg-white/[0.03] p-2">
                    <div className="text-[15px] text-slate-100">{p.snap?.telemetry.deaths ?? 0}</div>deaths
                  </div>
                  <div className="rounded-[12px] bg-white/[0.03] p-2">
                    <div className="text-[15px] text-slate-100">{p.snap?.telemetry.bottlenecks ?? 0}</div>bottlenecks
                  </div>
                </div>
                <p className="text-[11px] leading-relaxed text-slate-500">Every 3 delivered crystals hatch one ant; every 25 births advance the colony generation. Below 35 survivors, a founder bottleneck brood wave hatches with a 2.5x trait-mutation boost.</p>
              </div>
            ) : null}
            {p.tab === "alchemy" ? (
              <div className="space-y-3">
                <div className="grid grid-cols-3 gap-2">
                  {swatches.map((s) => {
                    const [r, g, b] = mixer.mixSample(s.c);
                    return (
                      <div key={s.label} className="flex flex-col items-center gap-1 rounded-[12px] bg-black/30 p-2">
                        <svg width="36" height="36" viewBox="0 0 36 36" aria-hidden="true">
                          <circle cx="18" cy="18" r="15" fill={`rgb(${r},${g},${b})`} />
                          <circle cx="18" cy="18" r="17" fill="none" stroke={`rgba(${r},${g},${b},0.35)`} />
                        </svg>
                        <span className="text-center text-[10px] leading-tight text-slate-400">{s.label}</span>
                      </div>
                    );
                  })}
                </div>
                <Slider label="Evaporation" value={p.params.evaporation} min={0.01} max={0.3} step={0.005} fmt={(v) => `${v.toFixed(3)}/s`} onChange={(v) => p.onParams({ ...p.params, evaporation: v })} />
                <Slider label="Cross-reaction rate" value={p.params.reactionRate} min={0} max={2} step={0.05} fmt={(v) => v.toFixed(2)} onChange={(v) => p.onParams({ ...p.params, reactionRate: v })} />
                <Slider label="Diffusion (CFL clamped)" value={p.params.diffusion} min={0} max={1} step={0.01} fmt={(v) => v.toFixed(2)} onChange={(v) => p.onParams({ ...p.params, diffusion: v })} />
                <p className="text-[11px] leading-relaxed text-slate-500">
                  Tonemapped synthesis 1 - exp(-gamma * sum w*C*RGB). Alarm decays 3.2x faster, food and home polymerise and decay 35% slower, and noEntry dissolves foodTrail at 0.45 * C per second.
                </p>
                <div className="flex flex-wrap gap-1">
                  {CHANNEL_RGB.map((c, i) => (
                    <span key={i} className="rounded-[8px] px-2 py-0.5 text-[10px] font-semibold" style={{ color: `rgb(${c[0]},${c[1]},${c[2]})`, background: `rgba(${c[0]},${c[1]},${c[2]},0.1)` }}>
                      {CHANNEL_LABELS[i]}
                    </span>
                  ))}
                </div>
              </div>
            ) : null}
            {p.tab === "brush" ? (
              <div className="space-y-3">
                <Slider label="Brush radius" value={p.brushRadius} min={6} max={60} step={2} fmt={(v) => `${v}px`} onChange={p.onBrushRadius} />
                <p className="text-[12px] leading-relaxed text-slate-400">Strokes are smoothed with a Catmull-Rom spline and stamped every 0.25 r. Pheromone tools paint concentration with a soft falloff, Wall paints basalt with bioluminescent rims, and Eraser clears trails, crystals and walls.</p>
                <ul className="space-y-1 text-[12px] text-slate-300">
                  <li>1 Food: amber recruitment trail</li>
                  <li>2 Home: cyan nest guide</li>
                  <li>3 Alarm: crimson, violet, viridian or Spawn Predator</li>
                  <li>4 Crystal: seed emerald food</li>
                  <li>5 Wall: terraced basalt</li>
                  <li>6 Eraser: rotating reticle</li>
                </ul>
              </div>
            ) : null}
            {p.tab === "world" ? (
              <div className="space-y-2">
                {PRESETS.map((pr) => (
                  <button
                    key={pr.id}
                    type="button"
                    onClick={() => p.onPreset(pr.id)}
                    className={`flex w-full items-center gap-3 rounded-[20px] p-2 text-left ring-1 transition-colors duration-200 ${pr.id === p.presetId ? "bg-cyan-400/10 ring-cyan-300/40" : "bg-white/[0.03] ring-white/10"}`}
                  >
                    <PresetPreview preset={pr} w={p.worldW} h={p.worldH} />
                    <span>
                      <span className="block font-display text-[15px] text-slate-100">{pr.name}</span>
                      <span className="block text-[11px] text-slate-400">{pr.subtitle}</span>
                    </span>
                  </button>
                ))}
              </div>
            ) : null}
          </div>
        </>
      ) : null}
    </section>
  );
}
