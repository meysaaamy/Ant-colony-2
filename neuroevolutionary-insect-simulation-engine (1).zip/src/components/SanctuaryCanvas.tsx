"use client";

import { useEffect, useRef } from "react";
import { AntEngine, DT } from "@/lib/ant-soa-engine";
import { ChunkedBenchmark, ChunkedTrainer, sharedRandomBrain } from "@/lib/headless-sim";
import { brainFromJSON, CHAMPION_HISTORY, cloneBrain, createChampionBrain, exportBrainJSON } from "@/lib/neat";
import { CatmullRomBrush } from "@/lib/pheromone-grid";
import { getPreset } from "@/lib/presets";
import { createBrushOverlay, Renderer } from "@/lib/renderer";
import {
  CHANNEL_RGB,
  CH_ALARM,
  CH_FOOD,
  CH_HOME,
  CH_NOENTRY,
  CH_SCOUT,
  defaultSimConfig,
  type AblationMask,
  type AlarmSubMode,
  type ArenaMode,
  type BenchmarkReport,
  type Brain,
  type PresetId,
  type Telemetry,
  type ToolId,
  type TrainingPoint,
} from "@/lib/types";

export type ToastTone = "info" | "success" | "warn";

export interface SimParams {
  maxPop: number;
  predatorCount: number;
  atpBurn: number;
  lifespanScale: number;
  evaporation: number;
  diffusion: number;
  reactionRate: number;
}

export interface SimSnapshot {
  telemetry: Telemetry;
  fps: number;
  lowPerf: boolean;
  paused: boolean;
  training: boolean;
  trainProgress: number;
  benchmarking: boolean;
  benchProgress: number;
  benchReport: BenchmarkReport | null;
  history: TrainingPoint[];
  arena: ArenaMode;
}

export const DEFAULT_PARAMS: SimParams = { maxPop: 2400, predatorCount: 0, atpBurn: 1, lifespanScale: 1, evaporation: 0.07, diffusion: 0.35, reactionRate: 1 };

const LS_BRAIN = "pf.brain.v1";
const LS_HISTORY = "pf.history.v1";

export function safeGet(key: string): string | null {
  try {
    return typeof window !== "undefined" ? window.localStorage.getItem(key) : null;
  } catch {
    return null;
  }
}

export function safeSet(key: string, value: string): void {
  try {
    window.localStorage.setItem(key, value);
  } catch {
    /* storage full or disabled */
  }
}

function loadHistory(): TrainingPoint[] {
  const raw = safeGet(LS_HISTORY);
  if (!raw) return [...CHAMPION_HISTORY];
  try {
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [...CHAMPION_HISTORY];
    const out: TrainingPoint[] = [];
    for (const p of parsed) {
      if (typeof p !== "object" || p === null) continue;
      const r = p as Record<string, unknown>;
      if (typeof r.generation === "number" && typeof r.trained === "number" && typeof r.aco === "number" && typeof r.random === "number") {
        out.push({ generation: r.generation, trained: r.trained, trainedStd: typeof r.trainedStd === "number" ? r.trainedStd : 0, aco: r.aco, random: r.random });
      }
    }
    return out.length ? out : [...CHAMPION_HISTORY];
  } catch {
    return [...CHAMPION_HISTORY];
  }
}

/** Imperative host for engine + renderer + trainers. Lives outside React render. */
export class SimController {
  readonly worldW: number;
  readonly worldH: number;
  engine: AntEngine;
  renderer: Renderer | null = null;
  brain: Brain;
  preset: PresetId = "open-sanctuary";
  params: SimParams = { ...DEFAULT_PARAMS };
  paused = false;
  autoPaused = false;
  speed: 1 | 2 | 4 = 1;
  tool: ToolId = "food-trail";
  alarmMode: AlarmSubMode = "alarm";
  brushRadius = 18;
  readonly overlay = createBrushOverlay();
  trainer: ChunkedTrainer | null = null;
  benchmark: ChunkedBenchmark | null = null;
  benchReport: BenchmarkReport | null = null;
  history: TrainingPoint[];
  listener: ((s: SimSnapshot) => void) | null = null;
  toaster: ((msg: string, tone?: ToastTone) => void) | null = null;
  onFirstStroke: (() => void) | null = null;
  private brush = new CatmullRomBrush();
  private pointerId: number | null = null;
  private lastCrystalX = 0;
  private lastCrystalY = 0;
  private acc = 0;
  private lastFrame = 0;
  private lastEmit = 0;
  private t0 = 0;
  private time = 0;

  constructor(portrait: boolean) {
    this.worldW = portrait ? 720 : 1280;
    this.worldH = portrait ? 1280 : 720;
    const stored = brainFromJSON(safeGet(LS_BRAIN) ?? "");
    this.brain = stored ?? createChampionBrain();
    this.history = loadHistory();
    this.engine = this.buildEngine();
  }

  private buildEngine(): AntEngine {
    const cfg = defaultSimConfig(this.worldW, this.worldH);
    cfg.maxPop = this.params.maxPop;
    cfg.predatorCount = this.params.predatorCount;
    cfg.atpBurn = this.params.atpBurn;
    cfg.lifespanScale = this.params.lifespanScale;
    cfg.pheromone = { evaporation: this.params.evaporation, diffusion: this.params.diffusion, reactionRate: this.params.reactionRate };
    cfg.seed = 1337;
    const layout = getPreset(this.preset).build(this.worldW, this.worldH, cfg.seed);
    const prev = this.engine as AntEngine | undefined;
    if (prev) {
      cfg.arena = prev.cfg.arena;
      cfg.ablation = prev.cfg.ablation;
    }
    return new AntEngine(cfg, this.brain, sharedRandomBrain(), layout);
  }

  attach(canvas: HTMLCanvasElement): void {
    this.renderer = new Renderer(canvas, this.engine);
    this.t0 = performance.now();
  }

  detach(): void {
    this.renderer = null;
  }

  resize(w: number, h: number, dpr: number): void {
    this.renderer?.resize(w, h, dpr);
  }

  /* ----------------------------- loop ----------------------------- */

  frame(now: number): void {
    const r = this.renderer;
    if (!r) return;
    const low = r.trackFrame(now);
    this.engine.cfg.diffusionInterval = low ? 2 : 1;
    const real = this.lastFrame ? Math.min(0.1, (now - this.lastFrame) / 1000) : DT;
    this.lastFrame = now;
    if (!this.paused) {
      this.acc += real * this.speed;
      let steps = 0;
      const maxSteps = 3 * this.speed;
      while (this.acc >= DT && steps < maxSteps) {
        this.engine.step();
        this.acc -= DT;
        steps++;
      }
      if (steps >= maxSteps) this.acc = 0;
    }
    if (this.trainer?.busy) {
      this.trainer.step(low ? 6 : 11);
      if (!this.trainer.busy) this.finishTraining();
    }
    if (this.benchmark) {
      const done = this.benchmark.step(low ? 5 : 9);
      this.benchReport = this.benchmark.report;
      if (done) {
        this.benchmark = null;
        this.toaster?.("Multi-seed benchmark complete", "success");
      }
    }
    this.time = (now - this.t0) / 1000;
    r.render({ cohortMode: this.engine.cfg.arena === "ab-random" || this.engine.cfg.arena === "ab-aco", time: this.time }, this.overlay);
    if (now - this.lastEmit > 100) {
      this.lastEmit = now;
      this.emit();
    }
  }

  emit(): void {
    const r = this.renderer;
    this.listener?.({
      telemetry: { ...this.engine.telemetry },
      fps: r ? r.fps : 60,
      lowPerf: r ? r.lowPerf : false,
      paused: this.paused,
      training: !!this.trainer?.busy,
      trainProgress: this.trainer?.progress ?? 0,
      benchmarking: !!this.benchmark,
      benchProgress: this.benchmark?.progress ?? 0,
      benchReport: this.benchReport,
      history: this.trainer ? this.trainer.history : this.history,
      arena: this.engine.cfg.arena,
    });
  }

  /* ----------------------------- commands ----------------------------- */

  setPaused(p: boolean): void {
    this.paused = p;
    this.emit();
  }

  loadPreset(id: PresetId): void {
    this.preset = id;
    this.reset();
  }

  reset(): void {
    this.engine = this.buildEngine();
    this.renderer?.setEngine(this.engine);
    this.emit();
  }

  clearTrails(): void {
    this.engine.clearTrails();
  }

  spawnPredator(x?: number, y?: number): boolean {
    const ok = this.engine.spawnPredator(x, y) >= 0;
    if (!ok) this.toaster?.("All 6 Abyssal Stalker slots are active", "warn");
    return ok;
  }

  setArena(mode: ArenaMode): void {
    this.engine.setArena(mode);
    this.emit();
  }

  setAblation(mask: AblationMask): void {
    this.engine.setAblation(mask);
  }

  setParams(p: SimParams): void {
    this.params = { ...p };
    const c = this.engine.cfg;
    c.maxPop = p.maxPop;
    c.predatorCount = p.predatorCount;
    c.atpBurn = p.atpBurn;
    c.lifespanScale = p.lifespanScale;
    this.engine.setPheromoneParams(p.evaporation, p.diffusion, p.reactionRate);
  }

  train(generations: number): void {
    if (!this.trainer || !this.trainer.busy) {
      this.trainer = new ChunkedTrainer(this.brain, this.history, { populationSize: 8, seeds: [11, 23], ticks: 900 }, (this.history.length + 7) * 31);
    }
    this.trainer.addGenerations(generations);
    this.toaster?.(`Headless neuroevolution: +${generations} generations queued`, "info");
    this.emit();
  }

  private finishTraining(): void {
    const t = this.trainer;
    if (!t) return;
    this.history = [...t.history];
    const champ = t.championBrain();
    const last = this.history[this.history.length - 1];
    // population gen-0 contains the unmutated seed brain, so evo.best is never worse on the trainer seeds
    if (champ) {
      this.brain = champ;
      this.engine.setBrain(champ);
      safeSet(LS_BRAIN, exportBrainJSON(champ));
    }
    safeSet(LS_HISTORY, JSON.stringify(this.history));
    this.toaster?.(`Training complete: generation ${last ? last.generation : 0} champion now drives the colony`, "success");
    this.trainer = null;
    this.emit();
  }

  runBenchmark(): void {
    this.benchmark = new ChunkedBenchmark(cloneBrain(this.brain));
    this.benchReport = this.benchmark.report;
    this.toaster?.("Running 9 conditions x 3 seeds headless", "info");
    this.emit();
  }

  exportBrain(): string {
    return exportBrainJSON(this.brain, { generation: this.history.length ? this.history[this.history.length - 1].generation : 0, fitness: 0, note: "Prismatic Formicarium colony brain" });
  }

  importBrain(json: string): boolean {
    const b = brainFromJSON(json);
    if (!b) return false;
    this.brain = b;
    this.engine.setBrain(b);
    safeSet(LS_BRAIN, exportBrainJSON(b));
    return true;
  }

  restoreChampion(): void {
    this.brain = createChampionBrain();
    this.engine.setBrain(this.brain);
    this.history = [...CHAMPION_HISTORY];
    try {
      window.localStorage.removeItem(LS_BRAIN);
      window.localStorage.removeItem(LS_HISTORY);
    } catch {
      /* ignore */
    }
    this.emit();
  }

  /* ----------------------------- brush ----------------------------- */

  private channelForTool(): number {
    if (this.tool === "food-trail") return CH_FOOD;
    if (this.tool === "home-trail") return CH_HOME;
    if (this.alarmMode === "scout") return CH_SCOUT;
    if (this.alarmMode === "noentry") return CH_NOENTRY;
    return CH_ALARM;
  }

  private rgbForTool(): string {
    if (this.tool === "wall") return "56,189,248";
    if (this.tool === "crystal") return "0,230,118";
    if (this.tool === "eraser") return "226,232,240";
    const c = CHANNEL_RGB[this.channelForTool()];
    return `${c[0]},${c[1]},${c[2]}`;
  }

  private stamp = (x: number, y: number): void => {
    const e = this.engine;
    const r = this.brushRadius;
    switch (this.tool) {
      case "food-trail":
      case "home-trail":
      case "alarm":
        e.brushDeposit(this.channelForTool(), x, y, r, 40);
        break;
      case "wall":
        this.renderer?.markTerrainDirty(e.paintWall(x, y, r * 0.6, true));
        break;
      case "eraser":
        e.eraseAt(x, y, r);
        this.renderer?.markTerrainDirty(e.paintWall(x, y, r, false));
        break;
      case "crystal":
        break;
    }
  };

  pointerDown(id: number, sx: number, sy: number): boolean {
    if (this.pointerId !== null || !this.renderer) return false;
    this.pointerId = id;
    const { x, y } = this.renderer.screenToWorld(sx, sy);
    const o = this.overlay;
    o.active = true;
    o.count = 0;
    o.rgb = this.rgbForTool();
    o.radius = this.brushRadius;
    o.mode = this.tool === "eraser" ? "erase" : this.tool === "wall" ? "wall" : this.tool === "crystal" ? "crystal" : "paint";
    o.startX = x;
    o.startY = y;
    o.startT = this.time;
    this.pushOverlay(x, y);
    if (this.tool === "alarm" && this.alarmMode === "predator") {
      if (this.spawnPredator(x, y)) this.toaster?.("Abyssal Stalker released", "warn");
      return true;
    }
    if (this.tool === "crystal") {
      this.engine.addFood(x, y, 140);
      this.lastCrystalX = x;
      this.lastCrystalY = y;
    } else {
      this.brush.reset();
      this.brush.add(x, y, this.brushRadius, this.stamp);
    }
    this.onFirstStroke?.();
    return true;
  }

  pointerMove(id: number, sx: number, sy: number, hover: boolean): void {
    if (!this.renderer) return;
    const { x, y } = this.renderer.screenToWorld(sx, sy);
    const o = this.overlay;
    o.cursorX = x;
    o.cursorY = y;
    o.hasCursor = true;
    o.radius = this.brushRadius;
    o.mode = this.tool === "eraser" ? "erase" : "paint";
    if (hover || id !== this.pointerId) {
      if (this.pointerId === null) o.rgb = this.rgbForTool();
      return;
    }
    this.pushOverlay(x, y);
    if (this.tool === "alarm" && this.alarmMode === "predator") return;
    if (this.tool === "crystal") {
      if (Math.hypot(x - this.lastCrystalX, y - this.lastCrystalY) > 42) {
        this.engine.addFood(x, y, 110);
        this.lastCrystalX = x;
        this.lastCrystalY = y;
      }
      return;
    }
    this.brush.add(x, y, this.brushRadius, this.stamp);
  }

  pointerUp(id: number): void {
    if (id !== this.pointerId) return;
    this.pointerId = null;
    if (this.tool !== "crystal" && !(this.tool === "alarm" && this.alarmMode === "predator")) this.brush.end(this.brushRadius, this.stamp);
    this.overlay.active = false;
    this.overlay.count = 0;
  }

  pointerLeave(): void {
    this.overlay.hasCursor = false;
  }

  private pushOverlay(x: number, y: number): void {
    const o = this.overlay;
    if (o.count >= o.xs.length) {
      o.xs.copyWithin(0, 1);
      o.ys.copyWithin(0, 1);
      o.count = o.xs.length - 1;
    }
    o.xs[o.count] = x;
    o.ys[o.count] = y;
    o.count++;
  }
}

interface SanctuaryCanvasProps {
  controller: SimController;
  onPointerActive: (active: boolean) => void;
}

export default function SanctuaryCanvas({ controller, onPointerActive }: SanctuaryCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    controller.attach(canvas);
    controller.resize(window.innerWidth, window.innerHeight, window.devicePixelRatio || 1);
    let raf = 0;
    const loop = (t: number) => {
      controller.frame(t);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    let resizeTimer: ReturnType<typeof setTimeout> | null = null;
    const onResize = () => {
      if (resizeTimer) clearTimeout(resizeTimer);
      resizeTimer = setTimeout(() => controller.resize(window.innerWidth, window.innerHeight, window.devicePixelRatio || 1), 150);
    };
    const onVis = () => {
      if (document.hidden) {
        if (!controller.paused) {
          controller.autoPaused = true;
          controller.setPaused(true);
        }
      } else if (controller.autoPaused) {
        controller.autoPaused = false;
        controller.setPaused(false);
      }
    };
    window.addEventListener("resize", onResize);
    document.addEventListener("visibilitychange", onVis);
    return () => {
      cancelAnimationFrame(raf);
      if (resizeTimer) clearTimeout(resizeTimer);
      window.removeEventListener("resize", onResize);
      document.removeEventListener("visibilitychange", onVis);
      controller.detach();
    };
  }, [controller]);

  const local = (e: React.PointerEvent<HTMLCanvasElement>): [number, number] => {
    const r = e.currentTarget.getBoundingClientRect();
    return [e.clientX - r.left, e.clientY - r.top];
  };

  return (
    <canvas
      ref={canvasRef}
      className="sanctuary-canvas"
      aria-label="Ant sanctuary simulation canvas"
      onPointerDown={(e) => {
        const [x, y] = local(e);
        if (controller.pointerDown(e.pointerId, x, y)) {
          e.currentTarget.setPointerCapture(e.pointerId);
          onPointerActive(true);
        }
      }}
      onPointerMove={(e) => {
        const [x, y] = local(e);
        controller.pointerMove(e.pointerId, x, y, e.buttons === 0 && e.pointerType === "mouse");
      }}
      onPointerUp={(e) => {
        controller.pointerUp(e.pointerId);
        onPointerActive(false);
      }}
      onPointerCancel={(e) => {
        controller.pointerUp(e.pointerId);
        onPointerActive(false);
      }}
      onPointerLeave={() => controller.pointerLeave()}
    />
  );
}
