"use client";

import { CloseIcon } from "./ui/icons";

interface FieldGuideProps {
  open: boolean;
  onClose: () => void;
}

const TOPICS: ReadonlyArray<{ title: string; nature: string; sandbox: string }> = [
  {
    title: "Stigmergy",
    nature: "Foragers lay trail pheromone on the way home; nestmates reinforce shorter routes because round trips finish sooner (Deneubourg's double bridge, 1990).",
    sandbox: "Amber foodTrail and cyan homeGuide fields diffuse with a strict CFL 3x3 stencil and evaporate. Where they overlap they polymerise into pearl-white highways that decay 35% slower.",
  },
  {
    title: "Path integration",
    nature: "Desert ants (Cataglyphis) integrate stride count and sky-compass heading into a home vector and walk straight back.",
    sandbox: "Each ant integrates a home vector. The shared colony brain receives it in egocentric form; muting it in the ablation lab measures how much the evolved policy depends on it.",
  },
  {
    title: "Alarm and defence",
    nature: "Disturbed workers release volatile alarm compounds that recruit soldiers and scatter foragers.",
    sandbox: "Ants within 75px of an Abyssal Stalker emit a +80 crimson burst that decays 3.2x faster. Foragers flee down the gradient toward home, while wardens climb it and swarm the predator.",
  },
  {
    title: "Necrophoresis",
    nature: "Dead nestmates release oleic acid; undertaker ants carry corpses to refuse piles away from trails.",
    sandbox: "Starved or killed ants leave chitin husks that leak weak alarm. Wardens haul them to the graveyard ring.",
  },
  {
    title: "Tandem running and sealing",
    nature: "Temnothorax scouts teach routes by tandem running. Pharaoh ants mark unrewarding branches with repellent no-entry signals.",
    sandbox: "Returning scouts hand crystal coordinates to recruits with a violet scoutPulse. Ants that hit depleted crystals or dead ends turn back and lay viridian noEntry, which dissolves stale foodTrail.",
  },
];

const SHORTCUTS: ReadonlyArray<[string, string]> = [
  ["1-6", "Select tool: Food, Home, Alarm/Predator, Crystal, Wall, Eraser"],
  ["Space", "Play / pause"],
  ["[ / ]", "Shrink / grow brush radius"],
  ["Esc", "Close sheets and dialogs"],
];

export default function FieldGuideModal({ open, onClose }: FieldGuideProps) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 p-0 sm:items-center sm:p-6" role="dialog" aria-modal="true" aria-label="Field guide" onClick={onClose}>
      <div className="glass no-scrollbar max-h-[88dvh] w-full max-w-3xl overflow-y-auto rounded-t-[28px] p-5 sm:rounded-[28px]" onClick={(e) => e.stopPropagation()}>
        <div className="mb-4 flex items-start justify-between gap-4">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-cyan-300">Field Guide</p>
            <h2 className="font-display text-2xl text-slate-50">The Prismatic Formicarium</h2>
            <p className="mt-1 text-[13px] text-slate-400">How the real behaviour maps onto this sandbox.</p>
          </div>
          <button type="button" onClick={onClose} className="flex h-11 w-11 items-center justify-center rounded-[14px] bg-white/5 text-slate-200 hover:bg-white/10" aria-label="Close field guide">
            <CloseIcon size={20} />
          </button>
        </div>

        <div className="grid gap-3 sm:grid-cols-3">
          <figure className="rounded-[20px] border border-white/10 bg-black/30 p-2">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/assets/diagram-double-bridge.svg" alt="Double bridge experiment diagram" className="w-full rounded-[12px]" />
            <figcaption className="mt-1 text-[11px] text-slate-400">Short branch wins via faster reinforcement</figcaption>
          </figure>
          <figure className="rounded-[20px] border border-white/10 bg-black/30 p-2">
            <svg viewBox="0 0 200 100" className="w-full" aria-label="Pheromone mixing diagram">
              <rect width="200" height="100" rx="12" fill="#020307" />
              <g style={{ mixBlendMode: "screen" }}>
                <circle cx="70" cy="45" r="28" fill="rgb(255,168,0)" fillOpacity="0.75" />
                <circle cx="100" cy="45" r="28" fill="rgb(0,225,255)" fillOpacity="0.75" />
                <circle cx="130" cy="45" r="28" fill="rgb(175,50,255)" fillOpacity="0.75" />
                <circle cx="85" cy="70" r="20" fill="rgb(255,12,75)" fillOpacity="0.6" />
                <circle cx="118" cy="72" r="20" fill="rgb(80,255,100)" fillOpacity="0.6" />
              </g>
              <circle cx="85" cy="45" r="5" fill="#fffaf0" />
              <text x="100" y="96" textAnchor="middle" fontSize="8" fill="#94a3b8">food+home = pearl highway core</text>
            </svg>
            <figcaption className="mt-1 text-[11px] text-slate-400">Concentration-weighted spectral mixer</figcaption>
          </figure>
          <figure className="rounded-[20px] border border-white/10 bg-black/30 p-2">
            <svg viewBox="0 0 200 100" className="w-full" aria-label="Colony brain diagram">
              <rect width="200" height="100" rx="12" fill="#020307" />
              {Array.from({ length: 10 }, (_, i) => (
                <g key={`i${i}`}>
                  {Array.from({ length: 8 }, (_, h) => (
                    <line key={h} x1="30" y1={10 + i * 8.5} x2="100" y2={14 + h * 10.5} stroke="#00e1ff" strokeOpacity="0.12" />
                  ))}
                  <circle cx="30" cy={10 + i * 8.5} r="2.6" fill="#ffa800" />
                </g>
              ))}
              {Array.from({ length: 8 }, (_, h) => (
                <g key={`h${h}`}>
                  {Array.from({ length: 5 }, (_, o) => (
                    <line key={o} x1="100" y1={14 + h * 10.5} x2="170" y2={18 + o * 16} stroke="#af32ff" strokeOpacity="0.2" />
                  ))}
                  <circle cx="100" cy={14 + h * 10.5} r="3" fill="#00e1ff" />
                </g>
              ))}
              {Array.from({ length: 5 }, (_, o) => (
                <circle key={`o${o}`} cx="170" cy={18 + o * 16} r="3.4" fill="#00e676" />
              ))}
              <path d="M170 82 C 190 96, 20 100, 30 88" stroke="#a7f3d0" strokeDasharray="3 3" fill="none" strokeOpacity="0.6" />
            </svg>
            <figcaption className="mt-1 text-[11px] text-slate-400">19 inputs, 16 tanh, 9 outputs, recurrent memory</figcaption>
          </figure>
        </div>

        <div className="mt-4 space-y-2">
          {TOPICS.map((t) => (
            <div key={t.title} className="rounded-[20px] border border-white/10 bg-white/[0.02] p-3">
              <h3 className="font-display text-[15px] text-slate-100">{t.title}</h3>
              <div className="mt-1 grid gap-2 sm:grid-cols-2">
                <p className="text-[12px] leading-relaxed text-slate-300">
                  <span className="mr-1 font-semibold text-amber-300">In nature:</span>
                  {t.nature}
                </p>
                <p className="text-[12px] leading-relaxed text-slate-300">
                  <span className="mr-1 font-semibold text-cyan-300">In this sandbox:</span>
                  {t.sandbox}
                </p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-4 rounded-[20px] border border-white/10 p-3">
          <h3 className="mb-2 text-[12px] font-semibold uppercase tracking-[0.18em] text-slate-400">Shortcuts</h3>
          <ul className="grid gap-1 sm:grid-cols-2">
            {SHORTCUTS.map(([k, v]) => (
              <li key={k} className="flex items-center gap-2 text-[12px] text-slate-300">
                <kbd className="min-w-[48px] rounded-[8px] border border-white/15 bg-white/5 px-2 py-0.5 text-center font-semibold text-slate-100 tnum">{k}</kbd>
                {v}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
