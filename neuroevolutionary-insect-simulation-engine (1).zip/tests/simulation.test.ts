import { describe, expect, it } from "vitest";
import { AntEngine } from "../src/lib/ant-soa-engine";
import { BENCHMARK_SEEDS, buildTrainingLayout, conditionSetup, episodeSpec, runEpisode, sharedRandomBrain, TRAIN_WORLD } from "../src/lib/headless-sim";
import {
  brainFromJSON,
  createChampionBrain,
  createRandomBrain,
  DEFAULT_EVOLUTION,
  exportBrainJSON,
  forwardBrain,
  GENOME_SIZE,
  hasBakedChampion,
  NeuroEvolution,
} from "../src/lib/neat";
import { CatmullRomBrush, PheromoneGrid } from "../src/lib/pheromone-grid";
import { Mulberry32, Simplex2D } from "../src/lib/prng-noise";
import { PRESETS } from "../src/lib/presets";
import { BRAIN_HIDDEN, BRAIN_INPUTS, BRAIN_OUTPUTS, CH_ALARM, CH_FOOD, CH_HOME, CH_NOENTRY, MAX_ANTS, defaultSimConfig } from "../src/lib/types";

describe("prng + noise", () => {
  it("is deterministic per seed", () => {
    const a = new Mulberry32(42);
    const b = new Mulberry32(42);
    for (let i = 0; i < 100; i++) expect(a.next()).toBe(b.next());
    const n = new Simplex2D(7);
    const v = n.noise(1.3, 2.7);
    expect(v).toBeGreaterThanOrEqual(-1);
    expect(v).toBeLessThanOrEqual(1);
  });
});

describe("pheromone grid", () => {
  it("conserves mass under diffusion with zero-flux walls (no evaporation)", () => {
    const g = new PheromoneGrid(120, 120);
    g.params = { evaporation: 0, diffusion: 1, reactionRate: 0 };
    g.setWallCircle(30, 60, 10, true);
    g.deposit(CH_HOME, 60, 60, 100);
    const total = () => {
      let s = 0;
      for (let i = 0; i < g.size; i++) s += g.front[CH_HOME][i];
      return s;
    };
    const before = total();
    for (let t = 0; t < 120; t++) g.step(1 / 60);
    expect(Math.abs(total() - before) / before).toBeLessThan(0.02);
    for (let i = 0; i < g.size; i++) expect(g.front[CH_HOME][i]).toBeLessThanOrEqual(100);
  });

  it("alarm decays faster than food, and noEntry dissolves foodTrail", () => {
    const g = new PheromoneGrid(60, 60);
    g.params = { evaporation: 0.1, diffusion: 0, reactionRate: 1 };
    g.deposit(CH_FOOD, 30, 30, 50);
    g.deposit(CH_ALARM, 30, 30, 50);
    for (let t = 0; t < 60; t++) g.step(1 / 60);
    expect(g.sample(CH_ALARM, 30, 30)).toBeLessThan(g.sample(CH_FOOD, 30, 30));
    const g2 = new PheromoneGrid(60, 60);
    g2.params = { evaporation: 0.1, diffusion: 0, reactionRate: 1 };
    g2.deposit(CH_FOOD, 30, 30, 50);
    g2.deposit(CH_NOENTRY, 30, 30, 50);
    for (let t = 0; t < 60; t++) g2.step(1 / 60);
    expect(g2.sample(CH_FOOD, 30, 30)).toBeLessThan(g.sample(CH_FOOD, 30, 30));
  });

  it("mixes food+home into a pearl core and respects ablation masks", () => {
    const g = new PheromoneGrid(60, 60);
    const [r, gg, b] = g.mixSample([70, 70, 0, 0, 0]);
    expect(Math.min(r, gg, b)).toBeGreaterThan(150);
    g.setMuted(CH_FOOD, true);
    g.deposit(CH_FOOD, 30, 30, 50);
    expect(g.sample(CH_FOOD, 30, 30)).toBe(0);
  });

  it("Catmull-Rom brush emits evenly spaced stamps", () => {
    const brush = new CatmullRomBrush();
    let n = 0;
    const stamp = () => {
      n++;
    };
    brush.add(0, 0, 20, stamp);
    brush.add(50, 0, 20, stamp);
    brush.add(100, 0, 20, stamp);
    brush.end(20, stamp);
    expect(n).toBeGreaterThan(8);
  });
});

describe("colony brain", () => {
  it("has the 19 -> 16 -> 9 layout and a bounded forward pass", () => {
    expect(GENOME_SIZE).toBe(BRAIN_HIDDEN * BRAIN_INPUTS + BRAIN_HIDDEN + BRAIN_OUTPUTS * BRAIN_HIDDEN + BRAIN_OUTPUTS);
    const b = createRandomBrain(1);
    const inp = new Float32Array(BRAIN_INPUTS).map((_, i) => Math.sin(i));
    const out = new Float32Array(BRAIN_OUTPUTS);
    forwardBrain(b, inp, out, new Float32Array(BRAIN_HIDDEN));
    expect(out[0]).toBeGreaterThanOrEqual(-1);
    expect(out[0]).toBeLessThanOrEqual(1);
    for (let o = 1; o <= 6; o++) {
      expect(out[o]).toBeGreaterThanOrEqual(0);
      expect(out[o]).toBeLessThanOrEqual(1);
    }
  });

  it("round-trips JSON and rejects malformed input", () => {
    const b = createChampionBrain();
    const back = brainFromJSON(exportBrainJSON(b));
    expect(back).not.toBeNull();
    expect(back?.weights.length).toBe(GENOME_SIZE);
    expect(brainFromJSON("{\"format\":\"nope\"}")).toBeNull();
    expect(brainFromJSON("not json")).toBeNull();
  });

  it("evolution keeps elites and population size", () => {
    const evo = new NeuroEvolution({ ...DEFAULT_EVOLUTION, populationSize: 8 }, 5);
    evo.population.forEach((g, i) => (g.fitness = i));
    const bestW = new Float32Array(evo.population[7].weights);
    evo.evolve();
    expect(evo.population.length).toBe(8);
    expect(Array.from(evo.population[0].weights)).toEqual(Array.from(bestW));
    expect(evo.generation).toBe(1);
  });
});

describe("SoA engine", () => {
  it("preallocates 3000 ants and runs deterministic ticks", () => {
    const mk = () => {
      const cfg = defaultSimConfig(720, 1280);
      cfg.initialAnts = 200;
      return new AntEngine(cfg, createChampionBrain(), sharedRandomBrain(), PRESETS[0].build(720, 1280, 1));
    };
    const a = mk();
    const b = mk();
    expect(a.ants.x.length).toBe(MAX_ANTS);
    for (let t = 0; t < 120; t++) {
      a.step();
      b.step();
    }
    expect(a.ants.x[5]).toBe(b.ants.x[5]);
    expect(a.alive).toBe(200);
  });

  it("kills starving ants, leaves corpses and counts deaths", () => {
    const cfg = defaultSimConfig(TRAIN_WORLD, TRAIN_WORLD);
    cfg.initialAnts = 50;
    cfg.atpBurn = 400;
    cfg.enableBirths = false;
    const e = new AntEngine(cfg, createChampionBrain(), sharedRandomBrain(), buildTrainingLayout(TRAIN_WORLD, 3));
    for (let t = 0; t < 240; t++) e.step();
    expect(e.totalDeaths).toBeGreaterThan(0);
    expect(e.corpses.active.some((v) => v === 1)).toBe(true);
  });

  it("predators trigger alarm bursts", () => {
    const cfg = defaultSimConfig(TRAIN_WORLD, TRAIN_WORLD);
    cfg.initialAnts = 64;
    const e = new AntEngine(cfg, createChampionBrain(), sharedRandomBrain(), buildTrainingLayout(TRAIN_WORLD, 3));
    e.spawnPredator(TRAIN_WORLD / 2 + 30, TRAIN_WORLD / 2);
    for (let t = 0; t < 30; t++) e.step();
    expect(e.grid.mass[CH_ALARM]).toBeGreaterThan(0);
  });
});

describe("proof of learning (headless, multi-seed)", () => {
  it("baked champion beats Hand-Crafted ACO which beats Random (mean of 3 seeds)", () => {
    const mean = (cond: "trained" | "aco" | "random") =>
      BENCHMARK_SEEDS.reduce((s, seed) => {
        const c = conditionSetup(cond, createChampionBrain(), seed, 900);
        return s + runEpisode(c.brain, c.spec).foodDelivered;
      }, 0) / BENCHMARK_SEEDS.length;
    const trained = mean("trained");
    const aco = mean("aco");
    const random = mean("random");
    expect(hasBakedChampion()).toBe(true);
    expect(trained).toBeGreaterThan(aco);
    expect(aco).toBeGreaterThan(random);
  }, 120000);

  it("muting foodTrail or path integration reduces delivery", () => {
    const brain = createChampionBrain();
    const full = runEpisode(brain, episodeSpec(7)).foodDelivered;
    const noPI = conditionSetup("-pathIntegration", brain, 7, 900);
    const noFood = conditionSetup("-foodTrail", brain, 7, 900);
    const worst = Math.min(runEpisode(noPI.brain, noPI.spec).foodDelivered, runEpisode(noFood.brain, noFood.spec).foodDelivered);
    expect(worst).toBeLessThan(full);
  }, 120000);
});
