/*
 * Offline CLI trainer + multi-seed benchmark runner.
 *   npx tsx scripts/train.ts --gens 30 --pop 20 --seeds 2 --ticks 900 --bake
 * Options: --prior <fraction>  seed part of gen-0 with the innate reflex prior (default 0 = pure random init)
 *          --speciation        enable NEAT-style speciation + hidden-unit growth
 *          --bench-only        only benchmark the currently baked champion
 *          --bake              write champion weights + learning curve into src/lib/neat.ts
 */
import { readFileSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";
import {
  CHAMPION_HISTORY,
  createChampionBrain,
  createInnatePrior,
  DEFAULT_EVOLUTION,
  hasBakedChampion,
  NeuroEvolution,
} from "../src/lib/neat";
import { BENCHMARK_SEEDS, conditionSetup, episodeSpec, meanStd, runBenchmarkSync, runEpisode, sharedRandomBrain } from "../src/lib/headless-sim";
import type { Brain, BenchmarkReport, TrainingPoint } from "../src/lib/types";

function arg(name: string, fallback: number): number {
  const i = process.argv.indexOf(`--${name}`);
  if (i >= 0 && i + 1 < process.argv.length) {
    const v = Number(process.argv[i + 1]);
    if (Number.isFinite(v)) return v;
  }
  return fallback;
}
const flag = (name: string): boolean => process.argv.includes(`--${name}`);

const GENS = arg("gens", 30);
const POP = arg("pop", 20);
const NSEEDS = arg("seeds", 2);
const TICKS = arg("ticks", 900);
const PRIOR = arg("prior", 0);
const CURVE_SEEDS = BENCHMARK_SEEDS;
const VALIDATION_SEEDS = [301, 302, 303];

const fmt = (v: number): string => v.toFixed(1).padStart(6);

function evalFood(brain: Brain, seeds: readonly number[]): { mean: number; std: number } {
  return meanStd(seeds.map((s) => runEpisode(brain, episodeSpec(s, TICKS)).foodDelivered));
}

function baseline(cond: "aco" | "random", seeds: readonly number[]): number {
  return meanStd(seeds.map((s) => {
    const c = conditionSetup(cond, sharedRandomBrain(), s, TICKS);
    return runEpisode(c.brain, c.spec).foodDelivered;
  })).mean;
}

function printReport(rep: BenchmarkReport): void {
  console.log(`\nMulti-seed benchmark (seeds ${rep.seeds.join(",")}, ${rep.ticks} ticks):`);
  for (const r of rep.results) console.log(`  ${r.label.padEnd(20)} ${fmt(r.mean)} +- ${r.std.toFixed(1).padStart(5)}   [${r.samples.join(", ")}]`);
}

function bake(brain: Brain, history: TrainingPoint[], generation: number, fitness: number, rep: BenchmarkReport): void {
  const file = resolve(process.cwd(), "src/lib/neat.ts");
  const src = readFileSync(file, "utf8");
  const begin = "// <CHAMPION-BEGIN>";
  const end = "// <CHAMPION-END>";
  const a = src.indexOf(begin);
  const b = src.indexOf(end);
  if (a < 0 || b < 0) throw new Error("champion markers not found");
  const w = Array.from(brain.weights, (v) => Number(v.toFixed(4)));
  const lines: string[] = [];
  for (let i = 0; i < w.length; i += 16) lines.push("  " + w.slice(i, i + 16).join(", ") + ",");
  const hist = history.map((h) => `  { generation: ${h.generation}, trained: ${h.trained.toFixed(2)}, trainedStd: ${h.trainedStd.toFixed(2)}, aco: ${h.aco.toFixed(2)}, random: ${h.random.toFixed(2)} },`);
  const summary = rep.results.map((r) => `${r.label}=${r.mean.toFixed(1)}+-${r.std.toFixed(1)}`).join("; ");
  const block = [
    begin,
    "export const CHAMPION_WEIGHTS: readonly number[] = [",
    ...lines,
    "];",
    `export const CHAMPION_ENABLED: readonly number[] = [${Array.from(brain.enabled).join(", ")}];`,
    "export const CHAMPION_HISTORY: readonly TrainingPoint[] = [",
    ...hist,
    "];",
    `export const CHAMPION_META = { generation: ${generation}, fitness: ${fitness.toFixed(2)}, trainedAt: "${new Date().toISOString()}", benchmark: "${summary}" };`,
    end,
  ].join("\n");
  writeFileSync(file, src.slice(0, a) + block + src.slice(b + end.length));
  console.log(`\nBaked champion (${w.length} weights, ${history.length} curve points) into src/lib/neat.ts`);
}

function verify(rep: BenchmarkReport): boolean {
  const get = (c: string) => rep.results.find((r) => r.condition === c)?.mean ?? 0;
  const trained = get("trained");
  const aco = get("aco");
  const random = get("random");
  const order = trained > aco && aco > random;
  console.log(`\nOrdering Trained(${trained.toFixed(1)}) > ACO(${aco.toFixed(1)}) > Random(${random.toFixed(1)}): ${order ? "PASS" : "FAIL"}`);
  for (const r of rep.results) {
    if (!r.condition.startsWith("-")) continue;
    const drop = trained - r.mean;
    console.log(`  ablation ${r.label.padEnd(18)} drop ${drop >= 0 ? "-" : "+"}${Math.abs(drop).toFixed(1)} (${((drop / Math.max(1, trained)) * 100).toFixed(1)}%)`);
  }
  return order;
}

function main(): void {
  const t0 = Date.now();
  if (flag("bench-only")) {
    console.log(`Benchmarking ${hasBakedChampion() ? "baked champion" : "innate prior (no champion baked)"}`);
    const rep = runBenchmarkSync(createChampionBrain(), BENCHMARK_SEEDS, TICKS);
    printReport(rep);
    verify(rep);
    console.log(`done in ${((Date.now() - t0) / 1000).toFixed(1)}s`);
    return;
  }
  const params = { ...DEFAULT_EVOLUTION, populationSize: POP, useSpeciation: flag("speciation") };
  const evo = new NeuroEvolution(params, 2024, PRIOR > 0 ? createInnatePrior() : undefined, PRIOR);
  const curveAco = baseline("aco", CURVE_SEEDS);
  const curveRandom = baseline("random", CURVE_SEEDS);
  console.log(`Neuroevolution: pop=${POP} gens=${GENS} seeds/gen=${NSEEDS} ticks=${TICKS} prior=${PRIOR} speciation=${params.useSpeciation}`);
  console.log(`Curve baselines on seeds ${CURVE_SEEDS.join(",")}: ACO=${curveAco.toFixed(1)} Random=${curveRandom.toFixed(1)}`);
  const history: TrainingPoint[] = [];
  const hall: Array<{ brain: Brain; gen: number; fitness: number }> = [];
  for (let gen = 0; gen < GENS; gen++) {
    const seeds = Array.from({ length: NSEEDS }, (_, k) => 1000 + k * 977 + (gen % 6) * 31);
    let best = evo.population[0];
    for (const g of evo.population) {
      const rs = seeds.map((s) => runEpisode(evo.brainOf(g), episodeSpec(s, TICKS)));
      g.fitness = meanStd(rs.map((r) => r.fitness)).mean;
      if (g.fitness > best.fitness) best = g;
    }
    const champBrain: Brain = { weights: new Float32Array(best.weights), hidden: 16, enabled: new Uint8Array(best.enabled) };
    const curve = evalFood(champBrain, CURVE_SEEDS);
    history.push({ generation: gen, trained: curve.mean, trainedStd: curve.std, aco: curveAco, random: curveRandom });
    hall.push({ brain: champBrain, gen, fitness: best.fitness });
    console.log(`gen ${String(gen).padStart(3)}  bestFit ${fmt(best.fitness)}  champFood(curve) ${fmt(curve.mean)} +- ${curve.std.toFixed(1)}  ACO ${fmt(curveAco)}  sigma ${best.sigma.toFixed(3)}  t=${((Date.now() - t0) / 1000).toFixed(0)}s`);
    evo.evolve();
  }
  // champion selection on held-out validation seeds among the last generations' champions
  const candidates = hall.slice(-8);
  let pick = candidates[candidates.length - 1];
  let pickScore = -1;
  for (const c of candidates) {
    const v = evalFood(c.brain, VALIDATION_SEEDS).mean;
    if (v > pickScore) {
      pickScore = v;
      pick = c;
    }
  }
  console.log(`\nSelected champion from gen ${pick.gen} (validation food ${pickScore.toFixed(1)})`);
  const rep = runBenchmarkSync(pick.brain, BENCHMARK_SEEDS, TICKS);
  printReport(rep);
  const ok = verify(rep);
  if (flag("bake")) {
    const prev = flag("append") ? [...CHAMPION_HISTORY] : [];
    bake(pick.brain, [...prev, ...history], pick.gen, pick.fitness, rep);
  }
  console.log(`total ${((Date.now() - t0) / 1000).toFixed(1)}s  ${ok ? "OK" : "ORDER-CHECK-FAILED"}`);
}

main();
