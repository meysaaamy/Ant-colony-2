import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      borderRadius: {
        sm: "12px",
        md: "20px",
        lg: "28px",
      },
      spacing: {
        "1": "4px",
        "2": "8px",
        "3": "12px",
        "4": "16px",
        "5": "20px",
        "6": "24px",
      },
      transitionTimingFunction: {
        jewel: "cubic-bezier(0.2, 0.8, 0.2, 1)",
      },
      fontFamily: {
        display: ["var(--font-fraunces)", "serif"],
        sans: ["var(--font-jakarta)", "system-ui", "sans-serif"],
      },
      colors: {
        abyss: "#020307",
        basalt: "#0d1322",
        emerald: "#00e676",
        amber: "#ffa800",
        cyanx: "#00e1ff",
        crimson: "#ff0c4b",
        violet: "#af32ff",
        viridian: "#50ff64",
      },
    },
  },
};

export default config;
