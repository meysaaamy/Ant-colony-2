import { createAntSoA, createInitialBrain, evaluateNeat } from "../../../lib/ant-soa-engine";
import { PheromoneGrid } from "../../../lib/pheromone-grid";
import { MAX_ANTS, Pheromone } from "../../../lib/types";

export const dynamic = "force-dynamic";

export function GET(): Response {
  const checks: Record<string, boolean> = {};
  try {
    const ants = createAntSoA();
    checks.soa = ants.x.length === MAX_ANTS && ants.memB.length === MAX_ANTS && ants.state.length === MAX_ANTS && ants.generation.BYTES_PER_ELEMENT === 2;

    const brain = createInitialBrain();
    const inputs = new Float32Array(14);
    const outputs = new Float32Array(4);
    const scratch = new Float32Array(48);
    for (let index = 0; index < inputs.length; index += 1) inputs[index] = Math.sin(index) * 0.5;
    evaluateNeat(brain, inputs, outputs, scratch);
    checks.neatForward = outputs.every((value) => Number.isFinite(value)) && outputs.some((value) => Math.abs(value) > 0.0001);

    const grid = new PheromoneGrid(60, 60, 6);
    const rgba = new Uint8ClampedArray(4);
    for (let channel = 0; channel < 5; channel += 1) grid.channels[channel][grid.index(4, 4)] = 40;
    grid.mixCell(grid.index(4, 4), rgba, 0);
    checks.fiveChannelRgb = rgba[0] > 0 && rgba[1] > 0 && rgba[2] > 0 && rgba[3] === 255;

    grid.setAblation("foodTrail", false);
    const ablated = grid.sample(27, 27, Pheromone.foodTrail);
    grid.setAblation("foodTrail", true);
    const restored = grid.sample(27, 27, Pheromone.foodTrail);
    checks.ablation = ablated === 0 && restored > 0;

    const walls = new Uint8Array(grid.length);
    const wallIndex = grid.index(5, 5);
    walls[wallIndex] = 1;
    grid.setWalls(walls);
    grid.deposit(24, 30, Pheromone.foodTrail, 90, 4);
    grid.step(1 / 60, { evaporation: 0.05, diffusion: 0.1, crossReaction: 1, gamma: 1.65 });
    checks.zeroFluxWalls = grid.channels[Pheromone.foodTrail][wallIndex] === 0 && grid.channels[Pheromone.foodTrail][grid.index(4, 5)] > 0;

    const passed = Object.values(checks).every(Boolean);
    return Response.json({ status: passed ? "ok" : "failed", checks, ants: MAX_ANTS, pheromoneChannels: 5 }, { status: passed ? 200 : 500 });
  } catch (error) {
    return Response.json({ status: "failed", checks, error: error instanceof Error ? error.message : "Unknown verification error" }, { status: 500 });
  }
}
