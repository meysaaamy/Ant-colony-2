"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import FieldGuideModal from "../components/FieldGuideModal";
import FloatingToolDock from "../components/FloatingToolDock";
import ParameterSheet, { type TrainingState } from "../components/ParameterSheet";
import SanctuaryCanvas from "../components/SanctuaryCanvas";
import TelemetryPill from "../components/TelemetryPill";
import ToastOverlay from "../components/ToastOverlay";
import { AntSoAEngine, DEFAULT_COLONY_SETTINGS } from "../lib/ant-soa-engine";
import { DEFAULT_ABLATION, DEFAULT_PHEROMONE_SETTINGS } from "../lib/pheromone-grid";
import { getPreset } from "../lib/presets";
import { clamp } from "../lib/prng-noise";
import type {
  AblationMask,
  BrushSettings,
  ColonySettings,
  ComparisonMode,
  LabTab,
  PaintMode,
  PheromoneSettings,
  PresetId,
  SheetSnap,
  Telemetry,
  ToastMessage,
  ToolId,
} from "../lib/types";

const STORAGE_KEY = "prismara.sanctuary.v1";
const TOOL_IDS: readonly ToolId[] = ["food", "home", "alarm", "crystal", "wall", "eraser"];
const PAINT_MODES: readonly PaintMode[] = ["foodTrail", "homeGuide", "alarm", "scoutPulse", "noEntry", "predator"];

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null;
}
function numeric(value: unknown, fallback: number, min: number, max: number): number {
  return typeof value === "number" && Number.isFinite(value) ? clamp(value, min, max) : fallback;
}

export default function SanctuaryPage() {
  const [engine] = useState(() => new AntSoAEngine());
  const [telemetry, setTelemetry] = useState<Telemetry>(() => engine.getTelemetry(60));
  const [preset, setPreset] = useState(engine.preset);
  const [running, setRunning] = useState(true);
  const [speed, setSpeed] = useState(1);
  const [tool, setTool] = useState<ToolId>("food");
  const [paintMode, setPaintMode] = useState<PaintMode>("foodTrail");
  const [brush, setBrush] = useState<BrushSettings>({ radius: 28, strength: 35 });
  const [comparison, setComparison] = useState<ComparisonMode>("trained");
  const [ablation, setAblation] = useState<AblationMask>({ ...DEFAULT_ABLATION });
  const [colony, setColony] = useState<ColonySettings>({ ...DEFAULT_COLONY_SETTINGS });
  const [pheromones, setPheromones] = useState<PheromoneSettings>({ ...DEFAULT_PHEROMONE_SETTINGS });
  const [snap, setSnap] = useState<SheetSnap>("peek");
  const [tab, setTab] = useState<LabTab>("proof");
  const [guideOpen, setGuideOpen] = useState(false);
  const [painting, setPainting] = useState(false);
  const [ghostVisible, setGhostVisible] = useState(true);
  const [splashVisible, setSplashVisible] = useState(true);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [training, setTraining] = useState<TrainingState>({ active: false, target: 0, completed: 0, total: 0 });
  const [storageReady, setStorageReady] = useState(false);
  const toastId = useRef(0);
  const trainingConfig = useRef({ target: 0, total: 0, start: 0 });
  const latestFps = useRef(60);

  const pushToast = useCallback((title: string, detail: string, tone: ToastMessage["tone"] = "cyan") => {
    toastId.current += 1;
    const id = toastId.current;
    setToasts((current) => [...current.slice(-2), { id, title, detail, tone }]);
    window.setTimeout(() => setToasts((current) => current.filter((toast) => toast.id !== id)), 3600);
  }, []);

  useEffect(() => {
    const splashTimer = window.setTimeout(() => setSplashVisible(false), 340);
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as unknown;
        if (isRecord(parsed)) {
          if (typeof parsed.tool === "string" && TOOL_IDS.includes(parsed.tool as ToolId)) setTool(parsed.tool as ToolId);
          if (typeof parsed.paintMode === "string" && PAINT_MODES.includes(parsed.paintMode as PaintMode)) setPaintMode(parsed.paintMode as PaintMode);
          if (typeof parsed.speed === "number" && [1, 2, 4].includes(parsed.speed)) setSpeed(parsed.speed);
          if (parsed.comparison === "trained" || parsed.comparison === "random" || parsed.comparison === "aco") {
            setComparison(parsed.comparison);
            engine.setComparison(parsed.comparison);
          }
          if (isRecord(parsed.brush)) setBrush({ radius: numeric(parsed.brush.radius, 28, 6, 72), strength: numeric(parsed.brush.strength, 35, 5, 80) });
          if (isRecord(parsed.colony)) {
            const restored: ColonySettings = {
              maxPopulation: numeric(parsed.colony.maxPopulation, DEFAULT_COLONY_SETTINGS.maxPopulation, 100, 3000),
              predatorCount: 0,
              atpBurn: numeric(parsed.colony.atpBurn, 1, 0.2, 3),
              lifespan: numeric(parsed.colony.lifespan, 210, 60, 600),
              scoutRatio: numeric(parsed.colony.scoutRatio, 0.28, 0.05, 0.6),
              wardenRatio: numeric(parsed.colony.wardenRatio, 0.18, 0.02, 0.5),
            };
            Object.assign(engine.colony, restored);
            setColony({ ...restored });
          }
          if (isRecord(parsed.pheromones)) {
            const restored: PheromoneSettings = {
              evaporation: numeric(parsed.pheromones.evaporation, DEFAULT_PHEROMONE_SETTINGS.evaporation, 0.005, 0.2),
              diffusion: numeric(parsed.pheromones.diffusion, DEFAULT_PHEROMONE_SETTINGS.diffusion, 0, 0.18),
              crossReaction: numeric(parsed.pheromones.crossReaction, 1, 0, 2),
              gamma: numeric(parsed.pheromones.gamma, 1.65, 0.5, 3),
            };
            Object.assign(engine.pheromones, restored);
            setPheromones(restored);
          }
          if (isRecord(parsed.ablation)) {
            const restored = { ...DEFAULT_ABLATION };
            for (const key of Object.keys(restored) as (keyof AblationMask)[]) {
              if (typeof parsed.ablation[key] === "boolean") restored[key] = parsed.ablation[key];
              engine.grid.setAblation(key, restored[key]);
            }
            setAblation(restored);
          }
          if (parsed.preset === "sanctuary" || parsed.preset === "double-bridge" || parsed.preset === "labyrinth") {
            const restoredPreset = getPreset(parsed.preset);
            engine.reset(restoredPreset);
            setPreset(restoredPreset);
            setTelemetry(engine.getTelemetry(60));
          }
        }
      }
    } catch {
      window.localStorage.removeItem(STORAGE_KEY);
    } finally {
      setStorageReady(true);
    }
    return () => window.clearTimeout(splashTimer);
    // Restoring persisted state is intentionally a one-time mount operation.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [engine]);

  useEffect(() => {
    if (!storageReady) return;
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify({ tool, paintMode, speed, comparison, brush, colony: { ...colony, predatorCount: 0 }, pheromones, ablation, preset: preset.id }));
    } catch {
      // Private browsing and storage quotas must never interrupt simulation.
    }
  }, [storageReady, tool, paintMode, speed, comparison, brush, colony, pheromones, ablation, preset.id]);

  useEffect(() => {
    const keyboard = (event: KeyboardEvent) => {
      const target = event.target;
      if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement || training.active) return;
      if (event.key === " ") {
        event.preventDefault();
        setRunning((value) => !value);
      } else if (event.key >= "1" && event.key <= "6") {
        const selected = TOOL_IDS[Number(event.key) - 1];
        setTool(selected);
        if (selected === "food") setPaintMode("foodTrail");
        if (selected === "home") setPaintMode("homeGuide");
        if (selected === "alarm") setPaintMode("alarm");
      } else if (event.key === "[" || event.key === "]") {
        setBrush((current) => ({ ...current, radius: clamp(current.radius + (event.key === "]" ? 4 : -4), 6, 72) }));
      } else if (event.key === "Escape") {
        if (guideOpen) setGuideOpen(false);
        else setSnap("peek");
      }
    };
    window.addEventListener("keydown", keyboard);
    return () => window.removeEventListener("keydown", keyboard);
  }, [guideOpen, training.active]);

  useEffect(() => {
    if (!training.active) return;
    let cancelled = false;
    let animation = 0;
    const batch = () => {
      if (cancelled) return;
      engine.runTurboBatch(100);
      const completed = Math.min(trainingConfig.current.total, Math.max(0, engine.generation - trainingConfig.current.start));
      const currentTelemetry = engine.getTelemetry(latestFps.current);
      setTelemetry(currentTelemetry);
      if (engine.generation >= trainingConfig.current.target) {
        setTraining({ active: false, target: trainingConfig.current.target, completed: trainingConfig.current.total, total: trainingConfig.current.total });
        setRunning(true);
        pushToast("Hive-Mind evolution complete", `${trainingConfig.current.total} generations simulated. Visual playback resumed with ${currentTelemetry.hiddenNodes} hidden nodes and ${currentTelemetry.synapses} live synapses.`, "cyan");
        return;
      }
      setTraining((current) => ({ ...current, completed }));
      animation = requestAnimationFrame(batch);
    };
    animation = requestAnimationFrame(batch);
    return () => {
      cancelled = true;
      cancelAnimationFrame(animation);
    };
  }, [training.active, engine, pushToast]);

  const startTraining = useCallback((generations: number) => {
    if (training.active) return;
    setRunning(false);
    setSnap("half");
    setTab("proof");
    trainingConfig.current = { start: engine.generation, target: engine.generation + generations, total: generations };
    setTraining({ active: true, target: engine.generation + generations, completed: 0, total: generations });
    pushToast("Offline turbo engaged", `${generations} generations queued at 100 fixed ticks per frame. The visual colony is paused, not replaced.`, "amber");
  }, [engine, training.active, pushToast]);

  const changeComparison = useCallback((mode: ComparisonMode) => {
    engine.setComparison(mode);
    setComparison(mode);
    setTelemetry(engine.getTelemetry(latestFps.current));
    pushToast(mode === "trained" ? "Unified hive restored" : "A/B arena engaged", mode === "trained" ? "Every active ant now uses the evolved shared brain." : `Alternating ants now compete as trained NEAT versus ${mode === "aco" ? "hand-crafted ACO" : "a frozen random network"}.`, "cyan");
  }, [engine, pushToast]);

  const changeAblation = useCallback((name: keyof AblationMask, enabled: boolean) => {
    engine.grid.setAblation(name, enabled);
    setAblation((current) => ({ ...current, [name]: enabled }));
    pushToast(enabled ? "Sensor restored" : "Sensory knockout applied", `${name === "pathIntegration" ? "Vector memory" : name} is now ${enabled ? "online" : "zeroed at every antenna sample"}. Watch the measured delivery rate respond.`, enabled ? "cyan" : "amber");
  }, [engine, pushToast]);

  const changeColony = useCallback((settings: ColonySettings) => {
    Object.assign(engine.colony, settings);
    setColony({ ...settings });
  }, [engine]);

  const changePheromones = useCallback((settings: PheromoneSettings) => {
    Object.assign(engine.pheromones, settings);
    setPheromones(settings);
  }, [engine]);

  const changePredatorCount = useCallback((count: number) => {
    engine.setPredatorCount(count);
    setColony({ ...engine.colony });
    setTelemetry(engine.getTelemetry(latestFps.current));
    pushToast(count > 0 ? "Abyssal threat entered" : "Threat withdrawn", count > 0 ? `${count} armored stalkers targeted. Wardens will answer crimson alarm gradients.` : "Remaining stalkers removed; alarm plumes will decay naturally.", count > 0 ? "crimson" : "cyan");
  }, [engine, pushToast]);

  const spawnPredator = useCallback(() => {
    if (engine.spawnPredator()) {
      setColony({ ...engine.colony });
      pushToast("Stalker released", "A new armored predator is hunting the upper basin.", "crimson");
    }
  }, [engine, pushToast]);

  const loadPreset = useCallback((id: PresetId) => {
    const nextPreset = getPreset(id);
    engine.reset(nextPreset);
    engine.setComparison(comparison);
    setPreset(nextPreset);
    setTelemetry(engine.getTelemetry(latestFps.current));
    setSnap("peek");
    pushToast("World reseeded", `${nextPreset.name} is live. Laboratory and ablation settings were preserved.`, "cyan");
  }, [engine, comparison, pushToast]);

  const resetWorld = useCallback(() => {
    engine.reset(preset);
    engine.setComparison(comparison);
    setTelemetry(engine.getTelemetry(latestFps.current));
    setRunning(true);
    pushToast("Colony reset", "Founders, crystals, chemistry, learning history, and mortality counters restarted deterministically.", "amber");
  }, [engine, preset, comparison, pushToast]);

  const clearTrails = useCallback(() => {
    engine.clearTrails();
    pushToast("Chemical fields cleared", "All five channels returned to zero. Walls, ants, food, and the evolved brain were preserved.", "cyan");
  }, [engine, pushToast]);

  return (
    <main className="sanctuary-shell">
      <div className="canvas-stage">
        <SanctuaryCanvas
          engine={engine}
          running={running}
          speed={speed}
          tool={tool}
          paintMode={paintMode}
          brush={brush}
          onTelemetry={(value) => { latestFps.current = value.fps; setTelemetry(value); }}
          onPaintingChange={setPainting}
          onAutoPause={() => setRunning(false)}
          onInteraction={() => setGhostVisible(false)}
        />
      </div>

      <div className={`interface-layer${painting ? " is-painting" : ""}`}>
        <TelemetryPill
          telemetry={telemetry}
          running={running}
          speed={speed}
          comparison={comparison}
          onToggleRunning={() => setRunning((value) => !value)}
          onCycleSpeed={() => setSpeed((value) => value === 1 ? 2 : value === 2 ? 4 : 1)}
          onOpenGuide={() => setGuideOpen(true)}
          onOpenLab={() => { setSnap("half"); setTab("proof"); }}
        />
        {telemetry.bottleneck && <div className="bottleneck-banner glass">Founder Bottleneck / 2.5x hyper-mutation wave</div>}
        <ParameterSheet
          preset={preset}
          telemetry={telemetry}
          learning={engine.learning}
          brain={engine.brain}
          ablation={ablation}
          comparison={comparison}
          snap={snap}
          tab={tab}
          training={training}
          colony={colony}
          pheromones={pheromones}
          brush={brush}
          paintMode={paintMode}
          onSnapChange={setSnap}
          onTabChange={setTab}
          onTrain={startTraining}
          onComparisonChange={changeComparison}
          onAblationChange={changeAblation}
          onColonyChange={changeColony}
          onPheromonesChange={changePheromones}
          onBrushChange={setBrush}
          onPresetChange={loadPreset}
          onSpawnPredator={spawnPredator}
          onSetPredatorCount={changePredatorCount}
          onClearTrails={clearTrails}
          onReset={resetWorld}
        />
        <div className="bottom-cockpit">
          <FloatingToolDock tool={tool} paintMode={paintMode} brush={brush} onToolChange={setTool} onPaintModeChange={setPaintMode} onBrushChange={setBrush} />
        </div>
        <ToastOverlay toasts={toasts} />
      </div>

      {ghostVisible && !splashVisible && <div className="ghost-guide">
        <svg viewBox="0 0 190 110" fill="none" aria-hidden="true"><path d="M18 80C48 12 102 106 169 30" stroke="#a7f3d0" strokeWidth="1.5" /><circle cx="18" cy="80" r="8" stroke="#ffa800" /><circle cx="169" cy="30" r="5" fill="#00e676" fillOpacity=".5" /></svg>
        <div className="ghost-copy">Drag to lay an amber food trail</div>
      </div>}
      {training.active && <div className="turbo-overlay"><div className="turbo-card glass"><div className="micro-label">Headless neuroevolution / 100 ticks per frame</div><div className="turbo-value tabular">GEN {telemetry.generation}</div><div className="turbo-copy">{training.completed} of {training.total} requested generations complete<br />{telemetry.alive} ants / {telemetry.food} deliveries / {telemetry.synapses} synapses</div><div className="progress-track"><div className="progress-fill" style={{ width: `${training.completed / training.total * 100}%` }} /></div></div></div>}
      {guideOpen && <FieldGuideModal onClose={() => setGuideOpen(false)} />}
      {splashVisible && <div className="splash"><div className="splash-inner"><img className="splash-logo" src="/logo.svg" alt="" /><div className="splash-name">PRISMARA</div><div className="splash-sub">Neuroevolutionary sanctuary</div></div></div>}
    </main>
  );
}
