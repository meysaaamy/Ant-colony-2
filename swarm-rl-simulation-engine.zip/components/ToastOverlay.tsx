"use client";

import type { CSSProperties } from "react";
import type { ToastMessage } from "../lib/types";

const TONES = { cyan: "#2dd4bf", amber: "#ffa800", crimson: "#ff0c4b" } as const;

export default function ToastOverlay({ toasts }: { toasts: readonly ToastMessage[] }) {
  return (
    <div className="toast-stack" aria-live="polite" aria-atomic="false">
      {toasts.map((toast) => (
        <div className="toast glass" key={toast.id} style={{ "--toast-color": TONES[toast.tone] } as CSSProperties}>
          <span className="toast-mark" />
          <div>
            <div className="toast-title">{toast.title}</div>
            <div className="toast-detail">{toast.detail}</div>
          </div>
        </div>
      ))}
    </div>
  );
}
