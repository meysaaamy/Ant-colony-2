"use client";

import type { ComparisonMode, Telemetry } from "../lib/types";
import { AntIcon, CrystalIcon, GuideIcon, PauseIcon, PlayIcon, SlidersIcon } from "./ui/icons";

interface TelemetryPillProps {
  telemetry: Telemetry;
  running: boolean;
  speed: number;
  comparison: ComparisonMode;
  onToggleRunning: () => void;
  onCycleSpeed: () => void;
  onOpenGuide: () => void;
  onOpenLab: () => void;
}

export default function TelemetryPill({
  telemetry,
  running,
  speed,
  comparison,
  onToggleRunning,
  onCycleSpeed,
  onOpenGuide,
  onOpenLab,
}: TelemetryPillProps) {
  const opponent = comparison === "aco" ? telemetry.acoFood : telemetry.randomFood;
  return (
    <header className="top-hud">
      <div style={{ position: "relative" }}>
        <div className="hud-capsule glass tabular" aria-label="Live colony telemetry">
          <div className="hud-stat fps-stat" title={`${Math.round(telemetry.fps)} frames per second`}>
            <span className={`fps-dot${telemetry.fps < 50 ? " slow" : ""}`} />
            <span>{Math.round(telemetry.fps)}<small>FPS</small></span>
          </div>
          <div className="hud-stat">
            <AntIcon size={19} />
            <span>{telemetry.alive.toLocaleString()} <span style={{ color: "#64748b" }}>({telemetry.deaths} dead)</span><small>Colony</small></span>
          </div>
          <div className="hud-stat food-stat">
            <CrystalIcon size={18} />
            <span>{telemetry.food.toLocaleString()}<small>Food</small></span>
          </div>
          <div className="hud-stat energy-stat">
            <span>{Math.round(telemetry.meanEnergy)}%<small>Mean ATP</small></span>
          </div>
          <div className="hud-stat">
            <span className="gen-badge">GEN {telemetry.generation}</span>
            <button className="speed-chip" onClick={onCycleSpeed} title="Cycle simulation speed">{speed}x</button>
          </div>
          <button className="play-button" onClick={onToggleRunning} aria-label={running ? "Pause simulation" : "Resume simulation"} title="Play or pause (Space)">
            {running ? <PauseIcon size={19} /> : <PlayIcon size={19} />}
          </button>
        </div>
        {comparison !== "trained" && (
          <div className="ab-score glass tabular" aria-live="polite">
            <span className="trained">Trained: {telemetry.trainedFood} food</span>
            <span style={{ color: "#334155" }}>/</span>
            <span className="opponent">{comparison === "aco" ? "ACO" : "Random"}: {opponent} food</span>
          </div>
        )}
      </div>
      <div className="hud-actions">
        <button className="squircle glass" onClick={onOpenGuide} aria-label="Open field guide" title="Field guide">
          <GuideIcon size={21} />
        </button>
        <button className="squircle glass" onClick={onOpenLab} aria-label="Open parameters and proof lab" title="Parameters and proof lab">
          <SlidersIcon size={21} />
        </button>
      </div>
    </header>
  );
}
