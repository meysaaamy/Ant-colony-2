import type { SVGProps } from "react";

export type IconProps = SVGProps<SVGSVGElement> & { size?: number };

function IconBase({ size = 24, children, ...props }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" {...props}>
      {children}
    </svg>
  );
}

export function AntIcon(props: IconProps) {
  return <IconBase {...props}><ellipse cx="12" cy="7" rx="3" ry="2.6"/><ellipse cx="12" cy="12" rx="2.4" ry="2.8"/><ellipse cx="12" cy="17" rx="3.4" ry="4"/><path d="m10 10-4-3-2 1m16-1-2-1-4 3M10 12l-5 1-1 3m16-4-1-3-5 1m-4 4-4 4-1 3m14-6 1 3-4 1m-1-13-2-3m6 3 2-3"/></IconBase>;
}
export function CrystalIcon(props: IconProps) {
  return <IconBase {...props}><path d="m12 2 6 5-2 10-4 5-4-5L6 7l6-5Z"/><path d="m6 7 6 4 6-4M12 11v11M8 17l4-6 4 6"/></IconBase>;
}
export function PlayIcon(props: IconProps) {
  return <IconBase {...props}><path d="m8 5 11 7-11 7V5Z" fill="currentColor" stroke="none"/></IconBase>;
}
export function PauseIcon(props: IconProps) {
  return <IconBase {...props}><path d="M8 5v14M16 5v14" strokeWidth="3"/></IconBase>;
}
export function GuideIcon(props: IconProps) {
  return <IconBase {...props}><path d="M4 5c3-1 6 0 8 2v13c-2-2-5-3-8-2V5Zm16 0c-3-1-6 0-8 2v13c2-2 5-3 8-2V5Z"/><path d="M7 9h2m-2 3h2m6-3h2m-2 3h2"/></IconBase>;
}
export function SlidersIcon(props: IconProps) {
  return <IconBase {...props}><path d="M4 7h5m4 0h7M4 17h9m4 0h3M4 12h1m4 0h11"/><circle cx="11" cy="7" r="2"/><circle cx="15" cy="17" r="2"/><circle cx="7" cy="12" r="2"/></IconBase>;
}
export function TrainIcon(props: IconProps) {
  return <IconBase {...props}><circle cx="5" cy="6" r="2"/><circle cx="5" cy="18" r="2"/><circle cx="19" cy="12" r="2"/><circle cx="12" cy="12" r="2"/><path d="m7 7 3 4m-3 6 3-4m4 0 3 0M7 6h10l2 6"/></IconBase>;
}
export function CompareIcon(props: IconProps) {
  return <IconBase {...props}><path d="M8 4 4 8l4 4M4 8h12m0 8 4-4-4-4m4 4H8"/><rect x="3" y="3" width="18" height="18" rx="5" strokeOpacity=".35"/></IconBase>;
}
export function PredatorIcon(props: IconProps) {
  return <IconBase {...props}><path d="m12 3 7 4 2 7-5 6h-8l-5-6 2-7 7-4Z"/><path d="m5 7 4 4m10-4-4 4M8 20l2-5m6 5-2-5"/><circle cx="9" cy="12" r="1" fill="currentColor"/><circle cx="15" cy="12" r="1" fill="currentColor"/></IconBase>;
}
export function ClearIcon(props: IconProps) {
  return <IconBase {...props}><path d="M4 7h16M9 7V4h6v3m-9 0 1 13h10l1-13M10 11v5m4-5v5"/></IconBase>;
}
export function ResetIcon(props: IconProps) {
  return <IconBase {...props}><path d="M4 10a8 8 0 1 1 2 7M4 4v6h6"/></IconBase>;
}
export function ChevronIcon(props: IconProps) {
  return <IconBase {...props}><path d="m7 10 5 5 5-5"/></IconBase>;
}
export function CloseIcon(props: IconProps) {
  return <IconBase {...props}><path d="m6 6 12 12M18 6 6 18"/></IconBase>;
}
export function RadiusIcon(props: IconProps) {
  return <IconBase {...props}><circle cx="12" cy="12" r="8" strokeDasharray="2 3"/><circle cx="12" cy="12" r="2"/><path d="M12 12 18 6"/></IconBase>;
}
export function CheckIcon(props: IconProps) {
  return <IconBase {...props}><path d="m5 12 4 4L19 6"/></IconBase>;
}
export function WallIcon(props: IconProps) {
  return <IconBase {...props}><path d="M3 5c5-2 13-2 18 0v14c-5 2-13 2-18 0V5Z"/><path d="M3 10h18M3 15h18M8 5v5m8-5v5m-4 0v5m-5 0v5m10-5v5"/></IconBase>;
}
export function EraserIcon(props: IconProps) {
  return <IconBase {...props}><path d="m14.5 4.5 5 5-10 10H5l-2-2 11.5-13Z"/><path d="m10 9 5 5m-5.5 5.5H21"/></IconBase>;
}
export function FoodTrailIcon(props: IconProps) {
  return <IconBase {...props}><path d="M4 19c2-7 5-2 7-9s5-2 9-6"/><path d="m17 4 3 0 0 3"/><circle cx="5" cy="18" r="1.5"/><circle cx="11" cy="11" r="1.5"/></IconBase>;
}
export function HomeIcon(props: IconProps) {
  return <IconBase {...props}><path d="m3 11 9-8 9 8M5 10v10h14V10M9 20v-6h6v6"/></IconBase>;
}
export function AlarmIcon(props: IconProps) {
  return <IconBase {...props}><path d="M12 3 2.8 20h18.4L12 3Z"/><path d="M12 9v5m0 3.5v.1"/></IconBase>;
}
export function InfoIcon(props: IconProps) {
  return <IconBase {...props}><circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10v.1"/></IconBase>;
}
export function SparkIcon(props: IconProps) {
  return <IconBase {...props}><path d="m12 2 1.8 7.2L21 12l-7.2 2.8L12 22l-1.8-7.2L3 12l7.2-2.8L12 2Z"/></IconBase>;
}
