"use client";

import { useEffect, useRef } from "react";
import type { AntSoAEngine } from "../lib/ant-soa-engine";
import { SanctuaryRenderer } from "../lib/renderer";
import {
  FIXED_DT,
  Pheromone,
  type BrushSettings,
  type BrushVisual,
  type PaintMode,
  type PheromoneName,
  type Telemetry,
  type ToolId,
} from "../lib/types";

interface SanctuaryCanvasProps {
  engine: AntSoAEngine;
  running: boolean;
  speed: number;
  tool: ToolId;
  paintMode: PaintMode;
  brush: BrushSettings;
  onTelemetry: (telemetry: Telemetry) => void;
  onPaintingChange: (painting: boolean) => void;
  onAutoPause: () => void;
  onInteraction: () => void;
}

const CHANNEL_COLORS: Record<PheromoneName, string> = {
  foodTrail: "#ffa800",
  homeGuide: "#00e1ff",
  alarm: "#ff0c4b",
  scoutPulse: "#af32ff",
  noEntry: "#50ff64",
};

export default function SanctuaryCanvas({
  engine,
  running,
  speed,
  tool,
  paintMode,
  brush,
  onTelemetry,
  onPaintingChange,
  onAutoPause,
  onInteraction,
}: SanctuaryCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const settingsRef = useRef({ running, speed, tool, paintMode, brush });
  const callbacksRef = useRef({ onTelemetry, onPaintingChange, onAutoPause, onInteraction });
  settingsRef.current = { running, speed, tool, paintMode, brush };
  callbacksRef.current = { onTelemetry, onPaintingChange, onAutoPause, onInteraction };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const renderer = new SanctuaryRenderer(canvas, engine);
    let animationFrame = 0;
    let previousTime = performance.now();
    let accumulator = 0;
    let lastTelemetry = 0;
    let resizeTimer = 0;
    let disposed = false;
    const visualBrush: BrushVisual = {
      active: false,
      x: 0,
      y: 0,
      previousX: 0,
      previousY: 0,
      radius: brush.radius,
      startedAt: 0,
      erasing: false,
      color: "#ffffff",
    };
    const worldPoint = { x: 0, y: 0 };
    const pointer = {
      id: -1,
      x0: 0, y0: 0,
      x1: 0, y1: 0,
      x2: 0, y2: 0,
      moved: false,
    };

    const resizeNow = () => {
      const rect = canvas.getBoundingClientRect();
      renderer.resize(rect.width, rect.height, window.devicePixelRatio || 1);
    };
    resizeNow();
    const resizeObserver = new ResizeObserver(() => {
      window.clearTimeout(resizeTimer);
      resizeTimer = window.setTimeout(resizeNow, 150);
    });
    resizeObserver.observe(canvas);

    const channelForTool = (): PheromoneName | null => {
      const current = settingsRef.current;
      if (current.tool === "food") return "foodTrail";
      if (current.tool === "home") return "homeGuide";
      if (current.tool === "alarm" && current.paintMode !== "predator") return current.paintMode;
      return null;
    };

    const paintAt = (x: number, y: number, initial: boolean) => {
      const current = settingsRef.current;
      const channel = channelForTool();
      if (channel) {
        const amount = current.brush.strength * (initial ? 1.4 : 0.75);
        if (initial) engine.grid.deposit(x, y, Pheromone[channel], amount, current.brush.radius);
        else engine.grid.strokeCatmullRom(pointer.x0, pointer.y0, pointer.x1, pointer.y1, pointer.x2, pointer.y2, x, y, Pheromone[channel], amount, current.brush.radius);
        pointer.x0 = pointer.x1;
        pointer.y0 = pointer.y1;
        pointer.x1 = pointer.x2;
        pointer.y1 = pointer.y2;
        pointer.x2 = x;
        pointer.y2 = y;
      } else if (current.tool === "wall" || current.tool === "eraser") {
        const erase = current.tool === "eraser";
        if (initial) engine.paintWall(x, y, current.brush.radius, erase);
        else {
          const distance = Math.hypot(x - pointer.x2, y - pointer.y2);
          const steps = Math.max(1, Math.ceil(distance / Math.max(3, current.brush.radius * 0.3)));
          for (let step = 1; step <= steps; step += 1) {
            const t = step / steps;
            engine.paintWall(pointer.x2 + (x - pointer.x2) * t, pointer.y2 + (y - pointer.y2) * t, current.brush.radius, erase);
          }
        }
        pointer.x2 = x;
        pointer.y2 = y;
      }
    };

    const pointerDown = (event: PointerEvent) => {
      if (pointer.id !== -1 || !renderer.clientToWorld(event.clientX, event.clientY, worldPoint)) return;
      event.preventDefault();
      pointer.id = event.pointerId;
      pointer.x0 = worldPoint.x;
      pointer.y0 = worldPoint.y;
      pointer.x1 = worldPoint.x;
      pointer.y1 = worldPoint.y;
      pointer.x2 = worldPoint.x;
      pointer.y2 = worldPoint.y;
      pointer.moved = false;
      canvas.setPointerCapture(event.pointerId);
      const current = settingsRef.current;
      visualBrush.active = true;
      visualBrush.x = worldPoint.x;
      visualBrush.y = worldPoint.y;
      visualBrush.previousX = worldPoint.x;
      visualBrush.previousY = worldPoint.y;
      visualBrush.radius = current.brush.radius;
      visualBrush.startedAt = performance.now();
      visualBrush.erasing = current.tool === "eraser";
      const channel = channelForTool();
      visualBrush.color = channel ? CHANNEL_COLORS[channel] : current.tool === "crystal" ? "#00e676" : "#94a3b8";
      callbacksRef.current.onPaintingChange(true);
      callbacksRef.current.onInteraction();
      if (current.tool === "crystal") engine.addFoodSource(worldPoint.x, worldPoint.y, 120, 24);
      else if (current.tool === "alarm" && current.paintMode === "predator") engine.spawnPredator(worldPoint.x, worldPoint.y);
      else paintAt(worldPoint.x, worldPoint.y, true);
    };

    const pointerMove = (event: PointerEvent) => {
      if (event.pointerId !== pointer.id || !renderer.clientToWorld(event.clientX, event.clientY, worldPoint)) return;
      event.preventDefault();
      visualBrush.previousX = visualBrush.x;
      visualBrush.previousY = visualBrush.y;
      visualBrush.x = worldPoint.x;
      visualBrush.y = worldPoint.y;
      visualBrush.radius = settingsRef.current.brush.radius;
      pointer.moved = true;
      const current = settingsRef.current;
      if (current.tool !== "crystal" && !(current.tool === "alarm" && current.paintMode === "predator")) paintAt(worldPoint.x, worldPoint.y, false);
    };

    const endPointer = (event: PointerEvent) => {
      if (event.pointerId !== pointer.id) return;
      pointer.id = -1;
      visualBrush.active = false;
      callbacksRef.current.onPaintingChange(false);
      if (canvas.hasPointerCapture(event.pointerId)) canvas.releasePointerCapture(event.pointerId);
    };

    const visibilityChange = () => {
      if (document.hidden) callbacksRef.current.onAutoPause();
      previousTime = performance.now();
      accumulator = 0;
    };

    canvas.addEventListener("pointerdown", pointerDown);
    canvas.addEventListener("pointermove", pointerMove);
    canvas.addEventListener("pointerup", endPointer);
    canvas.addEventListener("pointercancel", endPointer);
    document.addEventListener("visibilitychange", visibilityChange);

    const frame = (now: number) => {
      if (disposed) return;
      const delta = Math.min(0.1, Math.max(0, (now - previousTime) / 1000));
      previousTime = now;
      const current = settingsRef.current;
      if (current.running && !document.hidden) {
        accumulator += delta * current.speed;
        let steps = 0;
        while (accumulator >= FIXED_DT && steps < 12) {
          engine.step(FIXED_DT);
          accumulator -= FIXED_DT;
          steps += 1;
        }
        if (steps === 12) accumulator = 0;
      } else accumulator = 0;
      const fps = renderer.render(now, visualBrush);
      if (now - lastTelemetry >= 100) {
        lastTelemetry = now;
        callbacksRef.current.onTelemetry(engine.getTelemetry(fps));
      }
      animationFrame = requestAnimationFrame(frame);
    };
    animationFrame = requestAnimationFrame(frame);

    return () => {
      disposed = true;
      cancelAnimationFrame(animationFrame);
      window.clearTimeout(resizeTimer);
      resizeObserver.disconnect();
      canvas.removeEventListener("pointerdown", pointerDown);
      canvas.removeEventListener("pointermove", pointerMove);
      canvas.removeEventListener("pointerup", endPointer);
      canvas.removeEventListener("pointercancel", endPointer);
      document.removeEventListener("visibilitychange", visibilityChange);
    };
  }, [engine]);

  return <canvas ref={canvasRef} className="sanctuary-canvas" aria-label="Interactive living ant sanctuary. Drag to apply the selected field tool." />;
}
