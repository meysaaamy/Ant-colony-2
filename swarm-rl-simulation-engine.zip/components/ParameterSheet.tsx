"use client";

import { useEffect, useMemo, useRef, useState, type CSSProperties, type PointerEvent as ReactPointerEvent } from "react";
import { PheromoneGrid } from "../lib/pheromone-grid";
import { PRESETS } from "../lib/presets";
import { renderPresetPreview } from "../lib/renderer";
import {
  PHEROMONE_NAMES,
  type AblationMask,
  type BrushSettings,
  type ComparisonMode,
  type LabTab,
  type LearningPoint,
  type PaintMode,
  type PheromoneName,
  type PheromoneSettings,
  type ColonySettings,
  type PresetId,
  type SharedNeatBrain,
  type SheetSnap,
  type Telemetry,
  type WorldPreset,
} from "../lib/types";
import { AlarmIcon, CheckIcon, ChevronIcon, ClearIcon, CompareIcon, CrystalIcon, GuideIcon, PredatorIcon, RadiusIcon, ResetIcon, SlidersIcon, SparkIcon, TrainIcon } from "./ui/icons";

export interface TrainingState {
  active: boolean;
  target: number;
  completed: number;
  total: number;
}

interface ParameterSheetProps {
  preset: WorldPreset;
  telemetry: Telemetry;
  learning: readonly LearningPoint[];
  brain: SharedNeatBrain;
  ablation: AblationMask;
  comparison: ComparisonMode;
  snap: SheetSnap;
  tab: LabTab;
  training: TrainingState;
  colony: ColonySettings;
  pheromones: PheromoneSettings;
  brush: BrushSettings;
  paintMode: PaintMode;
  onSnapChange: (snap: SheetSnap) => void;
  onTabChange: (tab: LabTab) => void;
  onTrain: (generations: number) => void;
  onComparisonChange: (mode: ComparisonMode) => void;
  onAblationChange: (name: keyof AblationMask, enabled: boolean) => void;
  onColonyChange: (settings: ColonySettings) => void;
  onPheromonesChange: (settings: PheromoneSettings) => void;
  onBrushChange: (settings: BrushSettings) => void;
  onPresetChange: (id: PresetId) => void;
  onSpawnPredator: () => void;
  onSetPredatorCount: (count: number) => void;
  onClearTrails: () => void;
  onReset: () => void;
}

const CHANNEL_META: Record<PheromoneName, { label: string; color: string }> = {
  foodTrail: { label: "Food Amber", color: "#ffa800" },
  homeGuide: { label: "Home Cyan", color: "#00e1ff" },
  alarm: { label: "Alarm Crimson", color: "#ff0c4b" },
  scoutPulse: { label: "Scout Violet", color: "#af32ff" },
  noEntry: { label: "No-Entry Viridian", color: "#50ff64" },
};

const TABS: readonly { id: LabTab; label: string }[] = [
  { id: "proof", label: "Proof" },
  { id: "colony", label: "Colony" },
  { id: "alchemy", label: "Alchemy" },
  { id: "brush", label: "Brush" },
  { id: "world", label: "World" },
];

function TabGlyph({ tab }: { tab: LabTab }) {
  if (tab === "proof") return <TrainIcon size={17} />;
  if (tab === "colony") return <PredatorIcon size={17} />;
  if (tab === "alchemy") return <SparkIcon size={17} />;
  if (tab === "brush") return <RadiusIcon size={17} />;
  return <GuideIcon size={17} />;
}

function LearningChart({ points, telemetry, comparison }: { points: readonly LearningPoint[]; telemetry: Telemetry; comparison: ComparisonMode }) {
  const shown = useMemo(() => {
    const copy = points.slice(-32);
    const last = copy[copy.length - 1];
    if (!last || last.generation !== telemetry.generation) {
      copy.push({
        generation: telemetry.generation,
        neat: telemetry.foodThisGeneration,
        aco: comparison === "aco" ? telemetry.acoThisGeneration : last?.aco ?? 34,
        random: telemetry.randomThisGeneration,
        hiddenNodes: telemetry.hiddenNodes,
        synapses: telemetry.synapses,
      });
    }
    return copy;
  }, [points, telemetry, comparison]);
  const width = 360;
  const height = 170;
  const left = 29;
  const top = 12;
  const chartWidth = 315;
  const chartHeight = 125;
  const maxValue = Math.max(10, ...shown.map((point) => Math.max(point.neat, point.aco, point.random))) * 1.12;
  const minGeneration = shown[0]?.generation ?? 1;
  const maxGeneration = Math.max(minGeneration + 1, shown[shown.length - 1]?.generation ?? 2);
  const pathFor = (key: "neat" | "aco" | "random") => shown.map((point, index) => {
    const x = left + (point.generation - minGeneration) / (maxGeneration - minGeneration) * chartWidth;
    const y = top + chartHeight - point[key] / maxValue * chartHeight;
    return `${index === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(" ");
  return (
    <div>
      <div className="chart-wrap">
        <svg className="line-chart" viewBox={`0 0 ${width} ${height}`} role="img" aria-label="Food delivered per generation for trained NEAT, hand-crafted ACO, and random networks">
          <defs><linearGradient id="neatStroke" x1="0" x2="1"><stop stopColor="#2dd4bf" /><stop offset="1" stopColor="#ffd166" /></linearGradient></defs>
          {[0, 0.25, 0.5, 0.75, 1].map((fraction) => {
            const y = top + chartHeight * fraction;
            return <g key={fraction}><line x1={left} x2={left + chartWidth} y1={y} y2={y} stroke="rgba(148,163,184,.1)" /><text x={left - 6} y={y + 3} textAnchor="end" fill="#526174" fontSize="7">{Math.round(maxValue * (1 - fraction))}</text></g>;
          })}
          <text x={left} y={158} fill="#526174" fontSize="7">GEN {minGeneration}</text>
          <text x={left + chartWidth} y={158} textAnchor="end" fill="#526174" fontSize="7">GEN {maxGeneration}</text>
          <text x={left + chartWidth / 2} y={158} textAnchor="middle" fill="#526174" fontSize="7" letterSpacing="1">FOOD / GENERATION</text>
          {shown.length > 1 && <>
            <path d={pathFor("random")} fill="none" stroke="#64748b" strokeWidth="1.2" strokeDasharray="1 5" strokeLinecap="round" />
            <path d={pathFor("aco")} fill="none" stroke="#38bdf8" strokeWidth="1.5" strokeDasharray="5 4" strokeLinecap="round" />
            <path d={pathFor("neat")} fill="none" stroke="url(#neatStroke)" strokeWidth="2.4" strokeLinejoin="round" strokeLinecap="round" />
          </>}
          {shown.map((point) => {
            const x = left + (point.generation - minGeneration) / (maxGeneration - minGeneration) * chartWidth;
            const y = top + chartHeight - point.neat / maxValue * chartHeight;
            return <circle key={point.generation} cx={x} cy={y} r="2.8" fill="#07110f" stroke="#a7f3d0" strokeWidth="1.2"><title>Generation {point.generation}: {point.neat} NEAT, {point.aco} ACO, {point.random} random</title></circle>;
          })}
        </svg>
      </div>
      <div className="chart-legend"><span className="legend-item"><i className="legend-line" style={{ "--legend": "#2dd4bf" } as CSSProperties} />Shared NEAT</span><span className="legend-item"><i className="legend-line dashed" style={{ "--legend": "#38bdf8" } as CSSProperties} />Hand-crafted ACO</span><span className="legend-item"><i className="legend-line dashed" style={{ "--legend": "#64748b" } as CSSProperties} />Random floor</span></div>
    </div>
  );
}

const INPUT_LABELS = [
  "Food L", "Food R", "Home L", "Home R", "Alarm L", "Alarm R", "Scout L", "Scout R",
  "Seal L", "Seal R", "Wall rays", "Home bearing", "ATP / load", "Recurrent memory",
];
const OUTPUT_LABELS = ["Steering torque", "Speed modulation", "Deposition weight", "Social drive"];

function TopologyVisualizer({ brain }: { brain: SharedNeatBrain }) {
  const [selected, setSelected] = useState<number>(18 - 4);
  const hidden = brain.nodes.filter((node) => node.kind === "hidden");
  const positions = useMemo(() => {
    const map = new Map<number, { x: number; y: number }>();
    for (let index = 0; index < 14; index += 1) map.set(index, { x: 30, y: 14 + index * 14.5 });
    hidden.forEach((node, index) => map.set(node.id, { x: 172 + (index % 2) * 24, y: 24 + Math.floor(index / 2) * Math.min(28, 176 / Math.max(1, Math.ceil(hidden.length / 2))) }));
    for (let index = 0; index < 4; index += 1) map.set(14 + index, { x: 326, y: 45 + index * 40 });
    return map;
  }, [brain.nodes, hidden]);
  const selectedNode = brain.nodes.find((node) => node.id === selected);
  const selectedConnections = brain.connections.filter((connection) => connection.from === selected || connection.to === selected);
  return (
    <div>
      <svg className="topology" viewBox="0 0 360 226" role="img" aria-label="Interactive live NEAT topology">
        <text x="30" y="222" textAnchor="middle" fill="#526174" fontSize="7">14 SENSORS</text>
        <text x="184" y="222" textAnchor="middle" fill="#526174" fontSize="7">{hidden.length} EVOLVED</text>
        <text x="326" y="222" textAnchor="middle" fill="#526174" fontSize="7">4 MOTOR</text>
        {brain.connections.map((connection) => {
          const from = positions.get(connection.from);
          const to = positions.get(connection.to);
          if (!from || !to) return null;
          const highlighted = connection.from === selected || connection.to === selected;
          return <line key={connection.innovation} x1={from.x} y1={from.y} x2={to.x} y2={to.y} stroke={connection.weight >= 0 ? "#2dd4bf" : "#ff0c4b"} strokeOpacity={connection.enabled ? highlighted ? 0.85 : 0.15 : 0.04} strokeWidth={Math.min(2.2, 0.35 + Math.abs(connection.weight) * 0.55)} strokeDasharray={connection.enabled ? undefined : "2 3"} />;
        })}
        {brain.nodes.map((node) => {
          const position = positions.get(node.id);
          if (!position) return null;
          const color = node.kind === "input" ? "#38bdf8" : node.kind === "output" ? "#fbbf24" : "#af32ff";
          const label = node.kind === "input" ? INPUT_LABELS[node.id] : node.kind === "output" ? OUTPUT_LABELS[node.id - 14] : `H${node.id}`;
          return <g key={node.id} className="topology-node" onClick={() => setSelected(node.id)} role="button" tabIndex={0} onKeyDown={(event) => { if (event.key === "Enter") setSelected(node.id); }} aria-label={`${label} node`}>
            <circle cx={position.x} cy={position.y} r={node.kind === "hidden" ? 5.5 : 4.2} fill="#07101b" stroke={color} strokeWidth={selected === node.id ? 2 : 1} />
            {node.kind === "input" && <text x={position.x + 8} y={position.y + 2.5} fill="#64748b" fontSize="5.8">{label}</text>}
            {node.kind === "output" && <text x={position.x - 8} y={position.y + 2.5} textAnchor="end" fill="#8b7d55" fontSize="6">{label}</text>}
          </g>;
        })}
      </svg>
      <div className="topology-detail">
        {selectedNode ? <><strong style={{ color: "#cbd5e1" }}>{selectedNode.kind === "input" ? INPUT_LABELS[selectedNode.id] : selectedNode.kind === "output" ? OUTPUT_LABELS[selectedNode.id - 14] : `Hidden node ${selectedNode.id}`}</strong> / {selectedNode.activation} / bias {selectedNode.bias.toFixed(2)}<br />{selectedConnections.length} attached synapses. Teal excites; crimson inhibits. Click any node to inspect it.</> : "Select a node to inspect its synapses."}
      </div>
    </div>
  );
}

function RangeControl({ label, value, display, min, max, step, onChange }: { label: string; value: number; display: string; min: number; max: number; step: number; onChange: (value: number) => void }) {
  return <div className="control-row"><label className="control-label"><span>{label}</span><span className="control-value">{display}</span></label><input aria-label={label} type="range" min={min} max={max} step={step} value={value} onChange={(event) => onChange(Number(event.target.value))} /></div>;
}

function MixingPreview() {
  const [levels, setLevels] = useState<number[]>([68, 52, 8, 24, 4]);
  const mixer = useMemo(() => new PheromoneGrid(6, 6, 6), []);
  const rgb = useMemo(() => {
    for (let channel = 0; channel < 5; channel += 1) mixer.channels[channel][0] = levels[channel];
    const output = new Uint8ClampedArray(4);
    mixer.mixCell(0, output, 0, 1.65);
    return `rgb(${output[0]},${output[1]},${output[2]})`;
  }, [levels, mixer]);
  const interaction = levels[0] > 20 && levels[1] > 20 ? "Pearl highway polymer" : levels[0] > 20 && levels[3] > 20 ? "Rose-gold recruitment" : levels[1] > 20 && levels[2] > 20 ? "Electric escape plume" : levels[2] > 20 && levels[4] > 20 ? "Sulfur hazard field" : "Spectral concentration mix";
  return (
    <div>
      <div className="mix-preview">
        {PHEROMONE_NAMES.map((name, index) => <button key={name} className="mix-channel" style={{ "--channel": CHANNEL_META[name].color, "--level": levels[index] } as CSSProperties} onClick={() => setLevels((current) => current.map((level, item) => item === index ? (level + 35) % 105 : level))} title={`${CHANNEL_META[name].label}: ${levels[index]} concentration. Click to cycle.`}><span className="mix-channel-name">{name === "foodTrail" ? "FOOD" : name === "homeGuide" ? "HOME" : name === "alarm" ? "ALARM" : name === "scoutPulse" ? "SCOUT" : "SEAL"}<br />{levels[index]}</span></button>)}
      </div>
      <div className="mix-result" style={{ background: rgb }}>{interaction}</div>
    </div>
  );
}

function PresetPreview({ preset }: { preset: WorldPreset }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    if (canvasRef.current) renderPresetPreview(canvasRef.current, preset);
  }, [preset]);
  return <canvas ref={canvasRef} className="preset-preview" aria-label={`${preset.name} map preview`} />;
}

export default function ParameterSheet(props: ParameterSheetProps) {
  const {
    preset, telemetry, learning, brain, ablation, comparison, snap, tab, training, colony, pheromones, brush,
    onSnapChange, onTabChange, onTrain, onComparisonChange, onAblationChange, onColonyChange, onPheromonesChange,
    onBrushChange, onPresetChange, onSpawnPredator, onSetPredatorCount, onClearTrails, onReset,
  } = props;
  const [resetArmed, setResetArmed] = useState(false);
  const resetTimer = useRef<number>(0);
  const dragStart = useRef<number | null>(null);
  useEffect(() => () => window.clearTimeout(resetTimer.current), []);

  const handleReset = () => {
    if (!resetArmed) {
      setResetArmed(true);
      resetTimer.current = window.setTimeout(() => setResetArmed(false), 2400);
      return;
    }
    window.clearTimeout(resetTimer.current);
    setResetArmed(false);
    onReset();
  };
  const handleDragEnd = (event: ReactPointerEvent<HTMLDivElement>) => {
    if (dragStart.current === null) return;
    const distance = event.clientY - dragStart.current;
    dragStart.current = null;
    if (distance < -36) onSnapChange(snap === "peek" ? "half" : "full");
    else if (distance > 36) onSnapChange(snap === "full" ? "half" : "peek");
  };

  return (
    <section className={`parameter-sheet glass ${snap}`} aria-label="Colony control and proof laboratory">
      <div className="sheet-peek" onPointerDown={(event) => { dragStart.current = event.clientY; }} onPointerUp={handleDragEnd}>
        <div className="drag-handle" />
        <div className="preset-heading">
          <div><div className="preset-title">{preset.name}</div><div className="preset-kicker">{preset.subtitle}</div></div>
          <button className="sheet-expand" onClick={() => onSnapChange(snap === "peek" ? "half" : "peek")} aria-label={snap === "peek" ? "Expand laboratory" : "Collapse laboratory"}><ChevronIcon size={18} /></button>
        </div>
        <div className="peek-actions">
          <button className="action-pill" onClick={() => onTrain(10)} disabled={training.active}><TrainIcon size={14} />{training.active ? `Training ${training.completed}/${training.total}` : "Offline Train +10 Gen"}</button>
          <button className={`action-pill${comparison === "random" ? " active" : ""}`} onClick={() => onComparisonChange(comparison === "random" ? "trained" : "random")}><CompareIcon size={14} />A/B vs Random</button>
          <button className={`action-pill danger${telemetry.predators > 0 ? " active" : ""}`} onClick={() => onSetPredatorCount(telemetry.predators > 0 ? 0 : 2)}><PredatorIcon size={14} />Predator Threat</button>
          <button className="action-pill" onClick={onClearTrails}><ClearIcon size={13} />Clear trails</button>
          <button className={`action-pill${resetArmed ? " arm" : ""}`} onClick={handleReset}><ResetIcon size={13} />{resetArmed ? "Tap again to reset" : "Reset"}</button>
        </div>
      </div>
      <div className="sheet-content">
        <nav className="sheet-tabs" aria-label="Laboratory sections">
          {TABS.map((item) => <button key={item.id} className={`sheet-tab${tab === item.id ? " active" : ""}`} onClick={() => onTabChange(item.id)}><TabGlyph tab={item.id} /><span>{item.label}</span></button>)}
        </nav>
        <div className="sheet-scroll">
          {tab === "proof" && <>
            <section className="lab-section">
              <div className="section-heading"><div><div className="section-title">Proof of Learning</div><div className="section-subtitle">Actual deliveries per 25-birth generation, under identical world physics.</div></div><span className="gen-badge">GEN {telemetry.generation}</span></div>
              <LearningChart points={learning} telemetry={telemetry} comparison={comparison} />
              <div className="metric-strip"><div className="metric-card"><div className="metric-value" style={{ color: "#a7f3d0" }}>{Math.round(telemetry.efficiency)}</div><div className="metric-name">Food / sim minute</div></div><div className="metric-card"><div className="metric-value">{telemetry.hiddenNodes}</div><div className="metric-name">Hidden nodes</div></div><div className="metric-card"><div className="metric-value">{telemetry.synapses}</div><div className="metric-name">Live synapses</div></div></div>
            </section>
            <section className="lab-section">
              <div className="section-heading"><div><div className="section-title">Offline Turbo Neuroevolution</div><div className="section-subtitle">100 fixed simulation ticks per frame. Real foraging, mortality, births, mutation, and topology growth continue headlessly.</div></div><TrainIcon size={20} /></div>
              <button className="primary-button" disabled={training.active} onClick={() => onTrain(10)}><TrainIcon size={17} />{training.active ? `Evolving generation ${telemetry.generation}` : "Fast-forward +10 generations"}</button>
              <div className="button-pair"><button className="action-pill" disabled={training.active} onClick={() => onTrain(10)}>+10 GEN</button><button className="action-pill" disabled={training.active} onClick={() => onTrain(25)}>+25 GEN</button></div>
              <button className="action-pill" style={{ width: "100%", marginTop: 7 }} disabled={training.active} onClick={() => onTrain(50)}>+50 GEN DEEP RUN</button>
              <div className="progress-track"><div className="progress-fill" style={{ width: `${training.active ? training.completed / training.total * 100 : 0}%` }} /></div>
            </section>
            <section className="lab-section">
              <div className="section-heading"><div><div className="section-title">Side-by-Side Arena</div><div className="section-subtitle">Alternating ants are reassigned in place. No separate map, food supply, or easier physics.</div></div></div>
              <div className="segmented">
                <button className={`segment${comparison === "trained" ? " active" : ""}`} onClick={() => onComparisonChange("trained")}>100%<br />Trained NEAT</button>
                <button className={`segment${comparison === "random" ? " active" : ""}`} onClick={() => onComparisonChange("random")}>50 / 50<br />Random Net</button>
                <button className={`segment${comparison === "aco" ? " active" : ""}`} onClick={() => onComparisonChange("aco")}>50 / 50<br />Hand-crafted ACO</button>
              </div>
              <div className="metric-strip"><div className="metric-card"><div className="metric-value" style={{ color: "#ffd166" }}>{telemetry.trainedFood}</div><div className="metric-name">Trained deliveries</div></div><div className="metric-card"><div className="metric-value">{comparison === "aco" ? telemetry.acoFood : telemetry.randomFood}</div><div className="metric-name">Opponent deliveries</div></div><div className="metric-card"><div className="metric-value">{telemetry.brainFitness.toFixed(1)}</div><div className="metric-name">TD fitness</div></div></div>
            </section>
            <section className="lab-section">
              <div className="section-heading"><div><div className="section-title">Sensory Ablation Matrix</div><div className="section-subtitle">Online channels feed the antennae. Off channels still render, but their neural input is exactly zero.</div></div></div>
              <div className="ablation-grid">
                {PHEROMONE_NAMES.map((name) => <button key={name} className={`ablation-toggle${ablation[name] ? " on" : ""}`} style={{ "--channel": CHANNEL_META[name].color } as CSSProperties} onClick={() => onAblationChange(name, !ablation[name])} aria-pressed={ablation[name]}><span className="name"><span className="channel-swatch" style={{ "--pill-color": CHANNEL_META[name].color } as CSSProperties} />{CHANNEL_META[name].label}</span><span className="toggle-track" /></button>)}
                <button className={`ablation-toggle${ablation.pathIntegration ? " on" : ""}`} style={{ "--channel": "#e2e8f0" } as CSSProperties} onClick={() => onAblationChange("pathIntegration", !ablation.pathIntegration)} aria-pressed={ablation.pathIntegration}><span className="name"><span className="channel-swatch" style={{ "--pill-color": "#e2e8f0" } as CSSProperties} />Vector Memory</span><span className="toggle-track" /></button>
              </div>
              <div className="metric-card" style={{ marginTop: 8 }}><div className="metric-value" style={{ color: telemetry.ablatedEfficiencyDrop > 0 ? "#fda4af" : "#a7f3d0" }}>{telemetry.ablatedEfficiencyDrop.toFixed(1)}</div><div className="metric-name">Measured efficiency drop / food per minute</div></div>
            </section>
            <section className="lab-section">
              <div className="section-heading"><div><div className="section-title">Live Hive-Mind Topology</div><div className="section-subtitle">Innovation-numbered synapses, eight hyper-genes, recurrent membrane states.</div></div><span className="micro-label">SPECIES {brain.species}</span></div>
              <TopologyVisualizer brain={brain} />
              <div className="topology-detail">Hyper-genes / trail {brain.hyperGenes.trailCommitment.toFixed(2)} / curiosity {brain.hyperGenes.curiosityDrive.toFixed(2)} / altruism {brain.hyperGenes.trophallaxisAltruism.toFixed(2)} / aggression {brain.hyperGenes.alarmAggression.toFixed(2)}</div>
            </section>
          </>}

          {tab === "colony" && <>
            <section className="lab-section"><div className="section-heading"><div><div className="section-title">Colony Physiology</div><div className="section-subtitle">Births cost three deliveries. ATP depletion and lifespan create persistent mortality.</div></div></div>
              <RangeControl label="Maximum population" value={colony.maxPopulation} display={`${colony.maxPopulation} ants`} min={100} max={3000} step={100} onChange={(value) => onColonyChange({ ...colony, maxPopulation: value })} />
              <RangeControl label="ATP burn multiplier" value={colony.atpBurn} display={`${colony.atpBurn.toFixed(2)}x`} min={0.2} max={3} step={0.05} onChange={(value) => onColonyChange({ ...colony, atpBurn: value })} />
              <RangeControl label="Base lifespan" value={colony.lifespan} display={`${colony.lifespan} sec`} min={60} max={600} step={10} onChange={(value) => onColonyChange({ ...colony, lifespan: value })} />
              <RangeControl label="Scout hatch ratio" value={colony.scoutRatio} display={`${Math.round(colony.scoutRatio * 100)}%`} min={0.05} max={0.6} step={0.01} onChange={(value) => onColonyChange({ ...colony, scoutRatio: Math.min(value, 0.9 - colony.wardenRatio) })} />
              <RangeControl label="Warden hatch ratio" value={colony.wardenRatio} display={`${Math.round(colony.wardenRatio * 100)}%`} min={0.02} max={0.5} step={0.01} onChange={(value) => onColonyChange({ ...colony, wardenRatio: Math.min(value, 0.9 - colony.scoutRatio) })} />
              <div className="metric-strip"><div className="metric-card"><div className="metric-value">{telemetry.alive}</div><div className="metric-name">Living</div></div><div className="metric-card"><div className="metric-value">{telemetry.births}</div><div className="metric-name">Food-born</div></div><div className="metric-card"><div className="metric-value">{Math.round(telemetry.meanEnergy)}%</div><div className="metric-name">Mean ATP</div></div></div>
            </section>
            <section className="lab-section"><div className="section-heading"><div><div className="section-title">Abyssal Stalkers</div><div className="section-subtitle">Armored hunters trigger crimson broadcasts. Scouts flee; wardens climb alarm gradients and inflict real damage.</div></div><PredatorIcon size={22} /></div>
              <RangeControl label="Predator count" value={colony.predatorCount} display={`${telemetry.predators} active / ${colony.predatorCount} target`} min={0} max={6} step={1} onChange={onSetPredatorCount} />
              <button className="primary-button" disabled={telemetry.predators >= 6} onClick={onSpawnPredator}><PredatorIcon size={17} />Spawn predator in upper basin</button>
              <div className="topology-detail">Alarm radius 75 px / explosive deposit +80 / warden contact DPS scales with the alarmAggression hyper-gene.</div>
            </section>
          </>}

          {tab === "alchemy" && <>
            <section className="lab-section"><div className="section-heading"><div><div className="section-title">Five-Channel RGB Alchemy</div><div className="section-subtitle">Tap a vessel to cycle concentration. The result uses the renderer’s exact tonemapped mixer.</div></div></div><MixingPreview /></section>
            <section className="lab-section"><div className="section-heading"><div><div className="section-title">Reaction-Diffusion Field</div><div className="section-subtitle">3x3 CFL-safe diffusion with zero-flux Neumann boundaries at basalt walls.</div></div></div>
              <RangeControl label="Evaporation" value={pheromones.evaporation} display={`${(pheromones.evaporation * 100).toFixed(1)}% / sec`} min={0.005} max={0.2} step={0.005} onChange={(value) => onPheromonesChange({ ...pheromones, evaporation: value })} />
              <RangeControl label="Cross-reaction rate" value={pheromones.crossReaction} display={`${pheromones.crossReaction.toFixed(2)}x`} min={0} max={2} step={0.05} onChange={(value) => onPheromonesChange({ ...pheromones, crossReaction: value })} />
              <RangeControl label="Diffusion coefficient" value={pheromones.diffusion} display={pheromones.diffusion.toFixed(3)} min={0} max={0.18} step={0.005} onChange={(value) => onPheromonesChange({ ...pheromones, diffusion: value })} />
              <RangeControl label="Spectral gamma" value={pheromones.gamma} display={pheromones.gamma.toFixed(2)} min={0.5} max={3} step={0.05} onChange={(value) => onPheromonesChange({ ...pheromones, gamma: value })} />
              <div className="nature-grid"><div className="nature-card"><h3>Polymer core</h3><p>Amber plus cyan decays 35% slower where both concentrations exceed 3.</p></div><div className="nature-card"><h3>Chemical erasure</h3><p>No-entry subtracts 0.45 × viridian × dt from amber every reaction tick.</p></div></div>
            </section>
          </>}

          {tab === "brush" && <>
            <section className="lab-section"><div className="section-heading"><div><div className="section-title">Spectral Field Brush</div><div className="section-subtitle">A Catmull–Rom spline resamples every pointer stroke at one quarter of its radius for gap-free deposition.</div></div><RadiusIcon size={21} /></div>
              <RangeControl label="Radius" value={brush.radius} display={`${brush.radius} px`} min={6} max={72} step={2} onChange={(value) => onBrushChange({ ...brush, radius: value })} />
              <RangeControl label="Strength" value={brush.strength} display={`${brush.strength} units`} min={5} max={80} step={5} onChange={(value) => onBrushChange({ ...brush, strength: value })} />
              <div className="shortcut-grid"><div className="shortcut"><kbd>[</kbd>Smaller</div><div className="shortcut"><kbd>]</kbd>Larger</div><div className="shortcut"><kbd>1–6</kbd>Tools</div><div className="shortcut"><kbd>Space</kbd>Pause</div></div>
            </section>
            <section className="lab-section"><div className="section-title">Deposition contract</div><div className="nature-grid" style={{ marginTop: 10 }}><div className="nature-card"><h3>Saturating</h3><p>Each lattice cell is clamped to 100. A soft radial falloff prevents square brush footprints.</p></div><div className="nature-card"><h3>Zero-flux</h3><p>Walls neither accept nor leak concentration. Erasing a wall clears its trapped chemical cells.</p></div></div></section>
          </>}

          {tab === "world" && <>
            <section className="lab-section"><div className="section-heading"><div><div className="section-title">Sanctuary Cartography</div><div className="section-subtitle">Loading a preset resets colony history but preserves laboratory settings.</div></div><span className="micro-label">720 × 1280</span></div>
              <div className="preset-list">{PRESETS.map((item) => <button key={item.id} className={`preset-card${preset.id === item.id ? " active" : ""}`} onClick={() => onPresetChange(item.id)}><PresetPreview preset={item} /><div><div className="preset-card-title">{item.name}</div><div className="preset-card-copy">{item.description}</div><div className="world-facts"><span>{item.food.length} crystal beds</span><span>{item.initialPopulation} founders</span></div></div></button>)}</div>
            </section>
            <section className="lab-section"><div className="nature-card"><h3>Experimental note</h3><p>The double bridge has unequal route lengths around an occluding basalt core. Watch amber reinforcement select a highway; then ablate food amber and measure the collapse in delivery rate.</p></div><button className="primary-button" style={{ marginTop: 10 }} onClick={onClearTrails}><ClearIcon size={16} />Clear all five chemical fields</button></section>
          </>}
        </div>
      </div>
    </section>
  );
}
