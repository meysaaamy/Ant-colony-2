"use client";

import { useEffect } from "react";
import { CloseIcon } from "./ui/icons";

interface FieldGuideModalProps {
  onClose: () => void;
}

function AlchemyDiagram() {
  return (
    <svg viewBox="0 0 240 130" role="img" aria-label="Pheromone spectral mixing diagram">
      <rect width="240" height="130" fill="#050a12" />
      <path d="M28 88C62 16 105 120 140 46S202 35 216 72" fill="none" stroke="#ffa800" strokeWidth="6" strokeLinecap="round" />
      <path d="M28 88C62 16 105 120 140 46S202 35 216 72" fill="none" stroke="#00e1ff" strokeWidth="2" strokeDasharray="3 7" strokeLinecap="round" />
      <path d="M75 51C95 42 106 69 121 69" fill="none" stroke="#f8fafc" strokeWidth="4" strokeLinecap="round" />
      <circle cx="28" cy="88" r="5" fill="#ffa800" /><circle cx="216" cy="72" r="5" fill="#00e1ff" />
      <text x="120" y="119" textAnchor="middle" fill="#8291a5" fontSize="8" fontFamily="sans-serif" letterSpacing="1.5">PEARL HIGHWAY CORE</text>
    </svg>
  );
}

function BrainDiagram() {
  return (
    <svg viewBox="0 0 240 130" role="img" aria-label="Shared hive mind network diagram">
      <rect width="240" height="130" fill="#050a12" />
      <g strokeWidth="1" fill="none">
        <path d="M40 28 116 42 196 25M40 52 116 42 196 65M40 76 116 88 196 65M40 100 116 88 196 105" stroke="#2dd4bf" strokeOpacity=".65" />
        <path d="M40 28 116 88M40 100 116 42M116 42 196 105" stroke="#ff0c4b" strokeOpacity=".55" />
      </g>
      <g fill="#0d1322" stroke="#7dd3fc"><circle cx="40" cy="28" r="7" /><circle cx="40" cy="52" r="7" /><circle cx="40" cy="76" r="7" /><circle cx="40" cy="100" r="7" /></g>
      <g fill="#1d1233" stroke="#af32ff"><circle cx="116" cy="42" r="10" /><circle cx="116" cy="88" r="10" /></g>
      <g fill="#27200d" stroke="#fbbf24"><circle cx="196" cy="25" r="7" /><circle cx="196" cy="65" r="7" /><circle cx="196" cy="105" r="7" /></g>
    </svg>
  );
}

export default function FieldGuideModal({ onClose }: FieldGuideModalProps) {
  useEffect(() => {
    const escape = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", escape);
    return () => window.removeEventListener("keydown", escape);
  }, [onClose]);

  return (
    <div className="modal-backdrop" onPointerDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
      <section className="field-guide glass" role="dialog" aria-modal="true" aria-labelledby="guide-title">
        <header className="guide-header">
          <div>
            <div className="micro-label">Field notes / Prismara Station</div>
            <h2 className="guide-title" id="guide-title">Reading a living colony</h2>
            <div className="guide-subtitle">No ant receives a global plan. Every highway, retreat, and rescue emerges from local sensing and shared chemistry.</div>
          </div>
          <button className="squircle" onClick={onClose} aria-label="Close field guide" autoFocus><CloseIcon size={21} /></button>
        </header>
        <div className="guide-scroll">
          <div className="guide-diagrams">
            <div className="guide-diagram">
              <img src="/assets/diagram-double-bridge.svg" alt="Two asymmetric bridges linking a nest and food crystal" />
              <p><strong>Double bridge.</strong> Positive feedback can amplify the shorter route without any ant comparing both paths.</p>
            </div>
            <div className="guide-diagram"><AlchemyDiagram /><p><strong>Spectral highways.</strong> Amber and cyan overlap into turquoise margins and a pearl-white, slow-decay polymer core.</p></div>
            <div className="guide-diagram"><BrainDiagram /><p><strong>One shared mind.</strong> Every trained ant runs the same recurrent NEAT genome, but senses a different local world.</p></div>
          </div>

          <div className="lab-section">
            <div className="section-heading"><div><div className="section-title">Five chemical dialects</div><div className="section-subtitle">Concentrations live on a 6 px reaction-diffusion lattice, capped at 100 per channel.</div></div></div>
            <div className="nature-grid">
              <div className="nature-card"><h3 style={{ color: "#ffa800" }}>Food trail / Solar Amber</h3><p>Loaded returners deposit it. Ants compare Weber–Fechner log concentrations at left and right antennae, then reinforce useful paths.</p></div>
              <div className="nature-card"><h3 style={{ color: "#00e1ff" }}>Home guide / Abyssal Cyan</h3><p>Outgoing breadcrumbs complement path integration. Overlap with food trail creates a protected polymer highway.</p></div>
              <div className="nature-card"><h3 style={{ color: "#ff0c4b" }}>Alarm / Crimson-Neon</h3><p>Decays 3.2 times faster. Foragers flee its source while wardens climb the gradient to armored stalkers.</p></div>
              <div className="nature-card"><h3 style={{ color: "#af32ff" }}>Scout pulse / Electric Violet</h3><p>Marks pioneer discoveries and tandem-running transfers. With amber it forms rose-gold recruitment plumes.</p></div>
              <div className="nature-card"><h3 style={{ color: "#50ff64" }}>No-entry / Acid Viridian</h3><p>Deposited after stalls and depletion. It chemically dissolves obsolete amber trails instead of merely hiding them.</p></div>
              <div className="nature-card"><h3>Interference is physical</h3><p>Cyan plus alarm makes electric-magenta escape plumes. Alarm plus no-entry yields sulfur-gold hazard zones. All color is computed per cell.</p></div>
            </div>
          </div>

          <div className="lab-section">
            <div className="section-title">In nature / In this sandbox</div>
            <div className="nature-grid" style={{ marginTop: 10 }}>
              <div className="nature-card"><h3>In nature</h3><p>Trophallaxis redistributes food, necrophoresis removes corpses, and tandem running teaches a route directly. These behaviors cost time and energy; they are not free global knowledge.</p></div>
              <div className="nature-card"><h3>In this sandbox</h3><p>ATP falls with motion, load, and combat. Well-fed ants donate energy to starving neighbors. Wardens haul marked husks to the graveyard. Every third delivery hatches one ant.</p></div>
              <div className="nature-card"><h3>Learning claim</h3><p>The proof lab compares actual deliveries from coexisting cohorts. Random and ACO ants share the same sensors, body, metabolism, crystals, and threats as the trained hive-mind.</p></div>
              <div className="nature-card"><h3>Ablation claim</h3><p>Knocking out a channel changes the sensor values at the next tick; chemistry remains visible. Compare delivery rate before and after rather than trusting a cosmetic switch.</p></div>
            </div>
          </div>

          <div className="lab-section">
            <div className="section-title">Field shortcuts</div>
            <div className="shortcut-grid">
              <div className="shortcut"><kbd>1–6</kbd>Select tools</div>
              <div className="shortcut"><kbd>Space</kbd>Play / pause</div>
              <div className="shortcut"><kbd>[</kbd><kbd>]</kbd>Brush radius</div>
              <div className="shortcut"><kbd>Esc</kbd>Close / peek</div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
