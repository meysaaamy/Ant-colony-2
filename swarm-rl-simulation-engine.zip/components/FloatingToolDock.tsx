"use client";

import { useState, type CSSProperties } from "react";
import type { BrushSettings, PaintMode, PheromoneName, ToolId } from "../lib/types";
import { AlarmIcon, CrystalIcon, EraserIcon, FoodTrailIcon, HomeIcon, PredatorIcon, RadiusIcon, WallIcon } from "./ui/icons";

interface FloatingToolDockProps {
  tool: ToolId;
  paintMode: PaintMode;
  brush: BrushSettings;
  onToolChange: (tool: ToolId) => void;
  onPaintModeChange: (mode: PaintMode) => void;
  onBrushChange: (brush: BrushSettings) => void;
}

const TOOLS: readonly { id: ToolId; label: string; color: string }[] = [
  { id: "food", label: "Food trail", color: "#ffa800" },
  { id: "home", label: "Home guide", color: "#00e1ff" },
  { id: "alarm", label: "Alarm field", color: "#ff0c4b" },
  { id: "crystal", label: "Food crystal", color: "#00e676" },
  { id: "wall", label: "Basalt wall", color: "#38bdf8" },
  { id: "eraser", label: "Erase field", color: "#cbd5e1" },
];

const CHANNELS: readonly { id: PheromoneName; label: string; short: string; color: string; tool: ToolId }[] = [
  { id: "foodTrail", label: "Food Amber", short: "Food", color: "#ffa800", tool: "food" },
  { id: "homeGuide", label: "Home Cyan", short: "Home", color: "#00e1ff", tool: "home" },
  { id: "alarm", label: "Alarm Crimson", short: "Alarm", color: "#ff0c4b", tool: "alarm" },
  { id: "scoutPulse", label: "Scout Violet", short: "Scout", color: "#af32ff", tool: "alarm" },
  { id: "noEntry", label: "No-Entry Viridian", short: "Seal", color: "#50ff64", tool: "alarm" },
];

function ToolGlyph({ tool }: { tool: ToolId }) {
  if (tool === "food") return <FoodTrailIcon size={24} />;
  if (tool === "home") return <HomeIcon size={24} />;
  if (tool === "alarm") return <AlarmIcon size={24} />;
  if (tool === "crystal") return <CrystalIcon size={24} />;
  if (tool === "wall") return <WallIcon size={24} />;
  return <EraserIcon size={24} />;
}

export default function FloatingToolDock({ tool, paintMode, brush, onToolChange, onPaintModeChange, onBrushChange }: FloatingToolDockProps) {
  const [radiusOpen, setRadiusOpen] = useState(false);
  const activeTool = TOOLS.find((item) => item.id === tool) ?? TOOLS[0];
  return (
    <>
      <div className="context-row" aria-label="Pheromone brush modes">
        <span className="context-pill active" style={{ "--pill-color": activeTool.color } as CSSProperties}>
          {activeTool.label}
        </span>
        {CHANNELS.map((channel) => (
          <button
            key={channel.id}
            className={`context-pill${paintMode === channel.id ? " active" : ""}`}
            style={{ "--pill-color": channel.color } as CSSProperties}
            onClick={() => {
              onToolChange(channel.tool);
              onPaintModeChange(channel.id);
            }}
            title={channel.label}
          >
            <span className="channel-swatch" />{channel.short}
          </button>
        ))}
        <button
          className={`context-pill${paintMode === "predator" ? " active" : ""}`}
          style={{ "--pill-color": "#ff0c4b" } as CSSProperties}
          onClick={() => {
            onToolChange("alarm");
            onPaintModeChange("predator");
          }}
        >
          <PredatorIcon size={13} />Stalker
        </button>
        <button className={`context-pill${radiusOpen ? " active" : ""}`} onClick={() => setRadiusOpen((open) => !open)} aria-expanded={radiusOpen}>
          <RadiusIcon size={14} />{Math.round(brush.radius)} px
        </button>
      </div>
      {radiusOpen && (
        <div className="radius-control glass interactive">
          <div className="control-label"><span>Brush radius</span><span className="control-value tabular">{brush.radius} px</span></div>
          <input aria-label="Brush radius" type="range" min="6" max="72" step="2" value={brush.radius} onChange={(event) => onBrushChange({ ...brush, radius: Number(event.target.value) })} />
          <div className="control-label"><span>Deposition strength</span><span className="control-value tabular">{brush.strength}</span></div>
          <input aria-label="Deposition strength" type="range" min="5" max="80" step="5" value={brush.strength} onChange={(event) => onBrushChange({ ...brush, strength: Number(event.target.value) })} />
        </div>
      )}
      <nav className="tool-dock glass" aria-label="Sanctuary tools">
        {TOOLS.map((item, index) => (
          <button
            key={item.id}
            className={`tool-jewel${tool === item.id ? " active" : ""}`}
            style={{ "--tool-color": item.color } as CSSProperties}
            onClick={() => {
              onToolChange(item.id);
              if (item.id === "food") onPaintModeChange("foodTrail");
              if (item.id === "home") onPaintModeChange("homeGuide");
              if (item.id === "alarm" && paintMode !== "predator") onPaintModeChange("alarm");
            }}
            aria-label={`${item.label}, shortcut ${index + 1}`}
            title={`${item.label} [${index + 1}]`}
          >
            <span className="tool-key">{index + 1}</span>
            <ToolGlyph tool={item.id} />
          </button>
        ))}
      </nav>
    </>
  );
}
