import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      borderRadius: { sm: "12px", md: "20px", lg: "28px" },
      transitionTimingFunction: { cryo: "cubic-bezier(0.2, 0.8, 0.2, 1)" },
      fontFamily: {
        sans: ["var(--font-jakarta)", "sans-serif"],
        display: ["var(--font-fraunces)", "serif"],
      },
    },
  },
};

export default config;
