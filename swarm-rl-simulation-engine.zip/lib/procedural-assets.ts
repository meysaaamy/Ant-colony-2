import { SimplexNoise2D, mulberry32 } from "./prng-noise";
import { WORLD_HEIGHT, WORLD_WIDTH } from "./types";

export interface ProceduralAssets {
  antSprites: HTMLCanvasElement[][][];
  predator: HTMLCanvasElement;
  crystals: HTMLCanvasElement[];
  corpse: HTMLCanvasElement;
  soilTile: HTMLCanvasElement;
  basaltTile: HTMLCanvasElement;
  vignette: HTMLCanvasElement;
  grainTile: HTMLCanvasElement;
}

function canvas(width: number, height: number): HTMLCanvasElement {
  const element = document.createElement("canvas");
  element.width = width;
  element.height = height;
  return element;
}

function context2d(element: HTMLCanvasElement): CanvasRenderingContext2D {
  const context = element.getContext("2d");
  if (!context) throw new Error("Canvas 2D is unavailable");
  return context;
}

function makeAnt(palette: number, caste: number, frame: number): HTMLCanvasElement {
  const sprite = canvas(32, 32);
  const ctx = context2d(sprite);
  const phase = frame / 8 * Math.PI * 2;
  const colors = palette === 0
    ? ["#b79cff", "#ffd166", "#9dffb0", "#94a3b8"]
    : ["#67e8f9", "#fff0b3", "#ff5c7a", "#64748b"];
  const core = colors[caste];
  ctx.translate(16, 16);
  ctx.lineCap = "round";
  for (let side = -1; side <= 1; side += 2) {
    for (let leg = 0; leg < 3; leg += 1) {
      const anchorY = -3 + leg * 4;
      const gait = Math.sin(phase + leg * 2.1 + (side > 0 ? Math.PI : 0));
      ctx.strokeStyle = leg === 1 ? core : "#728397";
      ctx.lineWidth = 1.05;
      ctx.beginPath();
      ctx.moveTo(side * 2, anchorY);
      ctx.lineTo(side * (6 + gait * 1.2), anchorY + (leg - 1) * 2.5);
      ctx.lineTo(side * (9 + gait * 1.7), anchorY + (leg - 1) * 5.2);
      ctx.stroke();
    }
  }
  ctx.strokeStyle = core;
  ctx.lineWidth = 0.85;
  ctx.beginPath();
  ctx.moveTo(-1.6, -6);
  ctx.quadraticCurveTo(-5, -11, -7, -9);
  ctx.moveTo(1.6, -6);
  ctx.quadraticCurveTo(5, -11, 7, -9);
  ctx.stroke();
  const abdomen = ctx.createRadialGradient(-1.5, 6, 0.5, 0, 7, 6);
  abdomen.addColorStop(0, core);
  abdomen.addColorStop(0.28, "#263446");
  abdomen.addColorStop(1, "#070c13");
  ctx.fillStyle = abdomen;
  ctx.beginPath();
  ctx.ellipse(0, 7, caste === 1 ? 4.6 : 4, caste === 1 ? 6 : 5.4, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = core;
  ctx.globalAlpha = 0.65;
  ctx.lineWidth = 0.7;
  ctx.stroke();
  ctx.globalAlpha = 1;
  ctx.fillStyle = "#111c29";
  ctx.beginPath();
  ctx.ellipse(0, 0, 3.1, 3.7, 0, 0, Math.PI * 2);
  ctx.ellipse(0, -5, caste === 2 ? 3.8 : 3.2, 3.1, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = core;
  ctx.globalAlpha = 0.9;
  ctx.beginPath();
  ctx.arc(-1.5, -5.8, 0.65, 0, Math.PI * 2);
  ctx.arc(1.5, -5.8, 0.65, 0, Math.PI * 2);
  ctx.fill();
  ctx.globalAlpha = 1;
  if (caste === 2) {
    ctx.strokeStyle = "#ff4d6d";
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(-2.5, -7);
    ctx.lineTo(-5, -9);
    ctx.moveTo(2.5, -7);
    ctx.lineTo(5, -9);
    ctx.stroke();
  }
  return sprite;
}

function makePredator(): HTMLCanvasElement {
  const sprite = canvas(72, 72);
  const ctx = context2d(sprite);
  ctx.translate(36, 36);
  ctx.lineCap = "round";
  for (let side = -1; side <= 1; side += 2) {
    for (let leg = 0; leg < 4; leg += 1) {
      const y = -15 + leg * 10;
      ctx.strokeStyle = leg % 2 ? "#48566b" : "#7f2b45";
      ctx.lineWidth = 2.2;
      ctx.beginPath();
      ctx.moveTo(side * 8, y);
      ctx.lineTo(side * (20 + leg * 2), y - 7 + leg * 3);
      ctx.lineTo(side * (26 + leg), y + 2 + leg * 2);
      ctx.stroke();
    }
  }
  const shell = ctx.createLinearGradient(-12, -20, 14, 22);
  shell.addColorStop(0, "#4c5b70");
  shell.addColorStop(0.35, "#131d2c");
  shell.addColorStop(1, "#050910");
  ctx.fillStyle = shell;
  ctx.strokeStyle = "#738197";
  ctx.lineWidth = 1.2;
  ctx.beginPath();
  ctx.moveTo(0, -25);
  ctx.lineTo(13, -15);
  ctx.lineTo(15, 11);
  ctx.lineTo(7, 24);
  ctx.lineTo(-7, 24);
  ctx.lineTo(-15, 11);
  ctx.lineTo(-13, -15);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.strokeStyle = "#334155";
  for (let y = -8; y < 18; y += 8) {
    ctx.beginPath();
    ctx.moveTo(-12, y);
    ctx.lineTo(12, y + 2);
    ctx.stroke();
  }
  ctx.fillStyle = "#ff0c4b";
  ctx.beginPath();
  ctx.arc(-5, -15, 2.1, 0, Math.PI * 2);
  ctx.arc(5, -15, 2.1, 0, Math.PI * 2);
  ctx.fill();
  return sprite;
}

function makeCrystal(variant: number): HTMLCanvasElement {
  const sprite = canvas(56, 64);
  const ctx = context2d(sprite);
  const random = mulberry32(9301 + variant * 71);
  ctx.translate(28, 34);
  for (let shard = 0; shard < 5; shard += 1) {
    const angle = (shard - 2) * 0.22 + (random() - 0.5) * 0.12;
    const height = 17 + random() * 18;
    const width = 5 + random() * 5;
    ctx.save();
    ctx.translate((shard - 2) * 6, 12 - Math.abs(shard - 2) * 2);
    ctx.rotate(angle);
    const gradient = ctx.createLinearGradient(-width, -height, width, 8);
    gradient.addColorStop(0, "#a7f3d0");
    gradient.addColorStop(0.25, "#00e676");
    gradient.addColorStop(1, "#065f46");
    ctx.fillStyle = gradient;
    ctx.strokeStyle = "#a7f3d0";
    ctx.lineWidth = 0.65;
    ctx.beginPath();
    ctx.moveTo(0, -height);
    ctx.lineTo(width, -height * 0.55);
    ctx.lineTo(width * 0.8, 6);
    ctx.lineTo(0, 12);
    ctx.lineTo(-width * 0.8, 6);
    ctx.lineTo(-width, -height * 0.55);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.strokeStyle = "rgba(220,255,240,.65)";
    ctx.beginPath();
    ctx.moveTo(0, -height);
    ctx.lineTo(0, 10);
    ctx.moveTo(0, -height * 0.35);
    ctx.lineTo(width, -height * 0.55);
    ctx.stroke();
    ctx.restore();
  }
  return sprite;
}

function makeCorpse(): HTMLCanvasElement {
  const sprite = canvas(28, 28);
  const ctx = context2d(sprite);
  ctx.translate(14, 14);
  ctx.rotate(0.7);
  ctx.strokeStyle = "#5d5260";
  ctx.fillStyle = "#16131b";
  ctx.lineWidth = 1;
  for (let side = -1; side <= 1; side += 2) {
    for (let leg = 0; leg < 3; leg += 1) {
      ctx.beginPath();
      ctx.moveTo(side * 2, -3 + leg * 4);
      ctx.lineTo(side * 7, -7 + leg * 7);
      ctx.stroke();
    }
  }
  ctx.beginPath();
  ctx.ellipse(0, 6, 4, 5, 0, 0, Math.PI * 2);
  ctx.ellipse(0, 0, 2.8, 3, 0, 0, Math.PI * 2);
  ctx.ellipse(0, -5, 3, 2.5, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  return sprite;
}

function makeSoil(noise: SimplexNoise2D): HTMLCanvasElement {
  const tile = canvas(256, 256);
  const ctx = context2d(tile);
  const image = ctx.createImageData(256, 256);
  for (let y = 0; y < 256; y += 1) {
    for (let x = 0; x < 256; x += 1) {
      const index = (y * 256 + x) * 4;
      const n = noise.fbm(x / 55, y / 55, 4);
      const vein = Math.max(0, 0.055 - Math.abs(noise.noise(x / 82 + 8, y / 82))) * 75;
      image.data[index] = Math.min(9, 2 + vein * 2);
      image.data[index + 1] = Math.min(14, 3 + vein * 4 + Math.max(0, n) * 2);
      image.data[index + 2] = Math.min(26, 7 + vein * 7 + Math.max(0, n) * 3);
      image.data[index + 3] = 255;
    }
  }
  ctx.putImageData(image, 0, 0);
  return tile;
}

function makeBasalt(noise: SimplexNoise2D): HTMLCanvasElement {
  const tile = canvas(192, 192);
  const ctx = context2d(tile);
  const image = ctx.createImageData(192, 192);
  for (let y = 0; y < 192; y += 1) {
    for (let x = 0; x < 192; x += 1) {
      const index = (y * 192 + x) * 4;
      const terrace = Math.floor((noise.fbm(x / 45, y / 45, 3) + 1) * 4) / 4;
      image.data[index] = 8 + terrace * 5;
      image.data[index + 1] = 13 + terrace * 7;
      image.data[index + 2] = 24 + terrace * 10;
      image.data[index + 3] = 255;
    }
  }
  ctx.putImageData(image, 0, 0);
  return tile;
}

function makeVignette(): HTMLCanvasElement {
  const layer = canvas(WORLD_WIDTH, WORLD_HEIGHT);
  const ctx = context2d(layer);
  const gradient = ctx.createRadialGradient(WORLD_WIDTH / 2, WORLD_HEIGHT / 2, WORLD_HEIGHT * 0.16, WORLD_WIDTH / 2, WORLD_HEIGHT / 2, WORLD_HEIGHT * 0.67);
  gradient.addColorStop(0, "rgba(0,0,0,0)");
  gradient.addColorStop(0.65, "rgba(0,2,8,.08)");
  gradient.addColorStop(1, "rgba(0,2,8,.74)");
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, WORLD_WIDTH, WORLD_HEIGHT);
  return layer;
}

function makeGrain(): HTMLCanvasElement {
  const tile = canvas(128, 128);
  const ctx = context2d(tile);
  const image = ctx.createImageData(128, 128);
  const random = mulberry32(7727);
  for (let i = 0; i < image.data.length; i += 4) {
    const value = random() > 0.5 ? 255 : 0;
    image.data[i] = value;
    image.data[i + 1] = value;
    image.data[i + 2] = value;
    image.data[i + 3] = Math.floor(random() * 16);
  }
  ctx.putImageData(image, 0, 0);
  return tile;
}

export function createProceduralAssets(): ProceduralAssets {
  const antSprites: HTMLCanvasElement[][][] = [];
  for (let palette = 0; palette < 2; palette += 1) {
    const casteSprites: HTMLCanvasElement[][] = [];
    for (let caste = 0; caste < 4; caste += 1) {
      const frames: HTMLCanvasElement[] = [];
      for (let frame = 0; frame < 8; frame += 1) frames.push(makeAnt(palette, caste, frame));
      casteSprites.push(frames);
    }
    antSprites.push(casteSprites);
  }
  const crystals: HTMLCanvasElement[] = [];
  for (let variant = 0; variant < 8; variant += 1) crystals.push(makeCrystal(variant));
  const noise = new SimplexNoise2D(419);
  return {
    antSprites,
    predator: makePredator(),
    crystals,
    corpse: makeCorpse(),
    soilTile: makeSoil(noise),
    basaltTile: makeBasalt(noise),
    vignette: makeVignette(),
    grainTile: makeGrain(),
  };
}
