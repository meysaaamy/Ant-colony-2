export const WORLD_WIDTH = 720;
export const WORLD_HEIGHT = 1280;
export const MAX_ANTS = 3000;
export const MAX_PREDATORS = 6;
export const FIXED_DT = 1 / 60;

export const Pheromone = {
  foodTrail: 0,
  homeGuide: 1,
  alarm: 2,
  scoutPulse: 3,
  noEntry: 4,
} as const;
export type PheromoneChannel = (typeof Pheromone)[keyof typeof Pheromone];
export type PheromoneName = keyof typeof Pheromone;
export const PHEROMONE_NAMES: readonly PheromoneName[] = [
  "foodTrail",
  "homeGuide",
  "alarm",
  "scoutPulse",
  "noEntry",
];

export const AntState = {
  FORAGING: 0,
  RETURNING: 1,
  ALARMED: 2,
  DEFENDING: 3,
  TRAIL_DAMPING: 4,
  TANDEM_FOLLOW: 5,
  NECROPHORESIS: 6,
  DEAD: 7,
} as const;
export type AntStateValue = (typeof AntState)[keyof typeof AntState];

export const Caste = { SCOUT: 0, HAULER: 1, WARDEN: 2 } as const;
export type CasteValue = (typeof Caste)[keyof typeof Caste];
export const Cohort = { TRAINED_NEAT: 0, BASELINE_ACO: 1, RANDOM_NET: 2 } as const;
export type CohortValue = (typeof Cohort)[keyof typeof Cohort];
export type ComparisonMode = "trained" | "random" | "aco";
export type PresetId = "sanctuary" | "double-bridge" | "labyrinth";
export type ToolId = "food" | "home" | "alarm" | "crystal" | "wall" | "eraser";
export type PaintMode = PheromoneName | "predator";
export type SheetSnap = "peek" | "half" | "full";
export type LabTab = "proof" | "colony" | "alchemy" | "brush" | "world";

export interface Vec2 {
  x: number;
  y: number;
}

export interface AblationMask {
  foodTrail: boolean;
  homeGuide: boolean;
  alarm: boolean;
  scoutPulse: boolean;
  noEntry: boolean;
  pathIntegration: boolean;
}

export interface HyperGenes {
  trailCommitment: number;
  curiosityDrive: number;
  obstacleForesight: number;
  vectorMemoryTrust: number;
  negativeFeedbackSensitivity: number;
  metabolicEfficiency: number;
  trophallaxisAltruism: number;
  alarmAggression: number;
}

export type NodeKind = "input" | "hidden" | "output";
export interface NeatNode {
  id: number;
  kind: NodeKind;
  bias: number;
  activation: "tanh" | "sigmoid" | "relu";
}
export interface NeatConnection {
  from: number;
  to: number;
  weight: number;
  enabled: boolean;
  innovation: number;
}
export interface SharedNeatBrain {
  nodes: NeatNode[];
  connections: NeatConnection[];
  generation: number;
  nextNodeId: number;
  nextInnovation: number;
  hyperGenes: HyperGenes;
  fitness: number;
  species: number;
}
export interface LearningPoint {
  generation: number;
  neat: number;
  aco: number;
  random: number;
  hiddenNodes: number;
  synapses: number;
}

export interface AntSoA {
  x: Float32Array;
  y: Float32Array;
  vx: Float32Array;
  vy: Float32Array;
  angle: Float32Array;
  homeDx: Float32Array;
  homeDy: Float32Array;
  targetX: Float32Array;
  targetY: Float32Array;
  legPhase: Float32Array;
  pheromoneTimer: Float32Array;
  timeSinceLastVisit: Float32Array;
  ouNoise: Float32Array;
  energy: Float32Array;
  age: Float32Array;
  maxLifespan: Float32Array;
  fitness: Float32Array;
  memA: Float32Array;
  memB: Float32Array;
  tripDistance: Float32Array;
  tripOriginDistance: Float32Array;
  stallTime: Float32Array;
  state: Uint8Array;
  caste: Uint8Array;
  cohort: Uint8Array;
  carryingFood: Uint8Array;
  active: Uint8Array;
  generation: Uint16Array;
  targetIndex: Int32Array;
}

export interface FoodSource {
  x: number;
  y: number;
  amount: number;
  maxAmount: number;
  radius: number;
  variant: number;
  discovered: boolean;
  active: boolean;
}

export interface Corpse {
  x: number;
  y: number;
  age: number;
  caste: number;
  active: boolean;
  claimedBy: number;
}

export interface Predator {
  x: number;
  y: number;
  vx: number;
  vy: number;
  angle: number;
  hp: number;
  maxHp: number;
  attackCooldown: number;
  active: boolean;
  target: number;
}

export interface SignalArc {
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  ttl: number;
  kind: 0 | 1 | 2;
  active: boolean;
}

export interface PheromoneSettings {
  evaporation: number;
  diffusion: number;
  crossReaction: number;
  gamma: number;
}

export interface ColonySettings {
  maxPopulation: number;
  predatorCount: number;
  atpBurn: number;
  lifespan: number;
  scoutRatio: number;
  wardenRatio: number;
}

export interface BrushSettings {
  radius: number;
  strength: number;
}

export interface WallSpec {
  x: number;
  y: number;
  x2: number;
  y2: number;
  radius: number;
  kind: "stone" | "capsule";
}

export interface FoodSpec {
  x: number;
  y: number;
  amount: number;
  radius: number;
}

export interface WorldPreset {
  id: PresetId;
  name: string;
  subtitle: string;
  description: string;
  nest: Vec2;
  graveyard: Vec2;
  walls: readonly WallSpec[];
  food: readonly FoodSpec[];
  initialPopulation: number;
}

export interface Telemetry {
  fps: number;
  alive: number;
  deaths: number;
  food: number;
  generation: number;
  births: number;
  trainedFood: number;
  randomFood: number;
  acoFood: number;
  foodThisGeneration: number;
  acoThisGeneration: number;
  randomThisGeneration: number;
  predators: number;
  meanEnergy: number;
  efficiency: number;
  ablatedEfficiencyDrop: number;
  hiddenNodes: number;
  synapses: number;
  brainFitness: number;
  bottleneck: boolean;
  storedFood: number;
  ticks: number;
  turbo: boolean;
}

export interface ToastMessage {
  id: number;
  title: string;
  detail: string;
  tone: "cyan" | "amber" | "crimson";
}

export interface BrushVisual {
  active: boolean;
  x: number;
  y: number;
  previousX: number;
  previousY: number;
  radius: number;
  startedAt: number;
  erasing: boolean;
  color: string;
}

export interface EngineSnapshot {
  telemetry: Telemetry;
  learning: readonly LearningPoint[];
  brain: SharedNeatBrain;
}
