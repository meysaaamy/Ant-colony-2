import type { AntSoAEngine } from "./ant-soa-engine";
import { createProceduralAssets, type ProceduralAssets } from "./procedural-assets";
import { clamp, mulberry32, SimplexNoise2D } from "./prng-noise";
import {
  AntState,
  Cohort,
  WORLD_HEIGHT,
  WORLD_WIDTH,
  type BrushVisual,
  type WallSpec,
  type WorldPreset,
} from "./types";

function makeCanvas(width: number, height: number): HTMLCanvasElement {
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  return canvas;
}

function getContext(canvas: HTMLCanvasElement): CanvasRenderingContext2D {
  const context = canvas.getContext("2d");
  if (!context) throw new Error("Canvas 2D is unavailable");
  return context;
}

function organicStonePath(ctx: CanvasRenderingContext2D, wall: WallSpec, expand = 0): void {
  const segments = 30;
  ctx.beginPath();
  for (let index = 0; index <= segments; index += 1) {
    const angle = index / segments * Math.PI * 2;
    const wobble = 1 + Math.sin(angle * 5 + wall.x * 0.017) * 0.035 + Math.cos(angle * 9 + wall.y * 0.013) * 0.025;
    const radius = (wall.radius + expand) * wobble;
    const x = wall.x + Math.cos(angle) * radius;
    const y = wall.y + Math.sin(angle) * radius;
    if (index === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.closePath();
}

function traceWall(ctx: CanvasRenderingContext2D, wall: WallSpec, expand = 0): void {
  if (wall.kind === "stone") {
    organicStonePath(ctx, wall, expand);
    return;
  }
  ctx.beginPath();
  ctx.moveTo(wall.x, wall.y);
  ctx.lineTo(wall.x2, wall.y2);
  ctx.lineCap = "round";
  ctx.lineWidth = (wall.radius + expand) * 2;
}

function strokeWallRim(ctx: CanvasRenderingContext2D, wall: WallSpec, color: string, width: number): void {
  ctx.strokeStyle = color;
  if (wall.kind === "stone") {
    ctx.lineWidth = width;
    organicStonePath(ctx, wall, -2);
    ctx.stroke();
  } else {
    traceWall(ctx, wall, -3);
    ctx.strokeStyle = color;
    ctx.lineWidth = Math.max(1, width);
    ctx.stroke();
  }
}

export function renderPresetPreview(canvas: HTMLCanvasElement, preset: WorldPreset): void {
  const rect = canvas.getBoundingClientRect();
  const dpr = Math.min(2, window.devicePixelRatio || 1);
  canvas.width = Math.max(1, Math.round(rect.width * dpr));
  canvas.height = Math.max(1, Math.round(rect.height * dpr));
  const ctx = getContext(canvas);
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  const width = rect.width;
  const height = rect.height;
  ctx.fillStyle = "#03070e";
  ctx.fillRect(0, 0, width, height);
  const scale = Math.min((width - 12) / WORLD_WIDTH, (height - 12) / WORLD_HEIGHT);
  const offsetX = (width - WORLD_WIDTH * scale) / 2;
  const offsetY = (height - WORLD_HEIGHT * scale) / 2;
  ctx.translate(offsetX, offsetY);
  ctx.scale(scale, scale);
  ctx.strokeStyle = "rgba(56,189,248,.12)";
  ctx.lineWidth = 2 / scale;
  ctx.strokeRect(0, 0, WORLD_WIDTH, WORLD_HEIGHT);
  for (const wall of preset.walls) {
    ctx.fillStyle = "#111c2d";
    ctx.strokeStyle = "rgba(45,212,191,.65)";
    ctx.lineWidth = 2 / scale;
    if (wall.kind === "stone") {
      organicStonePath(ctx, wall);
      ctx.fill();
      ctx.stroke();
    } else {
      traceWall(ctx, wall);
      ctx.strokeStyle = "#142538";
      ctx.stroke();
      traceWall(ctx, wall, -wall.radius + 1 / scale);
      ctx.strokeStyle = "rgba(45,212,191,.65)";
      ctx.stroke();
    }
  }
  for (const food of preset.food) {
    ctx.fillStyle = "#00e676";
    ctx.beginPath();
    ctx.arc(food.x, food.y, Math.max(8, food.radius * 0.45), 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.strokeStyle = "#fbbf24";
  ctx.lineWidth = 3 / scale;
  ctx.beginPath();
  ctx.arc(preset.nest.x, preset.nest.y, 32, 0, Math.PI * 2);
  ctx.stroke();
}

export class SanctuaryRenderer {
  private readonly canvas: HTMLCanvasElement;
  private readonly ctx: CanvasRenderingContext2D;
  private readonly engine: AntSoAEngine;
  private readonly assets: ProceduralAssets;
  private readonly terrain: HTMLCanvasElement;
  private readonly terrainCtx: CanvasRenderingContext2D;
  private readonly pheromone: HTMLCanvasElement;
  private readonly pheromoneCtx: CanvasRenderingContext2D;
  private readonly pheromoneImage: ImageData;
  private readonly bloom: HTMLCanvasElement;
  private readonly bloomCtx: CanvasRenderingContext2D;
  private readonly noise = new SimplexNoise2D(987);
  private readonly moteX = new Float32Array(45);
  private readonly moteY = new Float32Array(45);
  private readonly moteDepth = new Float32Array(45);
  private lastWallsRevision = -1;
  private frame = 0;
  private lastTimestamp = 0;
  private readonly fpsSamples = new Float32Array(60);
  private fpsCursor = 0;
  private fpsCount = 0;
  private fps = 60;
  private lowQuality = false;
  private recoveryFrames = 0;
  private dpr = 1;
  private displayWidth = 1;
  private displayHeight = 1;

  constructor(canvas: HTMLCanvasElement, engine: AntSoAEngine) {
    this.canvas = canvas;
    this.engine = engine;
    this.ctx = getContext(canvas);
    this.assets = createProceduralAssets();
    this.terrain = makeCanvas(WORLD_WIDTH, WORLD_HEIGHT);
    this.terrainCtx = getContext(this.terrain);
    this.pheromone = makeCanvas(engine.grid.cols, engine.grid.rows);
    this.pheromoneCtx = getContext(this.pheromone);
    this.pheromoneImage = this.pheromoneCtx.createImageData(engine.grid.cols, engine.grid.rows);
    this.bloom = makeCanvas(Math.ceil(WORLD_WIDTH / 4), Math.ceil(WORLD_HEIGHT / 4));
    this.bloomCtx = getContext(this.bloom);
    const random = mulberry32(7719);
    for (let index = 0; index < 45; index += 1) {
      this.moteX[index] = random() * WORLD_WIDTH;
      this.moteY[index] = random() * WORLD_HEIGHT;
      this.moteDepth[index] = 0.25 + random() * 0.75;
    }
  }

  resize(width: number, height: number, dpr: number): void {
    this.displayWidth = Math.max(1, width);
    this.displayHeight = Math.max(1, height);
    this.dpr = Math.min(2, Math.max(1, dpr));
    const pixelWidth = Math.round(this.displayWidth * this.dpr);
    const pixelHeight = Math.round(this.displayHeight * this.dpr);
    if (this.canvas.width !== pixelWidth || this.canvas.height !== pixelHeight) {
      this.canvas.width = pixelWidth;
      this.canvas.height = pixelHeight;
    }
  }

  private rebuildTerrain(): void {
    const dirty = this.engine.wallDirty;
    const partial = dirty.minX <= dirty.maxX && dirty.minX > 0;
    const minX = partial ? Math.max(0, dirty.minX - 18) : 0;
    const minY = partial ? Math.max(0, dirty.minY - 18) : 0;
    const maxX = partial ? Math.min(WORLD_WIDTH, dirty.maxX + 18) : WORLD_WIDTH;
    const maxY = partial ? Math.min(WORLD_HEIGHT, dirty.maxY + 18) : WORLD_HEIGHT;
    const ctx = this.terrainCtx;
    ctx.save();
    ctx.beginPath();
    ctx.rect(minX, minY, maxX - minX, maxY - minY);
    ctx.clip();
    ctx.fillStyle = "#020307";
    ctx.fillRect(minX, minY, maxX - minX, maxY - minY);
    const soil = ctx.createPattern(this.assets.soilTile, "repeat");
    if (soil) {
      ctx.fillStyle = soil;
      ctx.fillRect(minX, minY, maxX - minX, maxY - minY);
    }
    ctx.strokeStyle = "rgba(56,189,248,.045)";
    ctx.lineWidth = 1;
    for (let x = 0; x <= WORLD_WIDTH; x += 120) {
      ctx.beginPath();
      ctx.moveTo(x, minY);
      ctx.lineTo(x, maxY);
      ctx.stroke();
    }
    for (let y = 0; y <= WORLD_HEIGHT; y += 120) {
      ctx.beginPath();
      ctx.moveTo(minX, y);
      ctx.lineTo(maxX, y);
      ctx.stroke();
    }
    ctx.strokeStyle = "rgba(125,211,252,.13)";
    for (let y = 60; y < WORLD_HEIGHT; y += 240) {
      for (let x = 60; x < WORLD_WIDTH; x += 240) {
        ctx.beginPath();
        ctx.moveTo(x - 5, y);
        ctx.lineTo(x + 5, y);
        ctx.moveTo(x, y - 5);
        ctx.lineTo(x, y + 5);
        ctx.stroke();
      }
    }
    const basalt = ctx.createPattern(this.assets.basaltTile, "repeat");
    for (const wall of this.engine.preset.walls) this.drawWall(ctx, wall, basalt);
    this.drawPaintedWalls(ctx, minX, minY, maxX, maxY, basalt);
    ctx.restore();
    this.engine.markWallsClean();
    this.lastWallsRevision = this.engine.wallsRevision;
  }

  private drawWall(ctx: CanvasRenderingContext2D, wall: WallSpec, basalt: CanvasPattern | null): void {
    ctx.save();
    if (wall.kind === "stone") {
      organicStonePath(ctx, wall, 9);
      ctx.fillStyle = "rgba(0,0,0,.7)";
      ctx.fill();
      organicStonePath(ctx, wall);
      ctx.fillStyle = basalt ?? "#0d1322";
      ctx.fill();
    } else {
      traceWall(ctx, wall, 9);
      ctx.strokeStyle = "rgba(0,0,0,.72)";
      ctx.stroke();
      traceWall(ctx, wall);
      ctx.strokeStyle = basalt ?? "#0d1322";
      ctx.stroke();
    }
    strokeWallRim(ctx, wall, "rgba(45,212,191,.22)", 5);
    strokeWallRim(ctx, wall, "rgba(56,189,248,.68)", 1.1);
    ctx.restore();
  }

  private drawPaintedWalls(ctx: CanvasRenderingContext2D, minX: number, minY: number, maxX: number, maxY: number, basalt: CanvasPattern | null): void {
    const grid = this.engine.grid;
    const cell = grid.cellSize;
    const startColumn = clamp(Math.floor(minX / cell), 0, grid.cols - 1);
    const endColumn = clamp(Math.ceil(maxX / cell), 0, grid.cols - 1);
    const startRow = clamp(Math.floor(minY / cell), 0, grid.rows - 1);
    const endRow = clamp(Math.ceil(maxY / cell), 0, grid.rows - 1);
    for (let row = startRow; row <= endRow; row += 1) {
      for (let column = startColumn; column <= endColumn; column += 1) {
        const index = grid.index(column, row);
        if (!this.engine.walls[index]) continue;
        const x = column * cell;
        const y = row * cell;
        let belongsToPreset = false;
        for (const wall of this.engine.preset.walls) {
          const segmentX = wall.x2 - wall.x;
          const segmentY = wall.y2 - wall.y;
          const length = Math.max(1, segmentX * segmentX + segmentY * segmentY);
          const t = clamp(((x - wall.x) * segmentX + (y - wall.y) * segmentY) / length, 0, 1);
          if (Math.hypot(x - wall.x - segmentX * t, y - wall.y - segmentY * t) < wall.radius + cell) {
            belongsToPreset = true;
            break;
          }
        }
        if (belongsToPreset) continue;
        ctx.fillStyle = basalt ?? "#0d1322";
        ctx.beginPath();
        const wobble = this.noise.noise(x * 0.04, y * 0.04) * 1.5;
        ctx.arc(x + cell / 2, y + cell / 2, cell * 0.72 + wobble, 0, Math.PI * 2);
        ctx.fill();
        if (!this.engine.walls[index - 1] || column === 0 || !this.engine.walls[index - grid.cols] || row === 0) {
          ctx.strokeStyle = "rgba(45,212,191,.48)";
          ctx.lineWidth = 0.8;
          ctx.stroke();
        }
      }
    }
  }

  private drawPheromones(): void {
    this.engine.grid.writeImageData(this.pheromoneImage.data, this.engine.pheromones.gamma);
    this.pheromoneCtx.putImageData(this.pheromoneImage, 0, 0);
    const ctx = this.ctx;
    ctx.save();
    ctx.globalCompositeOperation = "screen";
    ctx.imageSmoothingEnabled = true;
    ctx.globalAlpha = 0.82;
    ctx.drawImage(this.pheromone, 0, 0, WORLD_WIDTH, WORLD_HEIGHT);
    ctx.restore();
  }

  private updateBloom(time: number): void {
    if (this.lowQuality || this.frame % 2 !== 0) return;
    const ctx = this.bloomCtx;
    const width = this.bloom.width;
    const height = this.bloom.height;
    ctx.globalCompositeOperation = "source-over";
    ctx.fillStyle = "#000000";
    ctx.fillRect(0, 0, width, height);
    ctx.globalCompositeOperation = "lighter";
    ctx.globalAlpha = 0.55;
    ctx.drawImage(this.pheromone, 0, 0, width, height);
    for (const food of this.engine.foods) {
      if (!food.active) continue;
      const gradient = ctx.createRadialGradient(food.x / 4, food.y / 4, 0, food.x / 4, food.y / 4, 10);
      gradient.addColorStop(0, "rgba(0,230,118,.55)");
      gradient.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = gradient;
      ctx.fillRect(food.x / 4 - 10, food.y / 4 - 10, 20, 20);
    }
    const nestPulse = 10 + Math.sin(time * 0.002) * 2;
    ctx.fillStyle = "rgba(255,190,70,.32)";
    ctx.beginPath();
    ctx.arc(this.engine.nest.x / 4, this.engine.nest.y / 4, nestPulse, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = 1;
  }

  private drawBloom(): void {
    if (this.lowQuality) return;
    const ctx = this.ctx;
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    ctx.imageSmoothingEnabled = true;
    ctx.globalAlpha = 0.17;
    ctx.drawImage(this.bloom, -3, 0, WORLD_WIDTH + 6, WORLD_HEIGHT);
    ctx.globalAlpha = 0.12;
    ctx.drawImage(this.bloom, 2, -2, WORLD_WIDTH - 4, WORLD_HEIGHT + 4);
    ctx.globalAlpha = 0.2;
    ctx.drawImage(this.bloom, 0, 0, WORLD_WIDTH, WORLD_HEIGHT);
    ctx.restore();
  }

  private drawFoodAndCorpses(time: number): void {
    const ctx = this.ctx;
    for (const corpse of this.engine.corpses) {
      if (!corpse.active) continue;
      ctx.save();
      ctx.translate(corpse.x, corpse.y);
      ctx.rotate(corpse.caste * 0.9 + corpse.age * 0.02);
      ctx.globalAlpha = clamp(1 - Math.max(0, corpse.age - 180) / 60, 0.2, 0.75);
      ctx.drawImage(this.assets.corpse, -10, -10, 20, 20);
      ctx.restore();
    }
    for (const food of this.engine.foods) {
      if (!food.active) continue;
      const fraction = clamp(food.amount / food.maxAmount, 0, 1);
      const scale = 0.32 + Math.sqrt(fraction) * 0.68;
      const size = food.radius * 2.5 * scale;
      const bob = Math.sin(time * 0.0015 + food.variant) * 1.5;
      ctx.save();
      ctx.translate(food.x, food.y + bob);
      ctx.globalAlpha = 0.28;
      ctx.fillStyle = "#00e676";
      ctx.beginPath();
      ctx.ellipse(0, food.radius * 0.5, size * 0.42, size * 0.15, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalAlpha = 1;
      ctx.drawImage(this.assets.crystals[food.variant], -size / 2, -size * 0.65, size, size * 1.12);
      if (fraction < 0.25) {
        ctx.fillStyle = "#d1fae5";
        ctx.font = "9px var(--font-jakarta), monospace";
        ctx.textAlign = "center";
        ctx.fillText("DEPLETED", 0, size * 0.62);
      }
      ctx.restore();
    }
  }

  private drawNest(time: number): void {
    const ctx = this.ctx;
    const { x, y } = this.engine.nest;
    const generation = this.engine.generation;
    ctx.save();
    ctx.translate(x, y);
    const crater = ctx.createRadialGradient(0, 0, 4, 0, 0, 62);
    crater.addColorStop(0, "#010204");
    crater.addColorStop(0.5, "#09101b");
    crater.addColorStop(0.78, "rgba(39,29,23,.85)");
    crater.addColorStop(1, "rgba(2,3,7,0)");
    ctx.fillStyle = crater;
    ctx.beginPath();
    ctx.arc(0, 0, 64, 0, Math.PI * 2);
    ctx.fill();
    ctx.rotate(time * 0.00008);
    for (let ring = 0; ring < 4; ring += 1) {
      ctx.strokeStyle = ring % 2 ? "rgba(45,212,191,.26)" : "rgba(251,191,36,.34)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      const radius = 27 + ring * 8;
      for (let segment = 0; segment <= 72; segment += 1) {
        const angle = segment / 72 * Math.PI * 2;
        const harmonic = Math.sin(angle * (6 + ring * 2) + time * 0.0007) * 2.2;
        const px = Math.cos(angle) * (radius + harmonic);
        const py = Math.sin(angle) * (radius + harmonic);
        if (segment === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.stroke();
    }
    ctx.rotate(-time * 0.00008);
    const stored = this.engine.storedFood / 3;
    ctx.strokeStyle = "#fbbf24";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(0, 0, 54, -Math.PI / 2, -Math.PI / 2 + stored * Math.PI * 2);
    ctx.stroke();
    for (let pod = 0; pod < 8; pod += 1) {
      const angle = pod / 8 * Math.PI * 2 + time * 0.00005;
      ctx.fillStyle = pod < this.engine.storedFood * 2 ? "#a7f3d0" : "#334155";
      ctx.beginPath();
      ctx.ellipse(Math.cos(angle) * 19, Math.sin(angle) * 19, 2.2, 4.2, angle, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.fillStyle = "rgba(167,243,208,.78)";
    ctx.font = "600 10px var(--font-jakarta), monospace";
    ctx.textAlign = "center";
    ctx.fillText(`GEN ${generation}`, 0, 78);
    ctx.restore();
    ctx.save();
    ctx.translate(this.engine.graveyard.x, this.engine.graveyard.y);
    ctx.strokeStyle = "rgba(148,113,143,.25)";
    ctx.setLineDash([3, 6]);
    ctx.beginPath();
    ctx.arc(0, 0, 35, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }

  private drawAntsAndPredators(): void {
    const ctx = this.ctx;
    const ants = this.engine.ants;
    for (let index = 0; index < ants.active.length; index += 1) {
      if (!ants.active[index]) continue;
      const palette = ants.caste[index] === 2 ? 1 : 0;
      const visualCaste = this.engine.comparison !== "trained" && ants.cohort[index] !== Cohort.TRAINED_NEAT ? 3 : ants.caste[index];
      const frame = Math.floor(ants.legPhase[index]) & 7;
      const sprite = this.assets.antSprites[palette][visualCaste][frame];
      const size = ants.caste[index] === 1 ? 19 : ants.caste[index] === 2 ? 20 : 17;
      ctx.save();
      ctx.translate(ants.x[index], ants.y[index]);
      ctx.rotate(ants.angle[index] + Math.PI / 2);
      if (ants.state[index] === AntState.ALARMED) ctx.globalAlpha = 0.72 + Math.sin(this.frame * 0.8 + index) * 0.25;
      ctx.drawImage(sprite, -size / 2, -size / 2, size, size);
      if (ants.carryingFood[index] === 1) {
        ctx.fillStyle = "#00e676";
        ctx.strokeStyle = "#a7f3d0";
        ctx.lineWidth = 0.6;
        ctx.beginPath();
        ctx.moveTo(0, -15);
        ctx.lineTo(3.5, -11);
        ctx.lineTo(0, -8);
        ctx.lineTo(-3.5, -11);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
      }
      if (this.engine.comparison !== "trained") {
        ctx.strokeStyle = ants.cohort[index] === Cohort.TRAINED_NEAT ? "rgba(255,209,102,.8)" : ants.cohort[index] === Cohort.BASELINE_ACO ? "rgba(56,189,248,.65)" : "rgba(148,163,184,.45)";
        ctx.lineWidth = 0.65;
        ctx.beginPath();
        ctx.arc(0, 0, 9, 0, Math.PI * 2);
        ctx.stroke();
      }
      ctx.restore();
    }
    for (const predator of this.engine.predators) {
      if (!predator.active) continue;
      ctx.save();
      ctx.translate(predator.x, predator.y);
      ctx.rotate(predator.angle + Math.PI / 2);
      ctx.drawImage(this.assets.predator, -30, -30, 60, 60);
      ctx.rotate(-predator.angle - Math.PI / 2);
      ctx.strokeStyle = "rgba(255,12,75,.25)";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(0, 0, 34, 0, Math.PI * 2);
      ctx.stroke();
      ctx.strokeStyle = "#ff0c4b";
      ctx.beginPath();
      ctx.arc(0, 0, 34, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * clamp(predator.hp / predator.maxHp, 0, 1));
      ctx.stroke();
      ctx.restore();
    }
  }

  private drawArcs(): void {
    const ctx = this.ctx;
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    for (const arc of this.engine.arcs) {
      if (!arc.active) continue;
      const frame = clamp(Math.floor(arc.ttl / 0.04), 0, 2);
      const colors = arc.kind === 0 ? ["#fbbf24", "#00e676"] : arc.kind === 1 ? ["#af32ff", "#00e1ff"] : ["#ff0c4b", "#ffd166"];
      const mx = (arc.x1 + arc.x2) * 0.5 + (frame - 1) * 4;
      const my = (arc.y1 + arc.y2) * 0.5 - 5 + frame * 3;
      ctx.globalAlpha = clamp(arc.ttl / 0.12, 0, 1);
      for (let strand = 0; strand < 2; strand += 1) {
        ctx.strokeStyle = colors[strand];
        ctx.lineWidth = strand === 0 ? 1.4 : 0.65;
        ctx.beginPath();
        ctx.moveTo(arc.x1, arc.y1);
        ctx.quadraticCurveTo(mx + strand * 2, my - strand * 3, arc.x2, arc.y2);
        ctx.stroke();
      }
    }
    ctx.restore();
  }

  private drawMotes(time: number): void {
    const ctx = this.ctx;
    ctx.save();
    ctx.globalCompositeOperation = "screen";
    const count = this.lowQuality ? 24 : 45;
    for (let index = 0; index < count; index += 1) {
      const depth = this.moteDepth[index];
      const x = (this.moteX[index] + time * 0.002 * depth + Math.sin(time * 0.0004 + index) * 12) % WORLD_WIDTH;
      const y = (this.moteY[index] - time * 0.003 * depth + WORLD_HEIGHT * 10) % WORLD_HEIGHT;
      ctx.globalAlpha = 0.08 + depth * 0.15;
      ctx.fillStyle = index % 5 === 0 ? "#7dd3fc" : "#a7f3d0";
      ctx.beginPath();
      ctx.arc(x, y, 0.5 + depth * 1.2, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }

  private drawBrush(brush: BrushVisual, time: number): void {
    if (!brush.active) return;
    const ctx = this.ctx;
    ctx.save();
    ctx.translate(brush.x, brush.y);
    if (brush.erasing) {
      ctx.rotate(time * 0.002);
      ctx.strokeStyle = "rgba(226,232,240,.85)";
      ctx.lineWidth = 1.4;
      ctx.setLineDash([5, 7]);
      ctx.beginPath();
      ctx.arc(0, 0, brush.radius, 0, Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.beginPath();
      ctx.moveTo(-brush.radius - 6, 0);
      ctx.lineTo(brush.radius + 6, 0);
      ctx.moveTo(0, -brush.radius - 6);
      ctx.lineTo(0, brush.radius + 6);
      ctx.stroke();
    } else {
      ctx.strokeStyle = brush.color;
      ctx.globalAlpha = 0.26;
      ctx.lineWidth = 6;
      ctx.beginPath();
      ctx.arc(0, 0, brush.radius, 0, Math.PI * 2);
      ctx.stroke();
      ctx.globalAlpha = 0.95;
      ctx.strokeStyle = "#f8fafc";
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.arc(0, 0, brush.radius, 0, Math.PI * 2);
      ctx.stroke();
      const age = Math.max(0, time - brush.startedAt);
      if (age < 500) {
        ctx.globalAlpha = 1 - age / 500;
        ctx.strokeStyle = brush.color;
        ctx.beginPath();
        ctx.arc(0, 0, brush.radius + age * 0.09, 0, Math.PI * 2);
        ctx.stroke();
      }
      ctx.globalAlpha = 0.2;
      ctx.strokeStyle = brush.color;
      ctx.lineWidth = 7;
      ctx.beginPath();
      ctx.moveTo(brush.previousX - brush.x, brush.previousY - brush.y);
      ctx.lineTo(0, 0);
      ctx.stroke();
      ctx.globalAlpha = 0.9;
      ctx.strokeStyle = "#ffffff";
      ctx.lineWidth = 1.2;
      ctx.stroke();
    }
    ctx.restore();
  }

  private drawOverlay(): void {
    const ctx = this.ctx;
    ctx.save();
    ctx.globalCompositeOperation = "source-over";
    ctx.drawImage(this.assets.vignette, 0, 0);
    const grain = ctx.createPattern(this.assets.grainTile, "repeat");
    if (grain) {
      ctx.globalAlpha = 0.19;
      ctx.globalCompositeOperation = "screen";
      ctx.fillStyle = grain;
      ctx.fillRect(0, 0, WORLD_WIDTH, WORLD_HEIGHT);
    }
    ctx.restore();
  }

  private sampleFps(timestamp: number): void {
    if (this.lastTimestamp > 0) {
      const delta = Math.min(250, timestamp - this.lastTimestamp);
      if (delta > 0) {
        this.fpsSamples[this.fpsCursor] = 1000 / delta;
        this.fpsCursor = (this.fpsCursor + 1) % 60;
        this.fpsCount = Math.min(60, this.fpsCount + 1);
        if (this.fpsCount === 60 && this.fpsCursor === 0) {
          let total = 0;
          for (let index = 0; index < 60; index += 1) total += this.fpsSamples[index];
          this.fps = total / 60;
          if (this.fps < 50) {
            this.lowQuality = true;
            this.recoveryFrames = 0;
          } else if (this.fps > 56 && this.lowQuality) {
            this.recoveryFrames += 1;
            if (this.recoveryFrames > 3) this.lowQuality = false;
          }
          this.engine.setAdaptiveQuality(this.lowQuality);
        }
      }
    }
    this.lastTimestamp = timestamp;
  }

  render(timestamp: number, brush: BrushVisual): number {
    this.sampleFps(timestamp);
    this.frame += 1;
    if (this.lastWallsRevision !== this.engine.wallsRevision) this.rebuildTerrain();
    const ctx = this.ctx;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.fillStyle = "#020307";
    ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
    const scale = Math.min(this.displayWidth / WORLD_WIDTH, this.displayHeight / WORLD_HEIGHT);
    const offsetX = (this.displayWidth - WORLD_WIDTH * scale) / 2;
    const offsetY = (this.displayHeight - WORLD_HEIGHT * scale) / 2;
    ctx.setTransform(this.dpr * scale, 0, 0, this.dpr * scale, this.dpr * offsetX, this.dpr * offsetY);
    ctx.save();
    ctx.beginPath();
    ctx.rect(0, 0, WORLD_WIDTH, WORLD_HEIGHT);
    ctx.clip();
    ctx.drawImage(this.terrain, 0, 0);
    this.drawPheromones();
    this.updateBloom(timestamp);
    this.drawBloom();
    this.drawFoodAndCorpses(timestamp);
    this.drawNest(timestamp);
    this.drawAntsAndPredators();
    this.drawArcs();
    this.drawMotes(timestamp);
    this.drawBrush(brush, timestamp);
    this.drawOverlay();
    ctx.restore();
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    return this.fps;
  }

  clientToWorld(clientX: number, clientY: number, output: { x: number; y: number }): boolean {
    const rect = this.canvas.getBoundingClientRect();
    const scale = Math.min(rect.width / WORLD_WIDTH, rect.height / WORLD_HEIGHT);
    const offsetX = (rect.width - WORLD_WIDTH * scale) / 2;
    const offsetY = (rect.height - WORLD_HEIGHT * scale) / 2;
    output.x = (clientX - rect.left - offsetX) / scale;
    output.y = (clientY - rect.top - offsetY) / scale;
    return output.x >= 0 && output.y >= 0 && output.x <= WORLD_WIDTH && output.y <= WORLD_HEIGHT;
  }
}
