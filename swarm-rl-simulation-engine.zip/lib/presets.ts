import type { WorldPreset } from "./types";

export const PRESETS: readonly WorldPreset[] = [
  {
    id: "sanctuary",
    name: "Open Sanctuary",
    subtitle: "Unconstrained emergence",
    description: "A broad obsidian basin with scattered basalt islands. Long-range scouting and highway formation dominate.",
    nest: { x: 360, y: 1020 },
    graveyard: { x: 640, y: 1160 },
    initialPopulation: 520,
    walls: [
      { x: 118, y: 830, x2: 118, y2: 830, radius: 64, kind: "stone" },
      { x: 580, y: 760, x2: 580, y2: 760, radius: 82, kind: "stone" },
      { x: 218, y: 475, x2: 250, y2: 430, radius: 52, kind: "capsule" },
      { x: 505, y: 335, x2: 505, y2: 335, radius: 45, kind: "stone" },
      { x: 94, y: 198, x2: 140, y2: 182, radius: 35, kind: "capsule" },
    ],
    food: [
      { x: 360, y: 865, amount: 220, radius: 22 },
      { x: 352, y: 770, amount: 150, radius: 23 },
      { x: 108, y: 602, amount: 180, radius: 26 },
      { x: 614, y: 520, amount: 180, radius: 26 },
      { x: 340, y: 238, amount: 240, radius: 30 },
      { x: 92, y: 105, amount: 130, radius: 22 },
      { x: 630, y: 150, amount: 130, radius: 22 },
    ],
  },
  {
    id: "double-bridge",
    name: "Deneubourg's Double Bridge",
    subtitle: "Asymmetric path selection",
    description: "Two unequal routes connect nest and crystal. Amplification should select the shorter northern bridge without central control.",
    nest: { x: 88, y: 650 },
    graveyard: { x: 88, y: 790 },
    initialPopulation: 560,
    walls: [
      { x: 358, y: 650, x2: 358, y2: 650, radius: 150, kind: "stone" },
      { x: 354, y: 650, x2: 354, y2: 650, radius: 92, kind: "stone" },
      { x: 350, y: 1070, x2: 350, y2: 1070, radius: 110, kind: "stone" },
      { x: 350, y: 220, x2: 350, y2: 220, radius: 86, kind: "stone" },
    ],
    food: [
      { x: 634, y: 650, amount: 420, radius: 32 },
      { x: 615, y: 1040, amount: 140, radius: 23 },
      { x: 606, y: 120, amount: 140, radius: 23 },
    ],
  },
  {
    id: "labyrinth",
    name: "Subterranean Labyrinth",
    subtitle: "Memory under occlusion",
    description: "Terraced basalt corridors punish loops and obsolete trails. Vector memory, sealing, and tandem recruitment become decisive.",
    nest: { x: 360, y: 1135 },
    graveyard: { x: 642, y: 1170 },
    initialPopulation: 600,
    walls: [
      { x: 55, y: 955, x2: 500, y2: 955, radius: 25, kind: "capsule" },
      { x: 220, y: 790, x2: 665, y2: 790, radius: 27, kind: "capsule" },
      { x: 55, y: 620, x2: 500, y2: 620, radius: 27, kind: "capsule" },
      { x: 220, y: 450, x2: 665, y2: 450, radius: 27, kind: "capsule" },
      { x: 55, y: 280, x2: 500, y2: 280, radius: 27, kind: "capsule" },
      { x: 172, y: 875, x2: 172, y2: 790, radius: 22, kind: "capsule" },
      { x: 548, y: 705, x2: 548, y2: 620, radius: 22, kind: "capsule" },
      { x: 172, y: 535, x2: 172, y2: 450, radius: 22, kind: "capsule" },
      { x: 548, y: 365, x2: 548, y2: 280, radius: 22, kind: "capsule" },
      { x: 425, y: 1135, x2: 425, y2: 1035, radius: 18, kind: "capsule" },
    ],
    food: [
      { x: 585, y: 875, amount: 170, radius: 25 },
      { x: 110, y: 705, amount: 180, radius: 25 },
      { x: 590, y: 535, amount: 200, radius: 27 },
      { x: 105, y: 365, amount: 220, radius: 28 },
      { x: 585, y: 130, amount: 300, radius: 32 },
    ],
  },
];

export function getPreset(id: string): WorldPreset {
  return PRESETS.find((preset) => preset.id === id) ?? PRESETS[0];
}
