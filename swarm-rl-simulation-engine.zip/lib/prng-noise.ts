export function mulberry32(seed: number): () => number {
  let value = seed >>> 0;
  return () => {
    value = (value + 0x6d2b79f5) >>> 0;
    let t = value;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export class XorShift32 {
  private state: number;

  constructor(seed: number) {
    this.state = (seed | 0) || 0x6d2b79f5;
  }

  nextUint(): number {
    let x = this.state;
    x ^= x << 13;
    x ^= x >>> 17;
    x ^= x << 5;
    this.state = x | 0;
    return x >>> 0;
  }

  next(): number {
    return this.nextUint() / 4294967296;
  }

  range(min: number, max: number): number {
    return min + (max - min) * this.next();
  }

  signed(): number {
    return this.next() * 2 - 1;
  }

  int(maxExclusive: number): number {
    return Math.floor(this.next() * maxExclusive);
  }
}

const GRAD_X = new Int8Array([1, -1, 1, -1, 1, -1, 1, -1, 0, 0, 0, 0]);
const GRAD_Y = new Int8Array([1, 1, -1, -1, 0, 0, 0, 0, 1, -1, 1, -1]);
const F2 = 0.5 * (Math.sqrt(3) - 1);
const G2 = (3 - Math.sqrt(3)) / 6;

export class SimplexNoise2D {
  private readonly permutation = new Uint8Array(512);

  constructor(seed = 1337) {
    const random = mulberry32(seed);
    const source = new Uint8Array(256);
    for (let i = 0; i < 256; i += 1) source[i] = i;
    for (let i = 255; i > 0; i -= 1) {
      const j = Math.floor(random() * (i + 1));
      const value = source[i];
      source[i] = source[j];
      source[j] = value;
    }
    for (let i = 0; i < 512; i += 1) this.permutation[i] = source[i & 255];
  }

  noise(x: number, y: number): number {
    const skew = (x + y) * F2;
    const i = Math.floor(x + skew);
    const j = Math.floor(y + skew);
    const unskew = (i + j) * G2;
    const x0 = x - (i - unskew);
    const y0 = y - (j - unskew);
    const i1 = x0 > y0 ? 1 : 0;
    const j1 = x0 > y0 ? 0 : 1;
    const x1 = x0 - i1 + G2;
    const y1 = y0 - j1 + G2;
    const x2 = x0 - 1 + 2 * G2;
    const y2 = y0 - 1 + 2 * G2;
    const ii = i & 255;
    const jj = j & 255;
    const p = this.permutation;
    const gi0 = p[ii + p[jj]] % 12;
    const gi1 = p[ii + i1 + p[jj + j1]] % 12;
    const gi2 = p[ii + 1 + p[jj + 1]] % 12;
    let n0 = 0;
    let n1 = 0;
    let n2 = 0;
    let t = 0.5 - x0 * x0 - y0 * y0;
    if (t > 0) {
      t *= t;
      n0 = t * t * (GRAD_X[gi0] * x0 + GRAD_Y[gi0] * y0);
    }
    t = 0.5 - x1 * x1 - y1 * y1;
    if (t > 0) {
      t *= t;
      n1 = t * t * (GRAD_X[gi1] * x1 + GRAD_Y[gi1] * y1);
    }
    t = 0.5 - x2 * x2 - y2 * y2;
    if (t > 0) {
      t *= t;
      n2 = t * t * (GRAD_X[gi2] * x2 + GRAD_Y[gi2] * y2);
    }
    return 70 * (n0 + n1 + n2);
  }

  fbm(x: number, y: number, octaves = 4): number {
    let value = 0;
    let amplitude = 0.5;
    let frequency = 1;
    let normalizer = 0;
    for (let octave = 0; octave < octaves; octave += 1) {
      value += this.noise(x * frequency, y * frequency) * amplitude;
      normalizer += amplitude;
      amplitude *= 0.5;
      frequency *= 2.03;
    }
    return value / normalizer;
  }
}

export function clamp(value: number, min: number, max: number): number {
  return value < min ? min : value > max ? max : value;
}

export function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}
