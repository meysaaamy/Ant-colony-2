import { clamp } from "./prng-noise";
import {
  PHEROMONE_NAMES,
  Pheromone,
  type AblationMask,
  type PheromoneChannel,
  type PheromoneName,
  type PheromoneSettings,
} from "./types";

export const CHANNEL_RGB: readonly (readonly [number, number, number])[] = [
  [255, 168, 0],
  [0, 225, 255],
  [255, 12, 75],
  [175, 50, 255],
  [80, 255, 100],
];

export const DEFAULT_ABLATION: AblationMask = {
  foodTrail: true,
  homeGuide: true,
  alarm: true,
  scoutPulse: true,
  noEntry: true,
  pathIntegration: true,
};

export const DEFAULT_PHEROMONE_SETTINGS: PheromoneSettings = {
  evaporation: 0.055,
  diffusion: 0.115,
  crossReaction: 1,
  gamma: 1.65,
};

export class PheromoneGrid {
  readonly cols: number;
  readonly rows: number;
  readonly cellSize: number;
  readonly length: number;
  readonly channels: Float32Array[] = [];
  private next: Float32Array[] = [];
  private walls: Uint8Array;
  private readonly mixConcentrations = new Float32Array(5);
  private readonly boundsMinX = new Int32Array(5);
  private readonly boundsMinY = new Int32Array(5);
  private readonly boundsMaxX = new Int32Array(5);
  private readonly boundsMaxY = new Int32Array(5);
  readonly ablation: AblationMask = { ...DEFAULT_ABLATION };

  constructor(worldWidth: number, worldHeight: number, cellSize = 6) {
    this.cellSize = cellSize;
    this.cols = Math.ceil(worldWidth / cellSize);
    this.rows = Math.ceil(worldHeight / cellSize);
    this.length = this.cols * this.rows;
    this.walls = new Uint8Array(this.length);
    for (let channel = 0; channel < 5; channel += 1) {
      this.channels.push(new Float32Array(this.length));
      this.next.push(new Float32Array(this.length));
    }
    this.resetActivityBounds();
  }

  private resetActivityBounds(): void {
    for (let channel = 0; channel < 5; channel += 1) {
      this.boundsMinX[channel] = this.cols;
      this.boundsMinY[channel] = this.rows;
      this.boundsMaxX[channel] = -1;
      this.boundsMaxY[channel] = -1;
    }
  }

  private expandActivity(channel: number, minX: number, minY: number, maxX: number, maxY: number): void {
    this.boundsMinX[channel] = Math.min(this.boundsMinX[channel], minX);
    this.boundsMinY[channel] = Math.min(this.boundsMinY[channel], minY);
    this.boundsMaxX[channel] = Math.max(this.boundsMaxX[channel], maxX);
    this.boundsMaxY[channel] = Math.max(this.boundsMaxY[channel], maxY);
  }

  setCell(column: number, row: number, channel: PheromoneChannel, value: number): void {
    if (column < 0 || row < 0 || column >= this.cols || row >= this.rows) return;
    this.channels[channel][this.index(column, row)] = clamp(value, 0, 100);
    this.expandActivity(channel, column, row, column, row);
  }

  setWalls(walls: Uint8Array): void {
    if (walls.length !== this.length) throw new Error("Wall grid dimensions do not match pheromone grid");
    this.walls = walls;
  }

  setAblation(name: PheromoneName | "pathIntegration", enabled: boolean): void {
    this.ablation[name] = enabled;
  }

  index(column: number, row: number): number {
    return row * this.cols + column;
  }

  rawAt(column: number, row: number, channel: PheromoneChannel): number {
    if (column < 0 || row < 0 || column >= this.cols || row >= this.rows) return 0;
    return this.channels[channel][this.index(column, row)];
  }

  sample(x: number, y: number, channel: PheromoneChannel, respectAblation = true): number {
    if (respectAblation && !this.ablation[PHEROMONE_NAMES[channel]]) return 0;
    const gx = clamp(x / this.cellSize - 0.5, 0, this.cols - 1.001);
    const gy = clamp(y / this.cellSize - 0.5, 0, this.rows - 1.001);
    const x0 = Math.floor(gx);
    const y0 = Math.floor(gy);
    const x1 = Math.min(this.cols - 1, x0 + 1);
    const y1 = Math.min(this.rows - 1, y0 + 1);
    const tx = gx - x0;
    const ty = gy - y0;
    const field = this.channels[channel];
    const a = field[this.index(x0, y0)];
    const b = field[this.index(x1, y0)];
    const c = field[this.index(x0, y1)];
    const d = field[this.index(x1, y1)];
    return (a + (b - a) * tx) + ((c + (d - c) * tx) - (a + (b - a) * tx)) * ty;
  }

  deposit(x: number, y: number, channel: PheromoneChannel, amount: number, radius = 4): void {
    const gx = x / this.cellSize - 0.5;
    const gy = y / this.cellSize - 0.5;
    const gridRadius = Math.max(0.75, radius / this.cellSize);
    const minX = Math.max(0, Math.floor(gx - gridRadius));
    const maxX = Math.min(this.cols - 1, Math.ceil(gx + gridRadius));
    const minY = Math.max(0, Math.floor(gy - gridRadius));
    const maxY = Math.min(this.rows - 1, Math.ceil(gy + gridRadius));
    this.expandActivity(channel, minX, minY, maxX, maxY);
    const field = this.channels[channel];
    const invRadius = 1 / Math.max(0.001, gridRadius * gridRadius);
    for (let row = minY; row <= maxY; row += 1) {
      for (let column = minX; column <= maxX; column += 1) {
        const index = this.index(column, row);
        if (this.walls[index]) continue;
        const dx = column - gx;
        const dy = row - gy;
        const falloff = Math.max(0, 1 - (dx * dx + dy * dy) * invRadius);
        if (falloff <= 0) continue;
        field[index] = Math.min(100, field[index] + amount * falloff * falloff);
      }
    }
  }

  depositLine(x0: number, y0: number, x1: number, y1: number, channel: PheromoneChannel, amount: number, radius: number): void {
    const distance = Math.hypot(x1 - x0, y1 - y0);
    const spacing = Math.max(1, radius * 0.25);
    const steps = Math.max(1, Math.ceil(distance / spacing));
    for (let step = 0; step <= steps; step += 1) {
      const t = step / steps;
      this.deposit(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t, channel, amount / Math.sqrt(steps), radius);
    }
  }

  strokeCatmullRom(
    x0: number, y0: number,
    x1: number, y1: number,
    x2: number, y2: number,
    x3: number, y3: number,
    channel: PheromoneChannel,
    amount: number,
    radius: number,
  ): void {
    const approximateLength = Math.hypot(x2 - x1, y2 - y1) + Math.hypot(x3 - x0, y3 - y0) * 0.25;
    const steps = Math.max(2, Math.ceil(approximateLength / Math.max(1, radius * 0.25)));
    let previousX = x1;
    let previousY = y1;
    for (let step = 1; step <= steps; step += 1) {
      const t = step / steps;
      const t2 = t * t;
      const t3 = t2 * t;
      const x = 0.5 * ((2 * x1) + (-x0 + x2) * t + (2 * x0 - 5 * x1 + 4 * x2 - x3) * t2 + (-x0 + 3 * x1 - 3 * x2 + x3) * t3);
      const y = 0.5 * ((2 * y1) + (-y0 + y2) * t + (2 * y0 - 5 * y1 + 4 * y2 - y3) * t2 + (-y0 + 3 * y1 - 3 * y2 + y3) * t3);
      this.depositLine(previousX, previousY, x, y, channel, amount / steps, radius);
      previousX = x;
      previousY = y;
    }
  }

  erase(x: number, y: number, radius: number): void {
    const minX = Math.max(0, Math.floor((x - radius) / this.cellSize));
    const maxX = Math.min(this.cols - 1, Math.ceil((x + radius) / this.cellSize));
    const minY = Math.max(0, Math.floor((y - radius) / this.cellSize));
    const maxY = Math.min(this.rows - 1, Math.ceil((y + radius) / this.cellSize));
    const radiusSquared = radius * radius;
    for (let row = minY; row <= maxY; row += 1) {
      for (let column = minX; column <= maxX; column += 1) {
        const dx = (column + 0.5) * this.cellSize - x;
        const dy = (row + 0.5) * this.cellSize - y;
        if (dx * dx + dy * dy > radiusSquared) continue;
        const index = this.index(column, row);
        for (let channel = 0; channel < 5; channel += 1) this.channels[channel][index] = 0;
      }
    }
  }

  step(dt: number, settings: PheromoneSettings): void {
    const diffusion = clamp(settings.diffusion, 0, 0.18);
    const evaporation = settings.evaporation;
    const reaction = settings.crossReaction;
    for (let channel = 0; channel < 5; channel += 1) {
      if (this.boundsMaxX[channel] < 0) continue;
      const minX = Math.max(0, this.boundsMinX[channel] - 1);
      const minY = Math.max(0, this.boundsMinY[channel] - 1);
      const maxX = Math.min(this.cols - 1, this.boundsMaxX[channel] + 1);
      const maxY = Math.min(this.rows - 1, this.boundsMaxY[channel] + 1);
      const field = this.channels[channel];
      const target = this.next[channel];
      for (let row = minY; row <= maxY; row += 1) {
        for (let column = minX; column <= maxX; column += 1) {
          const index = row * this.cols + column;
          if (this.walls[index]) {
            target[index] = 0;
            continue;
          }
          const left = column > 0 && !this.walls[index - 1] ? index - 1 : index;
          const right = column < this.cols - 1 && !this.walls[index + 1] ? index + 1 : index;
          const up = row > 0 && !this.walls[index - this.cols] ? index - this.cols : index;
          const down = row < this.rows - 1 && !this.walls[index + this.cols] ? index + this.cols : index;
          const center = field[index];
          const laplacian = field[left] + field[right] + field[up] + field[down] - 4 * center;
          let polymer = 1;
          if (channel === Pheromone.foodTrail || channel === Pheromone.homeGuide) {
            polymer = Math.min(this.channels[Pheromone.foodTrail][index], this.channels[Pheromone.homeGuide][index]) > 3 ? 0.65 : 1;
          }
          const decayRate = evaporation * (channel === Pheromone.alarm ? 3.2 : 1) * polymer;
          let value = center + diffusion * laplacian - center * decayRate * dt;
          if (channel === Pheromone.foodTrail) value -= 0.45 * this.channels[Pheromone.noEntry][index] * reaction * dt;
          target[index] = value < 0 ? 0 : value > 100 ? 100 : value;
        }
      }
      this.boundsMinX[channel] = minX;
      this.boundsMinY[channel] = minY;
      this.boundsMaxX[channel] = maxX;
      this.boundsMaxY[channel] = maxY;
    }
    for (let channel = 0; channel < 5; channel += 1) {
      const swap = this.channels[channel];
      this.channels[channel] = this.next[channel];
      this.next[channel] = swap;
    }
  }

  mixCell(index: number, output: Uint8ClampedArray, offset: number, gamma = DEFAULT_PHEROMONE_SETTINGS.gamma): void {
    const food = this.channels[0][index] / 100;
    const home = this.channels[1][index] / 100;
    const alarm = this.channels[2][index] / 100;
    const scout = this.channels[3][index] / 100;
    const noEntry = this.channels[4][index] / 100;
    const concentrations = this.mixConcentrations;
    concentrations[0] = food;
    concentrations[1] = home;
    concentrations[2] = alarm;
    concentrations[3] = scout;
    concentrations[4] = noEntry;
    let red = 0;
    let green = 0;
    let blue = 0;
    for (let channel = 0; channel < 5; channel += 1) {
      const concentration = concentrations[channel];
      red += concentration * CHANNEL_RGB[channel][0] / 255;
      green += concentration * CHANNEL_RGB[channel][1] / 255;
      blue += concentration * CHANNEL_RGB[channel][2] / 255;
    }
    const highway = Math.min(food, home);
    const core = highway * highway;
    const edge = highway * (1 - Math.min(1, highway)) * 2.4;
    red += core * 1.25;
    green += core * 1.25 + edge * 0.55;
    blue += core * 1.25 + edge * 0.72;
    const coral = Math.min(food, scout) * 0.9;
    red += coral * 0.85;
    green += coral * 0.26;
    blue += coral * 0.2;
    const escape = Math.min(home, alarm) * 1.15;
    red += escape * 0.9;
    blue += escape * 0.95;
    const hazard = Math.min(alarm, noEntry) * 1.1;
    red += hazard * 0.85;
    green += hazard * 0.65;
    blue -= hazard * 0.3;
    output[offset] = 255 * (1 - Math.exp(-gamma * Math.max(0, red)));
    output[offset + 1] = 255 * (1 - Math.exp(-gamma * Math.max(0, green)));
    output[offset + 2] = 255 * (1 - Math.exp(-gamma * Math.max(0, blue)));
    output[offset + 3] = Math.max(food, home, alarm, scout, noEntry) > 0.002 ? 255 : 0;
  }

  writeImageData(output: Uint8ClampedArray, gamma: number): void {
    for (let index = 0; index < this.length; index += 1) this.mixCell(index, output, index * 4, gamma);
  }

  clear(): void {
    for (let channel = 0; channel < 5; channel += 1) {
      this.channels[channel].fill(0);
      this.next[channel].fill(0);
    }
    this.resetActivityBounds();
  }
}
