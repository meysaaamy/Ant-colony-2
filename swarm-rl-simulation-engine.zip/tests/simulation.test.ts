import { describe, expect, it } from "vitest";
import { AntSoAEngine, createAntSoA, createInitialBrain, evaluateNeat } from "../lib/ant-soa-engine";
import { PheromoneGrid } from "../lib/pheromone-grid";
import { mulberry32, SimplexNoise2D, XorShift32 } from "../lib/prng-noise";
import { AntState, Caste, Cohort, MAX_ANTS, Pheromone } from "../lib/types";

const settings = { evaporation: 0.05, diffusion: 0.1, crossReaction: 1, gamma: 1.65 };

describe("deterministic random and noise", () => {
  it("reproduces Mulberry32 and XorShift sequences", () => {
    const a = mulberry32(42);
    const b = mulberry32(42);
    const x = new XorShift32(42);
    const y = new XorShift32(42);
    for (let index = 0; index < 20; index += 1) {
      expect(a()).toBe(b());
      expect(x.nextUint()).toBe(y.nextUint());
    }
  });

  it("produces bounded deterministic simplex noise", () => {
    const a = new SimplexNoise2D(12);
    const b = new SimplexNoise2D(12);
    const value = a.fbm(3.2, 7.1);
    expect(value).toBe(b.fbm(3.2, 7.1));
    expect(Math.abs(value)).toBeLessThanOrEqual(1);
  });
});

describe("SoA and shared NEAT brain", () => {
  it("preallocates all 3,000-ant typed buffers", () => {
    const ants = createAntSoA();
    expect(ants.x).toBeInstanceOf(Float32Array);
    expect(ants.x.length).toBe(MAX_ANTS);
    expect(ants.memA.length).toBe(MAX_ANTS);
    expect(ants.state).toBeInstanceOf(Uint8Array);
    expect(ants.generation).toBeInstanceOf(Uint16Array);
    expect(ants.targetIndex).toBeInstanceOf(Int32Array);
  });

  it("performs a finite recurrent-network forward pass", () => {
    const brain = createInitialBrain();
    const inputs = new Float32Array(14).map((_, index) => Math.sin(index));
    const outputs = new Float32Array(4);
    const scratch = new Float32Array(48);
    evaluateNeat(brain, inputs, outputs, scratch);
    expect([...outputs].every(Number.isFinite)).toBe(true);
    expect(outputs[1]).toBeGreaterThanOrEqual(0);
    expect(outputs[1]).toBeLessThanOrEqual(1);
    expect(outputs.some((value) => Math.abs(value) > 0)).toBe(true);
  });

  it("alternates competing cohorts in the same SoA world", () => {
    const engine = new AntSoAEngine();
    engine.setComparison("random");
    expect(engine.ants.cohort[0]).toBe(Cohort.TRAINED_NEAT);
    expect(engine.ants.cohort[1]).toBe(Cohort.RANDOM_NET);
    engine.setComparison("aco");
    expect(engine.ants.cohort[1]).toBe(Cohort.BASELINE_ACO);
  });
});

describe("five-channel reaction diffusion", () => {
  it("saturates deposition and gates sensory ablation", () => {
    const grid = new PheromoneGrid(60, 60);
    grid.deposit(30, 30, Pheromone.foodTrail, 250, 8);
    expect(grid.sample(30, 30, Pheromone.foodTrail)).toBeLessThanOrEqual(100);
    expect(grid.sample(30, 30, Pheromone.foodTrail)).toBeGreaterThan(0);
    grid.setAblation("foodTrail", false);
    expect(grid.sample(30, 30, Pheromone.foodTrail)).toBe(0);
    expect(grid.sample(30, 30, Pheromone.foodTrail, false)).toBeGreaterThan(0);
  });

  it("mixes amber and cyan into a luminous pearl core", () => {
    const grid = new PheromoneGrid(6, 6);
    const amberOnly = new Uint8ClampedArray(4);
    const mixed = new Uint8ClampedArray(4);
    grid.channels[Pheromone.foodTrail][0] = 70;
    grid.mixCell(0, amberOnly, 0);
    grid.channels[Pheromone.homeGuide][0] = 70;
    grid.mixCell(0, mixed, 0);
    expect(mixed[0]).toBeGreaterThan(amberOnly[0]);
    expect(mixed[1]).toBeGreaterThan(150);
    expect(mixed[2]).toBeGreaterThan(150);
  });

  it("enforces zero-flux walls", () => {
    const grid = new PheromoneGrid(60, 60);
    const walls = new Uint8Array(grid.length);
    const wall = grid.index(5, 5);
    walls[wall] = 1;
    grid.setWalls(walls);
    grid.deposit(24, 30, Pheromone.foodTrail, 100, 4);
    grid.step(1 / 60, settings);
    expect(grid.channels[Pheromone.foodTrail][wall]).toBe(0);
    expect(grid.channels[Pheromone.foodTrail][grid.index(4, 5)]).toBeGreaterThan(0);
  });

  it("dissolves food trail with viridian and decays alarm faster", () => {
    const grid = new PheromoneGrid(6, 6);
    grid.setCell(0, 0, Pheromone.foodTrail, 80);
    grid.setCell(0, 0, Pheromone.alarm, 80);
    grid.setCell(0, 0, Pheromone.noEntry, 40);
    grid.step(1, { ...settings, diffusion: 0 });
    expect(grid.channels[Pheromone.foodTrail][0]).toBeLessThan(60);
    expect(grid.channels[Pheromone.alarm][0]).toBeLessThan(70);
  });

  it("lays a continuous Catmull-Rom stroke", () => {
    const grid = new PheromoneGrid(240, 120);
    grid.strokeCatmullRom(10, 60, 20, 50, 150, 20, 220, 70, Pheromone.scoutPulse, 35, 12);
    expect(grid.sample(80, 34, Pheromone.scoutPulse)).toBeGreaterThan(0);
    expect(grid.sample(140, 22, Pheromone.scoutPulse)).toBeGreaterThan(0);
  });
});

describe("mortality, generations, and predators", () => {
  it("forages and delivers real food during headless fast-forward", () => {
    const engine = new AntSoAEngine();
    engine.runTurboBatch(900);
    expect(engine.totalFood).toBeGreaterThan(0);
    expect(engine.trainedFood).toBe(engine.totalFood);
    expect(engine.generation).toBeGreaterThan(1);
  });

  it("turns ATP exhaustion into death, corpse, and alarm", () => {
    const engine = new AntSoAEngine();
    engine.ants.active.fill(0);
    engine.ants.active[0] = 1;
    engine.ants.x[0] = 360;
    engine.ants.y[0] = 900;
    engine.ants.energy[0] = 0;
    engine.ants.age[0] = 1;
    engine.ants.maxLifespan[0] = 100;
    engine.step();
    expect(engine.totalDeaths).toBe(1);
    expect(engine.ants.state[0]).toBe(AntState.DEAD);
    expect(engine.corpses.some((corpse) => corpse.active)).toBe(true);
    expect(engine.grid.sample(360, 900, Pheromone.alarm, false)).toBeGreaterThan(0);
  });

  it("makes wardens defend and damage a nearby stalker", () => {
    const engine = new AntSoAEngine();
    engine.ants.active.fill(0);
    engine.ants.active[0] = 1;
    engine.ants.x[0] = 360;
    engine.ants.y[0] = 850;
    engine.ants.caste[0] = Caste.WARDEN;
    engine.ants.energy[0] = 100;
    engine.ants.age[0] = 0;
    engine.ants.maxLifespan[0] = 200;
    engine.spawnPredator(360, 850);
    const hp = engine.predators.find((predator) => predator.active)?.hp ?? 0;
    engine.step();
    expect(engine.ants.state[0]).toBe(AntState.DEFENDING);
    expect(engine.predators[0].hp).toBeLessThan(hp);
    expect(engine.grid.sample(360, 850, Pheromone.alarm, false)).toBeGreaterThan(0);
  });

  it("changes homeward steering when vector memory is ablated", () => {
    const intact = new AntSoAEngine();
    const ablated = new AntSoAEngine();
    for (const engine of [intact, ablated]) {
      engine.ants.active.fill(0);
      engine.ants.active[0] = 1;
      engine.ants.x[0] = 360;
      engine.ants.y[0] = 900;
      engine.ants.homeDx[0] = 0;
      engine.ants.homeDy[0] = 120;
      engine.ants.angle[0] = 0;
      engine.ants.state[0] = AntState.RETURNING;
      engine.ants.carryingFood[0] = 1;
      engine.ants.energy[0] = 100;
      engine.ants.age[0] = 0;
      engine.ants.maxLifespan[0] = 200;
    }
    ablated.grid.setAblation("pathIntegration", false);
    intact.step();
    ablated.step();
    expect(ablated.ants.angle[0]).not.toBe(intact.ants.angle[0]);
  });

  it("records a generation and advances the shared genome", () => {
    const engine = new AntSoAEngine();
    engine.foodThisGeneration = 71;
    engine.forceGenerationForTest();
    expect(engine.generation).toBe(2);
    expect(engine.brain.generation).toBe(2);
    expect(engine.learning.at(-1)?.neat).toBe(71);
    expect(engine.learning.at(-1)?.aco).toBeGreaterThan(0);
  });
});
