# Prismara — NEAT Ant Sanctuary

A deterministic, full-screen computational entomology sandbox built with Next.js App Router, strict TypeScript, Canvas 2D, and Tailwind CSS. No ant follows a global route plan. Five chemical fields, local sensors, a shared recurrent NEAT genome, and energy-constrained social behaviors produce the visible colony.

## Run

```bash
npm install
npm run dev
```

Production and scientific checks:

```bash
npx vitest run
npx next typegen
npm exec tsc -- --noEmit
npm run build
```

`GET /api/health` verifies the 3,000-ant SoA layout, NEAT forward pass, five-channel RGB mixer, sensory ablation, and zero-flux wall chemistry.

## Controls

- Drag on the world to deposit the selected pheromone, place crystals, or carve basalt.
- Keys `1` through `6` select Food, Home, Alarm, Crystal, Wall, and Eraser.
- `Space` pauses or resumes. `[` and `]` change brush radius. `Esc` closes the guide or collapses the sheet.
- The contextual dock selects violet scout pulse, viridian no-entry, and predator placement in addition to the three primary chemical brushes.
- The Proof Lab runs +10 or +25 real headless generations, starts 50/50 A/B arenas, ablates sensors, and exposes the current genome topology.

Settings are persisted in guarded `localStorage`. A hidden tab automatically pauses visual simulation. Resize is DPR-capped and deferred by 150 ms without resetting world state.

## Implementation notes

- Fixed world: 720 × 1280; fixed simulation step: 1/60 s.
- Five independent `Float32Array` ping-pong concentration buffers at 6 px resolution.
- Zero-flux Neumann wall sampling, CFL-limited diffusion, accelerated alarm decay, polymer decay protection, and viridian/amber dissolution.
- `MAX_ANTS = 3000` typed SoA arrays and an `Int32Array` spatial hash at 24 px resolution.
- Shared 14-input / 4-output NEAT brain with innovation-numbered topology mutation, behavioral hyper-genes, hall-of-fame crossover, and recurrent state.
- Mortality, necrophoresis, trophallaxis, tandem running, depleted-site sealing, births, generational waves, founder bottlenecks, and six optional predators.
- Ten compositor stages with no runtime blur filters or shadow blur. Bloom is quarter-resolution bilinear light transport. Adaptive quality sheds bloom and halves diffusion frequency while preserving every ant and physics tick.

The ACO curve is a deterministic hand-crafted reference when ACO is not active. In A/B ACO mode, actual ACO deliveries replace that reference. Random and ACO cohorts inhabit the same world and use the same metabolism, sensors, embodiment, food, and threats as trained ants.
